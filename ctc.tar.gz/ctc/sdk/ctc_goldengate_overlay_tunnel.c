/**
 @file ctc_goldengate_overlay_tunnel.c

 @date 2011-11-07

 @version v2.0


*/
/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctc_const.h"
#include "ctc_error.h"

#include "ctc_overlay_tunnel.h"
#include "sys_goldengate_overlay_tunnel.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
/****************************************************************************
 *
* Function
*
*****************************************************************************/

int32
ctc_goldengate_overlay_tunnel_init(uint8 lchip, void* overlay_tunnel_global_cfg)
{
    ctc_overlay_tunnel_global_cfg_t global_cfg;

    if (NULL == overlay_tunnel_global_cfg)
    {
        sal_memset(&global_cfg, 0, sizeof(ctc_overlay_tunnel_global_cfg_t));
    }
    else
    {
        sal_memcpy(&global_cfg, overlay_tunnel_global_cfg, sizeof(ctc_overlay_tunnel_global_cfg_t));
    }

    return sys_goldengate_overlay_tunnel_init(lchip, &global_cfg);
}

int32
ctc_goldengate_overlay_tunnel_set_fid(uint8 lchip, uint32 vn_id, uint16 fid )
{
    return sys_goldengate_overlay_tunnel_set_fid (lchip, vn_id,fid );
}

int32
ctc_goldengate_overlay_tunnel_get_fid(uint8 lchip, uint32 vn_id, uint16* p_fid )
{
    return sys_goldengate_overlay_tunnel_get_fid (lchip,  vn_id, p_fid );
}


int32
ctc_goldengate_overlay_tunnel_add_tunnel(uint8 lchip, ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    return sys_goldengate_overlay_tunnel_add_tunnel(lchip,  p_tunnel_param );
}

int32
ctc_goldengate_overlay_tunnel_remove_tunnel(uint8 lchip, ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    return sys_goldengate_overlay_tunnel_remove_tunnel(lchip,  p_tunnel_param );
}

int32
ctc_goldengate_overlay_tunnel_update_tunnel(uint8 lchip, ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    return sys_goldengate_overlay_tunnel_update_tunnel(lchip,  p_tunnel_param );
}

