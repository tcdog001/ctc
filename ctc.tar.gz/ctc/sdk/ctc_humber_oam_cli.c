/**
 @file ctc_oam_cli.c

 @date 2010-03-23

 @version v2.0

 This file defines functions for oam cli module

*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_humber_oam_cli.h"
#include "ctc_api.h"
#include "ctc_oam.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_port_mapping_cli.h"

#define OAM_NEW_API_DEBUG 0

#define CTC_CLI_OAM_CFM_DIRECTION_DESC "MEP direction"
#define CTC_CLI_OAM_CFM_DIRECTION_UP_DESC "Up MEP"
#define CTC_CLI_OAM_CFM_DIRECTION_DOWN_DESC "Down MEP"
#define CTC_CLI_OAM_LINK_OAM_DESC "Is link level oam"

#define CTC_CLI_OAM_CFM_DUMP_DESC "Dump registers or tables"

ctc_oam_key_t* p_chan_key = NULL;

/**
 @brief   debug functions for oam tables
*/
extern int32
sys_humber_oam_cfm_dump_maid(uint8 lchip, uint32 maid_index);
extern int32
sys_humber_oam_cfm_dump_key_and_chan(uint8 lchip, uint32 key_index, uint32 key_type);
extern int32
sys_humber_oam_cfm_dump_ma(uint8 lchip, uint32 ma_index);
extern int32
sys_humber_oam_cfm_dump_lmep(uint8 lchip, uint32 lmep_index);
extern int32
sys_humber_oam_cfm_dump_rmep(uint8 lchip, uint32 rmep_index);
extern int32
sys_humber_oam_cfm_dump_rmep_key_and_chan(uint8 lchip, uint32 key_index, uint32 key_type);

#define SYS_OAM_CCM_TIMER   1000  /*1s*/

static sal_timer_t* sys_cfm_ccm_timer = NULL;
static sal_timer_t* sys_cfm_error_cache_timer = NULL;

#if (SDK_WORK_ENV == 1) && (SDK_WORK_PLATFORM == 1)
/* mep tx related clis */
extern int32 oam_update_fsm(uint32 chip_id, uint32 min_ptr, uint32 max_ptr);
#endif

/**
 @brief oam engine ccm timer simulation

 @param[int] arg         point to argument function

 @return CTC_E_XXX

*/
static void
ctc_oam_cfm_ccm_while_timer_handler(void* arg)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;

    ctc_get_local_chip_num(&lchip_num);
    sal_timer_stop(sys_cfm_ccm_timer);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {

#if (SDK_WORK_ENV == 1) && (SDK_WORK_PLATFORM == 1)
        oam_update_fsm(lchip, 2, 2046);
#endif

    }

    sal_timer_start(sys_cfm_ccm_timer, 250);
}

extern int32
sys_humber_oam_report_error_cache(void);
extern int32
sys_humber_show_oam_cfm_brief(void);
extern int32
sys_oam_cfm_show_chan_index(ctc_oam_key_t* oam_key);

/**
 @brief error cache timer simulation

 @param[int] arg         point to argument function

 @return CTC_E_XXX

*/
static void
ctc_oam_cfm_error_cache_timer_handler(void* arg)
{
    sal_timer_stop(sys_cfm_error_cache_timer);
    sys_humber_oam_report_error_cache();
    sal_timer_start(sys_cfm_error_cache_timer, 1000);
}

/**
 @brief enable/disable of error cache timer

 @param[int] enable      enable/disable error cache timer

 @return CTC_E_XXX

*/
int32
ctc_oam_cfm_run_error_cache_timer(bool enable)
{
    int ret = 0;

    if (enable == TRUE)
    {
        if (!sys_cfm_error_cache_timer)
        {
            ret = sal_timer_create(&sys_cfm_error_cache_timer, ctc_oam_cfm_error_cache_timer_handler, NULL);
            if (0 != ret)
            {
                ctc_cli_out("sal_timer_create failed  0x%x\n", ret);
                return CTC_E_NOT_INIT;
            }
        }

        sal_timer_start(sys_cfm_error_cache_timer, 1000);
    }
    else
    {
        if (sys_cfm_error_cache_timer)
        {
            sal_timer_stop(sys_cfm_error_cache_timer);
            sal_timer_destroy(sys_cfm_error_cache_timer);
            sys_cfm_error_cache_timer = NULL;
        }
    }

    return CTC_E_NONE;
}

/**
 @brief enable/disable of oam engine ccm timer

 @param[int] enable      enable/disable oam engine ccm timer

 @return CTC_E_XXX

*/
uint32
ctc_oam_cfm_run_ccm(bool enable)
{
    int ret = 0;

    if (enable == TRUE)
    {
        if (!sys_cfm_ccm_timer)
        {
            ret = sal_timer_create(&sys_cfm_ccm_timer, &ctc_oam_cfm_ccm_while_timer_handler, NULL);
            if (0 != ret)
            {
                ctc_cli_out("sal_timer_create failed  0x%x\n", ret);
                return CTC_E_NOT_INIT;
            }
        }

        sal_timer_start(sys_cfm_ccm_timer, 1000);
    }
    else
    {
        if (sys_cfm_ccm_timer)
        {
            sal_timer_stop(sys_cfm_ccm_timer);
            sal_timer_destroy(sys_cfm_ccm_timer);
            sys_cfm_ccm_timer = NULL;
        }
    }

    return CTC_E_NONE;

}

/*********************************************************************
* Internal debug clis
*********************************************************************/
/**
 @brief  debug functions
*/
CTC_CLI(ctc_cli_hb_oam_cfm_dump_maid,
        ctc_cli_hb_oam_cfm_dump_maid_cmd,
        "oam cfm dump maid local-chipid CHIP_ID maid-index MAID_INDEX",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "MAID table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "MAID table index",
        "<0- max 1023 for 16bytes, 340 for 48byts>")
{
    int32  ret   = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("maid table index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_maid(lchip, index);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

/**
 @brief  debug functions
*/
CTC_CLI(ctc_cli_hb_oam_cfm_dump_key_and_chan,
        ctc_cli_hb_oam_cfm_dump_key_and_chan_cmd,
        "oam cfm dump lookup-chan local-chipid CHIP_ID key-index KEY_INDEX key-type KEY_TYPE",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "Lookup channel key and associate table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "Key index",
        "<0-2047 for hash, 0-255 for tcam>",
        "Key type",
        "0 for hash, 1 for tcam")
{
    int32  ret   = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;
    uint32 key_type = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Chan key index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Chan key type", key_type, argv[2], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_key_and_chan(lchip, index, key_type);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_oam_cfm_dump_ma,
        ctc_cli_hb_oam_cfm_dump_ma_cmd,
        "oam cfm dump ma local-chipid CHIP_ID ma-index MA_INDEX",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "MA table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "MA table index",
        "<0-2047>")
{
    int32  ret   = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("ma table index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_ma(lchip, index);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_oam_cfm_dump_lmep,
        ctc_cli_hb_oam_cfm_dump_lmep_cmd,
        "oam cfm dump lmep local-chipid CHIP_ID lmep-index MEP_INDEX",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "Local MEP table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "Local MEP table index",
        "<0-2047>")
{
    int32   ret  = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Mep table index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_lmep(lchip, index);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_oam_cfm_dump_rmep,
        ctc_cli_hb_oam_cfm_dump_rmep_cmd,
        "oam cfm dump rmep local-chipid CHIP_ID rmep-index MEP_INDEX",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "Remote MEP table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "Remote MEP table index",
        "<0-2047>")
{
    int32   ret  = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("RMep table index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_rmep(lchip, index);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_oam_cfm_dump_rmep_key_and_chan,
        ctc_cli_hb_oam_cfm_dump_rmep_key_and_chan_cmd,
        "oam cfm dump rmep-key-chan local-chipid CHIP_ID key-index KEY_INDEX key-type KEY_TYPE",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        CTC_CLI_OAM_CFM_DUMP_DESC,
        "Lookup channel key and associate table",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "Key index",
        "<0-2047 for hash, 0-255 for tcam>",
        "Key type",
        "0 for hash, 1 for tcam")
{
    int32  ret   = CLI_SUCCESS;
    uint32 index = 0;
    uint8  lchip = 0;
    uint32 key_type = 0;

    CTC_CLI_GET_UINT8_RANGE("local chip id", lchip, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Rmep chan key index", index, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Rmep key type", key_type, argv[2], 0, CTC_MAX_UINT32_VALUE);

    ret = sys_humber_oam_cfm_dump_rmep_key_and_chan(lchip, index, key_type);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

#if (SDK_WORK_ENV == 1) && (SDK_WORK_PLATFORM == 1)

CTC_CLI(ctc_cli_hb_oam_cfm_update_fsm,
        cli_oam_cfm_update_fs_cmd,
        "oam cfm update-mep local-chipid CHIP_ID mep-index MIN_MEP_INDEX MAX_MEP_INDEX",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "Update MEP",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "MEP index",
        "Min MEP index <2-2047>",
        "Max MEP index <2-2047>")
{
    int32 ret = CLI_SUCCESS;
    uint32 chip_id = 0;
    uint32 min_mep_index = 0;
    uint32 max_mep_index = 0;

    CTC_CLI_GET_UINT32_RANGE("Local chip id", chip_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Min MEP index", min_mep_index, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Max MEP index", max_mep_index, argv[2], 0, CTC_MAX_UINT32_VALUE);

    ret = oam_update_fsm(chip_id, min_mep_index, max_mep_index);

    if (ret < 0)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32 oam_tx_pkt(uint32 chip_id, bool bdi_tx, uint32 mep_idx, uint32 rmep_idx, uint32 ma_index);
CTC_CLI(ctc_cli_hb_oam_cfm_tx_pkt,
        ctc_cli_hb_oam_cfm_tx_pkt_cmd,
        "oam cfm tx local-chipid CHIP_ID mep-index MEP_INDEX rmep-index RMEP_INDEX ma-index MA_INDEX (is-bdi-tx|)",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "Tx OAM pkt",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC,
        "MEP index",
        "<2-2047>",
        "RMEP index",
        "<2-2047>",
        "MA index",
        "<0-2047>",
        "Is bid tx")
{
    int32 ret = CLI_SUCCESS;
    uint32 chip_id  = 0;
    bool   bdi_tx   = 0;
    uint32 mep_idx  = 0;
    uint32 rmep_idx = 0;
    uint32 ma_idx   = 0;
    uint8  index    = 0xff;

    CTC_CLI_GET_UINT32_RANGE("Local chip id", chip_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Mep index", mep_idx, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Rmep index", rmep_idx, argv[2], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("Ma index", ma_idx, argv[3], 0, CTC_MAX_UINT32_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("is-bdi-tx");
    if (index != 0xff)
    {
        bdi_tx = TRUE;
    }
    else
    {
        bdi_tx = FALSE;
    }

    ret = oam_tx_pkt(chip_id, bdi_tx, mep_idx, rmep_idx, ma_idx);

    if (ret < 0)
    {
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_oam_cfm_update_timer_enable,
        ctc_cli_hb_oam_cfm_update_timer_enable_cmd,
        "oam cfm update-timer (enable| disable)",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "OAM update timer",
        "Enable update timer",
        "Disable update timer")
{
    int32 ret = CLI_SUCCESS;
    bool enable = FALSE;

    if (0 == sal_memcmp(argv[0], "e", 1))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

    ret = ctc_oam_cfm_run_ccm(enable);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}
#endif

CTC_CLI(ctc_cli_hb_oam_cfm_show_chan_index,
        ctc_cli_hb_oam_cfm_show_chan_index_cmd,
        "show oam cfm lookup-chan gport GPORT_ID direction (up |down ) (link-oam |) (vlan VLAN_ID|)",
        "Show OAM information",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "OAM look-up channel",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_OAM_CFM_DIRECTION_DESC,
        CTC_CLI_OAM_CFM_DIRECTION_UP_DESC,
        CTC_CLI_OAM_CFM_DIRECTION_DOWN_DESC,
        CTC_CLI_OAM_LINK_OAM_DESC,
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC)
{
    int32 ret   = CLI_SUCCESS;
    uint8 index = 0xff;
    ctc_oam_key_t oam_key;

    sal_memset(&oam_key, 0, sizeof(ctc_oam_key_t));

    CTC_CLI_GET_UINT16_RANGE("gport", oam_key.u.eth.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);
    if (0 == sal_memcmp(argv[1], "u", 1))
    {
        CTC_SET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }
    else
    {
        CTC_UNSET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }

    index = CTC_CLI_GET_ARGC_INDEX("link-oam");
    if (index != 0xff)
    {
        CTC_SET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan");
    if (index != 0xff)
    {
        CTC_CLI_GET_UINT16_RANGE("VLAN ID", oam_key.u.eth.vlan_id, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    ret = sys_oam_cfm_show_chan_index(&oam_key);
    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_oam_cfm_show_brief,
        ctc_cli_hb_oam_cfm_show_brief_cmd,
        "show oam cfm brief",
        "Show OAM information",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "OAM brief information")
{
    int32 ret   = CLI_SUCCESS;

    ret = sys_humber_show_oam_cfm_brief();
    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_oam_cfm_update_error_cache_timer_enable,
        ctc_cli_hb_oam_cfm_update_error_cache_timer_enable_cmd,
        "oam cfm error-cache-timer (enable| disable)",
        CTC_CLI_OAM_M_STR,
        CTC_CLI_OAM_CFM_M_STR,
        "OAM error cache timer",
        "Enable timer",
        "Disable timer")
{
    int32 ret = CLI_SUCCESS;
    bool enable = FALSE;

    if (0 == sal_memcmp(argv[0], "e", 1))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

    ret = ctc_oam_cfm_run_error_cache_timer(enable);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

/**
 @brief  Initialize sdk oam module CLIs
*/
int32
ctc_humber_oam_cli_init(void)
{
    /* debug functions */
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_show_chan_index_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_show_brief_cmd);

#if (SDK_WORK_ENV == 1) && (SDK_WORK_PLATFORM == 1)
    install_element(CTC_SDK_MODE, &cli_oam_cfm_update_fs_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_tx_pkt_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_update_timer_enable_cmd);
#endif

#ifdef SDK_INTERNAL_CLI_SHOW
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_maid_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_key_and_chan_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_ma_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_lmep_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_rmep_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_update_error_cache_timer_enable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_oam_cfm_dump_rmep_key_and_chan_cmd);

#endif

    return 0;
}

