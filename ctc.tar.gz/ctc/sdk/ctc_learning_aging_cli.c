/**
 @file ctc_learning_aging_cli.c

 @date 2010-3-1

 @version v2.0

*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"

#include "ctc_learning_aging_cli.h"
#include "ctc_api.h"
#include "ctc_learning_aging.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_linklist.h"
#include "ctc_port_mapping_cli.h"

uint16 logic_port_mapping_array[CTC_MAX_LOGIC_PORT_ID];
struct ctc_port_nhid_s
{
    ctc_slistnode_t head;
    uint16 port;
    uint16 fid;
    uint32 nh_id;
    uint8 port_is_vp;
};

typedef   struct ctc_port_nhid_s ctc_port_nhid_t;
ctc_slist_t* g_port_nhid_list = NULL;

CTC_CLI(ctc_cli_learning_aging_debug_on,
        ctc_cli_learning_aging_debug_on_cmd,
        "debug learning-aging (ctc | sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_LEARNING_AGING_STR,
        "Ctc layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = L2_LEARNING_AGING_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = L2_LEARNING_AGING_SYS;
    }

    ctc_debug_set_flag("l2", "learning_aging", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_learning_aging_debug_off,
        ctc_cli_learning_aging_debug_off_cmd,
        "no debug learning-aging (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_LEARNING_AGING_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = L2_LEARNING_AGING_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = L2_LEARNING_AGING_SYS;
    }

    ctc_debug_set_flag("l2", "learning_aging", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_learning_aging_show_debug,
        ctc_cli_learning_aging_show_debug_cmd,
        "show debug learning-aging (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_LEARNING_AGING_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = L2_LEARNING_AGING_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = L2_LEARNING_AGING_SYS;
    }

    ctc_cli_out("learning_aging:%s debug %s\n", argv[0],
                (ctc_debug_get_flag("l2", "learning_aging", typeenum, &level) == TRUE) ? "on" : "off", ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

/******************
 Learning CLI CMD
******************/
CTC_CLI(ctc_cli_learning_aging_set_learning_action,
        ctc_cli_learning_aging_set_learning_action_cmd,
        "learning action (always-cpu|cache-full-to-cpu threshold THRESHOLD | cache-only  threshold THRESHOLD |dont-learn |(mac-table-full (enable|disable)))",
        CTC_CLI_LEARNING_STR,
        "Learning action",
        "Learning action always cpu",
        "Learning action full to cpu",
        "Cache threshod",
        CTC_CLI_LEARNING_CACHE_NUM,
        "Learning action cache only",
        "Cache threshod",
        CTC_CLI_LEARNING_CACHE_NUM,
        "Learning action dont learn",
        "Learning mac table full",
        "Learning mac table full enable",
        "Learning mac table full disable")
{
    ctc_learning_action_info_t learning_action;
    uint8 index = 0;
    int32 ret = 0;

    sal_memset(&learning_action, 0, sizeof(learning_action));
    if (0 == sal_memcmp("always-cpu", argv[0], 10))
    {
        learning_action.action = CTC_LEARNING_ACTION_ALWAYS_CPU;
    }
    else if (0 == sal_memcmp("cache-full-to-cpu", argv[0], 17))
    {
        learning_action.action = CTC_LEARNING_ACTION_CACHE_FULL_TO_CPU;
    }
    else if (0 == sal_memcmp("cache-only", argv[0], 10))
    {
        learning_action.action = CTC_LEARNING_ACTION_CACHE_ONLY;
    }
    else if (0 == sal_memcmp("dont-learn", argv[0], 10))
    {
        learning_action.action = CTC_LEARNING_ACTION_DONLEARNING;
    }

    index = CTC_CLI_GET_ARGC_INDEX("threshold");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8_RANGE("threshold", learning_action.value, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-table-full");
    if (0xFF != index)
    {
        learning_action.action = CTC_LEARNING_ACTION_MAC_TABLE_FULL;
        index = CTC_CLI_GET_ARGC_INDEX("enable");
        if (0xFF != index)
        {
            learning_action.value = 1;
        }
        else
        {
            learning_action.value = 0;
        }
    }

    ret = ctc_set_learning_action(&learning_action);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

/******************
 Learning CLI CMD
******************/
int32
ctc_get_nhid_by_port_fid(uint16 port, uint16 fid, uint8 port_is_vp, uint32* nh_id)
{

    ctc_slistnode_t* lisnode = NULL;
    ctc_port_nhid_t* p_vpls_nhid = NULL;

    *nh_id = CTC_MAX_UINT32_VALUE;

    if (CTC_SLISTCOUNT(g_port_nhid_list) == 0)
    {
        return CTC_E_INVALID_PARAM;
    }

    CTC_SLIST_LOOP(g_port_nhid_list, lisnode)
    {
        p_vpls_nhid = _ctc_container_of(lisnode, ctc_port_nhid_t, head);

        if (p_vpls_nhid && p_vpls_nhid->fid == fid && p_vpls_nhid->port_is_vp == port_is_vp
            && p_vpls_nhid->port == port && p_vpls_nhid->nh_id != CTC_MAX_UINT32_VALUE)

        {
            *nh_id = p_vpls_nhid->nh_id;
            return CTC_E_NONE;
        }
    }
    return CTC_E_NH_NOT_EXIST;
}

/******************
 Learning CLI CMD
******************/
int32
ctc_get_nhid_by_logic_port(uint16 logic_port, uint32* nh_id)
{
    ctc_port_nhid_t* p_vpls_nhid = NULL;
    ctc_slistnode_t* lisnode = NULL;

    if (!g_port_nhid_list)
    {
        ctc_cli_out(" List is NULL \n");
        return CLI_SUCCESS;
    }

    /*update nh_id*/
    CTC_SLIST_LOOP(g_port_nhid_list, lisnode)
    {
        p_vpls_nhid = _ctc_container_of(lisnode, ctc_port_nhid_t, head);
        if (p_vpls_nhid->port == logic_port)
        {
            *nh_id = p_vpls_nhid->nh_id;
            return CLI_SUCCESS;
        }
    }
    return CTC_E_NH_NOT_EXIST;
}

CTC_CLI(ctc_cli_learning_aging_logic_port_mapping_srcport,
        ctc_cli_learning_aging_logic_port_mapping_srcport_cmd,
        "learning virtual-port PORT mapping port GPORT_ID ",
        CTC_CLI_LEARNING_STR,
        "Logic port",
        "0-2240",
        "Logic port mapping",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC)
{
    uint32 logic_port = 0;
    uint32 gport = 0;

    CTC_CLI_GET_UINT16_RANGE("logic-port ", logic_port, argv[0], 0, 0x1FFF);
    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[1], 0, 0x1F7F);

    logic_port_mapping_array[logic_port] = gport;

    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_learning_aging_remove_port_nhid_mapping,
        ctc_cli_learning_aging_remove_port_nhid_mapping_cmd,
        "learning port-nhid remove (port GPORT_ID | logic-port VPLS_PORT_ID) fid FID",
        CTC_CLI_LEARNING_STR,
        "Port to nexthop mapping",
        "Remove Port to nexthop mapping",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC,
        "Vpls port",
        "<0-8191>",
        CTC_CLI_FID_DESC,
        CTC_CLI_FID_ID_DESC)
{
    ctc_port_nhid_t* p_vpls_nhid = NULL;
    ctc_slistnode_t* lisnode = NULL;
    uint16 port = 0;
    uint16 fid = 0;
    uint8 is_vpls = 0;
    uint8 node_exist = 0;

    if (0 == sal_memcmp("port", argv[0], 4))
    {
        CTC_CLI_GET_UINT16_RANGE("gport", port, argv[1], 0, CTC_MAX_LOGIC_PORT_ID);
    }
    else
    {
        CTC_CLI_GET_UINT16_RANGE("logic-port", port, argv[1], 0, CTC_MAX_UINT16_VALUE);
        is_vpls = 1;
    }

    CTC_CLI_GET_UINT16_RANGE("fid", fid, argv[2], 0, CTC_MAX_FID_ID);

    /*update nh_id*/
    CTC_SLIST_LOOP(g_port_nhid_list, lisnode)
    {
        p_vpls_nhid = _ctc_container_of(lisnode, ctc_port_nhid_t, head);
        if (p_vpls_nhid->port == port && p_vpls_nhid->fid == fid && p_vpls_nhid->port_is_vp == is_vpls)
        {
            node_exist = 1;
            break;
        }
    }

    if (node_exist)
    {

        ctc_slist_delete_node(g_port_nhid_list, &p_vpls_nhid->head);
        mem_free(p_vpls_nhid);
    }
    else
    {
        ctc_cli_out("Not found this mapping\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_learning_aging_show_logic_port_mapping,
        ctc_cli_learning_aging_show_logic_port_mapping_srcport_cmd,
        "show learning virtual-port PORT ",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LEARNING_STR,
        "Virtual port(VPLS  port)",
        "0-0x1FFF")
{
    uint32 logic_port = 0;

    CTC_CLI_GET_UINT16_RANGE("logic-port ", logic_port, argv[0], 0, CTC_MAX_LOGIC_PORT_ID);

    CTC_PORT_UNMAPPING(logic_port_mapping_array[logic_port]);
    ctc_cli_out("virtual-port %u --- gport 0x%04X \n", logic_port, logic_port_mapping_array[logic_port]);
    CTC_PORT_MAPPING(logic_port_mapping_array[logic_port], TRUE);
    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_learning_aging_show_port_nhid,
        ctc_cli_learning_aging_show_port_nhid_cmd,
        "show learning port-nhid mapping",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LEARNING_STR,
        "Port to nexthop mapping",
        "Port to nexthop mapping")
{

    ctc_slistnode_t* lisnode = NULL;
    ctc_port_nhid_t* p_vpls_nhid = NULL;
    char is_vpls[2] = {'N', 'Y'};

    if (CTC_SLISTCOUNT(g_port_nhid_list) == 0)
    {
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-9s%-9s%-9s%-9s\n", "Fid", "Port", "PW", "NH_ID");
    ctc_cli_out("--------------------------------------\n");
    CTC_SLIST_LOOP(g_port_nhid_list, lisnode)
    {
        p_vpls_nhid = _ctc_container_of(lisnode, ctc_port_nhid_t, head);
        CTC_PORT_UNMAPPING(p_vpls_nhid->port);
        ctc_cli_out("%9u0x%04X   %9c%9u\n", p_vpls_nhid->fid, p_vpls_nhid->port, is_vpls[p_vpls_nhid->port_is_vp], p_vpls_nhid->nh_id);
        if (!p_vpls_nhid->port_is_vp)
        {
            CTC_PORT_MAPPING(p_vpls_nhid->port, TRUE);
        }
    }

    return CLI_SUCCESS;

}

#if 0

/******************
 Aging CLI CMD
******************/
CTC_CLI(ctc_cli_learning_aging_get_aging_ptr,
        ctc_cli_learning_aging_get_aging_ptr_cmd,
        "show aging (ptr PTR|index INDEX)",
        "Show",
        CTC_CLI_AGING_STR,
        "aging_ptr",
        "Aging Ptr value",
        "Key index",
        "Key index value")
{
    uint32 aging_ptr = 0;
    uint32 key_index = 0;
    int32 ret = 0;
    uint8 i = 0;

    i = CTC_CLI_GET_ARGC_INDEX("ptr");
    if (0xFF != i)
    {
        CTC_CLI_GET_UINT32("Aging ptr", aging_ptr, argv[i + 1]);
        ret = sys_goldengate_aging_output_aging_status_by_ptr(0, SYS_AGING_DOMAIN_MAC_HASH, aging_ptr);
    }


    i = CTC_CLI_GET_ARGC_INDEX("index");
    if (0xFF != i)
    {
        CTC_CLI_GET_UINT32("Key index", key_index, argv[i + 1]);
        sys_goldengate_aging_index2ptr(SYS_AGING_DOMAIN_MAC_HASH,  key_index, &aging_ptr);
        ret = sys_goldengate_aging_output_aging_status_by_ptr(0, SYS_AGING_DOMAIN_MAC_HASH, aging_ptr);
    }


    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}
#endif

CTC_CLI(ctc_cli_learning_aging_set_aging_property,
        ctc_cli_learning_aging_set_aging_property_cmd,
        "aging ({fifo-threshold THRESHOLD} | { interval INTERVAL } | { fifo-scan (enable | disable) }|\
        {one-round (enable | disable)}) ((aging-tbl (mac|ipuc)) |)",
        CTC_CLI_AGING_STR,
        "Fifo threshold",
        "Threshold value <0-15>",
        "Aging interval",
        "Aging interval(unit: seconds)",
        "Aging fifo scan",
        "Open aging fifo scan",
        "Close aging fifo scan",
        "Scan one round",
        "Enable",
        "Disable",
        "Aging table",
        "MAC table",
        "IPUC table")
{
    ctc_aging_prop_t type = CTC_AGING_PROP_MAX;
    ctc_aging_table_type_t  tbl_type = CTC_AGING_TBL_MAC;
    uint32 value = 0;
    int32 ret = 0;

    uint32 index;

    /* set fifo threshold */
    index = CTC_CLI_GET_ARGC_INDEX("fifo-threshold");
    if (0xFF != index)
    {
        type = CTC_AGING_PROP_FIFO_THRESHOLD;
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("Fifo threshold", value, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    /* set aging interval */
    index = CTC_CLI_GET_ARGC_INDEX("interval");
    if (0xFF != index)
    {
        type = CTC_AGING_PROP_INTERVAL;
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT32_RANGE("Aging interval(unit: seconds)", value, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    /* set aging scan en */
    index = CTC_CLI_GET_ARGC_INDEX("fifo-scan");
    if (0xFF != index)
    {
        type = CTC_AGING_PROP_AGING_SCAN_EN;
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        if (0 == sal_memcmp("enable", argv[index + 1], 6))
        {
            value = 1;
        }
        else if (0 == sal_memcmp("disable", argv[index + 1], 7))
        {
            value = 0;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("one-round");
    if (0xFF != index)
    {
        type = CTC_AGING_PROP_STOP_SCAN_TIMER_EXPIRED;
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        if (CLI_CLI_STR_EQUAL("enable", (index + 1)))
        {
            value = 1;
        }
        else
        {
            value = 0;
        }
    }

    /* set aging table */
    index = CTC_CLI_GET_ARGC_INDEX("aging-tbl");
    if (0xFF != index)
    {
        if (0 == sal_memcmp("scl", argv[index + 1], 4))
        {
            tbl_type = CTC_AGING_TBL_SCL;
        }
        if (0 == sal_memcmp("ipuc", argv[index + 1], 4))
        {
            tbl_type = CTC_AGING_TBL_IPUC;
        }
    }

    ret = ctc_aging_set_property(tbl_type, type, value);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_learning_aging_show_config,
        ctc_cli_learning_aging_show_config_cmd,
        "show learning-aging config (aging-tbl (mac|scl) |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LEARNING_AGING_STR,
        "Config param",
        "Aging table",
        "MAC table",
        "SCL table")
{
    uint32 value32 = 0;
    uint8 value8 = 0;
    bool enable = TRUE;
    int32 ret = 0;

    ctc_learning_action_info_t learning_action;
    ctc_aging_table_type_t  tbl_type = CTC_AGING_TBL_MAC;
    uint32 index  = 0;

    ret = ctc_get_learning_action(&learning_action);

    switch (learning_action.action)
    {
    case CTC_LEARNING_ACTION_ALWAYS_CPU:
        ctc_cli_out("learning-action is : always cpu \n");
        break;

    case CTC_LEARNING_ACTION_CACHE_FULL_TO_CPU:
        ctc_cli_out("learning-action is : cache full to cpu \n");
        ctc_cli_out("learning-cache-threshold:%d \n", learning_action.value);
        break;

    case CTC_LEARNING_ACTION_CACHE_ONLY:
        ctc_cli_out("learning-action is : cache only \n");
        ctc_cli_out("learning-cache-threshold:%d \n", learning_action.value);
        break;

    case CTC_LEARNING_ACTION_DONLEARNING:
        ctc_cli_out("learning-action is : dont learn \n");
        break;

    default:
        break;
    }

    /* set aging table */
    index = CTC_CLI_GET_ARGC_INDEX("aging-tbl");
    if (0xFF != index)
    {
        if (0 == sal_memcmp("scl", argv[index + 1], 4))
        {
            tbl_type = CTC_AGING_TBL_SCL;
        }
    }

    ret = ctc_aging_get_property(tbl_type, CTC_AGING_PROP_FIFO_THRESHOLD, &value32);
    value8 = value32 & 0xFF;
    ctc_cli_out("fifo_threshold:%d \n", value8);

    ret = ctc_aging_get_property(tbl_type, CTC_AGING_PROP_INTERVAL, &value32);
    ctc_cli_out("aging_interval:%d \n", value32);

    ret = ctc_aging_get_property(tbl_type, CTC_AGING_PROP_STOP_SCAN_TIMER_EXPIRED, (uint32*)&enable);

    ctc_cli_out("stop_scan_timer_expired:%s \n", (enable == TRUE) ? "TRUE" : "FALSE");

    ret = ctc_aging_get_property(tbl_type, CTC_AGING_PROP_AGING_SCAN_EN, (uint32*)&enable);

    ctc_cli_out("aging_scan_en:%s\n", (enable == TRUE) ? "TRUE" : "FALSE");

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

int32
ctc_learning_aging_cli_init(void)
{
    uint16  logic_port = 0;

    for (logic_port = 0; logic_port < CTC_MAX_LOGIC_PORT_ID; logic_port++)
    {
        logic_port_mapping_array[logic_port] = 0xFFFF;
    }

    g_port_nhid_list = ctc_slist_new();
    /* Learning and aging module debug CLI */
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_debug_on_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_debug_off_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_show_debug_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_show_logic_port_mapping_srcport_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_show_port_nhid_cmd);
    /* Learning CLI */
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_set_learning_action_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_remove_port_nhid_mapping_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_logic_port_mapping_srcport_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_set_aging_property_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_learning_aging_show_config_cmd);
#if 0
    install_element(CTC_INTERNAL_MODE,  &ctc_cli_learning_aging_get_aging_ptr_cmd);
#endif

    return CLI_SUCCESS;
}

