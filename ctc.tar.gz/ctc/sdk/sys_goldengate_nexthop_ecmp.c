/**
 @file sys_goldengate_nexthop_ecmp.c

 @date 2009-12-23

 @version v2.0

 The file contains all ecmp related function
*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "ctc_const.h"
#include "ctc_error.h"
#include "sys_goldengate_opf.h"
#include "sys_goldengate_chip.h"
#include "sys_goldengate_nexthop_api.h"
#include "sys_goldengate_nexthop.h"
#include "sys_goldengate_nexthop_hw.h"
#include "sys_goldengate_l3if.h"
#include "drv_enum.h"
#include "drv_io.h"


#define SYS_ECMP_ALLOC_MEM_STEP  4

/****************************************************************************
*
* Global and Declaration
*
*****************************************************************************/
extern int32
sys_goldengate_stats_add_ecmp_stats(uint8 lchip, uint32 stats_id, uint16 ecmp_group_id);
extern int32
sys_goldengate_stats_remove_ecmp_stats(uint8 lchip, uint32 stats_id, uint16 ecmp_group_id);

int32
sys_goldengate_nh_update_ecmp_group(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb);
int32
sys_goldengate_nh_delete_ecmp_member(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb, sys_nh_info_com_t* p_nh_info);
int32
sys_goldengate_nh_add_ecmp_member(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb, sys_nh_info_com_t* p_nh_info);





int32
sys_goldengate_nh_update_xerspan_group(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb)
{
    uint8 index = 0;
    uint32 nhid = 0;
    sys_nh_info_com_t* p_nh_info = NULL;
    sys_nh_info_ip_tunnel_t* p_tunnel_nhdb = NULL;
    ds_t ds;
    sys_nexthop_t dsnh_8w;
    uint8 i = 0;
    uint16 hash_num = 0;
    uint16 mem_cnt = 0;
    uint32 dsnh_offset = 0;

    for (i = 7; i >= 1; i--)
    {
        if ((p_nhdb->valid_cnt <= (1 << i)) && (p_nhdb->valid_cnt > (1 << (i - 1))))
        {
            break;
        }
    }

    mem_cnt =  (p_nhdb->valid_cnt > 2)?((1 << i)):p_nhdb->valid_cnt ;
    hash_num = (p_nhdb->valid_cnt > 2)?i: ((p_nhdb->valid_cnt == 2)?1:0);


    for (index = 0 ; index < mem_cnt; index++)
    {
        i  = (index < p_nhdb->valid_cnt )?index:(index - p_nhdb->valid_cnt);
        nhid =  p_nhdb->nh_array[i];
        SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "Update nhid:%d\n", nhid);

        CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, nhid, (sys_nh_info_com_t**)&p_nh_info));

        p_tunnel_nhdb = (sys_nh_info_ip_tunnel_t *)p_nh_info;
        if (CTC_FLAG_ISSET(p_tunnel_nhdb->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_L2EDIT))
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_asic_table(lchip, SYS_NH_ENTRY_TYPE_L2EDIT_ETH_4W, p_tunnel_nhdb->dsl2edit_offset / 2, ds));
            if((p_tunnel_nhdb->dsl2edit_offset % 2) == 1)
            {
                sal_memcpy(ds, (uint8*)ds + sizeof(DsL2Edit3WOuter_m), sizeof(DsL2Edit3WOuter_m));
            }
            CTC_ERROR_RETURN(sys_goldengate_nh_set_asic_table(lchip, SYS_NH_ENTRY_TYPE_L2EDIT_6W, (p_nhdb->l2edit_offset_base + index*4) , ds));
            SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "l2edit_offset = read:  0x%x, write: 0x%x \n",  p_tunnel_nhdb->dsl2edit_offset, p_nhdb->l2edit_offset_base + index*4);
        }

        if (CTC_FLAG_ISSET(p_tunnel_nhdb->flag, SYS_NH_IP_TUNNEL_FLAG_IN_V6))
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_asic_table(lchip, SYS_NH_ENTRY_TYPE_L3EDIT_TUNNEL_V6, p_tunnel_nhdb->dsl3edit_offset, ds));
        }
        else
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_asic_table(lchip, SYS_NH_ENTRY_TYPE_L3EDIT_TUNNEL_V4, p_tunnel_nhdb->dsl3edit_offset, ds));
        }
        CTC_ERROR_RETURN(sys_goldengate_nh_set_asic_table(lchip, SYS_NH_ENTRY_TYPE_L3EDIT_TUNNEL_V6, p_nhdb->l3edit_offset_base + index*4, ds));
        SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "l3edit_offset = read:  0x%x, write: 0x%x \n",  p_tunnel_nhdb->dsl3edit_offset, p_nhdb->l3edit_offset_base + index*4);
    }

    dsnh_offset = p_nhdb->hdr.dsfwd_info.dsnh_offset;
    dsnh_8w.offset = dsnh_offset;
    dsnh_8w.hash_num =hash_num;
    dsnh_8w.update_type = 1;
    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "dsnh_offset = %d, hash_cnt:%d Valid edit_num = %d\n", dsnh_offset, hash_num, p_nhdb->valid_cnt);
    CTC_ERROR_RETURN(sys_goldengate_nh_update_asic_table(lchip, SYS_NH_ENTRY_TYPE_NEXTHOP_8W, dsnh_offset, &dsnh_8w));

    return CTC_E_NONE;
}


int32
sys_goldengate_nh_update_ecmp_member(uint8 lchip, uint32 nhid, uint8 change_type)
{
    sys_nh_info_com_t* p_nh_info = NULL;
    sys_nh_info_ecmp_t* p_nhdb = NULL;
    uint8 ecmp_mem_idx = 0;
    sys_nh_ref_list_node_t* p_curr = NULL;
    uint8 find_flag = 0;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, nhid, (sys_nh_info_com_t**)&p_nh_info));

    p_curr = p_nh_info->hdr.p_ref_nh_list;

    while (p_curr)
    {
        p_nhdb = (sys_nh_info_ecmp_t*)p_curr->p_ref_nhinfo;
        if (!p_nhdb)
        {
            p_curr = p_curr->p_next;
            continue;
        }

        find_flag = 0;

        for (ecmp_mem_idx = 0; ecmp_mem_idx < p_nhdb->ecmp_cnt; ecmp_mem_idx++)
        {
            if (p_nhdb->nh_array[ecmp_mem_idx] == nhid)
            {
                find_flag = 1;
                break;
            }
        }

        if (find_flag == 0)
        {
            p_curr = p_curr->p_next;
            continue;
        }

        switch (change_type)
        {
        case SYS_NH_CHANGE_TYPE_FWD_TO_UNROV:
            if (ecmp_mem_idx < p_nhdb->valid_cnt)
            {
                p_nhdb->nh_array[ecmp_mem_idx]  = p_nhdb->nh_array[ p_nhdb->valid_cnt - 1];
                p_nhdb->nh_array[ p_nhdb->valid_cnt - 1] = nhid;
                p_nhdb->valid_cnt -= 1;

            }

            break;

        case SYS_NH_CHANGE_TYPE_UNROV_TO_FWD:
		case SYS_NH_CHANGE_TYPE_ADD_DYNTBL:
            if (ecmp_mem_idx >= p_nhdb->valid_cnt)
            {
                p_nhdb->nh_array[ecmp_mem_idx] = p_nhdb->nh_array[p_nhdb->valid_cnt];
                p_nhdb->nh_array[p_nhdb->valid_cnt]  = nhid;
                p_nhdb->valid_cnt += 1;
            }

            break;

        case SYS_NH_CHANGE_TYPE_NH_DELETE:
            if (ecmp_mem_idx < p_nhdb->valid_cnt)
            {
                /*delete valid member in nh_array*/
                p_nhdb->nh_array[ecmp_mem_idx] = p_nhdb->nh_array[p_nhdb->valid_cnt - 1];
                p_nhdb->nh_array[p_nhdb->valid_cnt - 1] = p_nhdb->nh_array[p_nhdb->ecmp_cnt - 1];
                p_nhdb->valid_cnt -= 1;
                p_nhdb->ecmp_cnt  -= 1;
            }
            else
            {
                /*delete unrov member in nh_array*/
                p_nhdb->nh_array[ecmp_mem_idx] = p_nhdb->nh_array[p_nhdb->ecmp_cnt - 1];
                p_nhdb->ecmp_cnt  -= 1;
            }

            break;

        case SYS_NH_CHANGE_TYPE_UPDATE_FWD_ATTR:
            break;
        }

    if (p_nhdb->type != CTC_NH_ECMP_TYPE_XERSPAN)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_ecmp_group(lchip, p_nhdb));
    }
    else
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_xerspan_group(lchip, p_nhdb));
    }

        p_curr = p_curr->p_next;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_add_ecmp_member(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb, sys_nh_info_com_t* p_nh_info)
{
    sys_nh_ref_list_node_t* p_curr = NULL;
    sys_nh_ref_list_node_t* p_nh_ref_list_node = NULL;
    uint8 find_flag = 0;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_nhdb);
    CTC_PTR_VALID_CHECK(p_nh_info);

    p_curr = p_nh_info->hdr.p_ref_nh_list;

    while (p_curr)
    {
        if ((sys_nh_info_ecmp_t*)p_curr->p_ref_nhinfo == p_nhdb)
        {
            find_flag = 1;
            break;
        }

        p_curr = p_curr->p_next;
    }

    if (find_flag == 0)
    {
        p_nh_ref_list_node = (sys_nh_ref_list_node_t*)mem_malloc(MEM_NEXTHOP_MODULE, sizeof(sys_nh_ref_list_node_t));
        if (p_nh_ref_list_node == NULL)
        {
            return CTC_E_NO_MEMORY;
        }
        p_nh_ref_list_node->p_ref_nhinfo = (sys_nh_info_com_t*)p_nhdb;
        p_nh_ref_list_node->p_next = p_nh_info->hdr.p_ref_nh_list;

        p_nh_info->hdr.p_ref_nh_list = p_nh_ref_list_node;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_delete_ecmp_member(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb, sys_nh_info_com_t* p_nh_info)
{
    sys_nh_ref_list_node_t* p_curr = NULL;
    sys_nh_ref_list_node_t* p_prev = NULL;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_nhdb);
    CTC_PTR_VALID_CHECK(p_nh_info);

    p_curr = p_nh_info->hdr.p_ref_nh_list;

    while (p_curr)
    {
        if ((sys_nh_info_ecmp_t*)p_curr->p_ref_nhinfo == p_nhdb)
        {
            if (NULL == p_prev)
            /*Remove first node*/
            {
                p_nh_info->hdr.p_ref_nh_list = p_curr->p_next;
            }
            else
            {
                p_prev->p_next = p_curr->p_next;
            }

            mem_free(p_curr);
            return CTC_E_NONE;
        }

        p_prev = p_curr;
        p_curr = p_curr->p_next;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_update_ecmp_group(uint8 lchip, sys_nh_info_ecmp_t* p_nhdb)
{
    sys_nh_info_com_t* p_nh_info = NULL;
    uint8 valid_nh_idx = 0;
    uint8 ecmp_mem_idx = 0;
    uint8 dest_channel = 0;
    uint16 max_ecmp = 0;
    sys_fwd_t dsfwd;
    sys_dsecmp_member_t sys_ecmp_member;
    sys_dsecmp_group_t sys_ecmp_group;
    sys_dsecmp_rr_t sys_ecmp_rr;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_nhdb);

    if (p_nhdb->failover_en && (p_nhdb->type == CTC_NH_ECMP_TYPE_DLB))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    sal_memset(&sys_ecmp_member, 0, sizeof(sys_ecmp_member));
    sal_memset(&sys_ecmp_group, 0, sizeof(sys_ecmp_group));
    sal_memset(&sys_ecmp_rr, 0, sizeof(sys_ecmp_rr));
    sal_memset(&dsfwd, 0, sizeof(dsfwd));

    CTC_ERROR_RETURN(sys_goldengate_nh_get_max_ecmp(lchip, &max_ecmp));

    for (ecmp_mem_idx = 0; ecmp_mem_idx < max_ecmp; ecmp_mem_idx++)
    {
        if (p_nhdb->valid_cnt == 0)
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, CTC_NH_RESERVED_NHID_FOR_DROP, (sys_nh_info_com_t**)&p_nh_info));
        }
        else
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nhdb->nh_array[valid_nh_idx], (sys_nh_info_com_t**)&p_nh_info));

            if ((++valid_nh_idx) == p_nhdb->valid_cnt)
            {
                valid_nh_idx = 0;
            }
        }
        SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, " INFO: ecmp_mem_idx:%d()\n", ecmp_mem_idx);

        sys_goldengate_nh_get_entry_dsfwd(lchip, p_nh_info->hdr.dsfwd_info.dsfwd_offset, (void*)&dsfwd);
        /* for mux-demux port, need get by func, do it later ? */
        dest_channel = ((dsfwd.dest_map>>8 & 0x1) << 6) | (dsfwd.dest_map & 0x3F);

        if (ecmp_mem_idx%4 == 0)
        {
            sal_memset(&sys_ecmp_member, 0, sizeof(sys_ecmp_member));
            sys_ecmp_member.valid0 = 1;
            sys_ecmp_member.dsfwdptr0 = p_nh_info->hdr.dsfwd_info.dsfwd_offset;
            sys_ecmp_member.dest_channel0 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 1)
        {
            sys_ecmp_member.valid1 = 1;
            sys_ecmp_member.dsfwdptr1 = p_nh_info->hdr.dsfwd_info.dsfwd_offset;
            sys_ecmp_member.dest_channel1 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 2)
        {
            sys_ecmp_member.valid2 = 1;
            sys_ecmp_member.dsfwdptr2 = p_nh_info->hdr.dsfwd_info.dsfwd_offset;
            sys_ecmp_member.dest_channel2 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 3)
        {
            sys_ecmp_member.valid3 = 1;
            sys_ecmp_member.dsfwdptr3 = p_nh_info->hdr.dsfwd_info.dsfwd_offset;
            sys_ecmp_member.dest_channel3 = dest_channel;

            /* write ecmp member */
            sys_goldengate_nh_write_asic_table(lchip, SYS_NH_ENTRY_TYPE_ECMP_MEMBER,
                (p_nhdb->ecmp_member_base + ecmp_mem_idx)/4, &sys_ecmp_member);
        }
    }

    sys_ecmp_group.dlb_en = (p_nhdb->type == CTC_NH_ECMP_TYPE_DLB) ? 1 : 0;
    sys_ecmp_group.resilient_hash_en = p_nhdb->failover_en ? 1 : 0;
    sys_ecmp_group.rr_en = ((p_nhdb->type == CTC_NH_ECMP_TYPE_RR) || (p_nhdb->type == CTC_NH_ECMP_TYPE_RANDOM_RR)) ? 1 : 0;
    sys_ecmp_group.member_base = p_nhdb->ecmp_member_base / 4;
    sys_ecmp_group.member_num = (p_nhdb->valid_cnt > 0) ? (p_nhdb->valid_cnt-1) : 0;
    sys_ecmp_group.stats_valid = p_nhdb->stats_valid ? 1 : 0;

    if (sys_ecmp_group.rr_en)
    {
        sys_ecmp_rr.random_rr_en = p_nhdb->random_rr_en;
        sys_ecmp_rr.member_num = sys_ecmp_group.member_num;
        CTC_ERROR_RETURN(sys_goldengate_nh_write_asic_table(lchip, SYS_NH_ENTRY_TYPE_ECMP_RR_COUNT,
                p_nhdb->ecmp_group_id%SYS_NH_ECMP_RR_GROUP_NUM, &sys_ecmp_rr));
    }

    /* write ecmp group */
    CTC_ERROR_RETURN(sys_goldengate_nh_write_asic_table(lchip, SYS_NH_ENTRY_TYPE_ECMP_GROUP,
                p_nhdb->ecmp_group_id, &sys_ecmp_group));

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_update_ecmp_interface_group(uint8 lchip, sys_l3if_ecmp_if_t* p_group)
{
    uint8 valid_nh_idx = 0;
    uint8 ecmp_mem_idx = 0;
    uint8 dest_channel = 0;
    uint16 max_ecmp = 0;
    uint32 dsfwd_offset = 0;
    sys_nh_info_com_t* p_nh_info = NULL;
    sys_fwd_t dsfwd;
    sys_dsecmp_member_t sys_ecmp_member;
    sys_dsecmp_group_t sys_ecmp_group;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_group);

    if (p_group->failover_en && (p_group->ecmp_group_type == CTC_NH_ECMP_TYPE_DLB))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    sal_memset(&sys_ecmp_member, 0, sizeof(sys_ecmp_member));
    sal_memset(&sys_ecmp_group, 0, sizeof(sys_ecmp_group));
    sal_memset(&dsfwd, 0, sizeof(dsfwd));

    CTC_ERROR_RETURN(sys_goldengate_nh_get_max_ecmp(lchip, &max_ecmp));

    for (ecmp_mem_idx = 0; ecmp_mem_idx < max_ecmp; ecmp_mem_idx++)
    {
        if (p_group->intf_count == 0)
        {
            CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, CTC_NH_RESERVED_NHID_FOR_DROP, (sys_nh_info_com_t**)&p_nh_info));
            dsfwd_offset = p_nh_info->hdr.dsfwd_info.dsfwd_offset;
        }
        else
        {
            dsfwd_offset = p_group->dsfwd_offset[valid_nh_idx];
            if ((++valid_nh_idx) == p_group->intf_count)
            {
                valid_nh_idx = 0;
            }
        }
        SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, " INFO: ecmp_mem_idx:%d()\n", ecmp_mem_idx);

        sys_goldengate_nh_get_entry_dsfwd(lchip, dsfwd_offset, (void*)&dsfwd);
        /* for mux-demux port, need get by func, do it later ? */
        dest_channel = ((dsfwd.dest_map>>8 & 0x1) << 6) | (dsfwd.dest_map & 0x3F);

        if (ecmp_mem_idx%4 == 0)
        {
            sal_memset(&sys_ecmp_member, 0, sizeof(sys_ecmp_member));
            sys_ecmp_member.valid0 = 1;
            sys_ecmp_member.dsfwdptr0 = dsfwd_offset;
            sys_ecmp_member.dest_channel0 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 1)
        {
            sys_ecmp_member.valid1 = 1;
            sys_ecmp_member.dsfwdptr1 = dsfwd_offset;
            sys_ecmp_member.dest_channel1 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 2)
        {
            sys_ecmp_member.valid2 = 1;
            sys_ecmp_member.dsfwdptr2 = dsfwd_offset;
            sys_ecmp_member.dest_channel2 = dest_channel;
        }
        else if (ecmp_mem_idx%4 == 3)
        {
            sys_ecmp_member.valid3 = 1;
            sys_ecmp_member.dsfwdptr3 = dsfwd_offset;
            sys_ecmp_member.dest_channel3 = dest_channel;

            /* write ecmp member */
            sys_goldengate_nh_write_asic_table(lchip, SYS_NH_ENTRY_TYPE_ECMP_MEMBER,
                (p_group->ecmp_member_base + ecmp_mem_idx)/4, &sys_ecmp_member);
        }
    }

    sys_ecmp_group.dlb_en = (p_group->ecmp_group_type == CTC_NH_ECMP_TYPE_DLB) ? 1 : 0;
    sys_ecmp_group.resilient_hash_en = p_group->failover_en ? 1 : 0;
    sys_ecmp_group.member_base = p_group->ecmp_member_base / 4;
    sys_ecmp_group.member_num = (p_group->intf_count > 0) ? (p_group->intf_count-1) : 0;
    sys_ecmp_group.stats_valid = (p_group->stats_id > 0) ? 1 : 0;
    if (p_group->stats_id)
    {
        CTC_ERROR_RETURN(sys_goldengate_stats_add_ecmp_stats(lchip, p_group->stats_id, p_group->hw_group_id));
    }

    /* write ecmp group */
    CTC_ERROR_RETURN(sys_goldengate_nh_write_asic_table(lchip, SYS_NH_ENTRY_TYPE_ECMP_GROUP,
                p_group->hw_group_id, &sys_ecmp_group));

    return CTC_E_NONE;
}


int32
_sys_goldengate_nh_ecmp_update_member_nh(uint8 lchip, uint32 nhid, sys_nh_info_com_t * p_com_db)
{
    sys_nh_param_com_t nh_param;
    sal_memset(&nh_param, 0, sizeof(sys_nh_param_com_t));
    nh_param.hdr.nhid = nhid;
    nh_param.hdr.nh_param_type = p_com_db->hdr.nh_entry_type;
    nh_param.hdr.change_type  = SYS_NH_CHANGE_TYPE_ADD_DYNTBL;


    if (p_com_db->hdr.nh_entry_type == SYS_NH_TYPE_IPUC)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_ipuc_cb(lchip, (sys_nh_info_com_t*)p_com_db, (sys_nh_param_com_t*)&nh_param));

    }
    else if(p_com_db->hdr.nh_entry_type == SYS_NH_TYPE_MPLS)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_mpls_cb(lchip, (sys_nh_info_com_t*)p_com_db, (sys_nh_param_com_t*)&nh_param));


    }
    else if(p_com_db->hdr.nh_entry_type == SYS_NH_TYPE_IP_TUNNEL)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_ip_tunnel_cb(lchip, (sys_nh_info_com_t*)p_com_db, (sys_nh_param_com_t*)&nh_param));
    }
    else if(p_com_db->hdr.nh_entry_type == SYS_NH_TYPE_MISC)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_update_misc_cb(lchip, (sys_nh_info_com_t*)p_com_db, (sys_nh_param_com_t*)&nh_param));
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_create_normal_ecmp(uint8 lchip, sys_nh_param_com_t* p_com_nh_param, sys_nh_info_com_t* p_com_db)
{
    sys_nh_param_ecmp_t* p_nh_param = NULL;
    ctc_nh_ecmp_nh_param_t* p_nh_ecmp_param = NULL;
    sys_nh_info_ecmp_t* p_nhdb = NULL;
    sys_goldengate_opf_t opf;
    uint16 max_ecmp = 0;
    uint8  nh_array_size = 0;
    uint8  loop = 0, loop2 = 0;
    uint8  valid_cnt = 0, unrov_nh_cnt = 0;
    uint8  exist = 0;
    uint32 nh_array[CTC_MAX_ECPN] = {0};
    uint32 unrov_nh_array[CTC_MAX_ECPN] = {0};
    uint32 valid_nh_array[CTC_MAX_ECPN] = {0};

    uint32 offset = 0;
    int32  ret = CTC_E_NONE;

    sys_nh_info_com_t* p_nh_info = NULL;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_com_nh_param);
    CTC_PTR_VALID_CHECK(p_com_db);

    sal_memset(&opf, 0, sizeof(opf));

    p_nh_param = (sys_nh_param_ecmp_t*)(p_com_nh_param);
    p_nhdb = (sys_nh_info_ecmp_t*)(p_com_db);
    p_nhdb->hdr.nh_entry_type = SYS_NH_TYPE_ECMP;
    p_nh_ecmp_param = p_nh_param->p_ecmp_param;

    if (p_nh_ecmp_param->nh_num == 0)
    {
        return CTC_E_INVALID_PARAM;
    }

    if (p_nh_ecmp_param->failover_en && (p_nh_ecmp_param->type == CTC_NH_ECMP_TYPE_DLB))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    CTC_ERROR_RETURN(sys_goldengate_nh_get_max_ecmp(lchip, &max_ecmp));

    if (p_nh_ecmp_param->nh_num > max_ecmp)
    {
        return CTC_E_NH_EXCEED_MAX_ECMP_NUM;
    }

    /*1.Judge repeated Member */
    for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
    {
        for (loop2 = 0; loop2 < valid_cnt; loop2++)
        {
            if (p_nh_ecmp_param->nhid[loop] == nh_array[loop2])
            {
                p_nh_ecmp_param->nhid[loop] = CTC_MAX_UINT32_VALUE;
                exist = 1;
                break;
            }
        }

        if (!exist)
        {
            nh_array[valid_cnt] = p_nh_ecmp_param->nhid[loop];
            valid_cnt++;
        }
        exist = 0;
    }

    /*2.Judge  Member is FWD or unrsv */
    valid_cnt = 0;
    unrov_nh_cnt = 0;

    for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
    {
        if (p_nh_ecmp_param->nhid[loop] == CTC_MAX_UINT32_VALUE)
        {
            continue;
        }

        CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nh_ecmp_param->nhid[loop], (sys_nh_info_com_t**)&p_nh_info));
        if (p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_IPUC && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_MPLS
            && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_IP_TUNNEL && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_MISC
            && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_DROP)
        {
            return CTC_E_NH_INVALID_NH_TYPE;
        }


        if (!CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_IS_UNROV)
            && !CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_DSFWD))
        {
            _sys_goldengate_nh_ecmp_update_member_nh(lchip, p_nh_ecmp_param->nhid[loop],(sys_nh_info_com_t*)p_nh_info);
        }

        if (!CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_IS_UNROV))
        {
            valid_nh_array[valid_cnt++] = p_nh_ecmp_param->nhid[loop];

        }
        else
        {
            unrov_nh_array[unrov_nh_cnt++] = p_nh_ecmp_param->nhid[loop];
        }
    }


    if ((g_nh_master[lchip]->cur_ecmp_cnt + 1) > g_nh_master[lchip]->max_ecmp_group_num)
    {
        return CTC_E_NO_RESOURCE;
    }

    /*3.Save DB */
    p_nhdb->valid_cnt = valid_cnt;
    p_nhdb->ecmp_cnt = valid_cnt + unrov_nh_cnt;
    p_nhdb->ecmp_nh_id = p_nh_param->hdr.nhid;
    p_nhdb->type = p_nh_ecmp_param->type;
    p_nhdb->failover_en = p_nh_ecmp_param->failover_en;
    if ((p_nhdb->type == CTC_NH_ECMP_TYPE_RR)
        || (p_nhdb->type == CTC_NH_ECMP_TYPE_RANDOM_RR))
    {
        /* for rr, only support groupId 1-15 */

        opf.pool_type  = OPF_ECMP_GROUP_ID;
        opf.pool_index = 0;
        opf.reverse    = 0;

        CTC_ERROR_RETURN(sys_goldengate_opf_alloc_offset(lchip, &opf, 1, &offset));
        if (offset >= SYS_NH_ECMP_RR_GROUP_NUM)
        {
            SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_DUMP, " INFO: alloc ecmp_group_id:%d\n", offset);
            sys_goldengate_opf_free_offset(lchip, &opf, 1, offset);
            return CTC_E_NO_RESOURCE;
        }

        p_nhdb->ecmp_group_id = offset;

        if (p_nhdb->type == CTC_NH_ECMP_TYPE_RANDOM_RR)
        {
            p_nhdb->random_rr_en = 1;
        }

    }
    else
    {
        opf.pool_type  = OPF_ECMP_GROUP_ID;
        opf.pool_index = 0;
        opf.reverse    = 1;

        CTC_ERROR_RETURN(sys_goldengate_opf_alloc_offset(lchip, &opf, 1, &offset));
        p_nhdb->ecmp_group_id = offset;
    }
    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, " INFO: alloc ecmp_group_id:%d\n", p_nhdb->ecmp_group_id);

    opf.pool_type  = OPF_ECMP_MEMBER_ID;
    opf.pool_index = 0;
    opf.reverse    = 0;

    sys_goldengate_opf_alloc_offset(lchip, &opf, max_ecmp, &offset);
    p_nhdb->ecmp_member_base = offset;

    /* process stats */
    if (p_nh_ecmp_param->stats_id)
    {
        p_nhdb->stats_valid = 1;
        ret = sys_goldengate_stats_add_ecmp_stats(lchip, p_nh_ecmp_param->stats_id, p_nhdb->ecmp_group_id);
        if (ret < 0)
        {
            goto error1;
        }
    }

    nh_array_size = (p_nhdb->ecmp_cnt + SYS_ECMP_ALLOC_MEM_STEP - 1) / SYS_ECMP_ALLOC_MEM_STEP;
    nh_array_size = nh_array_size * SYS_ECMP_ALLOC_MEM_STEP;

    p_nhdb->nh_array = mem_malloc(MEM_NEXTHOP_MODULE, nh_array_size * sizeof(uint32));

    if (!p_nhdb->nh_array)
    {
        ret = CTC_E_NO_MEMORY;
        goto error2;
    }

    sal_memcpy(&p_nhdb->nh_array[0], &valid_nh_array[0], valid_cnt * sizeof(uint32));
    if (unrov_nh_cnt)
    {
        sal_memcpy(&p_nhdb->nh_array[valid_cnt], &unrov_nh_array[0], unrov_nh_cnt * sizeof(uint32));
    }

    /*4.Create ECMP group */
    sys_goldengate_nh_update_ecmp_group(lchip, p_nhdb);

    /*5.Add ECMP Nhid to member nexthop's linklist*/
    for (loop = 0; loop < p_nhdb->ecmp_cnt; loop++)
    {
        ret = sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nhdb->nh_array[loop], (sys_nh_info_com_t**)&p_nh_info);
        if (ret < 0)
        {
            mem_free(p_nhdb->nh_array);
            goto error2;
        }
        sys_goldengate_nh_add_ecmp_member(lchip, p_nhdb, p_nh_info);
    }

    return CTC_E_NONE;

error2:
    if (p_nh_ecmp_param->stats_id)
    {
        sys_goldengate_stats_remove_ecmp_stats(lchip, p_nh_ecmp_param->stats_id, p_nhdb->ecmp_group_id);
    }

error1:
    /* free ecmp groupId ? */
    {
        opf.pool_type = OPF_ECMP_GROUP_ID;
        opf.pool_index = 0;

        sys_goldengate_opf_free_offset(lchip, &opf, 1, (uint32)(p_nhdb->ecmp_group_id));

        opf.pool_type  = OPF_ECMP_MEMBER_ID;
        opf.pool_index = 0;
        opf.reverse    = 0;

        CTC_ERROR_RETURN(sys_goldengate_opf_free_offset(lchip, &opf, max_ecmp, (uint32)p_nhdb->ecmp_member_base));
    }


    return ret;
}

int32
sys_goldengate_nh_update_ecmp_cb(uint8 lchip, sys_nh_info_com_t* p_com_db, sys_nh_param_com_t* p_com_nh_param)
{
    sys_nh_param_ecmp_t* p_nh_param = NULL;
    ctc_nh_ecmp_nh_param_t* p_nh_ecmp_param = NULL;
    sys_nh_info_ecmp_t* p_nhdb = NULL;
    uint8 nh_array_size = 0, nh_array_size2 = 0;
    uint8 loop = 0, loop2 = 0;
    uint8 valid_cnt = 0;
    uint8 exist = 0;
    uint16 max_ecmp = 0;
    uint8  unrov_nh_cnt = 0;
    uint32 unrov_nh_array[CTC_MAX_ECPN] = {0};
    uint32 valid_nh_array[CTC_MAX_ECPN] = {0};
    sys_nh_info_com_t* p_nh_info = NULL;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_com_db);
    CTC_PTR_VALID_CHECK(p_com_nh_param);

    p_nh_param = (sys_nh_param_ecmp_t*)(p_com_nh_param);
    p_nhdb = (sys_nh_info_ecmp_t*)(p_com_db);
    p_nhdb->hdr.nh_entry_type = SYS_NH_TYPE_ECMP;
    p_nh_ecmp_param = p_nh_param->p_ecmp_param;

    if (p_nh_ecmp_param->nh_num == 0)
    {
        return CTC_E_INVALID_PARAM;
    }

    sal_memcpy(&valid_nh_array[0], &p_nhdb->nh_array[0], p_nhdb->valid_cnt * sizeof(uint32));
    sal_memcpy(&unrov_nh_array[0], &p_nhdb->nh_array[p_nhdb->valid_cnt], (p_nhdb->ecmp_cnt - p_nhdb->valid_cnt) * sizeof(uint32));
    unrov_nh_cnt = (p_nhdb->ecmp_cnt - p_nhdb->valid_cnt);
    valid_cnt = p_nhdb->valid_cnt;

    if (p_nh_ecmp_param->upd_type == CTC_NH_ECMP_ADD_MEMBER)
    {
        for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
        {
            for (loop2 = 0; loop2 < p_nhdb->ecmp_cnt; loop2++)
            {
                if (p_nh_ecmp_param->nhid[loop] == p_nhdb->nh_array[loop2])
                {
                    p_nh_ecmp_param->nhid[loop] = CTC_MAX_UINT32_VALUE;
                    exist = 1;
                    break;
                }
            }

            if (exist)
            {
                exist = 0;
                continue;
            }

            CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nh_ecmp_param->nhid[loop], (sys_nh_info_com_t**)&p_nh_info));

            if (p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_IPUC && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_MPLS
                && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_IP_TUNNEL && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_MISC
                && p_nh_info->hdr.nh_entry_type != SYS_NH_TYPE_DROP)
            {
                return CTC_E_NH_INVALID_NH_TYPE;
            }

           if (!CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_IS_UNROV)
            && !CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_DSFWD))
           {
               _sys_goldengate_nh_ecmp_update_member_nh(lchip, p_nh_ecmp_param->nhid[loop],(sys_nh_info_com_t*)p_nh_info);
           }

            if (!CTC_FLAG_ISSET(p_nh_info->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_IS_UNROV))
            {
                valid_nh_array[valid_cnt++] = p_nh_ecmp_param->nhid[loop];
            }
            else
            {
                unrov_nh_array[unrov_nh_cnt++] = p_nh_ecmp_param->nhid[loop];
            }
        }
    }
    else if (p_nh_ecmp_param->upd_type == CTC_NH_ECMP_REMOVE_MEMBER)
    {
        for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
        {
            for (loop2 = 0; loop2 < p_nhdb->ecmp_cnt; loop2++)
            {
                if (p_nh_ecmp_param->nhid[loop] == p_nhdb->nh_array[loop2])
                {
                    exist = 1;
                    break;
                }
            }

            if (exist == 0)
            {
                return CTC_E_NH_ECMP_MEM_NOS_EXIST;
            }
            else
            {
                p_nhdb->nh_array[loop2]  = CTC_MAX_UINT32_VALUE;
            }
        }

        for (loop = 0; loop < p_nhdb->ecmp_cnt; loop++)
        {
            if (p_nhdb->nh_array[loop] != CTC_MAX_UINT32_VALUE)
            {
                continue;
            }

            if (loop < p_nhdb->valid_cnt)
            {
                valid_nh_array[loop] = valid_nh_array[valid_cnt - 1];
                valid_cnt--;
            }
            else
            {
                unrov_nh_array[loop - valid_cnt] = unrov_nh_array[unrov_nh_cnt - 1];
                unrov_nh_cnt--;
            }
        }
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(sys_goldengate_nh_get_max_ecmp(lchip, &max_ecmp));

    if ((valid_cnt + unrov_nh_cnt) > max_ecmp)
    {
        return CTC_E_NH_EXCEED_MAX_ECMP_NUM;
    }

    /*old nh_array_size*/
    nh_array_size = (p_nhdb->ecmp_cnt + SYS_ECMP_ALLOC_MEM_STEP - 1) / SYS_ECMP_ALLOC_MEM_STEP;
    nh_array_size  = (nh_array_size == 0) ? 1 : nh_array_size;

    /*new nh_array_size*/
    nh_array_size2 = (valid_cnt + unrov_nh_cnt + SYS_ECMP_ALLOC_MEM_STEP - 1) / SYS_ECMP_ALLOC_MEM_STEP;
    nh_array_size2  = (nh_array_size2 == 0) ? 1 : nh_array_size2;

    if (nh_array_size != nh_array_size2)
    {
        mem_free(p_nhdb->nh_array);

        nh_array_size2 = nh_array_size2 * SYS_ECMP_ALLOC_MEM_STEP;
        p_nhdb->nh_array = mem_malloc(MEM_NEXTHOP_MODULE, nh_array_size2 * sizeof(uint32));

        if (!p_nhdb->nh_array)
        {
            return CTC_E_NO_MEMORY;
        }
    }

    p_nhdb->valid_cnt = valid_cnt;
    p_nhdb->ecmp_cnt = valid_cnt + unrov_nh_cnt;
    sal_memcpy(&p_nhdb->nh_array[0], &valid_nh_array[0], valid_cnt * sizeof(uint32));
    if (unrov_nh_cnt)
    {
        sal_memcpy(&p_nhdb->nh_array[valid_cnt], &unrov_nh_array[0], unrov_nh_cnt * sizeof(uint32));
    }

    if (p_nhdb->type != CTC_NH_ECMP_TYPE_XERSPAN)
    {
        sys_goldengate_nh_update_ecmp_group(lchip, p_nhdb);
    }
    else
    {
        sys_goldengate_nh_update_xerspan_group(lchip, p_nhdb);
    }

    if (p_nh_ecmp_param->upd_type == CTC_NH_ECMP_ADD_MEMBER)
    {
        for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
        {
            if (CTC_MAX_UINT32_VALUE != p_nh_ecmp_param->nhid[loop])
            {
                CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nh_ecmp_param->nhid[loop], (sys_nh_info_com_t**)&p_nh_info));
                sys_goldengate_nh_add_ecmp_member(lchip, p_nhdb, p_nh_info);
            }
        }
    }
    else if (p_nh_ecmp_param->upd_type == CTC_NH_ECMP_REMOVE_MEMBER)
    {
        for (loop = 0; loop < p_nh_ecmp_param->nh_num; loop++)
        {
            if (CTC_MAX_UINT32_VALUE != p_nh_ecmp_param->nhid[loop])
            {
                CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nh_ecmp_param->nhid[loop], (sys_nh_info_com_t**)&p_nh_info));
                sys_goldengate_nh_delete_ecmp_member(lchip, p_nhdb, p_nh_info);
            }
        }
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_nh_delete_ecmp_cb(uint8 lchip, sys_nh_info_com_t* p_com_db, uint32* p_nhid)
{
    sys_nh_info_ecmp_t* p_nhdb = NULL;
    uint8 loop = 0;
    uint16 max_ecmp = 0;
    sys_nh_info_com_t* p_nh_info = NULL;
    sys_goldengate_opf_t opf;
    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_PTR_VALID_CHECK(p_com_db);
    CTC_PTR_VALID_CHECK(p_nhid);

    sal_memset(&opf, 0, sizeof(opf));

    p_nhdb = (sys_nh_info_ecmp_t*)(p_com_db);


    if (p_nhdb->type != CTC_NH_ECMP_TYPE_XERSPAN )
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_get_max_ecmp(lchip, &max_ecmp));

        p_nhdb->valid_cnt = 0;
        p_nhdb->type = CTC_NH_ECMP_TYPE_STATIC;
        sys_goldengate_nh_update_ecmp_group(lchip, p_nhdb);

        /* free ecmp groupId ? */
        opf.pool_type = OPF_ECMP_GROUP_ID;
        opf.pool_index = 0;

        CTC_ERROR_RETURN(sys_goldengate_opf_free_offset(lchip, &opf, 1, (uint32)(p_nhdb->ecmp_group_id)));
        SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_INFO, " INFO: free ecmp_group_id:%d\n", p_nhdb->ecmp_group_id);

        opf.pool_type  = OPF_ECMP_MEMBER_ID;
        opf.pool_index = 0;
        opf.reverse    = 0;

        CTC_ERROR_RETURN(sys_goldengate_opf_free_offset(lchip, &opf, max_ecmp, (uint32)p_nhdb->ecmp_member_base));
    }
    else
    {
        uint8 hash_num = 16;
        CTC_ERROR_RETURN(sys_goldengate_nh_offset_free(lchip, SYS_NH_ENTRY_TYPE_NEXTHOP_8W, 1, p_nhdb->hdr.dsfwd_info.dsnh_offset));

        /*1. Free new dsl3edit  entry*/
        CTC_ERROR_RETURN(sys_goldengate_nh_offset_free(lchip,
                                                       SYS_NH_ENTRY_TYPE_L3EDIT_TUNNEL_V6, hash_num,
                                                       p_nhdb->l3edit_offset_base));

        if (CTC_FLAG_ISSET(p_nhdb->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_L2EDIT))
        {

            /*1. Free new dsl2edit  entry*/
            CTC_ERROR_RETURN(sys_goldengate_nh_offset_free(lchip,
                                                           SYS_NH_ENTRY_TYPE_L2EDIT_3W, hash_num*4,
                                                           p_nhdb->l2edit_offset_base));
        }

    }

    for (loop = 0; loop < p_nhdb->ecmp_cnt; loop++)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, p_nhdb->nh_array[loop], (sys_nh_info_com_t**)&p_nh_info));
        sys_goldengate_nh_delete_ecmp_member(lchip, p_nhdb, p_nh_info);
    }

    mem_free(p_nhdb->nh_array);
    return CTC_E_NONE;
}


int32
sys_goldengate_nh_create_rspan_ecmp(uint8 lchip, sys_nh_param_com_t* p_com_nh_para,
                                  sys_nh_info_com_t* p_com_db)
{
    sys_nh_param_ecmp_t* p_nh_param = NULL;
    sys_nh_info_ecmp_t* p_nhdb = NULL;
    uint8 hash_num = 0;
    uint32 nhid = 0;
    sys_nh_info_ip_tunnel_t* p_tunnel_nhdb = NULL;
    sys_nh_info_com_t* p_nh_info = NULL;
    sys_nh_param_dsnh_t dsnh_param;

    SYS_NH_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    /* 1. sanity check & init */
    CTC_PTR_VALID_CHECK(p_com_nh_para);
    CTC_PTR_VALID_CHECK(p_com_db);
    p_nh_param = (sys_nh_param_ecmp_t*)p_com_nh_para;
    p_nhdb = (sys_nh_info_ecmp_t*)p_com_db;
    CTC_PTR_VALID_CHECK(p_nh_param->p_ecmp_param);
    sal_memset(&dsnh_param, 0, sizeof(sys_nh_param_dsnh_t));

    p_nhdb->type = CTC_NH_ECMP_TYPE_XERSPAN;

    hash_num = 16;
    CTC_ERROR_RETURN(sys_goldengate_nh_offset_alloc(lchip, SYS_NH_ENTRY_TYPE_NEXTHOP_8W, 1, &p_nhdb->hdr.dsfwd_info.dsnh_offset));

    dsnh_param.dsnh_type = SYS_NH_PARAM_DSNH_TYPE_XERSPAN;
    dsnh_param.dsnh_offset = p_nhdb->hdr.dsfwd_info.dsnh_offset;
    p_nhdb->hdr.nh_entry_type = SYS_NH_TYPE_ECMP;

    nhid =  p_nh_param->p_ecmp_param->nhid[0];
    CTC_ERROR_RETURN(sys_goldengate_nh_get_nhinfo_by_nhid(lchip, nhid, (sys_nh_info_com_t**)&p_nh_info));
    p_tunnel_nhdb = (sys_nh_info_ip_tunnel_t *)p_nh_info;

    if (CTC_FLAG_ISSET(p_tunnel_nhdb->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_IS_UNROV))
    {
        return CTC_E_NH_IS_UNROV;
    }

    /*1. Allocate new dsl3edit mpls entry*/
    CTC_ERROR_RETURN(sys_goldengate_nh_offset_alloc(lchip,
                                                    SYS_NH_ENTRY_TYPE_L3EDIT_TUNNEL_V6, hash_num,
                                                    &dsnh_param.l3edit_ptr));
    p_nhdb->l3edit_offset_base = dsnh_param.l3edit_ptr;


    if (CTC_FLAG_ISSET(p_tunnel_nhdb->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_L2EDIT))
    {

        /*1. Allocate new dsl2edit mpls entry*/
        CTC_ERROR_RETURN(sys_goldengate_nh_offset_alloc(lchip,
                                                        SYS_NH_ENTRY_TYPE_L2EDIT_6W, hash_num*2,
                                                        &dsnh_param.l2edit_ptr));
        p_nhdb->l2edit_offset_base = dsnh_param.l2edit_ptr;
        CTC_SET_FLAG(p_nhdb->hdr.nh_entry_flags, SYS_NH_INFO_FLAG_HAVE_L2EDIT);
    }


    dsnh_param.hash_num = 0;
    dsnh_param.dest_vlan_ptr = p_tunnel_nhdb->dest_vlan_ptr;
    dsnh_param.span_id = p_tunnel_nhdb->span_id;
    p_nhdb->gport = p_tunnel_nhdb->gport;
    if (CTC_FLAG_ISSET(p_tunnel_nhdb->flag, SYS_NH_IP_TUNNEL_KEEP_IGS_TS))
    {
        CTC_SET_FLAG(dsnh_param.flag, SYS_NH_PARAM_FLAG_ERSPAN_KEEP_IGS_TS);
    }

    CTC_ERROR_RETURN(sys_goldengate_nh_write_entry_dsnh8w(lchip, &dsnh_param));

    p_nhdb->nh_array = mem_malloc(MEM_NEXTHOP_MODULE,  p_nh_param->p_ecmp_param->nh_num * sizeof(uint32));
    CTC_ERROR_RETURN(sys_goldengate_nh_update_ecmp_cb(lchip, p_com_db, p_com_nh_para ));



    return CTC_E_NONE;
}



int32
sys_goldengate_nh_create_ecmp_cb(uint8 lchip, sys_nh_param_com_t* p_com_nh_param, sys_nh_info_com_t* p_com_db)
{
    sys_nh_param_ecmp_t* p_nh_param = NULL;
    ctc_nh_ecmp_nh_param_t* p_nh_ecmp_param = NULL;

    CTC_PTR_VALID_CHECK(p_com_nh_param);
    CTC_PTR_VALID_CHECK(p_com_db);

    p_nh_param = (sys_nh_param_ecmp_t*)(p_com_nh_param);

    p_nh_ecmp_param = p_nh_param->p_ecmp_param;

    if (p_nh_ecmp_param->type != CTC_NH_ECMP_TYPE_XERSPAN)
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_create_normal_ecmp(lchip, p_com_nh_param, p_com_db));
    }
    else
    {
        CTC_ERROR_RETURN(sys_goldengate_nh_create_rspan_ecmp(lchip, p_com_nh_param, p_com_db));
    }

    return CTC_E_NONE;
}














