/**
 @file ctc_humber_bheader.h

 @author Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2012-3-14

 @version v2.0

 This file define the bheader APIs
*/

#ifndef _CTC_HUMBER_BHEADER_H
#define _CTC_HUMBER_BHEADER_H
#ifdef __cplusplus
extern "C" {
#endif
/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/

/****************************************************************
*
* Defines and Macros
*
****************************************************************/

/****************************************************************************
*
* Function
*
*****************************************************************************/

/**
 @addtogroup bheader BHEADER
 @{
*/

/**
 @brief decap cpu packet

 @param[in] lchip    local chip id

 @param[in]  cpu_packet packet_len

 @return CTC_E_XXX

*/
extern int32
ctc_humber_bheader_decap(uint8 lchip, void* pkt, uint16 pkt_len, ctc_bheader_rx_info_t* rx_info);

/**
 @brief encap cpu packet

 @param[in] lchip    local chip id

 @param[in]  packet_data data_len tx_info

 @return CTC_E_XXX

*/
extern int32
ctc_humber_bheader_encap(uint8 lchip, ctc_bheader_tx_info_t* tx_info, void* pkt, uint16* pkt_len);

/**@} end of @addgroup bheader BHEADER */

#ifdef __cplusplus
}
#endif

#endif /*_CTC_HUMBER_BHEADER_H*/

