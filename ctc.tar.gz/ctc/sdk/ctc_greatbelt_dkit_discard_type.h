#ifndef _CTC_DKIT_GOLDENGATE_DISCARD_TYPE_H_
#define _CTC_DKIT_GOLDENGATE_DISCARD_TYPE_H_


#ifdef __cplusplus
extern "C" {
#endif


#include "sal.h"

enum ctc_dkit_discard_reason_id_e
{
    CTC_DKIT_DISCARD_INVALIED                          =0x0000,/**< no discard*/
    /*IPE*/
    /* 0~9 */
    CTC_DKIT_IPE_USER_ID_BINDING_DISCARD =0x0001,                /**< The data in packet is not as SCL config, such as MAC DA, port, vlan, IP SA*/
    CTC_DKIT_IPE_HDR_ADJ_BYTE_RMV_ERR_DISCARD,                   /**< Loopback Header Adjust byte remove error discard*/
    CTC_DKIT_IPE_PSR_LEN_ERR,                                    /**< Parser length error discard*/
    CTC_DKIT_IPE_MAC_ISOLATED_DISCARD,                           /**< MAC Isolated Discard*/
    CTC_DKIT_IPE_EXCEP_2_DISCARD,                                /**< Exception 2 discard*/
    CTC_DKIT_IPE_USER_ID_DISCARD,                                /**< SCL config as discard*/
    CTC_DKIT_IPE_PORT_OR_DS_VLAN_RCV_DIS,                        /**< Port/DsVlan receive disable discard*/
    CTC_DKIT_IPE_ITAG_CHK_FAIL,                                  /**< ITag check failure, or invalid bmac, or loop MacSa of PIP port type in PBB*/
    CTC_DKIT_IPE_PTL_VLAN_DISCARD,                               /**< Portocol VLAN discard*/
    CTC_DKIT_IPE_VLAN_TAG_CTL_DISCARD,                           /**< AFT discard*/
    /* 10~19 */
    CTC_DKIT_IPE_NOT_ALLOW_MCAST_MAC_SA_DISCARD,                 /**< Mcast Mac SA/Same Mac SA DA/Same IP Da Sa discard/TCP Or UDP Header Error/ ICMP fragment packet/mismatch GRE version*/
    CTC_DKIT_IPE_STP_DISCARD,                                    /**< STP discard*/
    CTC_DKIT_IPE_RESERVED0,                                      /**< Reserved*/
    CTC_DKIT_IPE_PBB_OAM_DISCARD,                                /**< PBB OAM discard*/
    CTC_DKIT_IPE_ARP_DHCP_DISCARD,                               /**< ARP/DHCP/FIP discard*/
    CTC_DKIT_IPE_DS_PHYPORT_SRC_DISCARD,                         /**< Ingress phyport discard*/
    CTC_DKIT_IPE_VLAN_STATUS_FILTER_DISCARD,                     /**< Vlan filtering discard*/
    CTC_DKIT_IPE_ACLQOS_DISCARD_PKT,                             /**< ACL deny discard*/
    CTC_DKIT_IPE_ROUTING_MCAST_IP_ADDR_CHK_DISCARD,              /**< Routing multicast IP address check discard or IP Protocal Translation discard*/
    CTC_DKIT_IPE_BRG_BPDU_ETC_DISCARD,                           /**< Bridge Port Match or unknow Mcast/Ucast MAC address discard*/
    /* 20~29 */
    CTC_DKIT_IPE_STORM_CTL_DISCARD,                              /**< Storm Control discard*/
    CTC_DKIT_IPE_LEARNING_DISCARD,                               /**< MAC Sa discard/MAC Move/exceed to mac limit*/
    CTC_DKIT_IPE_POLICING_DISCARD,                               /**< Policing discard*/
    CTC_DKIT_IPE_NO_FWD_PTR_DISCARD,                             /**< Not find next hop, no dsFwdPtr*/
    CTC_DKIT_IPE_FWD_PTR_ALL_F_OR_VALID_DISCARD,                 /**< Next hop index is invalid*/
    CTC_DKIT_IPE_FATAL_EXCEPTION_DSCD,                           /**< Fatal Exception discard*/
    CTC_DKIT_IPE_APS_DISCARD,                                    /**< APS bridge or select discard*/
    CTC_DKIT_IPE_FWD_DEST_ID_DISCARD,                            /**< DestId Discard*/
    CTC_DKIT_IPE_RESERVED1,                                      /**< Reserved*/
    CTC_DKIT_IPE_HDR_AJUST_SMALL_PKT_DISCARD,                    /**< Header Adjust small packet discard*/
    /* 30~39 */
    CTC_DKIT_IPE_HDR_ADJUST_PKT_ERR,                             /**< Header Adjust packet error*/
    CTC_DKIT_IPE_TRILL_ESADI_PKT_DISCARD,                        /**< TRILL OAM packet discard, send to CPU*/
    CTC_DKIT_IPE_LOOPBACK_DISCARD,                               /**< Loopback discard*/
    CTC_DKIT_IPE_EFM_DISCARD,                                    /**< EFM OAM packet discard, send to CPU*/
    CTC_DKIT_IPE_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE,             /**< CAPWAP form AC error discard, CAPWAP unexpectable discard*/
    CTC_DKIT_IPE_STACKING_NETWORK_HEADER_CHK_ERR,                /**< Stacking network header check error*/
    CTC_DKIT_IPE_TRILL_FILTER_ERR,                               /**< TRILL filter discard / invalid TRILL MacDa on edge port*/
    CTC_DKIT_IPE_CAPWAP_CONTROL_EXCEPTION,                       /**< CAPWAP control exception discard, send to CPU*/
    CTC_DKIT_IPE_L3_EXCEPTION,                                   /**< L3 exception discard, send to CPU*/
    CTC_DKIT_IPE_L2_EXCEPTION,                                   /**< L2 exception discard, send to CPU*/
    /* 40~49 */
    CTC_DKIT_IPE_TRILL_MCAST_ADDR_CHK_ERR,                       /**< TRILL Mcast address check error discard*/
    CTC_DKIT_IPE_TRILL_VERSION_CHK_ERR,                          /**< TRILL version check error / inner VLAN ID check discard*/
    CTC_DKIT_IPE_PTP_VERSION_CHK_ERR,                            /**< PTP version check error discard*/
    CTC_DKIT_IPE_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD,             /**< PTPT P2P transparent clock discard delay*/
    CTC_DKIT_IPE_OAM_NOT_FOUND_DISCARD,                          /**< OAM MEP not found discard*/
    CTC_DKIT_IPE_OAM_STP_VLAN_FILTER_DISCARD,                    /**< OAM STP/VLAN filter discard*/
    CTC_DKIT_IPE_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR,                 /**< BFD single hop OAM TTL check error discard*/
    CTC_DKIT_IPE_CAPWAP_DTLS_DISCARD,                            /**< CAPWAP DTLS discard*/
    CTC_DKIT_IPE_NO_MEP_MIP_DISCARD,                             /**< No MEP/MIP discard*/
    CTC_DKIT_IPE_OAM_DIS,                                        /**< MPLS OAM disable discard*/
    /* 50~59 */
    CTC_DKIT_IPE_PBB_DECAP_DISCARD,                              /**< PBB decap discard*/
    CTC_DKIT_IPE_MPLS_TMPLS_OAM_DISCARD,                         /**< MPLS/T-MPLS OAM discard*/
    CTC_DKIT_IPE_MPLSTP_MCC_SCC_DISCARD,                         /**< MPLS-TP MCC/SCC discard, send to CPU*/
    CTC_DKIT_IPE_ICMP_ERR_MSG_DISCARD,                           /**< ICMP error message discard, send to CPU*/
    CTC_DKIT_IPE_PTP_ACL_EXCEPTION,                              /**< PTP ACL exception discard*/
    CTC_DKIT_IPE_ETHER_SERVICE_OAM_DISCARD,                      /**< Ethernet service OAM without vlan tag discard*/
    CTC_DKIT_IPE_LINK_OAM_DISCARD,                               /**< Ethernet link OAM with vlan tag discard*/
    CTC_DKIT_IPE_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD,        /**< Tunnel Decap outer header martian address discard*/
    CTC_DKIT_IPE_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD,     /**< CAPWAP BSSID lookup failure discard / CAPWAP logic port check discard*/
    CTC_DKIT_IPE_USER_ID_FWD_PTR_ALL_F_DISCARD,                  /**< Tunnel discard forwarding pointer discard*/
    /* 60~62 */
    CTC_DKIT_IPE_CAPWAP_FRAGMEN_DISCARD,                         /**< CAPWAP Fragment discard*/
    CTC_DKIT_IPE_TRILL_RPF_CHK_FAIL,                             /**< TRILL RPF check fail discard*/
    CTC_DKIT_IPE_MUX_PORT_ERR,                                   /**< Mux Port error discard*/
    CTC_DKIT_IPE_RESERVED2,                                      /**< Reserved*/

    CTC_DKIT_IPE_HW_HAR_ADJ,/**< some hardware error occurred at header adjust*/
    CTC_DKIT_IPE_HW_INT_MAP,/**< some hardware error occurred at interface mapper*/
    CTC_DKIT_IPE_HW_LKUP,/**< some hardware error occurred at lookup manager */
    CTC_DKIT_IPE_HW_PKT_PROC,/**< some hardware error occurred when do packet process*/
    CTC_DKIT_IPE_HW_PKT_FWD,/**< some hardware error occurred at forward*/
    CTC_DKIT_IPE_MAX,/**< */

    /*EPE*/
    CTC_DKIT_EPE_EPE_HDR_ADJ_DEST_ID_DISCARD=0x0100,             /**< EPE Bridge header destId Dicard*/
    CTC_DKIT_EPE_EPE_HDR_ADJ_PKT_ERR_DISCARD,                    /**< EPE Header Adjust pktErr discard*/
    CTC_DKIT_EPE_EPE_HDR_ADJ_BYTE_REMOVE_ERR,                    /**< EPE Header Adjust byte remove error discard*/
    CTC_DKIT_EPE_DEST_PHY_PORT_DEST_ID_DISCARD,                  /**< DestPort Discard*/
    CTC_DKIT_EPE_PORT_ISOLATE_DISCARD,                           /**< Port isolate discard*/
    CTC_DKIT_EPE_DS_VLAN_TRANS_DIS,                              /**< Port/DsVlan transmit disable discard*/
    CTC_DKIT_EPE_BRG_TO_SAME_PORT_DISCARD,                       /**< Bridge to same port discard*/
    CTC_DKIT_EPE_VPLS_HORIZON_SPLIT_DISCARD,                     /**< VPLS horizon  split or E-tree discard*/
    CTC_DKIT_EPE_EGRESS_VLAN_FILTER_DISCARD,                     /**< Egress VLAN filter discard*/
    CTC_DKIT_EPE_EGRESS_STP_DISCARD,                             /**< Egress STP discard*/
    /* 10~19 */
    CTC_DKIT_EPE_EGRESS_PARSER_LEN_ERR_DISCARD,                  /**< Egress parser length error discard */
    CTC_DKIT_EPE_EGRESS_PBB_CHK_DISCARD,                         /**< Egress PBB check discard */
    CTC_DKIT_EPE_UCAST_MCAST_FLOOD_DISCARD,                      /**< Discard unkown Unicast/mcast/broadcast on edge port */
    CTC_DKIT_EPE_802_3_OAM_DISCARD,                              /**< Discard non-EFM OAM packet */
    CTC_DKIT_EPE_EGRESS_TTL_FAIL,                                /**< Egress TTL failed discard */
    CTC_DKIT_EPE_REMOTE_MIRROR_ESCAPE_DISCARD,                   /**< Remote mirror filtering discard */
    CTC_DKIT_EPE_TUNNEL_MTU_CHK_DISCARD,                         /**< Tunnel MTU check discard */
    CTC_DKIT_EPE_INTERFACE_MTU_CHK_DISCARD,                      /**< Interface MTU check discard */
    CTC_DKIT_EPE_LOGIC_PORT_CHK_DISCARD,                         /**< Logic port check discard */
    CTC_DKIT_EPE_EGRESS_ACL_DISCARD,                             /**< Egress ACL deny */
    /* 20~29 */
    CTC_DKIT_EPE_EGRESS_QOS_DISCARD,                             /**< Egress QoS discard */
    CTC_DKIT_EPE_EGRESS_POLICING_DISCARD,                        /**< Egress policing discard */
    CTC_DKIT_EPE_CRC_ERR,                                        /**< Egress CRC error */
    CTC_DKIT_EPE_ROUTE_PAYLOAD_OPERATION_DISCARD,                /**< Route Payload operation no IP packet discard */
    CTC_DKIT_EPE_BRG_PAYLOAD_OPERATION_DISCARD,                  /**< Bridge payload operation bridge disable discard */
    CTC_DKIT_EPE_PT_LAYER4_OFFSET_LAGER_DISCARD,                 /**< Packet edit strip too large discard */
    CTC_DKIT_EPE_BFD_DISCARD,                                    /**< BFD discard */
    CTC_DKIT_EPE_PORT_REFLECTIVE_CHK_DISCARD,                    /**< Port reflective check discard */
    CTC_DKIT_EPE_IP_MPLS_TTL_CHK_ERR_DISCARD,                    /**< IP/MPLS TTL check error discard */
    CTC_DKIT_EPE_OAM_EGDE_PORT_DISCARD,                          /**< OAM edge port discard */
    /* 30~39*/
    CTC_DKIT_EPE_NAT_PT_ICMP_ERR,                                /**< NAT/PT ICMP error discard */
    CTC_DKIT_EPE_RESERVED0,                                             /**< Reserved*/
    CTC_DKIT_EPE_LOCAL_OAM_DISCARD,                              /**< local OAM discard */
    CTC_DKIT_EPE_OAM_FILTERING_DISCARD,                          /**< OAM filtering discard */
    CTC_DKIT_EPE_OAM_HASH_CONFILICT_DISCARD,                     /**< OAM hash confilict discard */
    CTC_DKIT_EPE_IPDA_EQUALS_TO_IPSA_DISCARD,                    /**< Same Mac Da Sa or IP da sa discard */
    CTC_DKIT_EPE_RESERVED1,                                      /**< Reserved */
    CTC_DKIT_EPE_TRILL_PAYLOAD_OPERATION_DISCARD,                /**< TRILL payload operation discard */
    CTC_DKIT_EPE_PBB_CHK_FAIL_DISCARD,                           /**< PBB check fail discard */
    CTC_DKIT_EPE_DS_NEXT_HOP_DATA_VIOLATE,                       /**< DsNextHop data violate */
    CTC_DKIT_EPE_DEST_VLAN_PTR_DISCARD,                          /**< destVlanPtr discard*/
    CTC_DKIT_EPE_DS_L3_EDIT_DATA_VIOLATE_1,                      /**< discard by DsL3Edit*/
    CTC_DKIT_EPE_DS_L3_EDIT_DATA_VIOLATE_2,                      /**< discard by DsL3Edit*/
    CTC_DKIT_EPE_DS_L3_EDIT_NAT_DATA_VIOLATE,                    /**< discard by DsL3EditNat */
    CTC_DKIT_EPE_DS_L2_EDIT_DATA_VIOLATE_1,                      /**< discard by DsL2Edit*/
    CTC_DKIT_EPE_DS_L2_EDIT_DATA_VIOLATE_2,                      /**< discard by DsL2Edit*/
    CTC_DKIT_EPE_PACKET_HEADER_C2C_TTL_ZERO,                     /**< PacketHeader C2C TTL zero */
    CTC_DKIT_EPE_PT_UDP_CHECKSUM_IS_ZERO,                        /**< PT UDP checksum is zero */
    CTC_DKIT_EPE_OAM_TO_LOCAL_DISCARD,                           /**< OAM to local discard */

    CTC_DKIT_EPE_HW_HAR_ADJ ,/**< some hardware error occurred at header adjust*/
    CTC_DKIT_EPE_HW_NEXT_HOP,/**< some hardware error occurred at nexthop mapper*/
    CTC_DKIT_EPE_HW_ACL_QOS,/**< some hardware error occurred when do ACL or QoS*/
    CTC_DKIT_EPE_HW_OAM ,/**< some hardware error occurred when do OAM process*/
    CTC_DKIT_EPE_HW_EDIT ,/**< some hardware error occurred at header edit*/
    CTC_DKIT_EPE_MAX,/**< */

    /*BSR*/
    CTC_DKIT_BSR_BUFSTORE_HW_ABORT              =0x0200,/**< hardware error at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_LEN_ERROR,                    /**< packet length error at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_SILENT,                    /**< hardware error at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_DATA_ERR, /**< data error at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_CHIP_MISMATCH, /**< chip mismatch at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_NO_BUFF,/**< no buffer at BUFSTORE, read PktErrStatsMem to confirm*/
    CTC_DKIT_BSR_BUFSTORE_HW_OTHER,/**< drop at BUFSTORE, read PktErrStatsMem to confirm*/

    CTC_DKIT_BSR_QMGR_CRITICAL,                         /**< critical packet discard at QMGR, read QMgrEnqDebugStats to confirm*/
    CTC_DKIT_BSR_QMGR_C2C,                              /**< C2C packet discard at QMGR, read QMgrEnqDebugStats to confirm*/
    CTC_DKIT_BSR_QMGR_IN_Q,                         /**< Enqueue discard at QMGR, read QMgrEnqDebugStats to confirm*/
    CTC_DKIT_BSR_QMGR_EGR_RESRC,                         /**< egress resource manager discard at QMGR, read QMgrEnqDebugStats to confirm*/
    CTC_DKIT_BSR_QMGR_OTHER,                            /**< drop at QMGR, read QMgrEnqDebugStats to confirm*/
    CTC_DKIT_BSR_MAX,/**< */

    /*NETRX*/
    CTC_DKIT_NETRX_NO_BUFFER,     /**< buffer is full, read NetRxDebugStats to confirm*/
    CTC_DKIT_NETRX_LEN_ERROR,     /**< packet length error, read NetRxDebugStats to confirm*/
    CTC_DKIT_NETRX_PKT_ERROR,     /**< packet or frame error, read NetRxDebugStats to confirm*/
    CTC_DKIT_NETRX_SOP_EOP,     /**< sop/eop error discard, read NetRxDebugStats to confirm*/
    CTC_DKIT_NETRX_MAX,/**< */

    /*NETTX*/
    CTC_DKIT_NETTX_MIN_LEN,     /**< packet length is too short, read NetTxDebugStats to confirm*/
    CTC_DKIT_NETTX_NO_BUFFER,     /**< buffer is full, read NetTxDebugStats to confirm*/
    CTC_DKIT_NETTX_SOP_EOP,     /**< sop/eop error discard, read NetTxDebugStats to confirm*/
    CTC_DKIT_NETTX_PI_ERROR,     /**< packet info error, read NetTxDebugStats to confirm*/
    CTC_DKIT_NETTX_MAX,/**< */

    /*OAM*/
    CTC_DKIT_OAM_HW_ERROR,                              /**< some hardware error occured*/
    CTC_DKIT_OAM_MAX,/**< */

    CTC_DKIT_DISCARD_MAX/**< */

};
typedef enum ctc_dkit_discard_reason_id_e ctc_dkit_discard_reason_id_t;


enum ctc_dkit_discard_sub_reason_id_e
{
    CTC_DKIT_SUB_DISCARD_INVALIED = 0x0,/**< no discard*/
    CTC_DKIT_SUB_DISCARD_AMBIGUOUS = 0x1,/**< the discard reason is ambiguous, try to use captured info*/
    CTC_DKIT_SUB_DISCARD_NEED_PARAM = 0x2/**< please input filter param to get the detail reason*/
};
typedef enum ctc_dkit_discard_sub_reason_id_e ctc_dkit_discard_sub_reason_id_t;

extern const char*
ctc_greatbelt_dkit_get_reason_desc(ctc_dkit_discard_reason_id_t reason_id);

extern const char*
ctc_greatbelt_dkit_get_sub_reason_desc(ctc_dkit_discard_sub_reason_id_t reason_id);



#ifdef __cplusplus
}
#endif

#endif




