/**********************************************************
 * ctc_api.c
 * Date:
 * Author: auto generate from include file
 **********************************************************/
/**********************************************************
 * 
 * Header file
 * 
 **********************************************************/
#include "ctc_api.h"
#include "ctcs_api.h"
/**********************************************************
 * 
 * Defines and macros
 * 
 **********************************************************/
/**********************************************************
 * 
 * Global and Declaration
 * 
 **********************************************************/
ctcs_api_t *ctc_api = NULL;
#ifdef HUMBER
extern ctcs_api_t ctc_humber_api;
#endif
#ifdef GREATBELT
extern ctcs_api_t ctc_greatbelt_api;
#endif
#ifdef GOLDENGATE
extern ctcs_api_t ctc_goldengate_api;
#endif
/**********************************************************
 * 
 * Functions
 * 
 **********************************************************/
int32 ctc_install_api()
{
    #ifdef HUMBER
    ctc_api = &ctc_humber_api;
    #endif
    #ifdef GREATBELT
    ctc_api = &ctc_greatbelt_api;
    #endif
    #ifdef GOLDENGATE
    ctc_api = &ctc_goldengate_api;
    #endif
    return CTC_E_NONE;
} 
int32 ctc_uninstall_api()
{
    ctc_api = NULL;
    return CTC_E_NONE;
}
/*##acl##*/
int32 ctc_acl_add_entry(uint32 group_id, ctc_acl_entry_t* acl_entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_add_entry ? ctc_api->ctcs_acl_add_entry(lchip, group_id, acl_entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_clear_stats(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_clear_stats ? ctc_api->ctcs_acl_clear_stats(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_copy_entry(ctc_acl_copy_entry_t* copy_entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_copy_entry ? ctc_api->ctcs_acl_copy_entry(lchip, copy_entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_create_group(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_create_group ? ctc_api->ctcs_acl_create_group(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_destroy_group(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_destroy_group ? ctc_api->ctcs_acl_destroy_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_get_group_info(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_get_group_info ? ctc_api->ctcs_acl_get_group_info(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_get_multi_entry(ctc_acl_query_t* query)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_get_multi_entry ? ctc_api->ctcs_acl_get_multi_entry(lchip, query) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_get_stats(uint32 entry_id, ctc_stats_basic_t* stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_get_stats ? ctc_api->ctcs_acl_get_stats(lchip, entry_id, stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_init(ctc_acl_global_cfg_t* acl_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_init ? ctc_api->ctcs_acl_init(lchip, acl_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_install_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_install_entry ? ctc_api->ctcs_acl_install_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_install_group(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_install_group ? ctc_api->ctcs_acl_install_group(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_remove_all_entry(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_remove_all_entry ? ctc_api->ctcs_acl_remove_all_entry(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_remove_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_remove_entry ? ctc_api->ctcs_acl_remove_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_set_entry_priority(uint32 entry_id, uint32 priority)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_set_entry_priority ? ctc_api->ctcs_acl_set_entry_priority(lchip, entry_id, priority) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_set_hash_field_sel(ctc_acl_hash_field_sel_t* field_sel)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_set_hash_field_sel ? ctc_api->ctcs_acl_set_hash_field_sel(lchip, field_sel) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_uninstall_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_uninstall_entry ? ctc_api->ctcs_acl_uninstall_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_uninstall_group(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_uninstall_group ? ctc_api->ctcs_acl_uninstall_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_acl_update_action(uint32 entry_id, ctc_acl_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_acl_update_action ? ctc_api->ctcs_acl_update_action(lchip, entry_id, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##aps##*/
int32 ctc_aps_create_aps_bridge_group(uint16 aps_bridge_group_id, ctc_aps_bridge_group_t* aps_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_create_aps_bridge_group ? ctc_api->ctcs_aps_create_aps_bridge_group(lchip, aps_bridge_group_id, aps_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_create_raps_mcast_group(uint16 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_create_raps_mcast_group ? ctc_api->ctcs_aps_create_raps_mcast_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_destroy_aps_bridge_group(uint16 aps_bridge_group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_destroy_aps_bridge_group ? ctc_api->ctcs_aps_destroy_aps_bridge_group(lchip, aps_bridge_group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_destroy_raps_mcast_group(uint16 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_destroy_raps_mcast_group ? ctc_api->ctcs_aps_destroy_raps_mcast_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_get_aps_bridge_protection_path(uint16 aps_bridge_group_id, uint16* gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_get_aps_bridge_protection_path ? ctc_api->ctcs_aps_get_aps_bridge_protection_path(lchip, aps_bridge_group_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_get_aps_bridge(uint16 aps_bridge_group_id, bool* protect_en)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_get_aps_bridge ? ctc_api->ctcs_aps_get_aps_bridge(lchip, aps_bridge_group_id, protect_en) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_get_aps_bridge_working_path(uint16 aps_bridge_group_id, uint16* gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_get_aps_bridge_working_path ? ctc_api->ctcs_aps_get_aps_bridge_working_path(lchip, aps_bridge_group_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_get_aps_select(uint16 aps_select_group_id, bool* protect_en)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_get_aps_select ? ctc_api->ctcs_aps_get_aps_select(lchip, aps_select_group_id, protect_en) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_init(void* aps_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_init ? ctc_api->ctcs_aps_init(lchip, aps_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_set_aps_bridge_group(uint16 aps_bridge_group_id, ctc_aps_bridge_group_t* aps_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_set_aps_bridge_group ? ctc_api->ctcs_aps_set_aps_bridge_group(lchip, aps_bridge_group_id, aps_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_set_aps_bridge_protection_path(uint16 aps_bridge_group_id, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_set_aps_bridge_protection_path ? ctc_api->ctcs_aps_set_aps_bridge_protection_path(lchip, aps_bridge_group_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_set_aps_bridge(uint16 aps_bridge_group_id, bool protect_en)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_set_aps_bridge ? ctc_api->ctcs_aps_set_aps_bridge(lchip, aps_bridge_group_id, protect_en) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_set_aps_bridge_working_path(uint16 aps_bridge_group_id, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_set_aps_bridge_working_path ? ctc_api->ctcs_aps_set_aps_bridge_working_path(lchip, aps_bridge_group_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_set_aps_select(uint16 aps_select_group_id, bool protect_en)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_set_aps_select ? ctc_api->ctcs_aps_set_aps_select(lchip, aps_select_group_id, protect_en) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aps_update_raps_mcast_member(ctc_raps_member_t* p_raps_mem)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aps_update_raps_mcast_member ? ctc_api->ctcs_aps_update_raps_mcast_member(lchip, p_raps_mem) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##bheader##*/
int32 ctc_bheader_decap(void* pkt, uint16 pkt_len, ctc_bheader_rx_info_t* rx_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bheader_decap ? ctc_api->ctcs_bheader_decap(lchip, pkt, pkt_len, rx_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_bheader_encap(ctc_bheader_tx_info_t* tx_info, void* pkt, uint16* pkt_len)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bheader_encap ? ctc_api->ctcs_bheader_encap(lchip, tx_info, pkt, pkt_len) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##bpe##*/
int32 ctc_bpe_get_intlk_en(bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bpe_get_intlk_en ? ctc_api->ctcs_bpe_get_intlk_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_bpe_get_port_extender(uint32 gport, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bpe_get_port_extender ? ctc_api->ctcs_bpe_get_port_extender(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_bpe_init(void* bpe_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bpe_init ? ctc_api->ctcs_bpe_init(lchip, bpe_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_bpe_set_intlk_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bpe_set_intlk_en ? ctc_api->ctcs_bpe_set_intlk_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_bpe_set_port_extender(uint32 gport, ctc_bpe_extender_t* p_extender)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_bpe_set_port_extender ? ctc_api->ctcs_bpe_set_port_extender(lchip, gport, p_extender) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##chip##*/
int32 ctc_chip_get_access_type(ctc_chip_access_type_t* p_access_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_get_access_type ? ctc_api->ctcs_chip_get_access_type(lchip, p_access_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_get_gpio_input(uint8 gpio_id, uint8* in_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_get_gpio_input ? ctc_api->ctcs_chip_get_gpio_input(lchip, gpio_id, in_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_get_mdio_clock(ctc_chip_mdio_type_t type, uint16* p_freq)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_get_mdio_clock ? ctc_api->ctcs_chip_get_mdio_clock(lchip, type, p_freq) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_get_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_get_phy_mapping ? ctc_api->ctcs_chip_get_phy_mapping(lchip, phy_mapping_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_get_property(uint8 lchip_id, ctc_chip_property_t chip_prop, void* p_value)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_get_property ? ctc_api->ctcs_chip_get_property(lchip_id, chip_prop, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_i2c_read(ctc_chip_i2c_read_t* p_i2c_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_i2c_read ? ctc_api->ctcs_chip_i2c_read(lchip, p_i2c_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_i2c_write(ctc_chip_i2c_write_t* i2c_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_i2c_write ? ctc_api->ctcs_chip_i2c_write(lchip, i2c_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_init(uint8 lchip_num)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_init ? ctc_api->ctcs_chip_init(lchip, lchip_num) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_mdio_read(uint8 lchip_id, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_mdio_read ? ctc_api->ctcs_chip_mdio_read(lchip_id, type, p_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_mdio_write(uint8 lchip_id, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_mdio_write ? ctc_api->ctcs_chip_mdio_write(lchip_id, type, p_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_read_gephy_reg(uint32 gport, ctc_chip_gephy_para_t* gephy_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_read_gephy_reg ? ctc_api->ctcs_chip_read_gephy_reg(lchip, gport, gephy_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_read_i2c_buf(ctc_chip_i2c_scan_read_t* p_i2c_scan_read)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_read_i2c_buf ? ctc_api->ctcs_chip_read_i2c_buf(lchip, p_i2c_scan_read) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_read_xgphy_reg(uint32 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_read_xgphy_reg ? ctc_api->ctcs_chip_read_xgphy_reg(lchip, gport, xgphy_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_access_type(ctc_chip_access_type_t access_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_access_type ? ctc_api->ctcs_chip_set_access_type(lchip, access_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_gephy_scan_special_reg(ctc_chip_ge_opt_reg_t* p_scan_opt, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_gephy_scan_special_reg ? ctc_api->ctcs_chip_set_gephy_scan_special_reg(lchip, p_scan_opt, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_gpio_mode(uint8 gpio_id, ctc_chip_gpio_mode_t mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_gpio_mode ? ctc_api->ctcs_chip_set_gpio_mode(lchip, gpio_id, mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_gpio_output(uint8 gpio_id, uint8 out_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_gpio_output ? ctc_api->ctcs_chip_set_gpio_output(lchip, gpio_id, out_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_hss12g_enable(uint8 lchip_id, uint8 macro_id, ctc_chip_serdes_mode_t mode, uint8 enable)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_hss12g_enable ? ctc_api->ctcs_chip_set_hss12g_enable(lchip_id, macro_id, mode, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_i2c_scan_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_i2c_scan_en ? ctc_api->ctcs_chip_set_i2c_scan_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_i2c_scan_para(ctc_chip_i2c_scan_t* p_i2c_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_i2c_scan_para ? ctc_api->ctcs_chip_set_i2c_scan_para(lchip, p_i2c_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_mac_led_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_mac_led_en ? ctc_api->ctcs_chip_set_mac_led_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_mac_led_mapping(ctc_chip_mac_led_mapping_t* p_led_map)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_mac_led_mapping ? ctc_api->ctcs_chip_set_mac_led_mapping(lchip, p_led_map) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_mac_led_mode(ctc_chip_led_para_t* p_led_para, ctc_chip_mac_led_type_t led_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_mac_led_mode ? ctc_api->ctcs_chip_set_mac_led_mode(lchip, p_led_para, led_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_mdio_clock(ctc_chip_mdio_type_t type, uint16 freq)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_mdio_clock ? ctc_api->ctcs_chip_set_mdio_clock(lchip, type, freq) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_phy_mapping ? ctc_api->ctcs_chip_set_phy_mapping(lchip, phy_mapping_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_phy_scan_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_phy_scan_en ? ctc_api->ctcs_chip_set_phy_scan_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_phy_scan_para(ctc_chip_phy_scan_ctrl_t* p_scan_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_phy_scan_para ? ctc_api->ctcs_chip_set_phy_scan_para(lchip, p_scan_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_property(uint8 lchip_id, ctc_chip_property_t chip_prop, void* p_value)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_property ? ctc_api->ctcs_chip_set_property(lchip_id, chip_prop, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_serdes_mode(uint8 lchip_id, ctc_chip_serdes_info_t* p_serdes_info)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_serdes_mode ? ctc_api->ctcs_chip_set_serdes_mode(lchip_id, p_serdes_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_set_xgphy_scan_special_reg(ctc_chip_xg_opt_reg_t* scan_opt, uint8 enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_set_xgphy_scan_special_reg ? ctc_api->ctcs_chip_set_xgphy_scan_special_reg(lchip, scan_opt, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_write_gephy_reg(uint32 gport, ctc_chip_gephy_para_t* gephy_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_write_gephy_reg ? ctc_api->ctcs_chip_write_gephy_reg(lchip, gport, gephy_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_chip_write_xgphy_reg(uint32 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_chip_write_xgphy_reg ? ctc_api->ctcs_chip_write_xgphy_reg(lchip, gport, xgphy_para) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_datapath_get_mode(uint8 gchip, ctc_chip_datapath_mode_t* pmode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_datapath_get_mode ? ctc_api->ctcs_datapath_get_mode(lchip, gchip, pmode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_data_path_init(ctc_chip_reset_cb reset_cb, ctc_chip_datapath_t* chip_datapath, char* datapath_config_file)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_data_path_init ? ctc_api->ctcs_data_path_init(lchip, reset_cb, chip_datapath, datapath_config_file) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_datapath_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_datapath_init ? ctc_api->ctcs_datapath_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_datapath_set_mode(uint8 gchip, ctc_chip_datapath_mode_t datapath_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_datapath_set_mode ? ctc_api->ctcs_datapath_set_mode(lchip, gchip, datapath_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_datapath_sim_init()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_datapath_sim_init ? ctc_api->ctcs_datapath_sim_init(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_chip_clock(uint16* freq)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_chip_clock ? ctc_api->ctcs_get_chip_clock(lchip, freq) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_chip_sensor(uint8 lchip_id, ctc_chip_sensor_type_t type, uint32* p_value)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_chip_sensor ? ctc_api->ctcs_get_chip_sensor(lchip_id, type, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_gchip_id(uint8 lchip_id, uint8* gchip_id)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_gchip_id ? ctc_api->ctcs_get_gchip_id(lchip_id, gchip_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_local_chip_num(uint8* lchip_num)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_local_chip_num ? ctc_api->ctcs_get_local_chip_num(lchip, lchip_num) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_serdes_mode(uint16 gserdes_id, ctc_serdes_mode_t* serdes_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_serdes_mode ? ctc_api->ctcs_get_serdes_mode(lchip, gserdes_id, serdes_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_init_pll_hss()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_init_pll_hss ? ctc_api->ctcs_init_pll_hss(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parity_error_init()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parity_error_init ? ctc_api->ctcs_parity_error_init(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parse_datapath(char* datapath_config_file)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parse_datapath ? ctc_api->ctcs_parse_datapath(lchip, datapath_config_file) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_chip_global_cfg(ctc_chip_global_cfg_t* chip_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_chip_global_cfg ? ctc_api->ctcs_set_chip_global_cfg(lchip, chip_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_gchip_id(uint8 lchip_id, uint8 gchip_id)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_gchip_id ? ctc_api->ctcs_set_gchip_id(lchip_id, gchip_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_serdes_mode(uint16 gserdes_id, ctc_serdes_mode_t serdes_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_serdes_mode ? ctc_api->ctcs_set_serdes_mode(lchip, gserdes_id, serdes_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##cpu_traffic##*/
int32 ctc_cpu_traffic_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_cpu_traffic_init ? ctc_api->ctcs_cpu_traffic_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_cpu_traffic_set_exception(uint8 excp, uint16 dest_id, ctc_excp_dest_type_t dest_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_cpu_traffic_set_exception ? ctc_api->ctcs_cpu_traffic_set_exception(lchip, excp, dest_id, dest_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_cpu_traffic_set_fatal_exception(uint8 excp, uint16 dest_id, ctc_excp_dest_type_t dest_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_cpu_traffic_set_fatal_exception ? ctc_api->ctcs_cpu_traffic_set_fatal_exception(lchip, excp, dest_id, dest_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##dma##*/
int32 ctc_dma_init(ctc_dma_global_cfg_t* dma_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_dma_init ? ctc_api->ctcs_dma_init(lchip, dma_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_dma_rw_table(ctc_dma_tbl_rw_t* tbl_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_dma_rw_table ? ctc_api->ctcs_dma_rw_table(lchip, tbl_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_dma_tx_pkt(ctc_pkt_tx_t* tx_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_dma_tx_pkt ? ctc_api->ctcs_dma_tx_pkt(lchip, tx_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##efd##*/
int32 ctc_efd_get_global_ctl(ctc_efd_global_control_type_t type, void* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_efd_get_global_ctl ? ctc_api->ctcs_efd_get_global_ctl(lchip, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_efd_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_efd_init ? ctc_api->ctcs_efd_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_efd_register_cb(ctc_efd_fn_t callback, void* userdata)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_efd_register_cb ? ctc_api->ctcs_efd_register_cb(lchip, callback, userdata) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_efd_set_global_ctl(ctc_efd_global_control_type_t type, void* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_efd_set_global_ctl ? ctc_api->ctcs_efd_set_global_ctl(lchip, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##ftm##*/
int32 ctc_ftm_get_alloc_info(void* profile_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ftm_get_alloc_info ? ctc_api->ctcs_ftm_get_alloc_info(lchip, profile_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ftm_mem_alloc(ctc_ftm_profile_info_t* ctc_profile_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ftm_mem_alloc ? ctc_api->ctcs_ftm_mem_alloc(lchip, ctc_profile_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ftm_set_default_profile(ctc_ftm_profile_info_t* ctc_profile_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ftm_set_default_profile ? ctc_api->ctcs_ftm_set_default_profile(lchip, ctc_profile_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ftm_show_alloc_info()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ftm_show_alloc_info ? ctc_api->ctcs_ftm_show_alloc_info(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##internal_port##*/
int32 ctc_alloc_internal_port(ctc_internal_port_assign_para_t* port_assign)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_alloc_internal_port ? ctc_api->ctcs_alloc_internal_port(lchip, port_assign) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_free_internal_port(ctc_internal_port_assign_para_t* port_assign)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_free_internal_port ? ctc_api->ctcs_free_internal_port(lchip, port_assign) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_internal_port_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_internal_port_init ? ctc_api->ctcs_internal_port_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_internal_port(ctc_internal_port_assign_para_t* port_assign)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_internal_port ? ctc_api->ctcs_set_internal_port(lchip, port_assign) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##interrupt##*/
int32 ctc_interrupt_clear_fatal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_clear_fatal_intr ? ctc_api->ctcs_interrupt_clear_fatal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_clear_normal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_clear_normal_intr ? ctc_api->ctcs_interrupt_clear_normal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_clear_status(uint8 lchip_id, ctc_intr_type_t* p_type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_clear_status ? ctc_api->ctcs_interrupt_clear_status(lchip_id, p_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_clear_sub_normal_intr(uint8 lchip_id, ctc_interrupt_normal_intr_type_t type, uint8 bit_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_clear_sub_normal_intr ? ctc_api->ctcs_interrupt_clear_sub_normal_intr(lchip_id, type, bit_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_deinit()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_deinit ? ctc_api->ctcs_interrupt_deinit(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_disable_fatal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_disable_fatal_intr ? ctc_api->ctcs_interrupt_disable_fatal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_disable_normal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_disable_normal_intr ? ctc_api->ctcs_interrupt_disable_normal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_disable_sub_normal_intr(uint8 lchip_id, ctc_interrupt_normal_intr_type_t type, uint8 bit_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_disable_sub_normal_intr ? ctc_api->ctcs_interrupt_disable_sub_normal_intr(lchip_id, type, bit_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_enable_fatal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_enable_fatal_intr ? ctc_api->ctcs_interrupt_enable_fatal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_enable_normal_intr(uint8 lchip_id, uint8 type)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_enable_normal_intr ? ctc_api->ctcs_interrupt_enable_normal_intr(lchip_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_enable_sub_normal_intr(uint8 lchip_id, ctc_interrupt_normal_intr_type_t type, uint8 bit_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_enable_sub_normal_intr ? ctc_api->ctcs_interrupt_enable_sub_normal_intr(lchip_id, type, bit_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_get_en(uint8 lchip_id, ctc_intr_type_t* p_type, uint32* p_enable)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_get_en ? ctc_api->ctcs_interrupt_get_en(lchip_id, p_type, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_get_fatal_intr_status(uint8 lchip_id, uint8 type, ctc_interrupt_fatal_intr_status_t* status)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_get_fatal_intr_status ? ctc_api->ctcs_interrupt_get_fatal_intr_status(lchip_id, type, status) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_get_normal_all_intr_status(uint8 lchip_id, uint32* p_bitmap)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_get_normal_all_intr_status ? ctc_api->ctcs_interrupt_get_normal_all_intr_status(lchip_id, p_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_get_normal_intr_status(uint8 lchip_id, uint8 type, bool* p_enable)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_get_normal_intr_status ? ctc_api->ctcs_interrupt_get_normal_intr_status(lchip_id, type, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_get_status(uint8 lchip_id, ctc_intr_type_t* p_type, ctc_intr_status_t* p_status)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_get_status ? ctc_api->ctcs_interrupt_get_status(lchip_id, p_type, p_status) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_init ? ctc_api->ctcs_interrupt_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_reg_init_end()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_reg_init_end ? ctc_api->ctcs_interrupt_reg_init_end(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_reg_init_start()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_reg_init_start ? ctc_api->ctcs_interrupt_reg_init_start(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_register_event_cb(ctc_interrupt_event_t event, CTC_INTERRUPT_EVENT_FUNC cb)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_register_event_cb ? ctc_api->ctcs_interrupt_register_event_cb(lchip, event, cb) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_interrupt_set_en(uint8 lchip_id, ctc_intr_type_t* p_type, uint32 enable)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_interrupt_set_en ? ctc_api->ctcs_interrupt_set_en(lchip_id, p_type, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##ipfix##*/
int32 ctc_ipfix_add_entry(ctc_ipfix_data_t* p_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_add_entry ? ctc_api->ctcs_ipfix_add_entry(lchip, p_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_delete_entry(ctc_ipfix_data_t* p_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_delete_entry ? ctc_api->ctcs_ipfix_delete_entry(lchip, p_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_get_global_cfg(ctc_ipfix_global_cfg_t* ipfix_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_get_global_cfg ? ctc_api->ctcs_ipfix_get_global_cfg(lchip, ipfix_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_get_port_cfg(uint32 gport,ctc_ipfix_port_cfg_t* ipfix_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_get_port_cfg ? ctc_api->ctcs_ipfix_get_port_cfg(lchip, gport, ipfix_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_init ? ctc_api->ctcs_ipfix_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_register_cb(ctc_ipfix_fn_t callback,void* userdata)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_register_cb ? ctc_api->ctcs_ipfix_register_cb(lchip, callback, userdata) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_set_global_cfg(ctc_ipfix_global_cfg_t* ipfix_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_set_global_cfg ? ctc_api->ctcs_ipfix_set_global_cfg(lchip, ipfix_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_set_hash_field_sel(ctc_ipfix_hash_field_sel_t* field_sel)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_set_hash_field_sel ? ctc_api->ctcs_ipfix_set_hash_field_sel(lchip, field_sel) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_set_port_cfg(uint32 gport,ctc_ipfix_port_cfg_t* ipfix_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_set_port_cfg ? ctc_api->ctcs_ipfix_set_port_cfg(lchip, gport, ipfix_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipfix_traverse(ctc_ipfix_traverse_fn fn, ctc_ipfix_traverse_t* p_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipfix_traverse ? ctc_api->ctcs_ipfix_traverse(lchip, fn, p_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##ipmc##*/
int32 ctc_ipmc_add_default_entry(uint8 ip_version, ctc_ipmc_default_action_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_add_default_entry ? ctc_api->ctcs_ipmc_add_default_entry(lchip, ip_version, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_add_group(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_add_group ? ctc_api->ctcs_ipmc_add_group(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_add_member(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_add_member ? ctc_api->ctcs_ipmc_add_member(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_add_rp_intf(ctc_ipmc_rp_t* p_rp)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_add_rp_intf ? ctc_api->ctcs_ipmc_add_rp_intf(lchip, p_rp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_clear_stats(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_clear_stats ? ctc_api->ctcs_ipmc_clear_stats(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_get_group_info(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_get_group_info ? ctc_api->ctcs_ipmc_get_group_info(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_get_mcast_force_route(ctc_ipmc_force_route_t* p_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_get_mcast_force_route ? ctc_api->ctcs_ipmc_get_mcast_force_route(lchip, p_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_get_stats(ctc_ipmc_group_info_t* p_group, ctc_stats_basic_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_get_stats ? ctc_api->ctcs_ipmc_get_stats(lchip, p_group, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_init(void* ipmc_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_init ? ctc_api->ctcs_ipmc_init(lchip, ipmc_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_remove_group(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_remove_group ? ctc_api->ctcs_ipmc_remove_group(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_remove_member(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_remove_member ? ctc_api->ctcs_ipmc_remove_member(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_remove_rp_intf(ctc_ipmc_rp_t* p_rp)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_remove_rp_intf ? ctc_api->ctcs_ipmc_remove_rp_intf(lchip, p_rp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_set_mcast_force_route(ctc_ipmc_force_route_t* p_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_set_mcast_force_route ? ctc_api->ctcs_ipmc_set_mcast_force_route(lchip, p_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_traverse(uint8 ip_ver, ctc_ipmc_traverse_fn fn, void* user_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_traverse ? ctc_api->ctcs_ipmc_traverse(lchip, ip_ver, fn, user_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipmc_update_rpf(ctc_ipmc_group_info_t* p_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipmc_update_rpf ? ctc_api->ctcs_ipmc_update_rpf(lchip, p_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##ipuc##*/
int32 ctc_ipuc_add_default_entry(uint8 ip_ver, uint32 nh_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_add_default_entry ? ctc_api->ctcs_ipuc_add_default_entry(lchip, ip_ver, nh_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_add_nat_sa(ctc_ipuc_nat_sa_param_t* p_ipuc_nat_sa_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_add_nat_sa ? ctc_api->ctcs_ipuc_add_nat_sa(lchip, p_ipuc_nat_sa_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_add_tunnel(ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_add_tunnel ? ctc_api->ctcs_ipuc_add_tunnel(lchip, p_ipuc_tunnel_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_add(ctc_ipuc_param_t* p_ipuc_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_add ? ctc_api->ctcs_ipuc_add(lchip, p_ipuc_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_arrange_fragment(void* p_arrange_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_arrange_fragment ? ctc_api->ctcs_ipuc_arrange_fragment(lchip, p_arrange_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_cpu_rpf_check(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_cpu_rpf_check ? ctc_api->ctcs_ipuc_cpu_rpf_check(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_get(ctc_ipuc_param_t* p_ipuc_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_get ? ctc_api->ctcs_ipuc_get(lchip, p_ipuc_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_init(void* ipuc_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_init ? ctc_api->ctcs_ipuc_init(lchip, ipuc_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_ipv6_enable(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_ipv6_enable ? ctc_api->ctcs_ipuc_ipv6_enable(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_remove_nat_sa(ctc_ipuc_nat_sa_param_t* p_ipuc_nat_sa_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_remove_nat_sa ? ctc_api->ctcs_ipuc_remove_nat_sa(lchip, p_ipuc_nat_sa_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_remove_tunnel(ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_remove_tunnel ? ctc_api->ctcs_ipuc_remove_tunnel(lchip, p_ipuc_tunnel_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_remove(ctc_ipuc_param_t* p_ipuc_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_remove ? ctc_api->ctcs_ipuc_remove(lchip, p_ipuc_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_set_global_property(ctc_ipuc_global_property_t* p_global_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_set_global_property ? ctc_api->ctcs_ipuc_set_global_property(lchip, p_global_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_set_lookup_ctl(ctc_ipuc_global_property_t* p_global_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_set_lookup_ctl ? ctc_api->ctcs_ipuc_set_lookup_ctl(lchip, p_global_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_set_route_ctl(ctc_ipuc_global_property_t* p_global_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_set_route_ctl ? ctc_api->ctcs_ipuc_set_route_ctl(lchip, p_global_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ipuc_traverse(uint8 ip_ver, void* fn, void* data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ipuc_traverse ? ctc_api->ctcs_ipuc_traverse(lchip, ip_ver, fn, data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##l2##*/
int32 ctc_l2_add_default_entry(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_add_default_entry ? ctc_api->ctcs_l2_add_default_entry(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_add_fdb(ctc_l2_addr_t* l2_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_add_fdb ? ctc_api->ctcs_l2_add_fdb(lchip, l2_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_add_fdb_with_nexthop(ctc_l2_addr_t* l2_addr, uint32 nhp_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_add_fdb_with_nexthop ? ctc_api->ctcs_l2_add_fdb_with_nexthop(lchip, l2_addr, nhp_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_add_port_to_default_entry(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_add_port_to_default_entry ? ctc_api->ctcs_l2_add_port_to_default_entry(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_fdb_init(void* l2_fdb_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_fdb_init ? ctc_api->ctcs_l2_fdb_init(lchip, l2_fdb_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_flush_fdb(ctc_l2_flush_fdb_t* pFlush)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_flush_fdb ? ctc_api->ctcs_l2_flush_fdb(lchip, pFlush) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_default_entry_features(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_default_entry_features ? ctc_api->ctcs_l2_get_default_entry_features(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_fdb_by_index(uint32 index, ctc_l2_addr_t* l2_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_fdb_by_index ? ctc_api->ctcs_l2_get_fdb_by_index(lchip, index, l2_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_fdb_count(ctc_l2_fdb_query_t* pQuery)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_fdb_count ? ctc_api->ctcs_l2_get_fdb_count(lchip, pQuery) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_fdb_entry(ctc_l2_fdb_query_t* pQuery, ctc_l2_fdb_query_rst_t* query_rst)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_fdb_entry ? ctc_api->ctcs_l2_get_fdb_entry(lchip, pQuery, query_rst) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_fid_property(uint16 fid_id, ctc_l2_fid_property_t property, uint32* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_fid_property ? ctc_api->ctcs_l2_get_fid_property(lchip, fid_id, property, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_get_nhid_by_logic_port(uint16 logic_port, uint32* nhp_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_get_nhid_by_logic_port ? ctc_api->ctcs_l2_get_nhid_by_logic_port(lchip, logic_port, nhp_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2mcast_add_addr(ctc_l2_mcast_addr_t* l2mc_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2mcast_add_addr ? ctc_api->ctcs_l2mcast_add_addr(lchip, l2mc_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2mcast_add_member(ctc_l2_mcast_addr_t* l2mc_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2mcast_add_member ? ctc_api->ctcs_l2mcast_add_member(lchip, l2mc_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2mcast_remove_addr(ctc_l2_mcast_addr_t* l2mc_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2mcast_remove_addr ? ctc_api->ctcs_l2mcast_remove_addr(lchip, l2mc_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2mcast_remove_member(ctc_l2_mcast_addr_t* l2mc_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2mcast_remove_member ? ctc_api->ctcs_l2mcast_remove_member(lchip, l2mc_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_remove_default_entry(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_remove_default_entry ? ctc_api->ctcs_l2_remove_default_entry(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_remove_fdb_by_index(uint32 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_remove_fdb_by_index ? ctc_api->ctcs_l2_remove_fdb_by_index(lchip, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_remove_fdb(ctc_l2_addr_t* l2_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_remove_fdb ? ctc_api->ctcs_l2_remove_fdb(lchip, l2_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_remove_port_from_default_entry(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_remove_port_from_default_entry ? ctc_api->ctcs_l2_remove_port_from_default_entry(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_set_default_entry_features(ctc_l2dflt_addr_t* l2dflt_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_set_default_entry_features ? ctc_api->ctcs_l2_set_default_entry_features(lchip, l2dflt_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_set_fid_property(uint16 fid_id, ctc_l2_fid_property_t property, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_set_fid_property ? ctc_api->ctcs_l2_set_fid_property(lchip, fid_id, property, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2_set_nhid_by_logic_port(uint16 logic_port, uint32 nhp_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2_set_nhid_by_logic_port ? ctc_api->ctcs_l2_set_nhid_by_logic_port(lchip, logic_port, nhp_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##l3if##*/
int32 ctc_l3if_add_ecmp_if_member(uint16 ecmp_if_id, uint16 l3if_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_add_ecmp_if_member ? ctc_api->ctcs_l3if_add_ecmp_if_member(lchip, ecmp_if_id, l3if_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_add_vmac_low_8bit(uint16 l3if_id, ctc_l3if_vmac_t* p_l3if_vmac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_add_vmac_low_8bit ? ctc_api->ctcs_l3if_add_vmac_low_8bit(lchip, l3if_id, p_l3if_vmac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_create_ecmp_if(ctc_l3if_ecmp_if_t* p_ecmp_if)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_create_ecmp_if ? ctc_api->ctcs_l3if_create_ecmp_if(lchip, p_ecmp_if) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_create(uint16 l3if_id, ctc_l3if_t* p_l3_if)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_create ? ctc_api->ctcs_l3if_create(lchip, l3if_id, p_l3_if) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_destory_ecmp_if(uint16 ecmp_if_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_destory_ecmp_if ? ctc_api->ctcs_l3if_destory_ecmp_if(lchip, ecmp_if_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_destory(uint16 l3if_id, ctc_l3if_t* p_l3_if)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_destory ? ctc_api->ctcs_l3if_destory(lchip, l3if_id, p_l3_if) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_interface_router_mac(uint16 l3if_id, ctc_l3if_router_mac_t* router_mac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_interface_router_mac ? ctc_api->ctcs_l3if_get_interface_router_mac(lchip, l3if_id, router_mac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_l3if_id(ctc_l3if_t* p_l3_if, uint16* l3if_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_l3if_id ? ctc_api->ctcs_l3if_get_l3if_id(lchip, p_l3_if, l3if_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_property(uint16 l3if_id, ctc_l3if_property_t l3if_prop, uint32* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_property ? ctc_api->ctcs_l3if_get_property(lchip, l3if_id, l3if_prop, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_router_mac(mac_addr_t mac_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_router_mac ? ctc_api->ctcs_l3if_get_router_mac(lchip, mac_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_vmac_low_8bit(uint16 l3if_id, ctc_l3if_vmac_t* p_l3if_vmac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_vmac_low_8bit ? ctc_api->ctcs_l3if_get_vmac_low_8bit(lchip, l3if_id, p_l3if_vmac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_get_vmac_prefix(ctc_l3if_route_mac_type_t prefix_type, mac_addr_t mac_40bit)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_get_vmac_prefix ? ctc_api->ctcs_l3if_get_vmac_prefix(lchip, prefix_type, mac_40bit) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_init(void* l3if_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_init ? ctc_api->ctcs_l3if_init(lchip, l3if_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_remove_ecmp_if_member(uint16 ecmp_if_id, uint16 l3if_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_remove_ecmp_if_member ? ctc_api->ctcs_l3if_remove_ecmp_if_member(lchip, ecmp_if_id, l3if_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_remove_vmac_low_8bit(uint16 l3if_id, ctc_l3if_vmac_t* p_l3if_vmac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_remove_vmac_low_8bit ? ctc_api->ctcs_l3if_remove_vmac_low_8bit(lchip, l3if_id, p_l3if_vmac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_set_interface_router_mac(uint16 l3if_id, ctc_l3if_router_mac_t router_mac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_set_interface_router_mac ? ctc_api->ctcs_l3if_set_interface_router_mac(lchip, l3if_id, router_mac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_set_property(uint16 l3if_id, ctc_l3if_property_t l3if_prop, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_set_property ? ctc_api->ctcs_l3if_set_property(lchip, l3if_id, l3if_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_set_router_mac(mac_addr_t mac_addr)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_set_router_mac ? ctc_api->ctcs_l3if_set_router_mac(lchip, mac_addr) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_set_vmac_prefix(ctc_l3if_route_mac_type_t prefix_type, mac_addr_t mac_40bit)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_set_vmac_prefix ? ctc_api->ctcs_l3if_set_vmac_prefix(lchip, prefix_type, mac_40bit) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3if_set_vrf_stats_en(ctc_l3if_vrf_stats_t* p_vrf_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3if_set_vrf_stats_en ? ctc_api->ctcs_l3if_set_vrf_stats_en(lchip, p_vrf_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##learning_aging##*/
int32 ctc_aging_get_aging_status(uint32 aging_index, ctc_aging_status_t* age_status)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aging_get_aging_status ? ctc_api->ctcs_aging_get_aging_status(lchip, aging_index, age_status) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aging_get_property(ctc_aging_table_type_t tbl_type, ctc_aging_prop_t aging_prop, uint32* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aging_get_property ? ctc_api->ctcs_aging_get_property(lchip, tbl_type, aging_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aging_read_aging_fifo(ctc_aging_fifo_info_t* fifo_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aging_read_aging_fifo ? ctc_api->ctcs_aging_read_aging_fifo(lchip, fifo_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_aging_set_property(ctc_aging_table_type_t tbl_type, ctc_aging_prop_t aging_prop, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_aging_set_property ? ctc_api->ctcs_aging_set_property(lchip, tbl_type, aging_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_learning_action(ctc_learning_action_info_t* p_learning_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_learning_action ? ctc_api->ctcs_get_learning_action(lchip, p_learning_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_learning_aging_init(void* global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_learning_aging_init ? ctc_api->ctcs_learning_aging_init(lchip, global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_learning_clear_learning_cache(uint16 entry_vld_bitmap)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_learning_clear_learning_cache ? ctc_api->ctcs_learning_clear_learning_cache(lchip, entry_vld_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_learning_get_cache_entry_valid_bitmap(uint16* entry_vld_bitmap)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_learning_get_cache_entry_valid_bitmap ? ctc_api->ctcs_learning_get_cache_entry_valid_bitmap(lchip, entry_vld_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_learning_read_learning_cache(uint16 entry_vld_bitmap, ctc_learning_cache_t* l2_lc)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_learning_read_learning_cache ? ctc_api->ctcs_learning_read_learning_cache(lchip, entry_vld_bitmap, l2_lc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_learning_action(ctc_learning_action_info_t* p_learning_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_learning_action ? ctc_api->ctcs_set_learning_action(lchip, p_learning_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##linkagg##*/
int32 ctc_linkagg_add_port(uint8 tid, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_add_port ? ctc_api->ctcs_linkagg_add_port(lchip, tid, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_create(ctc_linkagg_group_t* p_linkagg_grp)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_create ? ctc_api->ctcs_linkagg_create(lchip, p_linkagg_grp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_destroy(uint8 tid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_destroy ? ctc_api->ctcs_linkagg_destroy(lchip, tid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_get_1st_local_port(uint8 tid, uint16* p_gport, uint8* local_cnt)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_get_1st_local_port ? ctc_api->ctcs_linkagg_get_1st_local_port(lchip, tid, p_gport, local_cnt) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_get_max_mem_num(uint8* max_num)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_get_max_mem_num ? ctc_api->ctcs_linkagg_get_max_mem_num(lchip, max_num) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_get_member_ports(uint8 tid, uint16* p_gports, uint8* cnt)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_get_member_ports ? ctc_api->ctcs_linkagg_get_member_ports(lchip, tid, p_gports, cnt) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_get_psc(ctc_linkagg_psc_t* psc)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_get_psc ? ctc_api->ctcs_linkagg_get_psc(lchip, psc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_init(void* linkagg_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_init ? ctc_api->ctcs_linkagg_init(lchip, linkagg_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_remove_port(uint8 tid, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_remove_port ? ctc_api->ctcs_linkagg_remove_port(lchip, tid, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_linkagg_set_psc(ctc_linkagg_psc_t* psc)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_linkagg_set_psc ? ctc_api->ctcs_linkagg_set_psc(lchip, psc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##mirror##*/
int32 ctc_mirror_add_session(ctc_mirror_dest_t* mirror)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_add_session ? ctc_api->ctcs_mirror_add_session(lchip, mirror) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_get_mirror_discard(ctc_direction_t dir, ctc_mirror_discard_t discard_flag, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_get_mirror_discard ? ctc_api->ctcs_mirror_get_mirror_discard(lchip, dir, discard_flag, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_get_port_info(uint32 gport, ctc_direction_t dir, bool* enable, uint8* session_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_get_port_info ? ctc_api->ctcs_mirror_get_port_info(lchip, gport, dir, enable, session_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_get_vlan_info(uint16 vlan_id, ctc_direction_t dir, bool* enable, uint8* session_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_get_vlan_info ? ctc_api->ctcs_mirror_get_vlan_info(lchip, vlan_id, dir, enable, session_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_init(void* mirror_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_init ? ctc_api->ctcs_mirror_init(lchip, mirror_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_remove_session(ctc_mirror_dest_t* mirror)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_remove_session ? ctc_api->ctcs_mirror_remove_session(lchip, mirror) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_erspan_psc(ctc_mirror_erspan_psc_t* psc)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_erspan_psc ? ctc_api->ctcs_mirror_set_erspan_psc(lchip, psc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_escape_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_escape_en ? ctc_api->ctcs_mirror_set_escape_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_escape_mac(ctc_mirror_rspan_escape_t* escape)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_escape_mac ? ctc_api->ctcs_mirror_set_escape_mac(lchip, escape) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_mirror_discard(ctc_direction_t dir, uint16 discard_flag, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_mirror_discard ? ctc_api->ctcs_mirror_set_mirror_discard(lchip, dir, discard_flag, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_port_en(uint32 gport, ctc_direction_t dir, bool enable, uint8 session_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_port_en ? ctc_api->ctcs_mirror_set_port_en(lchip, gport, dir, enable, session_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mirror_set_vlan_en(uint16 vlan_id, ctc_direction_t dir, bool enable, uint8 session_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mirror_set_vlan_en ? ctc_api->ctcs_mirror_set_vlan_en(lchip, vlan_id, dir, enable, session_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##monitor##*/
int32 ctc_monitor_clear_watermark(ctc_monitor_watermark_t* p_watermark)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_clear_watermark ? ctc_api->ctcs_monitor_clear_watermark(lchip, p_watermark) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_get_config(ctc_monitor_config_t* p_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_get_config ? ctc_api->ctcs_monitor_get_config(lchip, p_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_get_watermark(ctc_monitor_watermark_t* p_watermark)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_get_watermark ? ctc_api->ctcs_monitor_get_watermark(lchip, p_watermark) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_init ? ctc_api->ctcs_monitor_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_register_cb(ctc_monitor_fn_t callback,void* userdata)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_register_cb ? ctc_api->ctcs_monitor_register_cb(lchip, callback, userdata) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_set_config(ctc_monitor_config_t* p_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_set_config ? ctc_api->ctcs_monitor_set_config(lchip, p_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_monitor_set_global_config(ctc_monitor_glb_cfg_t* p_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_monitor_set_global_config ? ctc_api->ctcs_monitor_set_global_config(lchip, p_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##mpls##*/
int32 ctc_mpls_add_ilm(ctc_mpls_ilm_t* p_mpls_ilm)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_add_ilm ? ctc_api->ctcs_mpls_add_ilm(lchip, p_mpls_ilm) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_add_l2vpn_pw(ctc_mpls_l2vpn_pw_t* p_mpls_pw)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_add_l2vpn_pw ? ctc_api->ctcs_mpls_add_l2vpn_pw(lchip, p_mpls_pw) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_add_stats(ctc_mpls_stats_index_t* stats_index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_add_stats ? ctc_api->ctcs_mpls_add_stats(lchip, stats_index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_clear_in_sqn(uint8 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_clear_in_sqn ? ctc_api->ctcs_mpls_clear_in_sqn(lchip, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_clear_out_sqn(uint8 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_clear_out_sqn ? ctc_api->ctcs_mpls_clear_out_sqn(lchip, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_clear_stats(ctc_mpls_stats_index_t* stats_index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_clear_stats ? ctc_api->ctcs_mpls_clear_stats(lchip, stats_index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_del_ilm(ctc_mpls_ilm_t* p_mpls_ilm)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_del_ilm ? ctc_api->ctcs_mpls_del_ilm(lchip, p_mpls_ilm) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_del_l2vpn_pw(ctc_mpls_l2vpn_pw_t* p_mpls_pw)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_del_l2vpn_pw ? ctc_api->ctcs_mpls_del_l2vpn_pw(lchip, p_mpls_pw) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_get_ilm(uint32* nh_id, ctc_mpls_ilm_t* p_mpls_ilm)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_get_ilm ? ctc_api->ctcs_mpls_get_ilm(lchip, nh_id, p_mpls_ilm) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_get_stats(ctc_mpls_stats_index_t* stats_index, ctc_stats_basic_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_get_stats ? ctc_api->ctcs_mpls_get_stats(lchip, stats_index, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_init(ctc_mpls_init_t* p_mpls_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_init ? ctc_api->ctcs_mpls_init(lchip, p_mpls_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_remove_stats(ctc_mpls_stats_index_t* stats_index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_remove_stats ? ctc_api->ctcs_mpls_remove_stats(lchip, stats_index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_set_ilm_property(ctc_mpls_property_t* p_mpls_pro)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_set_ilm_property ? ctc_api->ctcs_mpls_set_ilm_property(lchip, p_mpls_pro) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mpls_update_ilm(ctc_mpls_ilm_t* p_mpls_ilm)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mpls_update_ilm ? ctc_api->ctcs_mpls_update_ilm(lchip, p_mpls_ilm) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##nexthop##*/
int32 ctc_nexthop_init(ctc_nh_global_cfg_t* nh_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nexthop_init ? ctc_api->ctcs_nexthop_init(lchip, nh_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_ecmp(uint32 nhid, ctc_nh_ecmp_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_ecmp ? ctc_api->ctcs_nh_add_ecmp(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_iloop(uint32 nhid, ctc_loopback_nexthop_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_iloop ? ctc_api->ctcs_nh_add_iloop(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_ip_tunnel(uint32 nhid, ctc_ip_tunnel_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_ip_tunnel ? ctc_api->ctcs_nh_add_ip_tunnel(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_ipuc(uint32 nhid, ctc_ip_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_ipuc ? ctc_api->ctcs_nh_add_ipuc(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_l2uc(uint32 gport, ctc_nh_param_brguc_sub_type_t nh_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_l2uc ? ctc_api->ctcs_nh_add_l2uc(lchip, gport, nh_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_mcast(uint32 nhid, ctc_mcast_nh_param_group_t* p_nh_mcast_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_mcast ? ctc_api->ctcs_nh_add_mcast(lchip, nhid, p_nh_mcast_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_misc(uint32 nhid, ctc_misc_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_misc ? ctc_api->ctcs_nh_add_misc(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_mpls_tunnel_label(uint16 tunnel_id, ctc_mpls_nexthop_tunnel_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_mpls_tunnel_label ? ctc_api->ctcs_nh_add_mpls_tunnel_label(lchip, tunnel_id, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_mpls(uint32 nhid, ctc_mpls_nexthop_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_mpls ? ctc_api->ctcs_nh_add_mpls(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_nexthop_mac(ctc_nh_nexthop_mac_param_t* p_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_nexthop_mac ? ctc_api->ctcs_nh_add_nexthop_mac(lchip, p_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_rspan(uint32 nhid, ctc_rspan_nexthop_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_rspan ? ctc_api->ctcs_nh_add_rspan(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_stats(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_stats ? ctc_api->ctcs_nh_add_stats(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_add_xlate(uint32 nhid, ctc_vlan_edit_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_add_xlate ? ctc_api->ctcs_nh_add_xlate(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_clear_stats(ctc_nh_stats_info_t* stats_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_clear_stats ? ctc_api->ctcs_nh_clear_stats(lchip, stats_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_del_stats(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_del_stats ? ctc_api->ctcs_nh_del_stats(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_l2uc(uint32 gport, ctc_nh_param_brguc_sub_type_t nh_type, uint32* nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_l2uc ? ctc_api->ctcs_nh_get_l2uc(lchip, gport, nh_type, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_max_ecmp(uint16* max_ecmp)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_max_ecmp ? ctc_api->ctcs_nh_get_max_ecmp(lchip, max_ecmp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_mcast_nh(uint32 group_id, uint32* p_nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_mcast_nh ? ctc_api->ctcs_nh_get_mcast_nh(lchip, group_id, p_nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_nh_info(uint32 nhid, ctc_nh_info_t* p_nh_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_nh_info ? ctc_api->ctcs_nh_get_nh_info(lchip, nhid, p_nh_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_resolved_dsnh_offset(ctc_nh_reserved_dsnh_offset_type_t type, uint32* p_offset)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_resolved_dsnh_offset ? ctc_api->ctcs_nh_get_resolved_dsnh_offset(lchip, type, p_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_get_stats(ctc_nh_stats_info_t* stats_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_get_stats ? ctc_api->ctcs_nh_get_stats(lchip, stats_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_ecmp(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_ecmp ? ctc_api->ctcs_nh_remove_ecmp(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_iloop(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_iloop ? ctc_api->ctcs_nh_remove_iloop(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_ip_tunnel(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_ip_tunnel ? ctc_api->ctcs_nh_remove_ip_tunnel(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_ipuc(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_ipuc ? ctc_api->ctcs_nh_remove_ipuc(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_l2uc(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_l2uc ? ctc_api->ctcs_nh_remove_l2uc(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_mcast(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_mcast ? ctc_api->ctcs_nh_remove_mcast(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_misc(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_misc ? ctc_api->ctcs_nh_remove_misc(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_mpls_tunnel_label(uint16 tunnel_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_mpls_tunnel_label ? ctc_api->ctcs_nh_remove_mpls_tunnel_label(lchip, tunnel_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_mpls(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_mpls ? ctc_api->ctcs_nh_remove_mpls(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_nexthop_mac(ctc_nh_nexthop_mac_param_t* p_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_nexthop_mac ? ctc_api->ctcs_nh_remove_nexthop_mac(lchip, p_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_rspan(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_rspan ? ctc_api->ctcs_nh_remove_rspan(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_remove_xlate(uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_remove_xlate ? ctc_api->ctcs_nh_remove_xlate(lchip, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_set_global_config(ctc_nh_global_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_set_global_config ? ctc_api->ctcs_nh_set_global_config(lchip, p_glb_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_set_max_ecmp(uint16 max_ecmp)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_set_max_ecmp ? ctc_api->ctcs_nh_set_max_ecmp(lchip, max_ecmp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_set_nh_drop(uint32 nhid, ctc_nh_drop_info_t* p_nh_drop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_set_nh_drop ? ctc_api->ctcs_nh_set_nh_drop(lchip, nhid, p_nh_drop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_swap_mpls_tunnel_label(uint16 old_tunnel_id,uint16 new_tunnel_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_swap_mpls_tunnel_label ? ctc_api->ctcs_nh_swap_mpls_tunnel_label(lchip, old_tunnel_id, new_tunnel_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_ecmp(uint32 nhid, ctc_nh_ecmp_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_ecmp ? ctc_api->ctcs_nh_update_ecmp(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_ip_tunnel(uint32 nhid, ctc_ip_tunnel_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_ip_tunnel ? ctc_api->ctcs_nh_update_ip_tunnel(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_ipuc(uint32 nhid, ctc_ip_nh_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_ipuc ? ctc_api->ctcs_nh_update_ipuc(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_mcast(uint32 nhid, ctc_mcast_nh_param_group_t* p_nh_mcast_group)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_mcast ? ctc_api->ctcs_nh_update_mcast(lchip, nhid, p_nh_mcast_group) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_mpls_tunnel_label(uint16 tunnel_id, ctc_mpls_nexthop_tunnel_param_t* p_new_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_mpls_tunnel_label ? ctc_api->ctcs_nh_update_mpls_tunnel_label(lchip, tunnel_id, p_new_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_mpls(uint32 nhid, ctc_mpls_nexthop_param_t* p_nh_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_mpls ? ctc_api->ctcs_nh_update_mpls(lchip, nhid, p_nh_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_nh_update_nexthop_mac(ctc_nh_nexthop_mac_param_t* p_old_param,ctc_nh_nexthop_mac_param_t* p_new_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_nh_update_nexthop_mac ? ctc_api->ctcs_nh_update_nexthop_mac(lchip, p_old_param, p_new_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##oam##*/
int32 ctc_oam_add_chan(ctc_oam_chan_t* p_chan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_add_chan ? ctc_api->ctcs_oam_add_chan(lchip, p_chan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_add_lmep(ctc_oam_lmep_t* p_lmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_add_lmep ? ctc_api->ctcs_oam_add_lmep(lchip, p_lmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_add_maid(ctc_oam_maid_t* p_maid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_add_maid ? ctc_api->ctcs_oam_add_maid(lchip, p_maid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_add_mip(ctc_oam_mip_t* p_mip)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_add_mip ? ctc_api->ctcs_oam_add_mip(lchip, p_mip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_add_rmep(ctc_oam_rmep_t* p_rmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_add_rmep ? ctc_api->ctcs_oam_add_rmep(lchip, p_rmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_clear_trpt_stats(uint8 gchip, uint8 session_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_clear_trpt_stats ? ctc_api->ctcs_oam_clear_trpt_stats(lchip, gchip, session_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_get_defect_info(uint8 lchip_id, void* p_defect_info)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_get_defect_info ? ctc_api->ctcs_oam_get_defect_info(lchip_id, p_defect_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_get_mep_info(uint8 lchip_id, ctc_oam_mep_info_t* p_mep_info)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_get_mep_info ? ctc_api->ctcs_oam_get_mep_info(lchip_id, p_mep_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_get_mep_info_with_key(ctc_oam_mep_info_with_key_t* p_mep_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_get_mep_info_with_key ? ctc_api->ctcs_oam_get_mep_info_with_key(lchip, p_mep_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_get_stats(ctc_oam_stats_info_t* p_stat_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_get_stats ? ctc_api->ctcs_oam_get_stats(lchip, p_stat_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_get_trpt_stats(uint8 gchip, uint8 session_id, ctc_oam_trpt_stats_t* p_trpt_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_get_trpt_stats ? ctc_api->ctcs_oam_get_trpt_stats(lchip, gchip, session_id, p_trpt_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_init(ctc_oam_global_t* p_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_init ? ctc_api->ctcs_oam_init(lchip, p_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_remove_chan(ctc_oam_chan_t* p_chan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_remove_chan ? ctc_api->ctcs_oam_remove_chan(lchip, p_chan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_remove_lmep(ctc_oam_lmep_t* p_lmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_remove_lmep ? ctc_api->ctcs_oam_remove_lmep(lchip, p_lmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_remove_maid(ctc_oam_maid_t* p_maid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_remove_maid ? ctc_api->ctcs_oam_remove_maid(lchip, p_maid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_remove_mip(ctc_oam_mip_t* p_mip)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_remove_mip ? ctc_api->ctcs_oam_remove_mip(lchip, p_mip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_remove_rmep(ctc_oam_rmep_t* p_rmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_remove_rmep ? ctc_api->ctcs_oam_remove_rmep(lchip, p_rmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_set_property(ctc_oam_property_t* p_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_set_property ? ctc_api->ctcs_oam_set_property(lchip, p_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_set_trpt_cfg(ctc_oam_trpt_t* p_throughput)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_set_trpt_cfg ? ctc_api->ctcs_oam_set_trpt_cfg(lchip, p_throughput) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_set_trpt_en(uint8 gchip, uint8 session_id, uint8 enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_set_trpt_en ? ctc_api->ctcs_oam_set_trpt_en(lchip, gchip, session_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_update_lmep(ctc_oam_update_t* p_lmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_update_lmep ? ctc_api->ctcs_oam_update_lmep(lchip, p_lmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_oam_update_rmep(ctc_oam_update_t* p_rmep)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_oam_update_rmep ? ctc_api->ctcs_oam_update_rmep(lchip, p_rmep) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##overlay_tunnel##*/
int32 ctc_overlay_tunnel_add_tunnel(ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_add_tunnel ? ctc_api->ctcs_overlay_tunnel_add_tunnel(lchip, p_tunnel_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_overlay_tunnel_get_fid(uint32 vn_id, uint16* p_fid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_get_fid ? ctc_api->ctcs_overlay_tunnel_get_fid(lchip, vn_id, p_fid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_overlay_tunnel_init(void* param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_init ? ctc_api->ctcs_overlay_tunnel_init(lchip, param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_overlay_tunnel_remove_tunnel(ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_remove_tunnel ? ctc_api->ctcs_overlay_tunnel_remove_tunnel(lchip, p_tunnel_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_overlay_tunnel_set_fid(uint32 vn_id, uint16 fid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_set_fid ? ctc_api->ctcs_overlay_tunnel_set_fid(lchip, vn_id, fid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_overlay_tunnel_update_tunnel(ctc_overlay_tunnel_param_t* p_tunnel_param)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_overlay_tunnel_update_tunnel ? ctc_api->ctcs_overlay_tunnel_update_tunnel(lchip, p_tunnel_param) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##packet##*/
int32 ctc_packet_decap(ctc_pkt_rx_t* p_pkt_rx)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_packet_decap ? ctc_api->ctcs_packet_decap(lchip, p_pkt_rx) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_packet_encap(ctc_pkt_tx_t* p_pkt_tx)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_packet_encap ? ctc_api->ctcs_packet_encap(lchip, p_pkt_tx) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_packet_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_packet_init ? ctc_api->ctcs_packet_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_packet_tx(ctc_pkt_tx_t* p_pkt_tx)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_packet_tx ? ctc_api->ctcs_packet_tx(lchip, p_pkt_tx) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##parser##*/
int32 ctc_parser_enable_l3_type(ctc_parser_l3_type_t l3_type, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_enable_l3_type ? ctc_api->ctcs_parser_enable_l3_type(lchip, l3_type, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_ecmp_hash_field(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_ecmp_hash_field ? ctc_api->ctcs_parser_get_ecmp_hash_field(lchip, hash_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_global_cfg(ctc_parser_global_cfg_t* global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_global_cfg ? ctc_api->ctcs_parser_get_global_cfg(lchip, global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_ipv6_ctl(uint8 index, ctc_parser_ipv6_ctl_t* ipv6_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_ipv6_ctl ? ctc_api->ctcs_parser_get_ipv6_ctl(lchip, index, ipv6_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l2_flex_header(ctc_parser_l2flex_header_t* l2flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l2_flex_header ? ctc_api->ctcs_parser_get_l2_flex_header(lchip, l2flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l3_flex_header(ctc_parser_l3flex_header_t* l3flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l3_flex_header ? ctc_api->ctcs_parser_get_l3_flex_header(lchip, l3flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l4_app_ctl(ctc_parser_l4app_ctl_t* l4app_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l4_app_ctl ? ctc_api->ctcs_parser_get_l4_app_ctl(lchip, l4app_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l4_app_data_ctl(uint8 index, ctc_parser_l4_app_data_entry_t* entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l4_app_data_ctl ? ctc_api->ctcs_parser_get_l4_app_data_ctl(lchip, index, entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l4_flex_header(ctc_parser_l4flex_header_t* l4flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l4_flex_header ? ctc_api->ctcs_parser_get_l4_flex_header(lchip, l4flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l4_len_op_ctl(uint8 index, uint16* length)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l4_len_op_ctl ? ctc_api->ctcs_parser_get_l4_len_op_ctl(lchip, index, length) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_l4_ptp_ctl(ctc_parser_ptp_ctl_t* l4ptp_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_l4_ptp_ctl ? ctc_api->ctcs_parser_get_l4_ptp_ctl(lchip, l4ptp_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_max_length_filed(uint16* max_length)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_max_length_filed ? ctc_api->ctcs_parser_get_max_length_filed(lchip, max_length) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_pbb_header(ctc_parser_pbb_header_t* pbb_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_pbb_header ? ctc_api->ctcs_parser_get_pbb_header(lchip, pbb_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_tpid(ctc_parser_l2_tpid_t type, uint16* tpid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_tpid ? ctc_api->ctcs_parser_get_tpid(lchip, type, tpid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_trill_header(ctc_parser_trill_header_t* trill_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_trill_header ? ctc_api->ctcs_parser_get_trill_header(lchip, trill_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_udf(uint32 index, ctc_parser_udf_t* udf)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_udf ? ctc_api->ctcs_parser_get_udf(lchip, index, udf) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_udp_app_op_ctl(uint8 index, ctc_parser_udp_app_op_ctl_t* udp_app_op_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_udp_app_op_ctl ? ctc_api->ctcs_parser_get_udp_app_op_ctl(lchip, index, udp_app_op_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_get_vlan_parser_num(uint8* vlan_num)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_get_vlan_parser_num ? ctc_api->ctcs_parser_get_vlan_parser_num(lchip, vlan_num) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_init(void* parser_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_init ? ctc_api->ctcs_parser_init(lchip, parser_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_l2_enable_l3_type(ctc_parser_l3_type_t l3_type, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_l2_enable_l3_type ? ctc_api->ctcs_parser_l2_enable_l3_type(lchip, l3_type, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_l3_enable_l4_type(ctc_parser_l4_type_t l4_type, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_l3_enable_l4_type ? ctc_api->ctcs_parser_l3_enable_l4_type(lchip, l4_type, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_map_l3_type(uint8 index, ctc_parser_l2_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_map_l3_type ? ctc_api->ctcs_parser_map_l3_type(lchip, index, entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_map_l4_type(uint8 index, ctc_parser_l3_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_map_l4_type ? ctc_api->ctcs_parser_map_l4_type(lchip, index, entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_ecmp_hash_field(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_ecmp_hash_field ? ctc_api->ctcs_parser_set_ecmp_hash_field(lchip, hash_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_global_cfg(ctc_parser_global_cfg_t* global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_global_cfg ? ctc_api->ctcs_parser_set_global_cfg(lchip, global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_ipv6_ctl(uint8 index, ctc_parser_ipv6_ctl_t* ipv6_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_ipv6_ctl ? ctc_api->ctcs_parser_set_ipv6_ctl(lchip, index, ipv6_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l2_flex_header(ctc_parser_l2flex_header_t* l2flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l2_flex_header ? ctc_api->ctcs_parser_set_l2_flex_header(lchip, l2flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l3_flex_header(ctc_parser_l3flex_header_t* l3flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l3_flex_header ? ctc_api->ctcs_parser_set_l3_flex_header(lchip, l3flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_app_ctl(ctc_parser_l4app_ctl_t* l4app_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_app_ctl ? ctc_api->ctcs_parser_set_l4_app_ctl(lchip, l4app_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_app_data_ctl(uint8 index, ctc_parser_l4_app_data_entry_t* entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_app_data_ctl ? ctc_api->ctcs_parser_set_l4_app_data_ctl(lchip, index, entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_flex_header(ctc_parser_l4flex_header_t* l4flex_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_flex_header ? ctc_api->ctcs_parser_set_l4_flex_header(lchip, l4flex_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_len_op_ctl(uint8 index, uint16 length)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_len_op_ctl ? ctc_api->ctcs_parser_set_l4_len_op_ctl(lchip, index, length) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_ptp_ctl(ctc_parser_ptp_ctl_t* l4ptp_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_ptp_ctl ? ctc_api->ctcs_parser_set_l4_ptp_ctl(lchip, l4ptp_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_l4_type(uint8 index, ctc_parser_l4_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_l4_type ? ctc_api->ctcs_parser_set_l4_type(lchip, index, entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_max_length_field(uint16 max_length)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_max_length_field ? ctc_api->ctcs_parser_set_max_length_field(lchip, max_length) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_pbb_header(ctc_parser_pbb_header_t* pbb_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_pbb_header ? ctc_api->ctcs_parser_set_pbb_header(lchip, pbb_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_tpid(ctc_parser_l2_tpid_t type, uint16 tpid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_tpid ? ctc_api->ctcs_parser_set_tpid(lchip, type, tpid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_trill_header(ctc_parser_trill_header_t* trill_header)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_trill_header ? ctc_api->ctcs_parser_set_trill_header(lchip, trill_header) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_udf(uint32 index, ctc_parser_udf_t* udf)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_udf ? ctc_api->ctcs_parser_set_udf(lchip, index, udf) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_udp_app_op_ctl(uint8 index, ctc_parser_udp_app_op_ctl_t* udp_app_op_ctl)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_udp_app_op_ctl ? ctc_api->ctcs_parser_set_udp_app_op_ctl(lchip, index, udp_app_op_ctl) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_set_vlan_parser_num(uint8 vlan_num)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_set_vlan_parser_num ? ctc_api->ctcs_parser_set_vlan_parser_num(lchip, vlan_num) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_unmap_l3_type(uint8 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_unmap_l3_type ? ctc_api->ctcs_parser_unmap_l3_type(lchip, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_parser_unmap_l4_type(uint8 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_parser_unmap_l4_type ? ctc_api->ctcs_parser_unmap_l4_type(lchip, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##pdu##*/
int32 ctc_l2pdu_classify_l2pdu(ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_l2pdu_key_t* key)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_classify_l2pdu ? ctc_api->ctcs_l2pdu_classify_l2pdu(lchip, l2pdu_type, index, key) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_get_classified_key(ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_l2pdu_key_t* key)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_get_classified_key ? ctc_api->ctcs_l2pdu_get_classified_key(lchip, l2pdu_type, index, key) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_get_global_action(ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_global_l2pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_get_global_action ? ctc_api->ctcs_l2pdu_get_global_action(lchip, l2pdu_type, index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_get_port_action(uint32 gport, uint8 action_index, ctc_pdu_port_l2pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_get_port_action ? ctc_api->ctcs_l2pdu_get_port_action(lchip, gport, action_index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_set_default_global_action()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_set_default_global_action ? ctc_api->ctcs_l2pdu_set_default_global_action(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_set_global_action(ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_global_l2pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_set_global_action ? ctc_api->ctcs_l2pdu_set_global_action(lchip, l2pdu_type, index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l2pdu_set_port_action(uint32 gport, uint8 action_index, ctc_pdu_port_l2pdu_action_t action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l2pdu_set_port_action ? ctc_api->ctcs_l2pdu_set_port_action(lchip, gport, action_index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_classify_l3pdu(ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_l3pdu_key_t* key)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_classify_l3pdu ? ctc_api->ctcs_l3pdu_classify_l3pdu(lchip, l3pdu_type, index, key) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_get_classified_key(ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_l3pdu_key_t* key)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_get_classified_key ? ctc_api->ctcs_l3pdu_get_classified_key(lchip, l3pdu_type, index, key) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_get_global_action(ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_global_l3pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_get_global_action ? ctc_api->ctcs_l3pdu_get_global_action(lchip, l3pdu_type, index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_get_l3if_action(uint16 l3ifid, uint8 action_index, ctc_pdu_l3if_l3pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_get_l3if_action ? ctc_api->ctcs_l3pdu_get_l3if_action(lchip, l3ifid, action_index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_set_default_global_action()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_set_default_global_action ? ctc_api->ctcs_l3pdu_set_default_global_action(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_set_global_action(ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_global_l3pdu_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_set_global_action ? ctc_api->ctcs_l3pdu_set_global_action(lchip, l3pdu_type, index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_l3pdu_set_l3if_action(uint16 l3ifid, uint8 action_index, ctc_pdu_l3if_l3pdu_action_t action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_l3pdu_set_l3if_action ? ctc_api->ctcs_l3pdu_set_l3if_action(lchip, l3ifid, action_index, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_pdu_init(void* pdu_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_pdu_init ? ctc_api->ctcs_pdu_init(lchip, pdu_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##port##*/
int32 ctc_get_ipg_size(ctc_ipg_size_t index, uint8* p_size)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_ipg_size ? ctc_api->ctcs_get_ipg_size(lchip, index, p_size) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_max_frame_size(ctc_frame_size_t index, uint16* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_max_frame_size ? ctc_api->ctcs_get_max_frame_size(lchip, index, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_get_min_frame_size(ctc_frame_size_t index, uint16* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_get_min_frame_size ? ctc_api->ctcs_get_min_frame_size(lchip, index, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_bridge_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_bridge_en ? ctc_api->ctcs_port_get_bridge_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_cpu_mac_en(bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_cpu_mac_en ? ctc_api->ctcs_port_get_cpu_mac_en(lchip, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_cross_connect(uint32 gport, uint32* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_cross_connect ? ctc_api->ctcs_port_get_cross_connect(lchip, gport, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_default_vlan(uint32 gport, uint16* p_vid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_default_vlan ? ctc_api->ctcs_port_get_default_vlan(lchip, gport, p_vid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_direction_property(uint32 gport, ctc_port_direction_property_t port_prop, ctc_direction_t dir, uint32* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_direction_property ? ctc_api->ctcs_port_get_direction_property(lchip, gport, port_prop, dir, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_dot1q_type(uint32 gport, ctc_dot1q_type_t* p_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_dot1q_type ? ctc_api->ctcs_port_get_dot1q_type(lchip, gport, p_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_flow_ctl_en(ctc_port_fc_prop_t* p_fc_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_flow_ctl_en ? ctc_api->ctcs_port_get_flow_ctl_en(lchip, p_fc_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_ipg(uint32 gport, ctc_ipg_size_t* p_index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_ipg ? ctc_api->ctcs_port_get_ipg(lchip, gport, p_index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_ipsg_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_ipsg_en ? ctc_api->ctcs_port_get_ipsg_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_keep_vlan_tag(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_keep_vlan_tag ? ctc_api->ctcs_port_get_keep_vlan_tag(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_learning_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_learning_en ? ctc_api->ctcs_port_get_learning_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_mac_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_mac_en ? ctc_api->ctcs_port_get_mac_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_mac_link_up(uint32 gport, bool* p_is_up)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_mac_link_up ? ctc_api->ctcs_port_get_mac_link_up(lchip, gport, p_is_up) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_max_frame(uint32 gport, uint32* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_max_frame ? ctc_api->ctcs_port_get_max_frame(lchip, gport, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_min_frame_size(uint32 gport, uint8* p_size)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_min_frame_size ? ctc_api->ctcs_port_get_min_frame_size(lchip, gport, p_size) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_mux_demux_en(uint32 gport, ctc_port_mux_demux_type_t type, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_mux_demux_en ? ctc_api->ctcs_port_get_mux_demux_en(lchip, gport, type, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_pading_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_pading_en ? ctc_api->ctcs_port_get_pading_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_phy_if_en(uint32 gport, uint16* p_l3if_id, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_phy_if_en ? ctc_api->ctcs_port_get_phy_if_en(lchip, gport, p_l3if_id, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_port_check_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_port_check_en ? ctc_api->ctcs_port_get_port_check_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_port_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_port_en ? ctc_api->ctcs_port_get_port_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_port_mac(uint32 gport, mac_addr_t* p_port_mac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_port_mac ? ctc_api->ctcs_port_get_port_mac(lchip, gport, p_port_mac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_preamble(uint32 gport, uint8* p_pre_bytes)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_preamble ? ctc_api->ctcs_port_get_preamble(lchip, gport, p_pre_bytes) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_property(uint32 gport, ctc_port_property_t port_prop, uint32* p_value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_property ? ctc_api->ctcs_port_get_property(lchip, gport, port_prop, p_value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_protocol_vlan_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_protocol_vlan_en ? ctc_api->ctcs_port_get_protocol_vlan_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_random_log_en(uint32 gport, ctc_direction_t dir, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_random_log_en ? ctc_api->ctcs_port_get_random_log_en(lchip, gport, dir, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_random_log_percent(uint32 gport, ctc_direction_t dir, uint8* p_percent)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_random_log_percent ? ctc_api->ctcs_port_get_random_log_percent(lchip, gport, dir, p_percent) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_receive_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_receive_en ? ctc_api->ctcs_port_get_receive_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_reflective_bridge_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_reflective_bridge_en ? ctc_api->ctcs_port_get_reflective_bridge_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_restriction(uint32 gport, ctc_port_restriction_t* p_restriction)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_restriction ? ctc_api->ctcs_port_get_restriction(lchip, gport, p_restriction) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_scl_key_type(uint32 gport, ctc_direction_t dir, uint8 scl_id, ctc_port_scl_key_type_t* p_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_scl_key_type ? ctc_api->ctcs_port_get_scl_key_type(lchip, gport, dir, scl_id, p_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_scl_property(uint32 gport, ctc_port_scl_property_t* prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_scl_property ? ctc_api->ctcs_port_get_scl_property(lchip, gport, prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_speed(uint32 gport, ctc_port_speed_t* p_speed_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_speed ? ctc_api->ctcs_port_get_speed(lchip, gport, p_speed_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_srcdiscard_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_srcdiscard_en ? ctc_api->ctcs_port_get_srcdiscard_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_stag_tpid_index(uint32 gport, ctc_direction_t dir, uint8* p_index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_stag_tpid_index ? ctc_api->ctcs_port_get_stag_tpid_index(lchip, gport, dir, p_index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_stretch_mode_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_stretch_mode_en ? ctc_api->ctcs_port_get_stretch_mode_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_sub_if_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_sub_if_en ? ctc_api->ctcs_port_get_sub_if_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_transmit_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_transmit_en ? ctc_api->ctcs_port_get_transmit_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_untag_dft_vid(uint32 gport, bool* p_enable, bool* p_untag_svlan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_untag_dft_vid ? ctc_api->ctcs_port_get_untag_dft_vid(lchip, gport, p_enable, p_untag_svlan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_use_inner_cos(uint32 gport, bool* p_is_inner)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_use_inner_cos ? ctc_api->ctcs_port_get_use_inner_cos(lchip, gport, p_is_inner) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_use_outer_ttl(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_use_outer_ttl ? ctc_api->ctcs_port_get_use_outer_ttl(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_classify_enable(uint32 gport, ctc_vlan_class_type_t* p_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_classify_enable ? ctc_api->ctcs_port_get_vlan_classify_enable(lchip, gport, p_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_ctl(uint32 gport, ctc_vlantag_ctl_t* p_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_ctl ? ctc_api->ctcs_port_get_vlan_ctl(lchip, gport, p_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_domain(uint32 gport, ctc_port_vlan_domain_type_t* p_vlan_domain)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_domain ? ctc_api->ctcs_port_get_vlan_domain(lchip, gport, p_vlan_domain) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_filter_en(uint32 gport, ctc_direction_t dir, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_filter_en ? ctc_api->ctcs_port_get_vlan_filter_en(lchip, gport, dir, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_mapping_en(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_mapping_en ? ctc_api->ctcs_port_get_vlan_mapping_en(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_get_vlan_range(uint32 gport, ctc_vlan_range_info_t* p_vrange_info, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_get_vlan_range ? ctc_api->ctcs_port_get_vlan_range(lchip, gport, p_vrange_info, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_init(void* p_port_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_init ? ctc_api->ctcs_port_init(lchip, p_port_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_auto_neg(uint32 gport, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_auto_neg ? ctc_api->ctcs_port_set_auto_neg(lchip, gport, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_bridge_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_bridge_en ? ctc_api->ctcs_port_set_bridge_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_cpu_mac_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_cpu_mac_en ? ctc_api->ctcs_port_set_cpu_mac_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_cross_connect(uint32 gport, uint32 nhid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_cross_connect ? ctc_api->ctcs_port_set_cross_connect(lchip, gport, nhid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_default_cfg(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_default_cfg ? ctc_api->ctcs_port_set_default_cfg(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_default_vlan(uint32 gport, uint16 vid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_default_vlan ? ctc_api->ctcs_port_set_default_vlan(lchip, gport, vid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_direction_property(uint32 gport, ctc_port_direction_property_t port_prop, ctc_direction_t dir, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_direction_property ? ctc_api->ctcs_port_set_direction_property(lchip, gport, port_prop, dir, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_dot1q_type(uint32 gport, ctc_dot1q_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_dot1q_type ? ctc_api->ctcs_port_set_dot1q_type(lchip, gport, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_flow_ctl_en(ctc_port_fc_prop_t* p_fc_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_flow_ctl_en ? ctc_api->ctcs_port_set_flow_ctl_en(lchip, p_fc_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_ipg(uint32 gport, ctc_ipg_size_t index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_ipg ? ctc_api->ctcs_port_set_ipg(lchip, gport, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_ipsg_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_ipsg_en ? ctc_api->ctcs_port_set_ipsg_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_keep_vlan_tag(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_keep_vlan_tag ? ctc_api->ctcs_port_set_keep_vlan_tag(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_learning_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_learning_en ? ctc_api->ctcs_port_set_learning_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_link_intr(uint32 gport, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_link_intr ? ctc_api->ctcs_port_set_link_intr(lchip, gport, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_loopback(ctc_port_lbk_param_t* p_port_lbk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_loopback ? ctc_api->ctcs_port_set_loopback(lchip, p_port_lbk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_mac_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_mac_en ? ctc_api->ctcs_port_set_mac_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_max_frame(uint32 gport, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_max_frame ? ctc_api->ctcs_port_set_max_frame(lchip, gport, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_min_frame_size(uint32 gport, uint8 size)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_min_frame_size ? ctc_api->ctcs_port_set_min_frame_size(lchip, gport, size) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_mux_demux_en(uint32 gport, ctc_port_mux_demux_type_t type, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_mux_demux_en ? ctc_api->ctcs_port_set_mux_demux_en(lchip, gport, type, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_pading_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_pading_en ? ctc_api->ctcs_port_set_pading_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_phy_if_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_phy_if_en ? ctc_api->ctcs_port_set_phy_if_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_port_check_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_port_check_en ? ctc_api->ctcs_port_set_port_check_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_port_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_port_en ? ctc_api->ctcs_port_set_port_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_port_mac_postfix(uint32 gport, ctc_port_mac_postfix_t* p_port_mac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_port_mac_postfix ? ctc_api->ctcs_port_set_port_mac_postfix(lchip, gport, p_port_mac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_port_mac_prefix(ctc_port_mac_prefix_t* p_port_mac)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_port_mac_prefix ? ctc_api->ctcs_port_set_port_mac_prefix(lchip, p_port_mac) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_preamble(uint32 gport, uint8 pre_bytes)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_preamble ? ctc_api->ctcs_port_set_preamble(lchip, gport, pre_bytes) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_property(uint32 gport, ctc_port_property_t port_prop, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_property ? ctc_api->ctcs_port_set_property(lchip, gport, port_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_protocol_vlan_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_protocol_vlan_en ? ctc_api->ctcs_port_set_protocol_vlan_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_random_log_en(uint32 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_random_log_en ? ctc_api->ctcs_port_set_random_log_en(lchip, gport, dir, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_random_log_percent(uint32 gport, ctc_direction_t dir, uint8 percent)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_random_log_percent ? ctc_api->ctcs_port_set_random_log_percent(lchip, gport, dir, percent) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_receive_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_receive_en ? ctc_api->ctcs_port_set_receive_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_reflective_bridge_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_reflective_bridge_en ? ctc_api->ctcs_port_set_reflective_bridge_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_restriction(uint32 gport, ctc_port_restriction_t* p_restriction)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_restriction ? ctc_api->ctcs_port_set_restriction(lchip, gport, p_restriction) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_scl_key_type(uint32 gport, ctc_direction_t dir, uint8 scl_id, ctc_port_scl_key_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_scl_key_type ? ctc_api->ctcs_port_set_scl_key_type(lchip, gport, dir, scl_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_scl_property(uint32 gport, ctc_port_scl_property_t* prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_scl_property ? ctc_api->ctcs_port_set_scl_property(lchip, gport, prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_speed(uint32 gport, ctc_port_speed_t speed_mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_speed ? ctc_api->ctcs_port_set_speed(lchip, gport, speed_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_srcdiscard_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_srcdiscard_en ? ctc_api->ctcs_port_set_srcdiscard_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_stag_tpid_index(uint32 gport, ctc_direction_t dir, uint8 index)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_stag_tpid_index ? ctc_api->ctcs_port_set_stag_tpid_index(lchip, gport, dir, index) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_stretch_mode_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_stretch_mode_en ? ctc_api->ctcs_port_set_stretch_mode_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_sub_if_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_sub_if_en ? ctc_api->ctcs_port_set_sub_if_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_transmit_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_transmit_en ? ctc_api->ctcs_port_set_transmit_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_untag_dft_vid(uint32 gport, bool enable, bool untag_svlan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_untag_dft_vid ? ctc_api->ctcs_port_set_untag_dft_vid(lchip, gport, enable, untag_svlan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_use_inner_cos(uint32 gport, bool is_inner)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_use_inner_cos ? ctc_api->ctcs_port_set_use_inner_cos(lchip, gport, is_inner) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_use_outer_ttl(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_use_outer_ttl ? ctc_api->ctcs_port_set_use_outer_ttl(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_classify_disable(uint32 gport, ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_classify_disable ? ctc_api->ctcs_port_set_vlan_classify_disable(lchip, gport, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_classify_enable(uint32 gport, ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_classify_enable ? ctc_api->ctcs_port_set_vlan_classify_enable(lchip, gport, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_ctl(uint32 gport, ctc_vlantag_ctl_t mode)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_ctl ? ctc_api->ctcs_port_set_vlan_ctl(lchip, gport, mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_domain(uint32 gport, ctc_port_vlan_domain_type_t vlan_domain)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_domain ? ctc_api->ctcs_port_set_vlan_domain(lchip, gport, vlan_domain) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_filter_en(uint32 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_filter_en ? ctc_api->ctcs_port_set_vlan_filter_en(lchip, gport, dir, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_mapping_en(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_mapping_en ? ctc_api->ctcs_port_set_vlan_mapping_en(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_set_vlan_range(uint32 gport, ctc_vlan_range_info_t* p_vrange_info, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_set_vlan_range ? ctc_api->ctcs_port_set_vlan_range(lchip, gport, p_vrange_info, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_ipg_size(ctc_ipg_size_t index, uint8 size)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_ipg_size ? ctc_api->ctcs_set_ipg_size(lchip, index, size) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_max_frame_size(ctc_frame_size_t index, uint16 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_max_frame_size ? ctc_api->ctcs_set_max_frame_size(lchip, index, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_set_min_frame_size(ctc_frame_size_t index, uint16 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_set_min_frame_size ? ctc_api->ctcs_set_min_frame_size(lchip, index, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##ptp##*/
int32 ctc_ptp_add_device_clock(ctc_ptp_clock_t* clock)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_add_device_clock ? ctc_api->ctcs_ptp_add_device_clock(lchip, clock) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_adjust_clock_offset(uint8 lchip_id, ctc_ptp_time_t* p_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_adjust_clock_offset ? ctc_api->ctcs_ptp_adjust_clock_offset(lchip_id, p_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_clear_sync_intf_code()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_clear_sync_intf_code ? ctc_api->ctcs_ptp_clear_sync_intf_code(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_clear_tod_intf_code()
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_clear_tod_intf_code ? ctc_api->ctcs_ptp_clear_tod_intf_code(lchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_adjust_delay(uint32 gport, ctc_ptp_adjust_delay_type_t type, int64* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_adjust_delay ? ctc_api->ctcs_ptp_get_adjust_delay(lchip, gport, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_captured_frc_ts(uint8 lchip_id, ctc_ptp_time_t* p_ts)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_captured_frc_ts ? ctc_api->ctcs_ptp_get_captured_frc_ts(lchip_id, p_ts) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_captured_rx_ts(uint8 lchip_id, ctc_ptp_time_t* p_ts)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_captured_rx_ts ? ctc_api->ctcs_ptp_get_captured_rx_ts(lchip_id, p_ts) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_captured_ts(uint8 lchip_id, ctc_ptp_capured_ts_t* p_captured_ts)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_captured_ts ? ctc_api->ctcs_ptp_get_captured_ts(lchip_id, p_captured_ts) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_captured_tx_ts(uint8 lchip_id, ctc_ptp_capured_ts_t* p_ts)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_captured_tx_ts ? ctc_api->ctcs_ptp_get_captured_tx_ts(lchip_id, p_ts) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_clock_drift(uint8 lchip_id, ctc_ptp_time_t* p_drift)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_clock_drift ? ctc_api->ctcs_ptp_get_clock_drift(lchip_id, p_drift) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_clock_timestamp(uint8 lchip_id, ctc_ptp_time_t* p_timestamp)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_clock_timestamp ? ctc_api->ctcs_ptp_get_clock_timestamp(lchip_id, p_timestamp) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_device_type(ctc_ptp_device_type_t* p_device_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_device_type ? ctc_api->ctcs_ptp_get_device_type(lchip, p_device_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_frc_offset(uint8 lchip_id, ctc_ptp_time_t* p_frc_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_frc_offset ? ctc_api->ctcs_ptp_get_frc_offset(lchip_id, p_frc_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_frc(uint8 lchip_id, ctc_ptp_time_t* p_frc)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_frc ? ctc_api->ctcs_ptp_get_frc(lchip_id, p_frc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_global_property(ctc_ptp_global_prop_t property, uint32* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_global_property ? ctc_api->ctcs_ptp_get_global_property(lchip, property, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_intr_bitmap(uint8 lchip_id, uint32* ptp_isr_bitmap)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_intr_bitmap ? ctc_api->ctcs_ptp_get_intr_bitmap(lchip_id, ptp_isr_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_sync_intf_code(uint8 lchip_id, ctc_ptp_sync_intf_code_t* p_time_code)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_sync_intf_code ? ctc_api->ctcs_ptp_get_sync_intf_code(lchip_id, p_time_code) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_sync_intf_toggle_time(uint8 lchip_id, ctc_ptp_time_t* p_toggle_time)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_sync_intf_toggle_time ? ctc_api->ctcs_ptp_get_sync_intf_toggle_time(lchip_id, p_toggle_time) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_sync_intf(uint8 lchip_id, ctc_ptp_sync_intf_cfg_t* p_sync_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_sync_intf ? ctc_api->ctcs_ptp_get_sync_intf(lchip_id, p_sync_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_tod_intf_rx_code(uint8 lchip_id, ctc_ptp_tod_intf_code_t* p_rx_code)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_tod_intf_rx_code ? ctc_api->ctcs_ptp_get_tod_intf_rx_code(lchip_id, p_rx_code) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_tod_intf_tx_code(uint8 lchip_id, ctc_ptp_tod_intf_code_t* p_tx_code)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_tod_intf_tx_code ? ctc_api->ctcs_ptp_get_tod_intf_tx_code(lchip_id, p_tx_code) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_get_tod_intf(uint8 lchip_id, ctc_ptp_tod_intf_cfg_t* p_tod_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_get_tod_intf ? ctc_api->ctcs_ptp_get_tod_intf(lchip_id, p_tod_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_init(ctc_ptp_global_config_t* p_ptp_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_init ? ctc_api->ctcs_ptp_init(lchip, p_ptp_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_port_enable(uint32 gport, bool ptp_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_port_enable ? ctc_api->ctcs_ptp_port_enable(lchip, gport, ptp_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_remove_device_clock(ctc_ptp_clock_t* clock)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_remove_device_clock ? ctc_api->ctcs_ptp_remove_device_clock(lchip, clock) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_adjust_delay(uint32 gport, ctc_ptp_adjust_delay_type_t type, int64 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_adjust_delay ? ctc_api->ctcs_ptp_set_adjust_delay(lchip, gport, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_clock_drift(uint8 lchip_id, ctc_ptp_time_t* p_drift)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_clock_drift ? ctc_api->ctcs_ptp_set_clock_drift(lchip_id, p_drift) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_device_type(ctc_ptp_device_type_t device_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_device_type ? ctc_api->ctcs_ptp_set_device_type(lchip, device_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_frc_offset(uint8 lchip_id, ctc_ptp_time_t* p_frc_offset)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_frc_offset ? ctc_api->ctcs_ptp_set_frc_offset(lchip_id, p_frc_offset) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_global_property(ctc_ptp_global_prop_t property, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_global_property ? ctc_api->ctcs_ptp_set_global_property(lchip, property, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_sync_intf_toggle_time(uint8 lchip_id, ctc_ptp_time_t* p_toggle_time)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_sync_intf_toggle_time ? ctc_api->ctcs_ptp_set_sync_intf_toggle_time(lchip_id, p_toggle_time) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_sync_intf(uint8 lchip_id, ctc_ptp_sync_intf_cfg_t* p_sync_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_sync_intf ? ctc_api->ctcs_ptp_set_sync_intf(lchip_id, p_sync_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_tod_intf_tx_code(uint8 lchip_id, ctc_ptp_tod_intf_code_t* p_tx_code)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_tod_intf_tx_code ? ctc_api->ctcs_ptp_set_tod_intf_tx_code(lchip_id, p_tx_code) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_set_tod_intf(uint8 lchip_id, ctc_ptp_tod_intf_cfg_t* p_tod_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_set_tod_intf ? ctc_api->ctcs_ptp_set_tod_intf(lchip_id, p_tod_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ptp_sync_intf_set_capture_ctl_mode(uint8 lchip_id, uint8 capture_mode)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ptp_sync_intf_set_capture_ctl_mode ? ctc_api->ctcs_ptp_sync_intf_set_capture_ctl_mode(lchip_id, capture_mode) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##qos##*/
int32 ctc_qos_clear_policer_stats(ctc_qos_policer_stats_t* p_policer_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_clear_policer_stats ? ctc_api->ctcs_qos_clear_policer_stats(lchip, p_policer_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_clear_queue_stats(ctc_qos_queue_stats_t* p_queue_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_clear_queue_stats ? ctc_api->ctcs_qos_clear_queue_stats(lchip, p_queue_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_create_service(ctc_qos_service_info_t* p_service)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_create_service ? ctc_api->ctcs_qos_create_service(lchip, p_service) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_destroy_service(ctc_qos_service_info_t* p_service)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_destroy_service ? ctc_api->ctcs_qos_destroy_service(lchip, p_service) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_domain_map(ctc_qos_domain_map_t* p_domain_map)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_domain_map ? ctc_api->ctcs_qos_get_domain_map(lchip, p_domain_map) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_drop_scheme(ctc_qos_drop_t* p_drop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_drop_scheme ? ctc_api->ctcs_qos_get_drop_scheme(lchip, p_drop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_global_config(ctc_qos_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_global_config ? ctc_api->ctcs_qos_get_global_config(lchip, p_glb_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_policer(ctc_qos_policer_t* p_policer)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_policer ? ctc_api->ctcs_qos_get_policer(lchip, p_policer) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_queue(ctc_qos_queue_cfg_t* p_que_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_queue ? ctc_api->ctcs_qos_get_queue(lchip, p_que_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_sched(ctc_qos_sched_t* p_sched)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_sched ? ctc_api->ctcs_qos_get_sched(lchip, p_sched) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_get_shape(ctc_qos_shape_t* p_shape)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_get_shape ? ctc_api->ctcs_qos_get_shape(lchip, p_shape) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_init(void* p_glb_parm)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_init ? ctc_api->ctcs_qos_init(lchip, p_glb_parm) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_query_policer_stats(ctc_qos_policer_stats_t* p_policer_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_query_policer_stats ? ctc_api->ctcs_qos_query_policer_stats(lchip, p_policer_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_query_pool_stats(ctc_qos_resrc_pool_stats_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_query_pool_stats ? ctc_api->ctcs_qos_query_pool_stats(lchip, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_query_queue_stats(ctc_qos_queue_stats_t* p_queue_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_query_queue_stats ? ctc_api->ctcs_qos_query_queue_stats(lchip, p_queue_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_domain_map(ctc_qos_domain_map_t* p_domain_map)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_domain_map ? ctc_api->ctcs_qos_set_domain_map(lchip, p_domain_map) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_drop_scheme(ctc_qos_drop_t* p_drop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_drop_scheme ? ctc_api->ctcs_qos_set_drop_scheme(lchip, p_drop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_global_config(ctc_qos_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_global_config ? ctc_api->ctcs_qos_set_global_config(lchip, p_glb_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_policer(ctc_qos_policer_t* p_policer)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_policer ? ctc_api->ctcs_qos_set_policer(lchip, p_policer) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_queue(ctc_qos_queue_cfg_t* p_que_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_queue ? ctc_api->ctcs_qos_set_queue(lchip, p_que_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_resrc(ctc_qos_resrc_t* p_resrc)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_resrc ? ctc_api->ctcs_qos_set_resrc(lchip, p_resrc) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_sched(ctc_qos_sched_t* p_sched)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_sched ? ctc_api->ctcs_qos_set_sched(lchip, p_sched) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_qos_set_shape(ctc_qos_shape_t* p_shape)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_qos_set_shape ? ctc_api->ctcs_qos_set_shape(lchip, p_shape) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##register##*/
int32 ctc_global_ctl_get(ctc_global_control_type_t type, void* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_global_ctl_get ? ctc_api->ctcs_global_ctl_get(lchip, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_global_ctl_set(ctc_global_control_type_t type, void* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_global_ctl_set ? ctc_api->ctcs_global_ctl_set(lchip, type, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_register_init(void* p_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_register_init ? ctc_api->ctcs_register_init(lchip, p_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##scl##*/
int32 ctc_scl_add_entry(uint32 group_id, ctc_scl_entry_t* scl_entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_add_entry ? ctc_api->ctcs_scl_add_entry(lchip, group_id, scl_entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_copy_entry(ctc_scl_copy_entry_t* copy_entry)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_copy_entry ? ctc_api->ctcs_scl_copy_entry(lchip, copy_entry) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_create_group(uint32 group_id, ctc_scl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_create_group ? ctc_api->ctcs_scl_create_group(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_destroy_group(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_destroy_group ? ctc_api->ctcs_scl_destroy_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_get_group_info(uint32 group_id, ctc_scl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_get_group_info ? ctc_api->ctcs_scl_get_group_info(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_get_multi_entry(ctc_scl_query_t* query)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_get_multi_entry ? ctc_api->ctcs_scl_get_multi_entry(lchip, query) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_init(void* scl_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_init ? ctc_api->ctcs_scl_init(lchip, scl_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_install_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_install_entry ? ctc_api->ctcs_scl_install_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_install_group(uint32 group_id, ctc_scl_group_info_t* group_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_install_group ? ctc_api->ctcs_scl_install_group(lchip, group_id, group_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_remove_all_entry(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_remove_all_entry ? ctc_api->ctcs_scl_remove_all_entry(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_remove_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_remove_entry ? ctc_api->ctcs_scl_remove_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_set_default_action(ctc_scl_default_action_t* def_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_set_default_action ? ctc_api->ctcs_scl_set_default_action(lchip, def_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_set_entry_priority(uint32 entry_id, uint32 priority)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_set_entry_priority ? ctc_api->ctcs_scl_set_entry_priority(lchip, entry_id, priority) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_set_hash_field_sel(ctc_scl_hash_field_sel_t* field_sel)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_set_hash_field_sel ? ctc_api->ctcs_scl_set_hash_field_sel(lchip, field_sel) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_uninstall_entry(uint32 entry_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_uninstall_entry ? ctc_api->ctcs_scl_uninstall_entry(lchip, entry_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_uninstall_group(uint32 group_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_uninstall_group ? ctc_api->ctcs_scl_uninstall_group(lchip, group_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_scl_update_action(uint32 entry_id, ctc_scl_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_scl_update_action ? ctc_api->ctcs_scl_update_action(lchip, entry_id, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##security##*/
int32 ctc_ip_source_guard_add_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ip_source_guard_add_entry ? ctc_api->ctcs_ip_source_guard_add_entry(lchip, p_elem) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_ip_source_guard_remove_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_ip_source_guard_remove_entry ? ctc_api->ctcs_ip_source_guard_remove_entry(lchip, p_elem) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_get_learn_limit(ctc_security_learn_limit_t* p_learn_limit)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_get_learn_limit ? ctc_api->ctcs_mac_security_get_learn_limit(lchip, p_learn_limit) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_get_port_mac_limit(uint32 gport, ctc_maclimit_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_get_port_mac_limit ? ctc_api->ctcs_mac_security_get_port_mac_limit(lchip, gport, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_get_port_security(uint32 gport, bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_get_port_security ? ctc_api->ctcs_mac_security_get_port_security(lchip, gport, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_get_system_mac_limit(ctc_maclimit_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_get_system_mac_limit ? ctc_api->ctcs_mac_security_get_system_mac_limit(lchip, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_get_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t* action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_get_vlan_mac_limit ? ctc_api->ctcs_mac_security_get_vlan_mac_limit(lchip, vlan_id, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_set_learn_limit(ctc_security_learn_limit_t* p_learn_limit)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_set_learn_limit ? ctc_api->ctcs_mac_security_set_learn_limit(lchip, p_learn_limit) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_set_port_mac_limit(uint32 gport, ctc_maclimit_action_t action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_set_port_mac_limit ? ctc_api->ctcs_mac_security_set_port_mac_limit(lchip, gport, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_set_port_security(uint32 gport, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_set_port_security ? ctc_api->ctcs_mac_security_set_port_security(lchip, gport, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_set_system_mac_limit(ctc_maclimit_action_t action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_set_system_mac_limit ? ctc_api->ctcs_mac_security_set_system_mac_limit(lchip, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_mac_security_set_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_mac_security_set_vlan_mac_limit ? ctc_api->ctcs_mac_security_set_vlan_mac_limit(lchip, vlan_id, action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_isolation_get_route_obey_isolated_en(bool* p_enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_isolation_get_route_obey_isolated_en ? ctc_api->ctcs_port_isolation_get_route_obey_isolated_en(lchip, p_enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_port_isolation_set_route_obey_isolated_en(bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_port_isolation_set_route_obey_isolated_en ? ctc_api->ctcs_port_isolation_set_route_obey_isolated_en(lchip, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_security_init(void* security_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_security_init ? ctc_api->ctcs_security_init(lchip, security_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_storm_ctl_get_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_storm_ctl_get_cfg ? ctc_api->ctcs_storm_ctl_get_cfg(lchip, stmctl_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_storm_ctl_get_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_storm_ctl_get_global_cfg ? ctc_api->ctcs_storm_ctl_get_global_cfg(lchip, p_glb_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_storm_ctl_set_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_storm_ctl_set_cfg ? ctc_api->ctcs_storm_ctl_set_cfg(lchip, stmctl_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_storm_ctl_set_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_storm_ctl_set_global_cfg ? ctc_api->ctcs_storm_ctl_set_global_cfg(lchip, p_glb_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##stacking##*/
int32 ctc_stacking_add_trunk_port(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_add_trunk_port ? ctc_api->ctcs_stacking_add_trunk_port(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_add_trunk_rchip(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_add_trunk_rchip ? ctc_api->ctcs_stacking_add_trunk_rchip(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_create_trunk(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_create_trunk ? ctc_api->ctcs_stacking_create_trunk(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_destroy_trunk(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_destroy_trunk ? ctc_api->ctcs_stacking_destroy_trunk(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_get_property(ctc_stacking_property_t* p_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_get_property ? ctc_api->ctcs_stacking_get_property(lchip, p_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_init(void* p_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_init ? ctc_api->ctcs_stacking_init(lchip, p_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_keeplive_add_member(ctc_stacking_keeplive_t* p_keeplive)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_keeplive_add_member ? ctc_api->ctcs_stacking_keeplive_add_member(lchip, p_keeplive) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_keeplive_remove_member(ctc_stacking_keeplive_t* p_keeplive)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_keeplive_remove_member ? ctc_api->ctcs_stacking_keeplive_remove_member(lchip, p_keeplive) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_remove_trunk_port(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_remove_trunk_port ? ctc_api->ctcs_stacking_remove_trunk_port(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_remove_trunk_rchip(ctc_stacking_trunk_t* p_trunk)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_remove_trunk_rchip ? ctc_api->ctcs_stacking_remove_trunk_rchip(lchip, p_trunk) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stacking_set_property(ctc_stacking_property_t* p_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stacking_set_property ? ctc_api->ctcs_stacking_set_property(lchip, p_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##stats##*/
int32 ctc_stats_clear_cpu_mac_stats(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_cpu_mac_stats ? ctc_api->ctcs_stats_clear_cpu_mac_stats(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_clear_global_fwd_stats(ctc_direction_t dir)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_global_fwd_stats ? ctc_api->ctcs_stats_clear_global_fwd_stats(lchip, dir) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_clear_mac_stats(uint32 gport, ctc_mac_stats_dir_t dir)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_mac_stats ? ctc_api->ctcs_stats_clear_mac_stats(lchip, gport, dir) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_clear_port_log_stats(uint32 gport, ctc_direction_t dir)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_port_log_stats ? ctc_api->ctcs_stats_clear_port_log_stats(lchip, gport, dir) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_clear_port_stats(uint32 gport, ctc_direction_t dir)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_port_stats ? ctc_api->ctcs_stats_clear_port_stats(lchip, gport, dir) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_clear_stats(uint32 stats_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_clear_stats ? ctc_api->ctcs_stats_clear_stats(lchip, stats_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_create_statsid(ctc_stats_statsid_t* statsid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_create_statsid ? ctc_api->ctcs_stats_create_statsid(lchip, statsid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_destroy_statsid(uint32 stats_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_destroy_statsid ? ctc_api->ctcs_stats_destroy_statsid(lchip, stats_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_cpu_mac_stats(uint32 gport, ctc_cpu_mac_stats_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_cpu_mac_stats ? ctc_api->ctcs_stats_get_cpu_mac_stats(lchip, gport, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_drop_packet_stats_en(ctc_stats_discard_t bitmap, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_drop_packet_stats_en ? ctc_api->ctcs_stats_get_drop_packet_stats_en(lchip, bitmap, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_global_cfg(ctc_stats_property_param_t stats_param, ctc_stats_property_t* p_stats_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_global_cfg ? ctc_api->ctcs_stats_get_global_cfg(lchip, stats_param, p_stats_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_mac_stats_cfg(uint32 gport, ctc_mac_stats_prop_type_t mac_stats_prop_type, ctc_mac_stats_property_t* p_prop_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_mac_stats_cfg ? ctc_api->ctcs_stats_get_mac_stats_cfg(lchip, gport, mac_stats_prop_type, p_prop_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_mac_stats(uint32 gport, ctc_mac_stats_dir_t dir, ctc_mac_stats_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_mac_stats ? ctc_api->ctcs_stats_get_mac_stats(lchip, gport, dir, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_port_log_stats(uint32 gport, ctc_direction_t dir, ctc_stats_basic_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_port_log_stats ? ctc_api->ctcs_stats_get_port_log_stats(lchip, gport, dir, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_port_stats_cfg(ctc_direction_t dir, ctc_stats_port_stats_option_type_t* p_type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_port_stats_cfg ? ctc_api->ctcs_stats_get_port_stats_cfg(lchip, dir, p_type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_get_stats(uint32 stats_id, ctc_stats_basic_t* p_stats)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_get_stats ? ctc_api->ctcs_stats_get_stats(lchip, stats_id, p_stats) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_init(void* stats_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_init ? ctc_api->ctcs_stats_init(lchip, stats_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_intr_callback_func(uint8* gchip)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_intr_callback_func ? ctc_api->ctcs_stats_intr_callback_func(lchip, gchip) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_register_cb(ctc_stats_sync_fn_t cb, void* userdata)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_register_cb ? ctc_api->ctcs_stats_register_cb(lchip, cb, userdata) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_set_drop_packet_stats_en(ctc_stats_discard_t bitmap, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_set_drop_packet_stats_en ? ctc_api->ctcs_stats_set_drop_packet_stats_en(lchip, bitmap, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_set_global_cfg(ctc_stats_property_param_t stats_param, ctc_stats_property_t stats_prop)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_set_global_cfg ? ctc_api->ctcs_stats_set_global_cfg(lchip, stats_param, stats_prop) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_set_mac_stats_cfg(uint32 gport, ctc_mac_stats_prop_type_t mac_stats_prop_type, ctc_mac_stats_property_t prop_data)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_set_mac_stats_cfg ? ctc_api->ctcs_stats_set_mac_stats_cfg(lchip, gport, mac_stats_prop_type, prop_data) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_set_port_stats_cfg(ctc_direction_t dir, ctc_stats_port_stats_option_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_set_port_stats_cfg ? ctc_api->ctcs_stats_set_port_stats_cfg(lchip, dir, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stats_set_syncup_cb_internal(uint32 stats_interval)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stats_set_syncup_cb_internal ? ctc_api->ctcs_stats_set_syncup_cb_internal(lchip, stats_interval) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##stp##*/
int32 ctc_stp_clear_all_inst_state(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_clear_all_inst_state ? ctc_api->ctcs_stp_clear_all_inst_state(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stp_get_state(uint32 gport, uint8 stpid, uint8* state)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_get_state ? ctc_api->ctcs_stp_get_state(lchip, gport, stpid, state) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stp_get_vlan_stpid(uint16 vlan_id, uint8* stpid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_get_vlan_stpid ? ctc_api->ctcs_stp_get_vlan_stpid(lchip, vlan_id, stpid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stp_init(void* stp_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_init ? ctc_api->ctcs_stp_init(lchip, stp_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stp_set_state(uint32 gport, uint8 stpid, uint8 state)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_set_state ? ctc_api->ctcs_stp_set_state(lchip, gport, stpid, state) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_stp_set_vlan_stpid(uint16 vlan_id, uint8 stpid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_stp_set_vlan_stpid ? ctc_api->ctcs_stp_set_vlan_stpid(lchip, vlan_id, stpid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##sync_ether##*/
int32 ctc_sync_ether_get_cfg(uint8 lchip_id, uint8 sync_ether_clock_id, ctc_sync_ether_cfg_t* p_sync_ether_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_sync_ether_get_cfg ? ctc_api->ctcs_sync_ether_get_cfg(lchip_id, sync_ether_clock_id, p_sync_ether_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_sync_ether_init(void* sync_ether_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_sync_ether_init ? ctc_api->ctcs_sync_ether_init(lchip, sync_ether_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_sync_ether_set_cfg(uint8 lchip_id, uint8 sync_ether_clock_id, ctc_sync_ether_cfg_t* p_sync_ether_cfg)
{
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_sync_ether_set_cfg ? ctc_api->ctcs_sync_ether_set_cfg(lchip_id, sync_ether_clock_id, p_sync_ether_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##usrid##*/
int32 ctc_usrid_init(void* usrid_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_usrid_init ? ctc_api->ctcs_usrid_init(lchip, usrid_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
/*##vlan##*/
int32 ctc_vlan_add_default_egress_vlan_mapping(uint32 gport, ctc_vlan_miss_t* p_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_default_egress_vlan_mapping ? ctc_api->ctcs_vlan_add_default_egress_vlan_mapping(lchip, gport, p_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_default_vlan_class(ctc_vlan_class_type_t type, ctc_vlan_miss_t* p_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_default_vlan_class ? ctc_api->ctcs_vlan_add_default_vlan_class(lchip, type, p_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_default_vlan_mapping(uint32 gport, ctc_vlan_miss_t* p_action)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_default_vlan_mapping ? ctc_api->ctcs_vlan_add_default_vlan_mapping(lchip, gport, p_action) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_egress_vlan_mapping(uint32 gport, ctc_egress_vlan_mapping_t* p_vlan_mapping)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_egress_vlan_mapping ? ctc_api->ctcs_vlan_add_egress_vlan_mapping(lchip, gport, p_vlan_mapping) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_port(uint16 vlan_id, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_port ? ctc_api->ctcs_vlan_add_port(lchip, vlan_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_vlan_class(ctc_vlan_class_t* p_vlan_class)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_vlan_class ? ctc_api->ctcs_vlan_add_vlan_class(lchip, p_vlan_class) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_vlan_mapping(uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_vlan_mapping ? ctc_api->ctcs_vlan_add_vlan_mapping(lchip, gport, p_vlan_mapping) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_add_vlan_range(ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_t* vlan_range)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_add_vlan_range ? ctc_api->ctcs_vlan_add_vlan_range(lchip, vrange_info, vlan_range) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_create_uservlan(ctc_vlan_uservlan_t* user_vlan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_create_uservlan ? ctc_api->ctcs_vlan_create_uservlan(lchip, user_vlan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_create_vlan_range_group(ctc_vlan_range_info_t* vrange_info, bool is_svlan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_create_vlan_range_group ? ctc_api->ctcs_vlan_create_vlan_range_group(lchip, vrange_info, is_svlan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_create_vlan(uint16 vlan_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_create_vlan ? ctc_api->ctcs_vlan_create_vlan(lchip, vlan_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_destroy_vlan_range_group(ctc_vlan_range_info_t* vrange_info)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_destroy_vlan_range_group ? ctc_api->ctcs_vlan_destroy_vlan_range_group(lchip, vrange_info) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_destroy_vlan(uint16 vlan_id)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_destroy_vlan ? ctc_api->ctcs_vlan_destroy_vlan(lchip, vlan_id) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_arp_excp_type(uint16 vlan_id, ctc_exception_type_t* type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_arp_excp_type ? ctc_api->ctcs_vlan_get_arp_excp_type(lchip, vlan_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_bridge_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_bridge_en ? ctc_api->ctcs_vlan_get_bridge_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_dhcp_excp_type(uint16 vlan_id, ctc_exception_type_t* type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_dhcp_excp_type ? ctc_api->ctcs_vlan_get_dhcp_excp_type(lchip, vlan_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_direction_property(uint16 vlan_id, ctc_vlan_direction_property_t vlan_prop, ctc_direction_t dir, uint32* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_direction_property ? ctc_api->ctcs_vlan_get_direction_property(lchip, vlan_id, vlan_prop, dir, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_fid(uint16 vlan_id, uint16* fid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_fid ? ctc_api->ctcs_vlan_get_fid(lchip, vlan_id, fid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_igmp_snoop_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_igmp_snoop_en ? ctc_api->ctcs_vlan_get_igmp_snoop_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_learning_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_learning_en ? ctc_api->ctcs_vlan_get_learning_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_ports(uint16 vlan_id, uint8 gchip, ctc_port_bitmap_t port_bitmap)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_ports ? ctc_api->ctcs_vlan_get_ports(lchip, vlan_id, gchip, port_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_property(uint16 vlan_id, ctc_vlan_property_t vlan_prop, uint32* value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_property ? ctc_api->ctcs_vlan_get_property(lchip, vlan_id, vlan_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_receive_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_receive_en ? ctc_api->ctcs_vlan_get_receive_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_replace_dspc_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_replace_dspc_en ? ctc_api->ctcs_vlan_get_replace_dspc_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_tagged_ports(uint16 vlan_id, uint8 gchip, ctc_port_bitmap_t port_bitmap)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_tagged_ports ? ctc_api->ctcs_vlan_get_tagged_ports(lchip, vlan_id, gchip, port_bitmap) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_transmit_en(uint16 vlan_id, bool* enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_transmit_en ? ctc_api->ctcs_vlan_get_transmit_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_vlan_range_type(ctc_vlan_range_info_t* vrange_info, bool* is_svlan)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_vlan_range_type ? ctc_api->ctcs_vlan_get_vlan_range_type(lchip, vrange_info, is_svlan) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_get_vlan_range(ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_group_t* vrange_group, uint8* count)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_get_vlan_range ? ctc_api->ctcs_vlan_get_vlan_range(lchip, vrange_info, vrange_group, count) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_init(ctc_vlan_global_cfg_t* vlan_global_cfg)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_init ? ctc_api->ctcs_vlan_init(lchip, vlan_global_cfg) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_all_egress_vlan_mapping_by_port(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_all_egress_vlan_mapping_by_port ? ctc_api->ctcs_vlan_remove_all_egress_vlan_mapping_by_port(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_all_vlan_class(ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_all_vlan_class ? ctc_api->ctcs_vlan_remove_all_vlan_class(lchip, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_all_vlan_mapping_by_port(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_all_vlan_mapping_by_port ? ctc_api->ctcs_vlan_remove_all_vlan_mapping_by_port(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_default_egress_vlan_mapping(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_default_egress_vlan_mapping ? ctc_api->ctcs_vlan_remove_default_egress_vlan_mapping(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_default_vlan_class(ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_default_vlan_class ? ctc_api->ctcs_vlan_remove_default_vlan_class(lchip, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_default_vlan_mapping(uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_default_vlan_mapping ? ctc_api->ctcs_vlan_remove_default_vlan_mapping(lchip, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_egress_vlan_mapping(uint32 gport, ctc_egress_vlan_mapping_t* p_vlan_mapping)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_egress_vlan_mapping ? ctc_api->ctcs_vlan_remove_egress_vlan_mapping(lchip, gport, p_vlan_mapping) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_port(uint16 vlan_id, uint32 gport)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_port ? ctc_api->ctcs_vlan_remove_port(lchip, vlan_id, gport) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_vlan_class(ctc_vlan_class_t* p_vlan_class)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_vlan_class ? ctc_api->ctcs_vlan_remove_vlan_class(lchip, p_vlan_class) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_vlan_mapping(uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_vlan_mapping ? ctc_api->ctcs_vlan_remove_vlan_mapping(lchip, gport, p_vlan_mapping) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_remove_vlan_range(ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_t* vlan_range)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_remove_vlan_range ? ctc_api->ctcs_vlan_remove_vlan_range(lchip, vrange_info, vlan_range) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_arp_excp_type(uint16 vlan_id, ctc_exception_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_arp_excp_type ? ctc_api->ctcs_vlan_set_arp_excp_type(lchip, vlan_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_bridge_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_bridge_en ? ctc_api->ctcs_vlan_set_bridge_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_dhcp_excp_type(uint16 vlan_id, ctc_exception_type_t type)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_dhcp_excp_type ? ctc_api->ctcs_vlan_set_dhcp_excp_type(lchip, vlan_id, type) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_direction_property(uint16 vlan_id, ctc_vlan_direction_property_t vlan_prop, ctc_direction_t dir, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_direction_property ? ctc_api->ctcs_vlan_set_direction_property(lchip, vlan_id, vlan_prop, dir, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_fid(uint16 vlan_id, uint16 fid)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_fid ? ctc_api->ctcs_vlan_set_fid(lchip, vlan_id, fid) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_igmp_snoop_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_igmp_snoop_en ? ctc_api->ctcs_vlan_set_igmp_snoop_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_learning_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_learning_en ? ctc_api->ctcs_vlan_set_learning_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_property(uint16 vlan_id, ctc_vlan_property_t vlan_prop, uint32 value)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_property ? ctc_api->ctcs_vlan_set_property(lchip, vlan_id, vlan_prop, value) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_receive_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_receive_en ? ctc_api->ctcs_vlan_set_receive_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_replace_dscp_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_replace_dscp_en ? ctc_api->ctcs_vlan_set_replace_dscp_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_tagged_port(uint16 vlan_id, uint32 gport, bool tagged)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_tagged_port ? ctc_api->ctcs_vlan_set_tagged_port(lchip, vlan_id, gport, tagged) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_set_transmit_en(uint16 vlan_id, bool enable)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_set_transmit_en ? ctc_api->ctcs_vlan_set_transmit_en(lchip, vlan_id, enable) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
int32 ctc_vlan_update_vlan_mapping(uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    uint8 lchip = 0;
    int32 ret = CTC_E_NOT_SUPPORT;
    ret = ctc_api->ctcs_vlan_update_vlan_mapping ? ctc_api->ctcs_vlan_update_vlan_mapping(lchip, gport, p_vlan_mapping) : CTC_E_NOT_SUPPORT;
    return ret;
}
 
 
 
