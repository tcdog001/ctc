/**
 @file ctc_greatbelt_acl.c

 @date 2009-10-17

 @version v2.0

 The file contains acl APIs
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_linklist.h"
#include "ctc_greatbelt_acl.h"

#include "sys_greatbelt_acl.h"

int32
ctc_greatbelt_acl_init(uint8 lchip, ctc_acl_global_cfg_t* acl_global_cfg)
{
    ctc_acl_global_cfg_t acl_cfg;

    if (NULL == acl_global_cfg)
    {
        /*set default*/
        sal_memset(&acl_cfg, 0, sizeof(ctc_acl_global_cfg_t));

        acl_cfg.merge_mac_ip                = 1;
        acl_cfg.ingress_use_mapped_vlan     = 0;
        acl_cfg.trill_use_ipv6              = 0;
        acl_cfg.arp_use_ipv6                = 0;
        acl_cfg.hash_acl_en                 = 0;
        acl_cfg.non_ipv4_mpls_use_ipv6      = 0;
        acl_cfg.priority_bitmap_of_stats    = 0x1;
        acl_cfg.ingress_port_service_acl_en = 0;
        acl_cfg.ingress_vlan_service_acl_en = 0;
        acl_cfg.egress_port_service_acl_en  = 0;
        acl_cfg.egress_vlan_service_acl_en  = 0;
        acl_cfg.hash_mac_key_flag           = CTC_ACL_HASH_MAC_KEY_FLAG_MAX -1;
        acl_cfg.hash_ipv4_key_flag          = CTC_ACL_HASH_IPV4_KEY_FLAG_MAX -1 ;
        acl_cfg.white_list_en               = 0;
        acl_global_cfg = &acl_cfg;
    }

    CTC_ERROR_RETURN(sys_greatbelt_acl_init(acl_global_cfg));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_create_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_create_group(group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_destroy_group(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_destroy_group(group_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_install_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_install_group(group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_uninstall_group(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_uninstall_group(group_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_get_group_info(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_get_group_info(group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_add_entry(uint8 lchip, uint32 group_id, ctc_acl_entry_t* acl_entry)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_add_entry(group_id, acl_entry));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_remove_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_greatbelt_acl_remove_entry(entry_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_install_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_greatbelt_acl_install_entry(entry_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_uninstall_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_greatbelt_acl_uninstall_entry(entry_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_remove_all_entry(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_remove_all_entry(group_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_set_entry_priority(uint8 lchip, uint32 entry_id, uint32 priority)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_set_entry_priority(entry_id, priority));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_get_multi_entry(uint8 lchip, ctc_acl_query_t* query)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_get_multi_entry(query));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_update_action(uint8 lchip, uint32 entry_id, ctc_acl_action_t* action)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_update_action(entry_id, action));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_acl_copy_entry(uint8 lchip, ctc_acl_copy_entry_t* copy_entry)
{
    CTC_ERROR_RETURN(sys_greatbelt_acl_copy_entry(copy_entry));
    return CTC_E_NONE;
}


