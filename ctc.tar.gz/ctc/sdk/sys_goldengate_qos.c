/**
 @file sys_goldengate_aclqos_policer.c

 @date 2009-10-16

 @version v2.0

*/

/****************************************************************************
  *
  * Header Files
  *
  ****************************************************************************/
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_macro.h"
#include "ctc_qos.h"
#include "ctc_debug.h"

#include "sys_goldengate_chip.h"
#include "sys_goldengate_port.h"
#include "sys_goldengate_qos.h"

#include "sys_goldengate_qos_class.h"
#include "sys_goldengate_qos_policer.h"
#include "sys_goldengate_queue_enq.h"
#include "sys_goldengate_queue_shape.h"
#include "sys_goldengate_queue_sch.h"
#include "sys_goldengate_queue_drop.h"
#include "sys_goldengate_cpu_reason.h"

/* #include "drv_lib.h" --never--*/

/****************************************************************************
  *
  * Defines and Macros
  *
  ****************************************************************************/

/*init*/
extern int32
sys_goldengate_qos_init(uint8 lchip, void* p_glb_parm)
{
    int32 ret = CTC_E_NONE;

    CTC_ERROR_RETURN(sys_goldengate_qos_class_init(lchip));

    CTC_ERROR_RETURN(sys_goldengate_qos_policer_init(lchip, p_glb_parm));

    CTC_ERROR_RETURN(sys_goldengate_queue_enq_init(lchip, p_glb_parm));

    CTC_ERROR_RETURN(sys_goldengate_queue_shape_init(lchip));

    CTC_ERROR_RETURN(sys_goldengate_queue_sch_init(lchip));

    CTC_ERROR_RETURN(sys_goldengate_queue_drop_init(lchip, p_glb_parm));

    CTC_ERROR_RETURN(sys_goldengate_queue_cpu_reason_init(lchip));

    return ret;
}

/*policer*/
extern int32
sys_goldengate_qos_set_policer(uint8 lchip, ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_policer_set(lchip, p_policer));
    return CTC_E_NONE;
}

/*shape*/
extern int32
sys_goldengate_qos_set_shape(uint8 lchip, ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(_sys_goldengate_qos_set_shape(lchip, p_shape));
    return CTC_E_NONE;
}

/*schedule*/
extern int32
sys_goldengate_qos_set_sched(uint8 lchip, ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(_sys_goldengate_qos_set_sched(lchip, p_sched));
    return CTC_E_NONE;
}

/*mapping*/
extern int32
sys_goldengate_qos_set_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_domain_map_set(lchip, p_domain_map));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_get_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_domain_map_get(lchip, p_domain_map));
    return CTC_E_NONE;
}

/*global param*/
extern int32
sys_goldengate_qos_set_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    switch (p_glb_cfg->cfg_type)
    {
    case CTC_QOS_GLB_CFG_POLICER_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_update_enable(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_STATS_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_stats_enable(lchip, p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_POLICER_IPG_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_ipg_enable(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_SEQENCE_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_sequential_enable(lchip, p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_QUE_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_queue_shape_enable(lchip, p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_GROUP_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_group_shape_enable(lchip, p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_PORT_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_port_shape_enable(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_SHAPE_IPG_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_shape_ipg_enable(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_FLOW_FIRST_EN:
        CTC_ERROR_RETURN(
        sys_goldengate_qos_set_policer_flow_first(lchip, (p_glb_cfg->u.value >> 16) & 0xFFFF,
                                                  (p_glb_cfg->u.value & 0xFFFF)));
        break;

    case CTC_QOS_GLB_CFG_RESRC_MGR_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_resrc_mgr_en(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_QUE_STATS_EN:
        return CTC_E_NOT_SUPPORT;
        break;


    case CTC_QOS_GLB_CFG_PHB_MAP:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_phb(lchip, &p_glb_cfg->u.phb_map));
        break;

    case CTC_QOS_GLB_CFG_REASON_SHAPE_PKT_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_reason_shp_base_pkt_en(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_HBWP_SHARE_EN:
        CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_hbwp_share_enable(lchip, p_glb_cfg->u.value));
        break;
    case CTC_QOS_GLB_CFG_MONITOR_DROP_QID:
	     CTC_ERROR_RETURN(
            sys_goldengate_qos_set_monitor_drop_queue_id(lchip, &p_glb_cfg->u.queue_id));
        break;
    case CTC_QOS_GLB_CFG_TRUNCATION_LEN:
			    CTC_ERROR_RETURN(
            sys_goldengate_cpu_reason_set_truncation_length(lchip, p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_MARK_ECN_EN:
			    CTC_ERROR_RETURN(
            sys_goldengate_qos_set_policer_mark_ecn_enable(lchip, p_glb_cfg->u.value));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_get_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    return CTC_E_NONE;
}

/*queue*/
extern int32
sys_goldengate_qos_set_queue(uint8 lchip, ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_queue_set(lchip, p_que_cfg));
    return CTC_E_NONE;
}

/*drop*/
extern int32
sys_goldengate_qos_set_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_set_drop(lchip, p_drop));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_get_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_get_drop(lchip, p_drop));
    return CTC_E_NONE;
}

/*Resrc*/
extern int32
sys_goldengate_qos_set_resrc(uint8 lchip, ctc_qos_resrc_t* p_resrc)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_set_resrc(lchip, p_resrc));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_query_pool_stats(uint8 lchip, ctc_qos_resrc_pool_stats_t* p_stats)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_query_pool_stats(lchip, p_stats));
    return CTC_E_NONE;
}

/*stats*/
extern int32
sys_goldengate_qos_query_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_stats_query(lchip, p_queue_stats));
    return CTC_E_NONE;
}

/*stats*/
extern int32
sys_goldengate_qos_clear_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_goldengate_queue_stats_clear(lchip, p_queue_stats));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_query_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_policer_stats_query(lchip, p_policer_stats));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_clear_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_goldengate_qos_policer_stats_clear(lchip, p_policer_stats));
    return CTC_E_NONE;
}

extern int32
sys_goldengate_qos_set_port_to_statcking_port(uint8 lchip, uint16 gport,uint8 enable)
{
	CTC_ERROR_RETURN(sys_goldengate_queue_set_to_stacking_port(lchip, gport,enable));
    return CTC_E_NONE;
}

