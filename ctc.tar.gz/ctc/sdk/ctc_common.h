/**
 @file ctc_common.h

 @date 2010-6-10

 @version v2.0

The file define all CTC SDK module's common function and APIs.
*/

#ifndef _CTC_COMMON_H
#define _CTC_COMMON_H
#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* _CTC_COMMON_H*/

