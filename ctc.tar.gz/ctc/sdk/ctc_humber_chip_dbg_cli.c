/****************************************************************************
 * ctc_humber_tools.c     debug tools for humber
 *
 * Copyright:    (c)2005 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision:     R0.01.
 * Author:       Zhu Jian
 * Date:         2010-08-18.
 * Reason:       First Create.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctc_cli.h"
#include "sal.h"
#include "ctc_humber_chip_dbg.h"
#include "ctc_humber_chip_dbg_cli.h"
#include "ctc_api.h"

/****************************************************************************
 *
* Defines and Macros
*
****************************************************************************/

extern int32
ctc_humber_diag_write_chip(uint32 bay_id, uint32 fpga_id, uint32 reg_offset,
                           uint32 value);

extern int32
ctc_humber_diag_read_chip(uint32 bay_id, uint32 fpga_id, uint32 reg_offset,
                          uint32* p_value);

/****************************************************************************
 *
* Functions
*
****************************************************************************/
CTC_CLI(ctc_cli_hb_debug_tool_show_modules_stats,
        cli_ctc_show_humber_modules_stats_cmd,
        "show humber CHIP_ID (gmac|xgmac|sgmac|qmac|muxnetrxtx|ipe|fwd|epe|cpumac|eloop|fabric|interrupt|internal|oam|parser|shareds|tbinfoarb|tcam|queueid|queuedepth|hashds) (all|INDEX)",
        CTC_CLI_SHOW_STR,
        "Humber",
        "Chip index",
        "Gmac",
        "Xgmac",
        "Sgmac",
        "Qmac",
        "Muxnetrxtx",
        "Ipe",
        "Fwd",
        "Epe",
        "Cpumac",
        "Eloop",
        "Fabric",
        "Interrupt",
        "Internal",
        "Oam",
        "Parser",
        "Shareds",
        "Tbinfoarb",
        "Tcam",
        "Queueid",
        "Queuedepth",
        "Hashds",
        "All",
        "Index")
{
    int chip_idx = 0;
    int mod_idx = 0;
    int ret = -1;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("gmac", 1))
    {
        if (CLI_CLI_STR_EQUAL("all", 2))
        {
            show_humber_diag_GmacAll(chip_idx);
        }
        else
        {
            mod_idx = ctc_cmd_str2uint(argv[2], &ret);
            if (mod_idx >= 48)
            {
                ctc_cli_out("Module index out of range!\n");
                return CLI_ERROR;
            }

            show_humber_diag_Gmac(chip_idx, mod_idx);
        }
    }
    else if (CLI_CLI_STR_EQUAL("xgmac", 1))
    {
        if (CLI_CLI_STR_EQUAL("all", 2))
        {
            show_humber_diag_XGmacAll(chip_idx);
        }
        else
        {
            mod_idx = ctc_cmd_str2uint(argv[2], &ret);
            if (mod_idx >= 4)
            {
                ctc_cli_out("Module index out of range!\n");
                return CLI_ERROR;
            }

            show_humber_diag_XGmac(chip_idx, mod_idx);
        }
    }

    if (CLI_CLI_STR_EQUAL("sgmac", 1))
    {
        if (CLI_CLI_STR_EQUAL("all", 2))
        {
            show_humber_diag_SGmacAll(chip_idx);
        }
        else
        {
            mod_idx = ctc_cmd_str2uint(argv[2], &ret);
            if (mod_idx >= 4)
            {
                ctc_cli_out("Module index out of range!\n");
                return CLI_ERROR;
            }

            show_humber_diag_SGmac(chip_idx, mod_idx);
        }
    }
    else if (CLI_CLI_STR_EQUAL("qmac", 1))
    {
        if (CLI_CLI_STR_EQUAL("all", 2))
        {
            show_humber_diag_QmacAll(chip_idx);
        }
        else
        {
            mod_idx = ctc_cmd_str2uint(argv[2], &ret);
            if (mod_idx >= 12)
            {
                ctc_cli_out("Module index out of range!\n");
                return CLI_ERROR;
            }

            show_humber_diag_Qmac(chip_idx, mod_idx);
        }
    }
    else if (CLI_CLI_STR_EQUAL("muxnetrxtx", 1))
    {
        show_humber_diag_MuxNetRxTx(chip_idx);

    }
    else if (CLI_CLI_STR_EQUAL("ipe", 1))
    {
        show_humber_diag_Ipe(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("fwd", 1))
    {
        show_humber_diag_Fwd(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("epe", 1))
    {
        show_humber_diag_Epe(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("cpumac", 1))
    {
        show_humber_diag_CpuMac(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("eloop", 1))
    {
        show_humber_diag_Eloop(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("fabric", 1))
    {
        show_humber_diag_Fabric(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("interrupt", 1))
    {
        show_humber_diag_Interrupt(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("internal", 1))
    {
        show_humber_diag_Internal(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("oam", 1))
    {
        show_humber_diag_Oam(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("parser", 1))
    {
        show_humber_diag_Parser(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("shareds", 1))
    {
        show_humber_diag_ShareDs(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("tbinfoarb", 1))
    {
        show_humber_diag_TbInfoArb(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("tcam", 1))
    {
        show_humber_diag_Tcam(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("queueid", 1))
    {
        show_humber_diag_QueueIdMon(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("queuedepth", 1))
    {
        show_humber_diag_QueueDepth(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("hashds", 1))
    {
        show_humber_diag_HashDs(chip_idx);
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_show_bus_info,
        cli_ctc_show_humber_bus_info_cmd,
        "show humber CHIP_ID bus (busHa2Im|busIm2LmPI|busIm2LmPR|busLm2PpPI|busLm2PpPR|busMfEnqMsgFifo|ha2NhPiBus|Nh2HpPiBus|Pr2HpPrBus|aqos2EditPiBus|cla2EditPiBus) START-MSG MSG-NUM",
        CTC_CLI_SHOW_STR,
        "Humber",
        "Chip index",
        "Bus",
        "BusHa2Im",
        "BusIm2LmPI",
        "BusIm2LmPR",
        "BusLm2PpPI",
        "BusLm2PpPR",
        "BusMfEnqMsgFifo",
        "Ha2NhPiBus",
        "Nh2HpPiBus",
        "Pr2HpPrBus",
        "Aqos2EditPiBus",
        "Cla2EditPiBus",
        "Start message",
        "Message number")
{
    int chip_idx = 0;
    int start_msg = 0;
    int msg_num = 0;
    ctc_humber_bus_message_t* p_bus_msg = NULL;
    int ret = -1;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    start_msg = ctc_cmd_str2uint(argv[2], &ret);
    msg_num = ctc_cmd_str2uint(argv[3], &ret);

    if (CLI_CLI_STR_EQUAL("busHa2Im", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(0);
    }
    else if (CLI_CLI_STR_EQUAL("busIm2LmPI", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(1);
    }
    else if (CLI_CLI_STR_EQUAL("busIm2LmPR", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(2);
    }
    else if (CLI_CLI_STR_EQUAL("busLm2PpPI", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(3);
    }
    else if (CLI_CLI_STR_EQUAL("busLm2PpPR", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(4);
    }
    else if (CLI_CLI_STR_EQUAL("busMfEnqMsgFifo", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(5);
    }
    else if (CLI_CLI_STR_EQUAL("ha2NhPiBus", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(6);
    }
    else if (CLI_CLI_STR_EQUAL("Nh2HpPiBus", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(7);
    }
    else if (CLI_CLI_STR_EQUAL("Pr2HpPrBus", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(8);
    }
    else if (CLI_CLI_STR_EQUAL("aqos2EditPiBus", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(9);
    }
    else if (CLI_CLI_STR_EQUAL("cla2EditPiBus", 1))
    {
        p_bus_msg = ctc_humber_diag_get_bus_msg(10);
    }

    ret = show_humber_diag_bus_info(chip_idx, p_bus_msg, start_msg, msg_num);
    if (ret < 0)
    {
        ctc_cli_out("show bus message failed!\n\r");
        return CLI_ERROR;
    }
    else
    {
        ctc_cli_out("\n");
        return CLI_SUCCESS;
    }
}

CTC_CLI(ctc_cli_hb_debug_tool_show_discard,
        cli_ctc_show_humber_discard_cmd,
        "show humber CHIP_ID discard",
        CTC_CLI_SHOW_STR,
        "Humber",
        "Chip index",
        "Discard type")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    show_humber_diag_DiscardType(chip_idx);

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_show_sgmac_link,
        cli_ctc_show_humber_sgmac_link_cmd,
        "show humber CHIP_ID sgmac link",
        CTC_CLI_SHOW_STR,
        "Humber",
        "Chip index",
        "Sgmac",
        "Link status")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    show_humber_diag_Sgmaclink(chip_idx);
    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_clear_discard,
        cli_ctc_clear_humber_discard_cmd,
        "clear humber CHIP_ID discard",
        CTC_CLI_CLEAR_STR,
        "Humber",
        "Chip index",
        "Discard type")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    clear_humber_diag_DiscardType(chip_idx);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_run_bist,
        cli_ctc_run_humber_bist_cmd,
        "run bist humber CHIP_ID (ddr|qdr|exttcam|inttcam) (LATENCY|)",
        "Run",
        "Bit",
        "Humber",
        "Chip index",
        "Ddr",
        "Qdr",
        "External tcam",
        "Internal tcam",
        "Latency")
{
    int chip_idx = 0;
    int latency = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (argc == 3)
    {
        latency = ctc_cmd_str2uint(argv[2], &ret);
    }

    if (CLI_CLI_STR_EQUAL("ddr", 1))
    {
        if (argc < 3)
        {
            latency = DDR_DFT_BISTEXP_LATENCY;
        }

        ctc_humber_diag_run_ddr_bist(chip_idx, latency);
    }
    else if (CLI_CLI_STR_EQUAL("qdr", 1))
    {
        if (argc < 3)
        {
            latency = QDR_DFT_BISTEXP_LATENCY;
        }

        ctc_humber_diag_run_qdr_bist(chip_idx, latency);
    }
    else if (CLI_CLI_STR_EQUAL("exttcam", 1))
    {
        if (argc < 3)
        {
            latency = EXT_TCAM_DFT_BISTEXP_LATENCY;
        }

        ctc_humber_diag_run_ext_tcam_bist(chip_idx, latency);
    }
    else if (CLI_CLI_STR_EQUAL("inttcam", 1))
    {
        if (argc < 3)
        {
            latency = INT_TCAM_DFT_BISTEXP_LATENCY;
        }

        ctc_humber_diag_run_init_tcam_bist(chip_idx, latency);
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_check_bist,
        cli_ctc_check_humber_bist_cmd,
        "check bist humber CHIP_ID (ddr|qdr|exttcam|inttcam)",
        "Run",
        "Bit",
        "Humber",
        "Chip index",
        "Ddr",
        "Qdr",
        "External tcam",
        "Internal tcam",
        "Latency")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("ddr", 1))
    {
        ret = ctc_humber_diag_check_ddr_bist_rlt(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("qdr", 1))
    {
        ret = ctc_humber_diag_check_qdr_bist_rlt(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("exttcam", 1))
    {
        ret = ctc_humber_diag_check_ext_tcam_bist_rlt(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("inttcam", 1))
    {
        ret = ctc_humber_diag_check_init_tcam_bist_rlt(chip_idx);
    }

    if (ret < 0)
    {
        ctc_cli_out("Humber bist failed!\n");
    }
    else
    {
        ctc_cli_out("Humber bist pass!\n");
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_test_tcam_latency,
        cli_ctc_test_humber_tcam_latency_cmd,
        "test tcam humber CHIP_ID  (mpmiReadLatency|bistLatency)",
        "Test",
        "Tcam",
        "Humber",
        "Chip index",
        "Mpmi read latency",
        "Bist latency")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("mpmiReadLatency", 1))
    {
        ctc_humber_diag_tcam_mpmi_read_latency(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("bistLatency", 1))
    {
        ctc_humber_diag_tcam_bistLatency(chip_idx);
    }
    else
    {
        ctc_cli_out("Error parameter\n\r");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_test_sram_latency,
        cli_ctc_test_humber_sram_latency_cmd,
        "test sram humber CHIP_ID (ddr |qdr) (bistLatency)",
        "Test",
        "Sram",
        "Humber",
        "Chip index",
        "Ddr",
        "Qdr",
        "Bist latency")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("ddr", 1))
    {
        ctc_humber_diag_ddr_readLatency(chip_idx);
    }
    else if (CLI_CLI_STR_EQUAL("qdr", 1))
    {
        ctc_humber_diag_qdr_readLatency(chip_idx);
    }
    else
    {
        ctc_cli_out("Error parameter\n\r");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_run_capture,
        cli_ctc_humber_run_capture_cmd,
        "run capture humber CHIP_ID {exttcam|inttcam|ddr|qdr}",
        "Run",
        "Capture",
        "Humber",
        "Chip index",
        "External tcam",
        "Internal tcam",
        "Ddr",
        "Qdr")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("exttcam", 1))
    {
        ctc_humber_diag_start_capture_tcam(chip_idx, EXTCAM);
    }
    else if (CLI_CLI_STR_EQUAL("inttcam", 1))
    {
        ctc_humber_diag_start_capture_tcam(chip_idx, INTCAM);
    }
    else if (CLI_CLI_STR_EQUAL("ddr", 1))
    {
        ctc_humber_diag_start_capture_sram(chip_idx, DDR);
    }
    else if (CLI_CLI_STR_EQUAL("qdr", 1))
    {
        ctc_humber_diag_start_capture_sram(chip_idx, QDR);
    }
    else
    {
        ctc_cli_out("Error parameter\n\r");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_check_capture,
        cli_ctc_humber_check_capture_cmd,
        "check capture humber CHIP_ID {exttcam|inttcam|ddr|qdr}",
        "Check",
        "Capture",
        "Humber",
        "Chip index",
        "External tcam",
        "Internal tcam",
        "Ddr",
        "Qdr")
{
    int chip_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    if (CLI_CLI_STR_EQUAL("exttcam", 1))
    {
        ctc_humber_diag_stop_capture_tcam(chip_idx, EXTCAM);
    }
    else if (CLI_CLI_STR_EQUAL("inttcam", 1))
    {
        ctc_humber_diag_stop_capture_tcam(chip_idx, INTCAM);
    }
    else if (CLI_CLI_STR_EQUAL("ddr", 1))
    {
        ctc_humber_diag_stop_capture_sram(chip_idx, DDR);
    }
    else if (CLI_CLI_STR_EQUAL("qdr", 1))
    {
        ctc_humber_diag_stop_capture_sram(chip_idx, QDR);
    }
    else
    {
        ctc_cli_out("Error parameter\n\r");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_tcam_write_entry,
        cli_ctc_humber_tcam_write_entry_cmd,
        "tcam write humber CHIP_ID entry INDEX DATA  MASK {internal|external}",
        "Tcam",
        "Write",
        "Humber",
        "Chip index",
        "Entry",
        "Entry index",
        "Data value",
        "Mask value",
        "Internal",
        "External")
{
    uint32 chip_idx = 0;
    uint32 key_idx = 0;
    int data[4];
    int mask[4];
    uint8* data_string;
    uint8* mask_string;
    int8 data_len;
    int8 mask_len;
    uint8 datastuff[24];
    uint8 maskstuff[24];
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    key_idx = ctc_cmd_str2uint(argv[1], &ret);
    data_string = (uint8*)argv[2];
    mask_string = (uint8*)argv[3];

    data_len = sal_strlen((char*)data_string);
    mask_len = sal_strlen((char*)mask_string);

    if ((data_len > (20 + 2)) || (mask_len > (20 + 2)))
    {
        ctc_cli_out("\nInvalid parameter\n");
        return -1;
    }

    memset(datastuff, '0', sizeof(datastuff));
    memset(maskstuff, '0', sizeof(maskstuff));

    sal_memcpy((uint8*)datastuff + (20 - (data_len - 2)) + 4, data_string + 2, data_len - 2);
    sal_memcpy((uint8*)maskstuff + (20 - (mask_len - 2)) + 4, mask_string + 2, mask_len - 2);

    sal_sscanf((char*)datastuff, "%8x", &data[1]);
    sal_sscanf((char*)(datastuff + 8), "%8x", &data[2]);
    sal_sscanf((char*)(datastuff + 16), "%8x", &data[3]);

    sal_sscanf((char*)maskstuff, "%8x", &mask[1]);
    sal_sscanf((char*)(maskstuff + 8), "%8x", &mask[2]);
    sal_sscanf((char*)(maskstuff + 16), "%8x", &mask[3]);

    if (CLI_CLI_STR_EQUAL("internal", 4))
    {
        ctc_humber_diag_int_tcam_write(chip_idx, data, mask, key_idx, 0);
    }
    else if (CLI_CLI_STR_EQUAL("external", 1))
    {
        ctc_humber_diag_ext_tcam_write(chip_idx, data, mask, key_idx, 0);
    }
    else
    {
        ctc_cli_out("Error parameter\n");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_hb_debug_tool_tcam_write_register,
        cli_ctc_humber_tcam_write_register_cmd,
        "tcam write humber CHIP_ID register INDEX VALUE",
        "Tcam",
        "Write",
        "Humber",
        "Chip index",
        "Register",
        "Index",
        "Value")
{
    uint32 chip_idx = 0;
    uint32 key_idx = 0;
    int data[4];
    int mask[4];
    uint8* data_string;
    int8 data_len;
    uint8 datastuff[24];
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    key_idx = ctc_cmd_str2uint(argv[1], &ret);
    data_string = (uint8*)argv[2];

    data_len = sal_strlen((char*)data_string);

    if (data_len > (20 + 2))
    {
        ctc_cli_out("\nInvalid parameter\n");
        return -1;
    }

    memset(datastuff, '0', sizeof(datastuff));

    sal_memcpy((uint8*)datastuff + (20 - (data_len - 2)) + 4, data_string + 2, data_len - 2);

    sal_sscanf((char*)datastuff, "%8x", &data[1]);
    sal_sscanf((char*)(datastuff + 8), "%8x", &data[2]);
    sal_sscanf((char*)(datastuff + 16), "%8x", &data[3]);

    ctc_humber_diag_ext_tcam_write(chip_idx, data, mask, key_idx, 1);

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_tcam_read_entry,
        cli_ctc_humber_tcam_read_entry_cmd,
        "tcam read humber CHIP_ID entry INDEX {internal|external}",
        "Tcam",
        "Read",
        "Humber",
        "Chip index",
        "Entry",
        "Entry index",
        "Internal tcam",
        "External tcam")
{
    uint32 chip_idx = 0;
    uint32 key_idx = 0;
    int data[4];
    int mask[4];
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    key_idx = ctc_cmd_str2uint(argv[1], &ret);

    if (CLI_CLI_STR_EQUAL("internal", 2))
    {
        ctc_humber_diag_int_tcam_read(chip_idx, data, mask, key_idx, 0);
        ctc_cli_out("\next tcam entry data\nX: 0x%08x %08x %08x\nY: 0x%08x %08x %08x\n",
                    data[1], data[2], data[3], mask[1], mask[2], mask[3]);
    }
    else if (CLI_CLI_STR_EQUAL("external", 2))
    {
        ctc_humber_diag_ext_tcam_read(chip_idx, data, mask, key_idx, 0);
        ctc_cli_out("\nint tcam entry data\nX: 0x%08x %08x %08x\nY: 0x%08x %08x %08x\n",
                    data[1], data[2], data[3], mask[1], mask[2], mask[3]);
    }
    else
    {
        ctc_cli_out("Error parameter\n\r");
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_tcam_read_register,
        cli_ctc_humber_tcam_read_register_cmd,
        "tcam read humber CHIP_ID register INDEX",
        "Run",
        "Bit",
        "Humber",
        "Chip index",
        "Ddr",
        "Qdr",
        "External tcam",
        "Internal tcam",
        "Latency")
{
    uint32 chip_idx = 0;
    uint32 key_idx = 0;
    int data[4];
    int mask[4];
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    key_idx = ctc_cmd_str2uint(argv[1], &ret);

    ctc_humber_diag_ext_tcam_read(chip_idx, data, mask, key_idx, 1);

    ctc_cli_out("\nint tcam entry data\nX: 0x%08x %08x %08x\nY: 0x%08x %08x %08x\n",
                data[1], data[2], data[3], mask[1], mask[2], mask[3]);

    ctc_cli_out("\n");
    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_hb_debug_tool_cfg_4ghss,
        cli_ctc_humber_cfg_4ghss_cmd,
        "config humber CHIP_ID  hss4g eq EQ_VALUE amp AMP_VALUE slew SLEW_VALUE coef COEF_VALUE (all|PORT)",
        "Configure",
        "Humber",
        "Chip index",
        "4G HSS",
        "Eq",
        "Value of Eq",
        "Amp",
        "Value of Amp",
        "Slew",
        "Value of Slew",
        "Coef",
        "Value of Coef",
        "All ports",
        "Port index")
{
    uint32 chip_idx = 0;
    uint32 eq_value = 0;
    uint32 amp_value = 0;
    uint32 slew_value = 0;
    uint32 coef_value = 0;
    uint32 port_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    eq_value = ctc_cmd_str2uint(argv[1], &ret);
    amp_value = ctc_cmd_str2uint(argv[2], &ret);
    slew_value = ctc_cmd_str2uint(argv[3], &ret);
    coef_value = ctc_cmd_str2uint(argv[4], &ret);
    if (CLI_CLI_STR_EQUAL("all", 5))
    {
        ctc_humber_diag_cfg_4G_all_port(chip_idx, eq_value, amp_value, slew_value, coef_value);
    }
    else
    {
        port_idx = ctc_cmd_str2uint(argv[5], &ret);
        ctc_humber_diag_cfg_4G_port(chip_idx, port_idx, eq_value, amp_value, slew_value, coef_value);
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_cfg_6ghss,
        cli_ctc_humber_cfg_6ghss_cmd,
        "config humber CHIP_ID hss6g coe0 COE0_VALUE coe1 COE1_VALUE coe2 COE2_VALUE coe3 COE3_VALUE polarity POLARITY_VALUE (all|PORT)",
        "Configure",
        "Humber",
        "Chip index",
        "6G HSS",
        "Coe0 ",
        "Value of coe0",
        "Coe1",
        "Value of coe1",
        "Coe2",
        "Value of coe2",
        "Coe3",
        "Value of coe3",
        "Polarity",
        "Value of polarity",
        "All ports",
        "Port index")
{
    uint32 chip_idx = 0;
    uint32 coe0_value = 0;
    uint32 coe1_value = 0;
    uint32 coe2_value = 0;
    uint32 coe3_value = 0;
    uint32 polarity = 0;
    uint32 port_idx = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("Chip index out of range!\n");
        return CLI_ERROR;
    }

    coe0_value = ctc_cmd_str2uint(argv[1], &ret);
    coe1_value = ctc_cmd_str2uint(argv[2], &ret);
    coe2_value = ctc_cmd_str2uint(argv[3], &ret);
    coe3_value = ctc_cmd_str2uint(argv[4], &ret);
    polarity = ctc_cmd_str2uint(argv[5], &ret);

    if (CLI_CLI_STR_EQUAL("all", 5))
    {
        ctc_humber_diag_cfg_6G_all_port(chip_idx, coe0_value, coe1_value, coe2_value, coe3_value, polarity);
    }
    else
    {
        port_idx = ctc_cmd_str2uint(argv[5], &ret);
        ctc_humber_diag_cfg_6G_port(chip_idx, port_idx, coe0_value, coe1_value, coe2_value, coe3_value, polarity);
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_read,
        cli_ctc_humber_read_cmd,
        "read humber CHIP_ID OFFSET (NUM|)",
        "Read",
        "Humber register",
        "Chip index",
        "Register offset",
        "Register numbers")
{
    uint32 chip_idx = 0;
    uint32 offset = 0;
    uint32 nums = 1;
    uint32 cnt = 0;
    uint32 value = 0;
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("\n\rChip index out of range!\n");
        return CLI_ERROR;
    }

    offset = ctc_cmd_str2uint(argv[1], &ret);
    if (argc > 2)
    {
        nums = ctc_cmd_str2uint(argv[2], &ret);
    }

    for (cnt = 0; cnt < nums; cnt++)
    {
        ctc_humber_diag_read_chip(chip_idx, 0, offset + cnt * 4, &value);
        ctc_cli_out("\n\rchip: 0x%.8x offset 0x%x value 0x%.8x\n", chip_idx, offset + cnt * 4, value);
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_write,
        cli_ctc_humber_write_cmd,
        "write humber CHIP_ID OFFSET VALUE",
        "Write",
        "Humber register",
        "Chip index",
        "Register offset",
        "Register value")
{
    uint32 offset = 0;
    uint32 value = 0;
    int ret;
    uint32 chip_idx = 0;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("\n\rChip index out of range!\n");
        return CLI_ERROR;
    }

    offset = ctc_cmd_str2uint(argv[1], &ret);
    value = ctc_cmd_str2uint(argv[2], &ret);

    ctc_humber_diag_write_chip(chip_idx, 0, offset, value);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tool_catch_netrx,
        cli_ctc_catch_netrx_cmd,
        "catch humber CHIP_ID netrx macid MACID_VALUE ctc_sgmac_version VERSION_VALUE",
        "Catch",
        "Humber",
        "Chip index",
        "NetRx",
        "Macid",
        "Macid value",
        "Ctc sgmac version",
        "Version value")
{
    uint32 chip_idx = 0;
    uint32 idx = 0;
    uint32 mac_id = 0;
    uint32 version_value = 0;
    uint32 startAddr;
    uint32 value;
    uint32 headPtr, tailPtr, packetLength;
    uint32 data[64];
    int ret;
    uint8 lchip_num = 0;

    ret = ctc_get_local_chip_num(&lchip_num);
    if (0 != ret)
    {
        ctc_cli_out("Get Local Chip Number Error!\n");
        return CLI_ERROR;
    }

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (chip_idx > lchip_num - 1)
    {
        ctc_cli_out("\n\rChip index out of range!\n");
        return CLI_ERROR;
    }

    mac_id = ctc_cmd_str2uint(argv[1], &ret);
    version_value = ctc_cmd_str2uint(argv[2], &ret);

    startAddr = 0x3e4000 + (mac_id + 48) * 8;

    /*we don't care first read value*/
    ret = ctc_humber_diag_read_chip(chip_idx, 0, startAddr, (uint32*)&(value));
    if (ret < 0)
    {
        ctc_cli_out("\nread netRx channelInfo ram %x fail!\n", startAddr);
        return CLI_ERROR;
    }

    ret = ctc_humber_diag_read_chip(chip_idx, 0, startAddr + 4, (uint32*)&(value));
    if (ret < 0)
    {
        ctc_cli_out("\nread netRx channelInfo ram %x fail!\n", startAddr);
        return CLI_ERROR;
    }

    tailPtr = (value & 0x1ff);
    headPtr = ((value >> 9) & 0x1ff);
    packetLength = ((value >> 18) & 0x3ff);
    ctc_cli_out("\ntailPtr: 0x%x ,headPtr :0x%x, packetLength:0x%x\n", tailPtr, headPtr, packetLength);
    if (tailPtr == headPtr)
    {
        /*we just get one packet which length < =128byte*/
        startAddr = 0x3e8000 + headPtr * 2 * 16 * 4;

        for (idx = 0; idx < 32; idx++)
        {
            ctc_humber_diag_read_chip(chip_idx, 0, startAddr + 4 * idx, (uint32*)&(data[idx]));
        }

        if (version_value == 0)
        {
            ctc_sgmac_plus_header_t ctc_sgmac_plus_hdr;

            memset(&ctc_sgmac_plus_hdr, 0, sizeof(ctc_sgmac_plus_header_t));
            memcpy(&ctc_sgmac_plus_hdr, data, ctc_sgmac_PLUS_HEADER_LEN);
            ctc_humber_diag_sgmac_plus_hdr(&ctc_sgmac_plus_hdr);
            ctc_humber_diag_packet_body(data, packetLength);
        }
        else
        {
            ctc_sgmac2_header_t ctc_sgmac2_hdr;

            memset(&ctc_sgmac2_hdr, 0, sizeof(ctc_sgmac2_header_t));
            memcpy(&ctc_sgmac2_hdr, data, ctc_sgmac2_HEADER_LEN);
            ctc_humber_diag_sgmac2_hdr(&ctc_sgmac2_hdr);
            ctc_humber_diag_packet_body(data, packetLength);
        }
    }
    else
    {
        /*we  get one packet which length < =256 byte*/
        startAddr = 0x3e8000 + headPtr * 2 * 16 * 4;

        for (idx = 0; idx < 32; idx++)
        {
            ctc_humber_diag_read_chip(chip_idx, 0, startAddr + 4 * idx, (uint32*)&(data[idx]));
        }

        startAddr = 0x3e8000 + tailPtr * 2 * 16 * 4;

        for (idx = 0; idx < 32; idx++)
        {
            ctc_humber_diag_read_chip(chip_idx, 0, startAddr + 4 * idx, (uint32*)&(data[32 + idx]));
        }

        if (version_value == 0)
        {
            ctc_sgmac_plus_header_t ctc_sgmac_plus_hdr;

            memset(&ctc_sgmac_plus_hdr, 0, sizeof(ctc_sgmac_plus_header_t));
            memcpy(&ctc_sgmac_plus_hdr, data, ctc_sgmac_PLUS_HEADER_LEN);
            ctc_humber_diag_sgmac_plus_hdr(&ctc_sgmac_plus_hdr);
            ctc_humber_diag_packet_body(data, packetLength);
        }
        else
        {
            ctc_sgmac2_header_t ctc_sgmac2_hdr;

            memset(&ctc_sgmac2_hdr, 0, sizeof(ctc_sgmac2_header_t));
            memcpy(&ctc_sgmac2_hdr, data, ctc_sgmac2_HEADER_LEN);
            ctc_humber_diag_sgmac2_hdr(&ctc_sgmac2_hdr);
            ctc_humber_diag_packet_body(data, packetLength);
        }
    }

    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

int32
ctc_humber_chip_dbg_cli_init()
{
    install_element(CTC_DEBUG_MODE, &cli_ctc_show_humber_modules_stats_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_show_humber_bus_info_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_show_humber_discard_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_show_humber_sgmac_link_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_clear_humber_discard_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_run_humber_bist_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_check_humber_bist_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_test_humber_tcam_latency_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_test_humber_sram_latency_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_run_capture_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_check_capture_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_tcam_write_entry_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_tcam_write_register_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_tcam_read_entry_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_tcam_read_register_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_cfg_4ghss_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_cfg_6ghss_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_read_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_humber_write_cmd);
    install_element(CTC_DEBUG_MODE, &cli_ctc_catch_netrx_cmd);

    return CLI_SUCCESS;
}

