/* db and asic function declearation of cfm oam sys layer */
/**
 @file sys_humber_oam_db.h

 @date 2010-5-20

 @version v2.0

  This file contains sys layer function declarations for Ethernet OAM, and shall be called only by sys_humber_oam_cfm.c
*/
#ifndef _SYS_HUMBER_OAM_CFM_DB_H
#define _SYS_HUMBER_OAM_CFM_DB_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "ctc_oam.h"
#include "ctc_parser.h"

#include "drv_humber.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
#define ETH_OAM_DB_HASH_SIZE 512
#define ETH_OAM_DB_NH_VECTOR_BLOCK_NUM 128
#define ETH_OAM_MEP_INDEX_VECTOR_BLOCK_NUM 128
#define ETH_OAM_MEP_INDEX_ON_CPU 0x7fff

/**
 @brief  Define aps signal fail type for mep
*/
enum sys_oam_signal_fail_mep_type_s
{
    SYS_ETH_OAM_LOCAL_MEP,     /**<Signal fail in local mep*/
    SYS_ETH_OAM_REMOTE_MEP     /**<Signal fail in remote mep*/
};
typedef enum sys_oam_signal_fail_mep_type_s sys_oam_signal_fail_mep_type_t;

#define MEP_INDEX_ON_CPU_CHECK(sys_lmep) \
    if (sys_lmep->mep_on_cpu) \
    { \
        OAM_UNLOCK; \
        return CTC_E_OAM_INVALID_OPERATION_ON_CPU_MEP; \
    }

struct sys_eth_oam_lmep_port_status_s
{
    uint8 lchip;
    uint8 rsv[3];
    uint16 gport;
    uint16 vlan_id;
    ctc_oam_eth_port_status_t port_status;
};
typedef struct sys_eth_oam_lmep_port_status_s sys_eth_oam_lmep_port_status_t;

struct sys_eth_oam_lmep_intf_status_s
{
    uint8 lchip;
    uint8 rsv;
    uint16 gport;
    ctc_oam_eth_interface_status_t intf_status;
};
typedef struct sys_eth_oam_lmep_intf_status_s sys_eth_oam_lmep_intf_status_t;

/****************************************************************************
 *
* Function
*
****************************************************************************/

/***************************************************************************************************
----------------          Ethernet OAM (support IEEE 802.1ag and  ITU Y1731 OAM)        ------------
***************************************************************************************************/
/**
 @brief   hash left bucket key generator for ethernet oam
*/
extern uint32
_sys_humber_eth_oam_db_hash_key(void* data);

/**
 @brief   hash left bucket key generator for ethernet oam
*/
extern uint8
_sys_humber_eth_oam_hash_left_key(oam_lookup_type_t oam_lookup_type, void* data);

/**
 @brief   hash right bucket key generator for ethernet oam
*/
extern uint8
_sys_humber_eth_oam_hash_right_key(oam_lookup_type_t oam_lookup_type, void* data);

/**
 @brief   hash data compare function for ethernet oam
*/
extern bool
_sys_humber_eth_oam_hash_cmp(void* bucket_data, void* data);

/**
 @brief   initilization for ethernet oam db
*/
extern int32
_sys_humber_eth_oam_init_db(ctc_oam_global_t* oam_global);

/**
 @brief   initilization for ethernet oam regs
*/
extern int32
_sys_humber_eth_oam_init_regs(ctc_oam_global_t* oam_global);

/**
 @brief   get a new chan key entry index in asic hash
*/
extern int32
_sys_humber_oam_hash_get_new_chan_key_index(uint8 lchip, void* data, uint32* key_entry_index, sys_humber_oam_asic_index_type_t* key_index_type);

/**
 @brief   get associated chan index using hash key entry index or tcam key entry index
*/
extern uint32
_sys_humber_eth_oam_get_associated_chan_index(uint32 key_entry_index, sys_humber_oam_asic_index_type_t key_index_type);

/**
 @brief   search the ma id list to see if ma id already exist and return the entry pointer
*/
extern sys_eth_oam_maid_t*
_sys_humber_eth_oam_get_maid_in_db(ctc_slist_t* maid_list, ctc_oam_maid_t* ctc_eth_oam_maid);

/**
 @brief   get chan's mep index at input level
*/
extern uint16 _sys_humber_oam_get_chan_mep_index(ds_eth_oam_chan_t* ds_eth_oam_chan, int32 level);

/**
 @brief   get chan's mep index at input level
*/
extern void _sys_humber_oam_set_chan_mep_index(ds_eth_oam_chan_t* ds_eth_oam_chan, int32 level, uint16 mep_index);

/**
 @brief   lookup the hash db and calculate chan key table entry index and type for new entry
*/
extern int32
_sys_humber_eth_oam_build_chan_key_index(uint8 lchip, ctc_oam_chan_t* lmep_lkup_chan, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   prepair data for new sys chan entry from ctc chan data structure
*/
extern int32
_sys_humber_eth_oam_build_chan_data(uint8 lchip, ctc_oam_chan_t* lmep_lkup_chan, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   free the tcam index allocated by opf
*/
extern int32
_sys_humber_eth_oam_free_chan_key_index_and_type(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   look up the chan hash table in db to see if this chan already exists
*/
extern sys_eth_oam_lmep_lkup_chan_t*
_sys_humber_eth_oam_get_sys_chan_in_db(uint8 lchip, ctc_oam_key_t* oam_key);

/**
 @brief   write the chan and key to hardware table, update the tables if entry exists
*/
extern int32
_sys_humber_eth_oam_add_chan_and_key_to_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   insert mep lookup chan to sw hash
*/
extern int32
_sys_humber_eth_oam_add_chan_to_db(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   remove mep lookup chan from sw hash
*/
extern int32
_sys_humber_eth_oam_remove_chan_from_db(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   clear the chan and key in hardware table
*/
extern int32
_sys_humber_eth_oam_remove_chan_and_key_from_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   creat new lookup chan in db and write to asic
*/
extern int32
_sys_humber_eth_oam_add_new_chan(uint8 lchip, ctc_oam_chan_t* lmep_lkup_chan, sys_humber_oam_hash_entry_status_t entry_statu);

/**
 @brief   remove lookup chan in db and asic
*/
extern int32
_sys_humber_eth_oam_remove_chan(uint8 lchip, ctc_oam_chan_t* lmep_lkup_chan);

/**
 @brief   search the lmep list using md level to find if lmep already exists in db
*/
extern sys_eth_oam_lmep_t*
_sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_eth_oam_lmep_lkup_chan_t* sys_chan, uint8 md_level);

/**
 @brief   create nexthop id with nexthop offset and vlan id
*/
extern int32
_sys_humber_eth_oam_create_dowmmep_nexthop_with_vid(uint16 vlan_id);

/**
 @brief   hash tranverse function
*/
extern int32
_sys_humber_eth_oam_hash_tranverse(void* bucket_data, void* user_data);

/**
 @brief   delete nexthop id with vlan id
*/
extern int32
_sys_humber_eth_oam_delete_dowmmep_nexthop_with_vid(uint16 vlan_id);

/**
 @brief   build data for sys lmep structure
*/
extern int32
_sys_humber_eth_oam_build_lmep_data(ctc_oam_lmep_t* lmep, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   build ma and mep index
*/
extern int32
_sys_humber_eth_oam_build_lmep_index(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   update the mep related chan in asic
*/
extern int32
_sys_humber_eth_oam_update_chan_in_asic_for_add_lmep(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   write the mep related tables to asic
*/
extern int32
_sys_humber_eth_oam_add_lmep_to_asic(uint8 lchip, ctc_oam_lmep_t* lmep, sys_eth_oam_lmep_lkup_chan_t* sys_chan, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   free ma and mep index
*/
extern int32
_sys_humber_eth_oam_free_lmep_index(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   build lmep data, add to db and asic
*/
extern int32
_sys_humber_eth_oam_add_lmep_to_db_and_asic(uint8 lchip, ctc_oam_lmep_t* lmep, sys_eth_oam_lmep_lkup_chan_t* sys_chan, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   update the passive chan in asic after active chan updated
*/
extern int32
_sys_humber_eth_oam_update_passive_chan_in_asic_for_add_lmep(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan, ctc_oam_y1731_lmep_t* lmep, uint8 md_level);

/**
 @brief   remove the mep related tables from asic
*/
extern int32
_sys_humber_eth_oam_remove_lmep_from_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   remove the mep related tables from asic and db
*/
extern int32
_sys_humber_eth_oam_remove_lmep_from_db_and_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   update the passive chan in asic after lmep removed from active chan
*/
extern int32
_sys_humber_eth_oam_update_passive_chan_in_asic_for_remove_lmep(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   check if gport is local and returns the local chip id
*/
extern int32
_sys_humber_oam_get_local_chip_for_chan(ctc_oam_key_t* lmep_chan_key, uint8* lchip);

/**
 @brief   enable local mep in asic
*/
extern int32
_sys_humber_eth_oam_enable_lmep_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   enable local mep ccm in asic
*/
extern int32
_sys_humber_eth_oam_enable_lmep_ccm_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   enable local mep dm in asic
*/
extern int32
_sys_humber_eth_oam_enable_lmep_dm_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   build data for sys rmep structure
*/
extern int32
_sys_humber_eth_oam_build_rmep_data(ctc_oam_mep_type_t mep_type, ctc_oam_y1731_rmep_t* rmep, sys_eth_oam_lmep_t* sys_lmep, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   build rmep index
*/
extern int32
_sys_humber_eth_oam_build_rmep_index(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   free rmep index
*/
extern int32
_sys_humber_eth_oam_free_rmep_index(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   get remote mep from lmep's rmep list
*/
extern sys_eth_oam_rmep_t*
_sys_humber_eth_oam_get_rmep_in_lmep(sys_eth_oam_lmep_t* sys_lmep, ctc_oam_y1731_rmep_t* rmep);

/**
 @brief   write remote mep's key and chan if needed
*/
extern int32
_sys_humber_eth_oam_add_rmep_key_and_chan_to_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   write remote mep table
*/
extern int32
_sys_humber_eth_oam_add_rmep_to_asic(uint8 lchip, ctc_oam_y1731_rmep_t* rmep, sys_eth_oam_lmep_t* sys_lmep, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   remove remote mep table from asic
*/
extern int32
_sys_humber_eth_oam_remove_rmep_from_asic(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   remove remote mep's key and chan in asic if needed
*/
extern int32
_sys_humber_eth_oam_remove_rmep_key_and_chan_from_asic(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   enable remote mep in asic
*/
extern int32
_sys_humber_eth_oam_enable_rmep_in_asic(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   clear rmep seq number fail counter in asic
*/
extern int32
_sys_humber_eth_oam_clear_rmep_seq_num_fail_in_asic(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep);

/**
 @brief   config edge port in asic
*/
extern int32
_sys_humber_eth_oam_add_edge_port_chan_and_key_to_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan, uint8 level);

/**
 @brief   remove edge port from asic
*/
extern int32
_sys_humber_eth_oam_remove_edge_port_chan_and_key_from_asic(uint8 lchip, sys_eth_oam_lmep_lkup_chan_t* sys_chan);

/**
 @brief   set local mep tx cos
*/
extern int32
_sys_humber_eth_oam_set_lmep_tx_cos_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep, uint8 cos);

/**
 @brief   update one mep's port status in asic
*/
extern int32
_sys_humber_eth_oam_set_mep_port_status_in_asic(uint8 lchip, uint16 ma_index, ctc_oam_eth_port_status_t port_status);

/**
 @brief   set interface status for mep in asic
*/
extern int32
_sys_humber_eth_oam_set_mep_interface_status_in_asic(uint8 lchip, uint16 ma_index, ctc_oam_eth_interface_status_t intf_status);

/**
 @brief   hash tranvers function
*/
extern int32
_sys_humber_eth_oam_tranvers_hash_and_set_interface_status(void* bucket_data, void* user_data);

/**
 @brief   clear local mep rdi status
*/
extern int32
_sys_humber_eth_oam_clear_lmep_rdi_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep);

/**
 @brief   set aps signal fail state in ma
*/
extern int32
_sys_humber_eth_oam_set_aps_signal_fail_state_in_asic(uint8 lchip, sys_eth_oam_lmep_t* sys_lmep, sys_oam_signal_fail_mep_type_t mep_type, bool state);

/**
 @brief   set Eth OAM larger ccm interval to cpu
*/
extern int32
_sys_humber_eth_oam_set_larger_ccm_interval_in_asic(uint8 larger_interval_to_cpu);

/**
 @brief   set Eth OAM maid length format
*/
extern int32
_sys_humber_eth_oam_set_maid_len_format_in_asic(ctc_oam_maid_len_format_t maid_format_ptr);

/**
 @brief   set Eth OAM sender id
*/
extern int32
_sys_humber_eth_oam_set_sender_id_in_asic(ctc_oam_eth_senderid_t* sender_id);

/**
 @brief   set Eth OAM bridge mac
*/
extern int32
_sys_humber_eth_oam_set_bridge_mac_in_asic(mac_addr_t bridge_mac);

/**
 @brief   set lbm proc in asic or cpu
*/
extern int32
_sys_humber_eth_oam_set_lbm_proc_in_asic(uint32 value);

/**
 @brief   set lbr sa use lbm da
*/
extern int32
_sys_humber_eth_oam_set_lbr_sa_use_da_in_asic(uint32 value);

/**
 @brief   set lbr sa bridge mac mode
*/
extern int32
_sys_humber_eth_oam_set_lbr_sa_bridge_mac_mode_in_asic(uint32 value);

/**
 @brief   get rmep mac addr in asic
*/
extern int32
_sys_humber_eth_oam_get_rmep_mac_addr_in_asic(uint8 lchip, sys_eth_oam_rmep_t* sys_rmep, mac_addr_t rmep_mac_addr);

/**
 @brief   get lmep info in hash db
*/
extern int32
_sys_humber_eth_oam_tranvers_hash_and_get_mep_info(void* bucket_data, void* user_data);

#ifdef __cplusplus
}
#endif

#endif

