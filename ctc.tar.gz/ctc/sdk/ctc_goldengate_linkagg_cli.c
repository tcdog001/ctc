
/**
 @file ctc_greatbel_vlan_cli.c

 @date 2011-11-25

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_linkagg_cli.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_error.h"
#include "ctc_api.h"
#include "ctc_port_mapping_cli.h"

extern int32
sys_goldengate_linkagg_show_all_member(uint8 lchip, uint8 tid);

CTC_CLI(ctc_cli_gg_linkagg_show_detail_member_port,
        ctc_cli_gg_linkagg_show_detail_member_port_cmd,
        "show linkagg AGG_ID member-ports detail (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LINKAGG_M_STR,
        CTC_CLI_LINKAGG_ID_DESC,
        "Member ports of linkagg group",
        "all member include pad member",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8 tid = 0;
    uint8 index = 0;

    CTC_CLI_GET_INTEGER("linkagg id", tid, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    ret = sys_goldengate_linkagg_show_all_member(lchip, tid);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}


CTC_CLI(ctc_cli_gg_linkagg_show_local_member_port,
        ctc_cli_gg_linkagg_show_local_member_port_cmd,
        "show linkagg AGG_ID member-ports local-ports",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LINKAGG_M_STR,
        CTC_CLI_LINKAGG_ID_DESC,
        "Member ports of linkagg group",
        "Local member ports of linkagg group")
{
    int32 ret = CLI_SUCCESS;
    uint8 cnt  = 0;
    uint8 idx = 0;
    uint8 tid = CTC_MAX_LINKAGG_GROUP_NUM;
    uint16* p_gports;
    uint8 max_num = 0;

    CTC_CLI_GET_UINT8("linkagg id", tid, argv[0]);

    ret = ctc_linkagg_get_max_mem_num(&max_num);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    p_gports = (uint16*)sal_malloc(sizeof(uint16) * max_num);
    if (NULL == p_gports)
    {
        return CLI_ERROR;
    }

    sal_memset(p_gports, 0, sizeof(uint16) * max_num);

    ret = ctc_linkagg_get_1st_local_port(tid, p_gports, &cnt);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("%-11s%s\n", "No.", "Member-Gport");
    ctc_cli_out("----------------------\n");

    for (idx = 0; idx < cnt; idx++)
    {
        CTC_PORT_UNMAPPING(p_gports[idx]);
        ctc_cli_out("%-11u0x%04X\n", idx + 1, p_gports[idx]);
    }

    sal_free(p_gports);
    p_gports = NULL;

    return ret;
}
int32
ctc_goldengate_linkagg_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gg_linkagg_show_detail_member_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_linkagg_show_local_member_port_cmd);

    return CLI_SUCCESS;
}

