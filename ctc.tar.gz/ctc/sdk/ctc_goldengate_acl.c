/**
 @file ctc_goldengate_acl.c

 @date 2009-10-17

 @version v2.0

 The file contains acl APIs
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_linklist.h"
#include "ctc_goldengate_acl.h"

#include "sys_goldengate_acl.h"

int32
ctc_goldengate_acl_init(uint8 lchip, ctc_acl_global_cfg_t* acl_global_cfg)
{
    ctc_acl_global_cfg_t acl_cfg;

    if (NULL == acl_global_cfg)
    {
        sal_memset(&acl_cfg, 0, sizeof(ctc_acl_global_cfg_t));
        acl_cfg.ingress_port_service_acl_en = 0xF;
        acl_cfg.ingress_vlan_service_acl_en = 0xF;
        acl_global_cfg = &acl_cfg;
    }

    CTC_ERROR_RETURN(sys_goldengate_acl_init(lchip, acl_global_cfg));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_create_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_create_group(lchip, group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_destroy_group(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_destroy_group(lchip, group_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_install_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_install_group(lchip, group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_uninstall_group(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_uninstall_group(lchip, group_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_get_group_info(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_get_group_info(lchip, group_id, group_info));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_add_entry(uint8 lchip, uint32 group_id, ctc_acl_entry_t* acl_entry)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_add_entry(lchip, group_id, acl_entry));

    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_remove_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_goldengate_acl_remove_entry(lchip, entry_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_install_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_goldengate_acl_install_entry(lchip, entry_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_uninstall_entry(uint8 lchip, uint32 entry_id)
{

    CTC_ERROR_RETURN(sys_goldengate_acl_uninstall_entry(lchip, entry_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_remove_all_entry(uint8 lchip, uint32 group_id)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_remove_all_entry(lchip, group_id));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_set_entry_priority(uint8 lchip, uint32 entry_id, uint32 priority)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_set_entry_priority(lchip, entry_id, priority));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_get_multi_entry(uint8 lchip, ctc_acl_query_t* query)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_get_multi_entry(lchip, query));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_update_action(uint8 lchip, uint32 entry_id, ctc_acl_action_t* action)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_update_action(lchip, entry_id, action));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_copy_entry(uint8 lchip, ctc_acl_copy_entry_t* copy_entry)
{
    CTC_ERROR_RETURN(sys_goldengate_acl_copy_entry(lchip, copy_entry));
    return CTC_E_NONE;
}

int32
ctc_goldengate_acl_set_hash_field_sel(uint8 lchip, ctc_acl_hash_field_sel_t* field_sel)
{
    return sys_goldengate_acl_set_hash_field_sel(lchip, field_sel);
}


