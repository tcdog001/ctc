#ifndef _CTC_DBG_TOOL_H_
#define _CTC_DBG_TOOL_H_

#include "sal.h"

extern int32 ctc_dbg_tool_init(uint8 cli_tree_mode);

#endif
