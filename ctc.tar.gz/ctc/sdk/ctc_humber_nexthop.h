/**
 @file ctc_humber_nexthop.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-11-18

 @version v2.0

  This file contains  the nexthop APIs for customer
*/

#ifndef _CTC_HUMBER_NH_H
#define _CTC_HUMBER_NH_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_stats.h"

/**********************************************************************************
                      Define API function interfaces
***********************************************************************************/
/**
 @addtogroup nexthop NEXTHOP
 @{
*/

/**
 @brief SDK nexthop module initilize

 @param[in] lchip    local chip id

 @param[in] nh_cfg  nexthop module global config

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nexthop_init(uint8 lchip, ctc_nh_global_cfg_t* nh_cfg);

/**********************************************************************************
                      Define l2 ucast nexthop functions
***********************************************************************************/
/**
 @brief This function is to create normal ucast bridge nexthop entry

 @param[in] lchip    local chip id

 @param[in] gport   global port id

 @param[in] nh_type   bridge unicast nexthop sub type to create

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_l2uc(uint8 lchip, uint32 gport,  ctc_nh_param_brguc_sub_type_t nh_type);

/**
 @brief This function is to delete normal ucast bridge nexthop entry

 @param[in] lchip    local chip id

 @param[in] gport   global port id

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_l2uc(uint8 lchip, uint32 gport);


/**
 @brief Get ucast nhid by port + type

 @param[in] lchip    local chip id

 @param[in] gport global port of the system

 @param[in] nh_type bridge unicast nexthop sub type to create

 @param[out] nhid nexthop ID to get

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_get_l2uc(uint8 lchip, uint32 gport, ctc_nh_param_brguc_sub_type_t nh_type, uint32* nhid);

/**********************************************************************************
                      Define ipuc nexthop functions
***********************************************************************************/
/**
 @brief Create IPUC nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param nexthop parameter used to create this ipuc nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_ipuc(uint8 lchip, uint32 nhid, ctc_ip_nh_param_t* p_nh_param);

/**
 @brief Remove IPUC nexthop

 @param[in] lchip    local chip id

 @param[in] nhid Nexthop ID to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_ipuc(uint8 lchip, uint32 nhid);

/**
 @brief Update IPUC nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be updated

 @param[in] p_nh_param nexthop parameter used to update this ipuc nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_update_ipuc(uint8 lchip, uint32 nhid, ctc_ip_nh_param_t* p_nh_param);

/**********************************************************************************
                      Define ip tunnel nexthop functions
***********************************************************************************/
/**
 @brief Create ip tunnel nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param nexthop parameter used to create this ip tunnel nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_ip_tunnel(uint8 lchip, uint32 nhid, ctc_ip_tunnel_nh_param_t* p_nh_param);

/**
 @brief Remove ip tunnel nexthop

 @param[in] lchip    local chip id

 @param[in] nhid Nexthop ID to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_ip_tunnel(uint8 lchip, uint32 nhid);

/**
 @brief Update ip tunnel nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be updated

 @param[in] p_nh_param nexthop parameter used to update this ip tunnel nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_update_ip_tunnel(uint8 lchip, uint32 nhid, ctc_ip_tunnel_nh_param_t* p_nh_param);

/**********************************************************************************
                      Define mpls nexthop functions
***********************************************************************************/

/**
 @brief Create a mpls nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param   nexthop parameter used to create this nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_mpls(uint8 lchip, uint32 nhid, ctc_mpls_nexthop_param_t* p_nh_param);

/**
 @brief Remove mpls nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_mpls(uint8 lchip, uint32 nhid);

/**
 @brief Update a mpls unresolved nexthop to forwarded mpls push nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be updated

 @param[in] p_nh_param nexthop parameter used to update this nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_update_mpls(uint8 lchip, uint32 nhid, ctc_mpls_nexthop_param_t* p_nh_param);

/**********************************************************************************
                      Define iloop nexthop functions
***********************************************************************************/
/**
 @brief Create a ipe loopback nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param loopback nexthop parameters

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_iloop(uint8 lchip, uint32 nhid, ctc_loopback_nexthop_param_t* p_nh_param);

/**
 @brief Remove ipe loopback nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_iloop(uint8 lchip, uint32 nhid);

/**********************************************************************************
                      Define rspan(remote mirror) nexthop functions
***********************************************************************************/
/**
 @brief Create a rspan(remote mirror) nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created


 @param[in] p_nh_param remote mirror nexthop parameters

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_rspan(uint8 lchip, uint32 nhid, ctc_rspan_nexthop_param_t* p_nh_param);

/**
 @brief Remove rspan(remote mirror) nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_rspan(uint8 lchip, uint32 nhid);

/**********************************************************************************
                      Define ECMP nexthop functions
***********************************************************************************/
/**
 @brief Create a ECMP nexthop

 @param[in] lchip    local chip id

 @param[in] nhid ECMP nexthopid

 @param[in] p_nh_param Create data

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_ecmp(uint8 lchip, uint32 nhid, ctc_nh_ecmp_nh_param_t* p_nh_param);

/**
 @brief Delete a ECMP nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID of ECMP to be removed

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_ecmp(uint8 lchip, uint32 nhid);

/**
 @brief Update a ECMP nexthop

 @param[in] lchip    local chip id

 @param[in] nhid ECMP nexthopid

 @param[in] p_nh_param Update data

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_update_ecmp(uint8 lchip, uint32 nhid, ctc_nh_ecmp_nh_param_t* p_nh_param);

/**********************************************************************************
                      Define advanced vlan/APS  nexthop functions
***********************************************************************************/

/**
 @brief The function is to create Egress Vlan Editing nexthop or APS Egress Vlan Editing nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param  nexthop parameter used to create this nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_xlate(uint8 lchip, uint32 nhid, ctc_vlan_edit_nh_param_t* p_nh_param);

/**
 @brief The function is to remove Egress Vlan Editing nexthop or APS Egress Vlan Editing nexthop

 @param[in] lchip    local chip id

 @param[in] nhid            Egress vlan Editing nexthop id or APS Egress vlan Editing nexthop id

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_xlate(uint8 lchip, uint32 nhid);

/**
 @brief The function is to create flexible nexthop

 @param[in] lchip    local chip id

 @param[in] nhid nexthop ID to be created

 @param[in] p_nh_param  nexthop parameter used to create this nexthop

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_add_misc(uint8 lchip, uint32 nhid, ctc_misc_nh_param_t* p_nh_param);

/**
 @brief The function is to remove Eflexible nexthop

 @param[in] lchip    local chip id

 @param[in] nhid     nexthop ID to be created

 @return CTC_E_XXX

*/
extern int32
ctc_humber_nh_remove_misc(uint8 lchip, uint32 nhid);

/**********************************************************************************
                      Define stats functions in nexthop
***********************************************************************************/

/**
 @brief The function is to add stats

 @param[in] lchip    local chip id

 @param[in] nhid            stats nexthop id

 @return CTC_E_XXX

 */
extern int32
ctc_humber_nh_add_stats(uint8 lchip, uint32 nhid);

/**
 @brief The function is to delete stats

 @param[in] lchip    local chip id

 @param[in] nhid            stats nexthop id

 @return CTC_E_XXX

 */
extern int32
ctc_humber_nh_del_stats(uint8 lchip, uint32 nhid);

/**
 @brief The function is to get stats

 @param[in] lchip    local chip id

 @param[in] stats_info            stats info

 @return CTC_E_XXX

 */
extern int32
ctc_humber_nh_get_stats(uint8 lchip, ctc_nh_stats_info_t* stats_info);

/**
 @brief The function is to reset stats

 @param[in] lchip    local chip id

 @param[in] stats_info            stats info

 @return CTC_E_XXX

 */
extern int32
ctc_humber_nh_clear_stats(uint8 lchip, ctc_nh_stats_info_t* stats_info);

/**
 @brief This function is to create mcast nexthop

 @param[in] lchip    local chip id

 @param[in] nhid   nexthop ID to be created

 @param[in] p_nh_mcast_group   nexthop parameter used to create this mcast nexthop

 @return CTC_E_XXX
 */
extern int32
ctc_humber_nh_add_mcast(uint8 lchip, uint32 nhid, ctc_mcast_nh_param_group_t* p_nh_mcast_group);

/**
 @brief This function is to delete mcast nexthop

 @param[in] lchip    local chip id

 @param[in] nhid   nexthopid

 @return CTC_E_XXX
 */
extern int32
ctc_humber_nh_remove_mcast(uint8 lchip, uint32 nhid);

/**
 @brief This function is to update mcast nexthop

 @param[in] lchip    local chip id

 @param[in] nhid   nexthop ID

 @param[in] p_nh_mcast_group,  nexthop parameter used to add/remove  mcast member

 @return CTC_E_XXX
 */
extern int32
ctc_humber_nh_update_mcast(uint8 lchip, uint32 nhid, ctc_mcast_nh_param_group_t* p_nh_mcast_group);

/**@} end of @addtogroup nexthop NEXTHOP*/

#ifdef __cplusplus
}
#endif

#endif /*_CTC_HUMBER_NH_H*/

