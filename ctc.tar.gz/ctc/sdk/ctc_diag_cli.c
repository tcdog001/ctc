
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_diag_cli.h"

#include "drv_io.h"
#include "drv_humber.h"

#include "ctc_humber_chip_dbg_cli.h"
#include "ctc_humber_tblreg_wr_cli.h"

int32
ctc_diag_cli_init(void)
{
    ctc_humber_tblreg_wr_cli_init();
    ctc_humber_chip_dbg_cli_init();
    return 0;
}

