/**
 @date 2010-05-25

 @version v2.0

---file comments----
*/

/****************************************************************************
 *
 * Header files
 *
 *****************************************************************************/
#if 1
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_api.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_cpu_traffic_cli.h"
#include "sys_humber_cpu_traffic.h"
#include "ctc_port_mapping_cli.h"
#include "sys_humber_stats.h"
#include "sys_humber_queue_enq.h"


/****************************************************************************
 *
 * Function
 *
 *****************************************************************************/
CTC_CLI(ctc_cli_hb_cpu_traffic_show_exception_to_cpu,
        cpu_traffic_pdu_to_cpu_show_cmd,
        "show cpu-traffic (exception|fatal-exception) (index EXCP|all)",
        "Show",
        CTC_CLI_CPU_TRAFFIC_STR,
        "Exception",
        "Fatal exception",
        "Index",
        "If is exception the value <0-55> else fatal exception the value is <0-12>",
        "All")
{
    int32 ret;
    uint8 excp_idx = 0;
    uint8 max_excp_index = 0;
    uint8 index = 0;
    bool is_excp = TRUE;
    bool is_all = FALSE;

    /*1. parse exception or fatal-exception*/
    if (CLI_CLI_STR_EQUAL("exception", 0))
    {
        is_excp = TRUE;
    }
    else if (CLI_CLI_STR_EQUAL("fatal-exception", 0))
    {
        is_excp = FALSE;
    }

    /*2. parse exception or fatal-exception index value*/
    index = CTC_CLI_GET_ARGC_INDEX("index");
    if (index != 0xFF)
    {
        is_all = FALSE;
        CTC_CLI_GET_UINT8_RANGE("exception index",  excp_idx, argv[index + 1], 0, 0xFF);
    }

    index = CTC_CLI_GET_ARGC_INDEX("all");
    if (index != 0xFF)
    {
        is_all = TRUE;
    }

    if (is_all == FALSE)
    {
        ret = is_excp ? sys_humber_cpu_traffic_show_exception(excp_idx) : sys_humber_cpu_traffic_show_fatal_exception(excp_idx);
    }
    else
    {
        if (is_excp == TRUE)
        {
            for (excp_idx = 0; excp_idx < CTC_FATAL_EXCEPTION_0; excp_idx++)
            {
                ret = sys_humber_cpu_traffic_show_exception(excp_idx);
            }
        }
        else
        {
            max_excp_index = CTC_FATAL_EXCEPTION_15 - CTC_FATAL_EXCEPTION_0;

            for (excp_idx = 0; excp_idx <= max_excp_index; excp_idx++)
            {
                ret = sys_humber_cpu_traffic_show_fatal_exception(excp_idx);
            }
        }
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret =%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

CTC_CLI(ctc_cli_hb_cpu_traffic_show_info,
        ctc_cli_hb_cpu_traffic_show_info_cmd,
        "show cpu-traffic info (brief | detail)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_CPU_TRAFFIC_STR,
        "Display CPU traffic information",
        "Display CPU traffic information briefly",
        "Display CPU traffic information in detail")
{
    int32 ret = CLI_SUCCESS;
    uint8 mode;

    if (CLI_CLI_STR_EQUAL("brief", 0))
    {
        mode = SYS_SHOW_CPU_TRAFFIC_INFO_MODE_BRIEF;
    }
    else
    {
        mode = SYS_SHOW_CPU_TRAFFIC_INFO_MODE_DETAIL;
    }

    ret = sys_humber_show_cpu_traffic_info(mode);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_show_cpu_traffic_exception_stats,
        ctc_cli_hb_show_cpu_traffic_exception_stats_cmd,
        "show cpu-traffic lchip CHIP exception (all|INDEX) statistics",
        CTC_CLI_SHOW_STR,
        CTC_CLI_CPU_TRAFFIC_STR,
        "Exception",
        "All exception",
        "Exception index",
        "Statistics")
{
    uint32 chip_idx = 0, min = 0, max = 0;
    int i, sub_index;
    uint16 excp;
    uint16 queue_id;
    sys_stats_queue_t stats;
    char s_byte[UINT64_STR_LEN];
    uint64 drop_pkts;
    uint64 drop_bytes;
    uint64 deq_pkts;
    uint64 deq_bytes;
    int ret;

    chip_idx = ctc_cmd_str2uint(argv[0], &ret);
    if (CLI_CLI_STR_EQUAL("all", 1))
    {
        max = MAX_CTC_EXCEPTION;
        min = 0;
    }
    else
    {
        max = ctc_cmd_str2uint(argv[1], &ret);
        if (max >= MAX_CTC_EXCEPTION)
        {
            ctc_cli_out("Exception index must be between 0 to %d!\n", MAX_CTC_EXCEPTION - 1);
            return CLI_ERROR;
        }

        min = max;
        max++;
    }

    for (excp = min; excp < max; excp++)
    {
        drop_pkts = 0;
        drop_bytes = 0;
        deq_pkts = 0;
        deq_bytes = 0;

        sub_index = 0;

        if (CTC_EXCEPTION_INGRESS_2 == excp)
        {
            sub_index = 15;
        }
        else if (CTC_EXCEPTION_INGRESS_3 == excp)
        {
            sub_index = 15;
        }
        else if (CTC_EXCEPTION_INGRESS_7 == excp)
        {
            sub_index = 4;
        }
        else if (CTC_EXCEPTION_INGRESS_PARSER_PTP == excp)
        {
            sub_index = 6;
        }
        else if (CTC_EXCEPTION_EGRESS_PARSER_PTP == excp)
        {
            sub_index = 3;
        }

        if (0 == sub_index)
        {
            sys_humber_queue_get_queue_id(CTC_QUEUE_TYPE_EXCP_CPU, excp, 0, &queue_id);
            sys_humber_stats_get_queue_stats(chip_idx, queue_id, &stats);
            drop_pkts += stats.queue_drop_pkts;
            drop_bytes += stats.queue_drop_bytes;
            deq_pkts += stats.queue_deq_pkts;
            deq_bytes += stats.queue_deq_bytes;

            ctc_cli_out("Exception %d statistics:\n", excp);
            ctc_uint64_to_str(drop_pkts, s_byte);
            ctc_cli_out("    Dropped packets:%s ,", s_byte);
            ctc_uint64_to_str(drop_bytes, s_byte);
            ctc_cli_out("Dropped bytes:%s\n", s_byte);
            ctc_uint64_to_str(deq_pkts, s_byte);
            ctc_cli_out("    Transmitted packets:%s ,", s_byte);
            ctc_uint64_to_str(deq_bytes, s_byte);
            ctc_cli_out("Transmitted bytes:%s\n", s_byte);
        }
        else
        {
            ctc_cli_out("Exception %d statistics:\n", excp);

            for (i = 0; i <= sub_index; i++)
            {
                drop_pkts = 0;
                drop_bytes = 0;
                deq_pkts = 0;
                deq_bytes = 0;

                sys_humber_queue_get_queue_id(CTC_QUEUE_TYPE_EXCP_CPU, excp, i, &queue_id);
                sys_humber_stats_get_queue_stats(chip_idx, queue_id, &stats);
                drop_pkts += stats.queue_drop_pkts;
                drop_bytes += stats.queue_drop_bytes;
                deq_pkts += stats.queue_deq_pkts;
                deq_bytes += stats.queue_deq_bytes;

                ctc_cli_out("    Sub Exception %d statistics:\n", i);
                ctc_uint64_to_str(drop_pkts, s_byte);
                ctc_cli_out("        Dropped packets:%s ,", s_byte);
                ctc_uint64_to_str(drop_bytes, s_byte);
                ctc_cli_out("Dropped bytes:%s\n", s_byte);
                ctc_uint64_to_str(deq_pkts, s_byte);
                ctc_cli_out("        Transmitted packets:%s ,", s_byte);
                ctc_uint64_to_str(deq_bytes, s_byte);
                ctc_cli_out("Transmitted bytes:%s\n", s_byte);
            }
        }
    }

    return CLI_SUCCESS;
}

int32
ctc_humber_cpu_traffic_cli_init(void)
{

#ifdef SDK_INTERNAL_CLI_SHOW
    install_element(CTC_SDK_MODE, &ctc_cli_hb_cpu_traffic_show_info_cmd);
    install_element(CTC_SDK_MODE, &cpu_traffic_pdu_to_cpu_show_cmd);
#endif
    install_element(CTC_SDK_MODE, &ctc_cli_hb_show_cpu_traffic_exception_stats_cmd);

    return 0;
}

#endif

