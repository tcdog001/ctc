/**
 @file ctc_chip_cli.h

 @date 2009-12-22

 @version v2.0

*/

#ifndef _CTC_HUMBER_CHIP_CLI_H_
#define _CTC_HUMBER_CHIP_CLI_H_
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_cli.h"

extern int32
ctc_humber_chip_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif

