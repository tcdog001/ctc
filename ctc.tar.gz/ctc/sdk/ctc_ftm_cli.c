/**
 @file ctc_alloc_cli.c

 @date 2009-11-23

 @version v2.0

---file comments----
*/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_ftm_cli.h"
#include "ctc_api.h"
#include "ctc_ftm.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "sys_humber_opf.h"
#include "ctc_port_mapping_cli.h"

CTC_CLI(ctc_cli_gb_ftm_debug_on,
        ctc_cli_gb_ftm_debug_on_cmd,
        "debug alloc (ctc|sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_MEM_ALLOCM_STR,
        "CTC layer",
        "Sys layer"
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = ALLOC_CTC;
    }
    else
    {
        typeenum = ALLOC_SYS;
    }

    ctc_debug_set_flag("alloc", "alloc", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ftm_debug_off,
        ctc_cli_gb_ftm_debug_off_cmd,
        "no debug alloc (ctc|sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_MEM_ALLOCM_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = ALLOC_CTC;
    }
    else
    {
        typeenum = ALLOC_SYS;
    }

    ctc_debug_set_flag("alloc", "alloc", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ftm_show_alloc_info,
        ctc_cli_gb_ftm_show_alloc_info_cmd,
        "show alloc info",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MEM_ALLOCM_STR,
        "Information of TCAM and Sram")
{
    int32 ret = CLI_SUCCESS;

    ret = ctc_ftm_show_alloc_info();

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

/* this data structure is related with enum sys_humber_opf_type */
char ctc_humber_opf_str[MAX_OPF_TBL_NUM][40] =
{
    "opf-usrid-vlan-key",
    "opf-usrid-mac-key",
    "opf-usrid-ipv4-key",
    "opf-usrid-ipv6-key",
    "local-met-dsfwd-sram",
    "local-nexthop-sram",
    "l2edit-sram",
    "l3edit-sram",
    "opf-nh-global-nh-offset",
    "fdb-sram-hash-collision-key",
    "nhid-internal",
    "opf-qos-flow-policer",
    "opf-qos-flow-policer-with-stats",
    "opf-qos-policer-profile",
    "fwd-stats-sram",
    "opf-queue-drop-profile",
    "opf-queue-shape-profile",
    "opf-group-shape-profile",
    "opf-queue-group",
    "opf-service-queue",
    "opf-oam-tcam-key",
    "opf-oam-mep-rmep",
    "opf-oam-ma",
    "opf-oam-ma-name",
    "opf-ipv4-uc-block",
    "opf-ipv6-uc-block",
    "opf-ipv4-mc-block",
    "opf-ipv6-mc-block",
    "opf-acl-fwd-sram",
    "opf-foam-mep",
    "opf-foam-ma",
    "opf-tunnel-ipv4-sa",
    "opf-tunnel-ipv6-ip",
    "opf-tunnel-ipv4-ipuc",
    "opf-tunnel-ipv6-ipuc",
    "opf-foam-ma-name",
/*end*/};

CTC_CLI(ctc_cli_gb_ftm_show_opf_type_info,
        ctc_cli_gb_ftm_show_opf_type_info_cmd,
        "show opf type (TYPE|all)",
        CTC_CLI_SHOW_STR,
        "Offset pool freelist",
        "OPF type",
        "OPF type value",
        "All types")
{
    uint8 opf_type;

    if (0 == sal_memcmp("all", argv[0], 3))
    {
        ctc_cli_out("-----------------------------------\n");

        for (opf_type = 0; opf_type < MAX_OPF_TBL_NUM; opf_type++)
        {
            ctc_cli_out("%d ---- %s\n", opf_type, ctc_humber_opf_str[opf_type]);
        }
    }
    else
    {
        CTC_CLI_GET_UINT8_RANGE("opf type", opf_type, argv[0], 0, CTC_MAX_UINT8_VALUE);
        if (opf_type >= MAX_OPF_TBL_NUM)
        {
            ctc_cli_out("invalid opf type : %d \n", opf_type);
            return CLI_ERROR;
        }

        ctc_cli_out("-----------------------------------\n");
        ctc_cli_out("%d ---- %s\n", opf_type, ctc_humber_opf_str[opf_type]);
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ftm_show_opf_alloc_info,
        ctc_cli_gb_ftm_show_opf_alloc_info_cmd,
        "show opf alloc type TYPE index INDEX",
        CTC_CLI_SHOW_STR,
        "Offset pool freelist",
        "OPF alloc info",
        "OPF type",
        "OPF type value",
        "The index of OPF",
        "Value <0-0xFf>")
{
    int32 ret = CLI_SUCCESS;

    sys_humber_opf_t opf;

    sal_memset(&opf, 0, sizeof(sys_humber_opf_t));

    CTC_CLI_GET_UINT8_RANGE("opf type", opf.pool_type, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT8_RANGE("opf index", opf.pool_index, argv[1], 0, CTC_MAX_UINT8_VALUE);

    if (opf.pool_type >= MAX_OPF_TBL_NUM)
    {
        ctc_cli_out("invalid opf type : %d \n", opf.pool_type);
        return CLI_ERROR;
    }

    ctc_cli_out("Print opf type:%d -- %s index :%d alloc information\n", opf.pool_type, ctc_humber_opf_str[opf.pool_type], opf.pool_index);
    ctc_cli_out("--------------------------------------------------------\n");

    ret = sys_humber_opf_print_alloc_info(&opf);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gb_ftm_opf_debug_on,
        ctc_cli_gb_ftm_opf_debug_on_cmd,
        "debug opf (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        "Offset pool freelist"
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    ctc_debug_set_flag("opf", "opf", OPF_SYS, level, TRUE);
    return CLI_SUCCESS;
}
CTC_CLI(ctc_cli_gb_ftm_opf_debug_off,
        ctc_cli_gb_ftm_opf_debug_off_cmd,
        "no debug opf",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        "Offset pool freelist")
{
    uint8 level = 0;

    ctc_debug_set_flag("opf", "opf", OPF_SYS, level, FALSE);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ftm_opf_show_debug,
        ctc_cli_gb_ftm_opf_show_debug_cmd,
        "show debug opf",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        "Offset pool freelist")
{
    uint8 level = 0;

    ctc_cli_out(" opf  debug %s\n",
                (ctc_debug_get_flag("opf", "opf", OPF_SYS, &level) == TRUE) ? "on" : "off");
    return CLI_SUCCESS;

}

int32
ctc_alloc_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_show_alloc_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_show_opf_type_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_show_opf_alloc_info_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_opf_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_opf_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ftm_opf_show_debug_cmd);

    return CTC_E_NONE;
}

