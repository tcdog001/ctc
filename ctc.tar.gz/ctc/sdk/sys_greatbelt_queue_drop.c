/**
 @file sys_greatbelt_queue_drop.c

 @date 2010-01-13

 @version v2.0

*/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "ctc_const.h"
#include "ctc_error.h"
#include "ctc_hash.h"

#include "sys_greatbelt_chip.h"
#include "sys_greatbelt_opf.h"
#include "sys_greatbelt_queue_enq.h"
#include "sys_greatbelt_queue_drop.h"

#include "drv_lib.h"
#include "drv_io.h"

/****************************************************************************
 *
 * Global and Declaration
 *
 ****************************************************************************/
#define SYS_DROP_PROFILE_BLOCK_NUM 2
#define SYS_DROP_PROFILE_BLOCK_SIZE 4
#define SYS_MAX_DROP_PROFILE_NUM  8
#define SYS_MAX_DROP_PROFILE 15

#define SYS_MAX_DROP_THRD (16 * 1024 - 1)
#define SYS_MAX_DROP_PROB (128 - 1)

extern sys_queue_master_t* p_queue_master;

/****************************************************************************
 *
 * Function
 *
 ****************************************************************************/

static INLINE uint32
_sys_greatbelt_queue_drop_profile_hash_make(sys_queue_drop_profile_t* p_prof)
{
    uint8* data= (uint8*)&p_prof->profile;
    uint8   length = sizeof(ds_que_thrd_profile_t);

    return ctc_hash_caculate(length, data);
}

/**
 @brief Queue drop hash comparison hook.
*/
static INLINE bool
_sys_greatbelt_queue_drop_profile_hash_cmp(sys_queue_drop_profile_t* p_prof1,
                                           sys_queue_drop_profile_t* p_prof2)
{
    SYS_QUEUE_DBG_FUNC();

    if (!p_prof1 || !p_prof2)
    {
        return FALSE;
    }

    if (!sal_memcmp(&p_prof1->profile, &p_prof2->profile, sizeof(ds_que_thrd_profile_t)))
    {
        return TRUE;
    }

    return 0;
}

static int32
_sys_greatbelt_queue_drop_profile_alloc_offset(uint8 lchip,
                                               uint16* profile_id)
{
    sys_greatbelt_opf_t opf;
    uint32 offset  = 0;

    SYS_QUEUE_DBG_FUNC();

    sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));
    opf.pool_type = OPF_QUEUE_DROP_PROFILE;
    opf.pool_index = lchip;

    CTC_ERROR_RETURN(sys_greatbelt_opf_alloc_offset(&opf, 1, &offset));

    *profile_id = offset;

    SYS_QUEUE_DBG_INFO("alloc drop profile id = %d\n", offset);

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_queue_drop_profile_free_offset(uint8 lchip,
                                              uint16 profile_id)
{
    sys_greatbelt_opf_t opf;
    uint32 offset  = 0;

    SYS_QUEUE_DBG_FUNC();

    sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));
    opf.pool_type = OPF_QUEUE_DROP_PROFILE;
    opf.pool_index = lchip;

    offset = profile_id;

    CTC_ERROR_RETURN(sys_greatbelt_opf_free_offset(&opf, 1, offset));

    SYS_QUEUE_DBG_INFO("free drop profile id = %d\n", offset);

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_queue_drop_profile_build_data(ctc_qos_queue_drop_t* p_drop,
                                             ds_que_thrd_profile_t* p_profile)
{
    SYS_QUEUE_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_drop);
    CTC_PTR_VALID_CHECK(p_profile);

    p_profile->wred_max_thrd0 = p_drop->max_th[0];
    p_profile->wred_max_thrd1 = p_drop->max_th[1];
    p_profile->wred_max_thrd2 = p_drop->max_th[2];
    p_profile->wred_max_thrd3 = p_drop->max_th[3];

    p_profile->wred_min_thrd0 = p_drop->min_th[0];
    p_profile->wred_min_thrd1 = p_drop->min_th[1];
    p_profile->wred_min_thrd2 = p_drop->min_th[2];
    p_profile->wred_min_thrd3 = p_drop->min_th[3];

    p_profile->max_drop_prob0 = p_drop->drop_prob[0];
    p_profile->max_drop_prob1 = p_drop->drop_prob[1];
    p_profile->max_drop_prob2 = p_drop->drop_prob[2];
    p_profile->max_drop_prob3 = p_drop->drop_prob[3];

    SYS_QUEUE_DBG_INFO("p_profile->wred_max_thrd0 = %d\n", p_profile->wred_max_thrd0);
    SYS_QUEUE_DBG_INFO("p_profile->wred_max_thrd1 = %d\n", p_profile->wred_max_thrd1);
    SYS_QUEUE_DBG_INFO("p_profile->wred_max_thrd2 = %d\n", p_profile->wred_max_thrd2);
    SYS_QUEUE_DBG_INFO("p_profile->wred_max_thrd3 = %d\n", p_profile->wred_max_thrd3);

    SYS_QUEUE_DBG_INFO("p_profile->wred_min_thrd0 = %d\n", p_profile->wred_min_thrd0);
    SYS_QUEUE_DBG_INFO("p_profile->wred_min_thrd1 = %d\n", p_profile->wred_min_thrd1);
    SYS_QUEUE_DBG_INFO("p_profile->wred_min_thrd2 = %d\n", p_profile->wred_min_thrd2);
    SYS_QUEUE_DBG_INFO("p_profile->wred_min_thrd3 = %d\n", p_profile->wred_min_thrd3);

    SYS_QUEUE_DBG_INFO("p_profile->max_drop_prob0 = %d\n", p_profile->max_drop_prob0);
    SYS_QUEUE_DBG_INFO("p_profile->max_drop_prob1 = %d\n", p_profile->max_drop_prob1);
    SYS_QUEUE_DBG_INFO("p_profile->max_drop_prob2 = %d\n", p_profile->max_drop_prob2);
    SYS_QUEUE_DBG_INFO("p_profile->max_drop_prob3 = %d\n", p_profile->max_drop_prob3);

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_queue_drop_profile_write_asic(uint8 lchip,
                                             sys_queue_drop_profile_t* p_sys_profile)
{
    uint32 cmd = 0;
    uint8 i = 0;
    uint8 profile_id = 0;

    SYS_QUEUE_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_sys_profile);
    cmd = DRV_IOW(DsQueThrdProfile_t, DRV_ENTRY_FLAG);

    for (i = 0; i < 8; i++)
    {
        profile_id = (p_sys_profile->profile_id << 3) + i;
        CTC_ERROR_RETURN(DRV_IOCTL(lchip,
                                   profile_id,
                                   cmd,
                                   &p_sys_profile->profile));

        SYS_QUEUE_DBG_INFO("write drop profile id = %d\n", profile_id);
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_queue_drop_write_asic(uint8 lchip,
                                     uint8 mode,
                                     uint16 queue_id,
                                     uint16 profile_id)
{
    uint32 cmd = 0;
    ds_egr_resrc_ctl_t ds_egr_resrc_ctl;

    SYS_QUEUE_DBG_FUNC();

    sal_memset(&ds_egr_resrc_ctl, 0, sizeof(ds_egr_resrc_ctl_t));

    cmd = DRV_IOR(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));
    ds_egr_resrc_ctl.wred_drop_mode = mode;
    ds_egr_resrc_ctl.que_min_prof_id = 1;
    ds_egr_resrc_ctl.que_thrd_prof_id_high = profile_id;
    cmd = DRV_IOW(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));
    SYS_QUEUE_DBG_INFO("queue_id = %d\n", queue_id);
    SYS_QUEUE_DBG_INFO("wred_drop_mode = %d\n", ds_egr_resrc_ctl.wred_drop_mode);
    SYS_QUEUE_DBG_INFO("que_min_prof_id = %d\n", ds_egr_resrc_ctl.que_min_prof_id);
    SYS_QUEUE_DBG_INFO("que_thrd_prof_id_high = %d\n", ds_egr_resrc_ctl.que_thrd_prof_id_high);

    return CTC_E_NONE;

}

static int32
_sys_greatbelt_queue_drop_profile_remove(uint8 lchip,
                                         sys_queue_drop_profile_t* p_sys_profile_old)
{
    sys_queue_drop_profile_t* p_sys_profile_find = NULL;
    ctc_spool_t* p_profile_pool               = NULL;
    int32 ret            = 0;
    uint16 profile_id    = 0;

    SYS_QUEUE_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_sys_profile_old);

    p_profile_pool = p_queue_master->p_drop_profile_pool[lchip];

    p_sys_profile_find = ctc_spool_lookup(p_profile_pool, p_sys_profile_old);
    if (NULL == p_sys_profile_find)
    {
        SYS_QUEUE_DBG_ERROR("p_sys_profile_find no found !!!!!!!!\n");
        return CTC_E_ENTRY_NOT_EXIST;
    }

    ret = ctc_spool_remove(p_profile_pool, p_sys_profile_old, NULL);
    if (ret < 0)
    {
        SYS_QUEUE_DBG_ERROR("ctc_spool_remove fail!!!!!!!!\n");
        return CTC_E_SPOOL_REMOVE_FAILED;
    }

    if (ret == CTC_SPOOL_E_OPERATE_MEMORY)
    {
        profile_id = p_sys_profile_find->profile_id;
        /*free ad index*/
        CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_profile_free_offset(lchip, profile_id));
        mem_free(p_sys_profile_find);
    }

    return CTC_E_NONE;
}


static int32
_sys_greatbelt_queue_drop_profile_add(uint8 lchip,
                                      ctc_qos_queue_drop_t* p_drop,
                                      sys_queue_node_t* p_sys_queue,
                                      sys_queue_drop_profile_t** pp_sys_profile_get)
{
    ctc_spool_t* p_profile_pool    = NULL;
    sys_queue_drop_profile_t* p_sys_profile_old = NULL;
    sys_queue_drop_profile_t* p_sys_profile_new = NULL;
    int32 ret            = 0;
    uint16 profile_id    = 0;

    SYS_QUEUE_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_drop);
    CTC_PTR_VALID_CHECK(p_sys_queue);
    CTC_PTR_VALID_CHECK(pp_sys_profile_get);

    p_sys_profile_new = mem_malloc(MEM_QUEUE_MODULE, sizeof(sys_queue_drop_profile_t));
    if (NULL == p_sys_profile_new)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_sys_profile_new, 0, sizeof(sys_queue_drop_profile_t));
    _sys_greatbelt_queue_drop_profile_build_data(p_drop,
                                                &p_sys_profile_new->profile);

    p_sys_profile_old = p_sys_queue->p_drop_profile;

    p_profile_pool = p_queue_master->p_drop_profile_pool[lchip];

    if (p_sys_profile_old)
    {
        if (!sal_memcmp(&p_sys_profile_old->profile,
                        &p_sys_profile_new->profile,
                        sizeof(ds_que_thrd_profile_t)))
        {
            *pp_sys_profile_get = p_sys_profile_old;
            mem_free(p_sys_profile_new);
            return CTC_E_NONE;
        }
    }

    ret = ctc_spool_add(p_profile_pool,
                        p_sys_profile_new,
                        p_sys_profile_old,
                        pp_sys_profile_get);

    if (ret == CTC_SPOOL_E_OPERATE_MEMORY)
    {
        ret = _sys_greatbelt_queue_drop_profile_alloc_offset(lchip, &profile_id);
        if (ret < 0)
        {
            ctc_spool_remove(p_profile_pool, p_sys_profile_new, NULL);
            mem_free(p_sys_profile_new);
            goto ERROR_RETURN;
        }

        (*pp_sys_profile_get)->profile_id = profile_id;
    }
    else
    {
        mem_free(p_sys_profile_new);

        if (ret < 0)
        {
            ret = CTC_E_SPOOL_ADD_UPDATE_FAILED;
            goto ERROR_RETURN;
        }
    }

    /*key is found, so there is an old ad need to be deleted.*/
    if (p_sys_profile_old)
    {
        CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_profile_remove(lchip, p_sys_profile_old));
    }

    p_sys_queue->p_drop_profile = *pp_sys_profile_get;


    return CTC_E_NONE;

ERROR_RETURN:
    return ret;

}

int32
sys_greatbelt_queue_set_queue_drop(uint8 lchip,
                                   uint16 queue_id,
                                   ctc_qos_queue_drop_t* p_drop)
{
    sys_queue_drop_profile_t* p_sys_profile_new = NULL;
    sys_queue_node_t* p_sys_queue_node = NULL;
    int32 ret = 0;
    uint8 i = 0;

    SYS_QUEUE_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_drop);

    for (i = 0; i < 4; i++)
    {
        CTC_MAX_VALUE_CHECK(p_drop->max_th[i],    SYS_MAX_DROP_THRD);
        CTC_MAX_VALUE_CHECK(p_drop->min_th[i],    SYS_MAX_DROP_THRD);
        CTC_MAX_VALUE_CHECK(p_drop->drop_prob[i], SYS_MAX_DROP_PROB);
        /*
        if(3 == i)
        {
            p_drop->max_th[i] = 10;
            p_drop->min_th[i] = 10;
            p_drop->drop_prob[i] = 10;
        }
        */
    }

    p_sys_queue_node = ctc_vector_get(p_queue_master->queue_vec[lchip], queue_id);
    if (NULL == p_sys_queue_node)
    {
        return CTC_E_ENTRY_NOT_EXIST;
    }

    /*add policer prof*/
    CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_profile_add(lchip,
                                                p_drop,
                                                p_sys_queue_node,
                                                &p_sys_profile_new));

    /*write policer prof*/
    CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_profile_write_asic(lchip,
                                                       p_sys_profile_new));

    /*write policer ctl and count*/
    CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_write_asic(lchip,
                                               p_drop->mode,
                                               queue_id,
                                               p_sys_profile_new->profile_id));

    return ret;

}

int32
sys_greatbelt_queue_set_drop(ctc_qos_drop_t* p_drop)
{
    uint16 queue_id = 0;
    uint8 lchip = 0;
    uint8 lchip_num = 0;

    SYS_QUEUE_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_drop);

    /*get queue_id*/

    lchip_num = sys_greatbelt_get_local_chip_num();
    ;

    for (lchip = 0; lchip < lchip_num; lchip++)
    {

        CTC_ERROR_RETURN(_sys_greatbelt_queue_get_queue_id(lchip,
                                                           &p_drop->queue,
                                                           &queue_id));

        CTC_ERROR_RETURN(sys_greatbelt_queue_set_queue_drop(lchip,
                                                            queue_id,
                                                            &p_drop->drop));
    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_queue_get_drop(ctc_qos_drop_t* p_drop)
{

    uint16 queue_id = 0;
    uint8 lchip = 0;
    sys_queue_node_t* p_sys_queue_node = NULL;
    ds_que_thrd_profile_t profile;
    uint32 cmd = 0;
    uint8 profile_id = 0;

    SYS_QUEUE_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_drop);

    sal_memset(&profile, 0, sizeof(ds_que_thrd_profile_t));

    /*get queue_id*/
    CTC_ERROR_RETURN(_sys_greatbelt_queue_get_queue_id(lchip,
                                                       &p_drop->queue,
                                                       &queue_id));

    p_sys_queue_node = ctc_vector_get(p_queue_master->queue_vec[lchip], queue_id);
    if (NULL == p_sys_queue_node)
    {
        return CTC_E_ENTRY_NOT_EXIST;
    }

    cmd = DRV_IOW(DsQueThrdProfile_t, DRV_ENTRY_FLAG);

    if (p_sys_queue_node->p_drop_profile)
    {
        profile_id = (p_sys_queue_node->p_drop_profile->profile_id << 3);
    }
    else
    {
        profile_id = SYS_DEFAULT_TAIL_DROP_PROFILE << 3;
    }

    CTC_ERROR_RETURN(DRV_IOCTL(lchip,
                               profile_id,
                               cmd,
                               &profile));

    p_drop->drop.max_th[0] = profile.wred_max_thrd0;
    p_drop->drop.max_th[1] = profile.wred_max_thrd1;
    p_drop->drop.max_th[2] = profile.wred_max_thrd2;
    p_drop->drop.max_th[3] = profile.wred_max_thrd3;

    p_drop->drop.min_th[0] = profile.wred_min_thrd0;
    p_drop->drop.min_th[1] = profile.wred_min_thrd1;
    p_drop->drop.min_th[2] = profile.wred_min_thrd2;
    p_drop->drop.min_th[3] = profile.wred_min_thrd3;

    p_drop->drop.drop_prob[0] = profile.max_drop_prob0;
    p_drop->drop.drop_prob[1] = profile.max_drop_prob1;
    p_drop->drop.drop_prob[2] = profile.max_drop_prob2;
    p_drop->drop.drop_prob[3] = profile.max_drop_prob3;

    return CTC_E_NONE;
}

int32
sys_greatbelt_queue_set_default_drop(uint8 lchip,
                                     uint16 queue_id,
                                     uint8 profile_id)
{
    uint32 cmd;
    ds_egr_resrc_ctl_t ds_egr_resrc_ctl;
    sys_queue_node_t* p_sys_queue_node = NULL;

    sal_memset(&ds_egr_resrc_ctl, 0, sizeof(ds_egr_resrc_ctl_t));



    p_sys_queue_node = ctc_vector_get(p_queue_master->queue_vec[lchip], queue_id);
    if (NULL == p_sys_queue_node)
    {
        uint32 field_val = 0;
        cmd = DRV_IOW(DsQueMap_t, DsQueMap_GrpId_f);
        field_val = SYS_MAX_QUEUE_GROUP_NUM-1;
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &field_val));
        return CTC_E_NONE;

    }

    cmd = DRV_IOR(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));

    if (p_sys_queue_node->channel >= 48 || p_sys_queue_node->channel <= 55)
    {
        ds_egr_resrc_ctl.mapped_tc = p_sys_queue_node->offset;
    }
    else
    {
        ds_egr_resrc_ctl.mapped_tc = 0;
    }

    ds_egr_resrc_ctl.que_min_prof_id = 1;
    ds_egr_resrc_ctl.que_thrd_prof_id_high = profile_id;

    cmd = DRV_IOW(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));

    return CTC_E_NONE;
}

/**
 @brief Initialize default queue drop.
*/
static int32
_sys_greatbelt_queue_drop_default_init(void)
{
    uint16 queue_id;
    uint8  lchip, lchip_num;
    uint8 cng_level = 0;
    uint8 tc = 0;
    uint8 sc = 0;
    uint32 index = 0;
    uint32 field_val = 0;
    uint32 field_id = 0;
    uint32 cmd;
    ds_que_thrd_profile_t ds_que_thrd_profile;
    egr_resrc_mgr_ctl_t egr_resrc_mgr_ctl;
    q_mgr_enq_ctl_t q_mgr_enq_ctl;
    q_mgr_enq_drop_ctl_t q_mgr_enq_drop_ctl;
    que_min_profile_t que_min_profile;
    ds_grp_drop_profile_t ds_grp_drop_profile;
    ds_egr_port_drop_profile_t ds_egr_port_drop_profile;
    uint16 dropThrd0[8] = {128, 128, 128, 128, 128, 128, 128, 128};
    uint16 dropThrd1[8] = {256, 256, 256, 256, 256, 256, 256, 256,};
    uint16 dropThrd2[8] = {512, 512, 512, 512, 512, 512, 512, 512};
    uint16 dropThrd3[8] = {512, 512, 512, 512, 512, 512, 512, 512};
    uint16 grpThrd[8]  = {588, 441, 294, 147, 73, 36, 12, 9};
    uint16 portThrd[8] = {588, 441, 294, 147, 73, 36, 12, 9};
    uint16 tcThrd[8]   = {720, 716, 712, 708, 704, 700, 696, 692};
    uint16 CngLevelThrd[7] = {147, 151, 155, 159, 163, 167, 171};
    uint8  drop_sed[128] =
                          {
                      13  , 46  , 23  , 17  , 67  , 5   , 92  , 93  , 41  , 10  ,
                      43  , 81  , 115 , 6   , 94  , 127 , 66  , 123 , 4   , 47  ,
                      45  , 102 , 88  , 85  , 118 , 65  , 116 , 56  , 119 , 70  ,
                      39  , 72  , 73  , 97  , 40  , 33  , 25  , 76  , 19  , 26  ,
                      51  , 64  , 8   , 87  , 36  , 44  , 60  , 16  , 1   , 2   ,
                      112 , 50  , 37  , 100 , 84  , 121 , 98  , 30  , 108 , 3   ,
                      101 , 57  , 58  , 59  , 110 , 107 , 32  , 48  , 96  , 122 ,
                      63  , 68  , 52  , 49  , 71  , 104 , 69  , 86  , 91  , 24  ,
                      111 , 105 , 82  , 27  , 34  , 53  , 62  , 106 , 114 , 125 ,
                      21  , 109 , 38  , 9   , 20  , 11  , 35  , 7   , 78  , 113 ,
                      75  , 1   , 15  , 103 , 18  , 14  , 117 , 89  , 126 , 61  ,
                      22  , 42  , 55  , 83  , 90  , 29  , 124 , 31  , 80  , 120 ,
                      99  , 79  , 95  , 12  , 74  , 54  , 28  , 77
                      };


    lchip_num = sys_greatbelt_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num; lchip++)
    {

        /*
        configure register fields for egress resource management
        1. enable egress resource management
        2. egress resource management is queue entry - based
        3. don't drop c2c and critical packets
        4. c2c and critical pools are reserved with 512 queue entries
        */
        sal_memset(&egr_resrc_mgr_ctl, 0, sizeof(egr_resrc_mgr_ctl_t));
        cmd = DRV_IOR(EgrResrcMgrCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &egr_resrc_mgr_ctl));
        egr_resrc_mgr_ctl.egr_resrc_mgr_en = 1;
        egr_resrc_mgr_ctl.egr_total_thrd = 736;
        cmd = DRV_IOW(EgrResrcMgrCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &egr_resrc_mgr_ctl));

        sal_memset(&q_mgr_enq_ctl, 0, sizeof(q_mgr_enq_ctl_t));
        cmd = DRV_IOR(QMgrEnqCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &q_mgr_enq_ctl));
        q_mgr_enq_ctl.based_on_buf_cnt = 1;
        q_mgr_enq_ctl.c2c_pkt_force_no_drop = 1;
        q_mgr_enq_ctl.critical_pkt_force_no_drop = 0;
        cmd = DRV_IOW(QMgrEnqCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &q_mgr_enq_ctl));

        /*
        configure QMgrEnqDropCtl register fields
        1. global enable wred random drop
        2. WRED don't care resource management discard conditions
        3. all non - tcp use drop precedence 0
        */
        sal_memset(&q_mgr_enq_drop_ctl, 0, sizeof(q_mgr_enq_drop_ctl_t));
        cmd = DRV_IOR(QMgrEnqDropCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &q_mgr_enq_drop_ctl));
        q_mgr_enq_drop_ctl.critical_pkt_drop_pri = 3;
        q_mgr_enq_drop_ctl.non_tcp_drop_pri = 0;
        q_mgr_enq_drop_ctl.wred_care_resrc_mgr = 0;
        q_mgr_enq_drop_ctl.wred_mode_glb_en = 1;
        cmd = DRV_IOW(QMgrEnqDropCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &q_mgr_enq_drop_ctl));

        /*
        three queue minimum guarantee profiles
        profile 0: 4 queue entries, used for GE channel queues
        profile 1: 7 queue entries, used for XGE channel queues
        profile 2: 0 queue entry, no guarantee
        */
        sal_memset(&que_min_profile, 0, sizeof(que_min_profile_t));
        cmd = DRV_IOR(QueMinProfile_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &que_min_profile));
        que_min_profile.que_min0 = 4;
        que_min_profile.que_min1 = 7;
        que_min_profile.que_min2 = 0;
        cmd = DRV_IOW(QueMinProfile_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &que_min_profile));


        /*queue threshold profile 1 -- for tail-drop purpose*/
        for (cng_level = 0; cng_level < 8; cng_level++)
        {
            sal_memset(&ds_que_thrd_profile, 0, sizeof(ds_que_thrd_profile_t));
            ds_que_thrd_profile.wred_max_thrd0 = dropThrd0[cng_level];
            ds_que_thrd_profile.wred_max_thrd1 = dropThrd1[cng_level];
            ds_que_thrd_profile.wred_max_thrd2 = dropThrd2[cng_level];
            ds_que_thrd_profile.wred_max_thrd3 = dropThrd3[cng_level];
            cmd = DRV_IOW(DsQueThrdProfile_t, DRV_ENTRY_FLAG);
            index = (SYS_DEFAULT_TAIL_DROP_PROFILE << 3) + cng_level;
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, index, cmd, &ds_que_thrd_profile));
        }

        /*queue threshold profile 1 -- for tail-drop purpose*/
        for (cng_level = 0; cng_level < 8; cng_level++)
        {
            sal_memset(&ds_que_thrd_profile, 0, sizeof(ds_que_thrd_profile_t));
            ds_que_thrd_profile.wred_max_thrd0 = 0;
            ds_que_thrd_profile.wred_max_thrd1 = 0;
            ds_que_thrd_profile.wred_max_thrd2 = 0;
            ds_que_thrd_profile.wred_max_thrd3 = 0;
            cmd = DRV_IOW(DsQueThrdProfile_t, DRV_ENTRY_FLAG);
            index = (SYS_MAX_TAIL_DROP_PROFILE << 3) + cng_level;
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, index, cmd, &ds_que_thrd_profile));
        }

        for (index = 0; index < 128; index++)
        {
            cmd = DRV_IOW(DsUniformRand_t, DsUniformRand_DropRandomNum_f);
            field_val = drop_sed[index];
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, index, cmd, &field_val));
        }

        /*group threshold profile 0*/
        for (cng_level = 0; cng_level < 8; cng_level++)
        {
            sal_memset(&ds_grp_drop_profile, 0, sizeof(ds_grp_drop_profile_t));
            cmd = DRV_IOW(DsGrpDropProfile_t, DRV_ENTRY_FLAG);
            ds_grp_drop_profile.grp_drop_thrd = grpThrd[cng_level];
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, cng_level, cmd, &ds_grp_drop_profile));
        }

        /*port threshold profile 0*/
        for (cng_level = 0; cng_level < 8; cng_level++)
        {
            sal_memset(&ds_egr_port_drop_profile, 0, sizeof(ds_egr_port_drop_profile_t));
            cmd = DRV_IOW(DsEgrPortDropProfile_t, DRV_ENTRY_FLAG);
            ds_egr_port_drop_profile.port_drop_thrd = portThrd[cng_level];
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, cng_level, cmd, &ds_egr_port_drop_profile));
        }

        /*tc threshold */
        for (tc = 0; tc < 8; tc++)
        {
            field_val = tcThrd[tc];
            field_id = EgrTcThrd_TcThrd0_f + tc;
            cmd = DRV_IOW(EgrTcThrd_t, field_id);
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        }

        /*scthreshold */
        field_val = 720;
        field_id = EgrScThrd_ScThrd0_f;
        cmd = DRV_IOW(EgrScThrd_t, field_id);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));

        /*evaluate congestion level to enable self-tuning threshold */
        for (sc = 0; sc < 7; sc++)
        {
            field_val = CngLevelThrd[sc];
            field_id = EgrCongestLevelThrd_Sc0Thrd0_f + sc;
            cmd = DRV_IOW(EgrCongestLevelThrd_t, field_id);
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        }

        /*EgrCondDisProfile 0*/
        field_val = (1<<6);
        field_id = EgrCondDisProfile_CondDisBmp0_f;
        cmd = DRV_IOW(EgrCondDisProfile_t, field_id);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));

        /*
        queue configurations for egress resource management
        1. all queue mapped to SC 0
        2. GE channel queues mapped to TC 0
        3. XGE channel queues mapped to TC 0 - 7, respectively
        */
        for (queue_id = 0; queue_id < SYS_MAX_QUEUE_NUM; queue_id++)
        {
            CTC_ERROR_RETURN(
                sys_greatbelt_queue_set_default_drop(lchip, queue_id, SYS_DEFAULT_TAIL_DROP_PROFILE));

        }


        /*for drop queue*/
        /*group threshold profile 1 for discard*/
        for (cng_level = 0; cng_level < 8; cng_level++)
        {
            sal_memset(&ds_grp_drop_profile, 0, sizeof(ds_grp_drop_profile_t));
            cmd = DRV_IOW(DsGrpDropProfile_t, DRV_ENTRY_FLAG);
            ds_grp_drop_profile.grp_drop_thrd = 0;
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, (1*8 + cng_level), cmd, &ds_grp_drop_profile));
        }

        /*EgrCondDisProfile 1*/
        field_val = (1<<6);
        field_id = EgrCondDisProfile_CondDisBmp0_f + 1;
        cmd = DRV_IOW(EgrCondDisProfile_t, field_id);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));


    }

    return CTC_E_NONE;
}



int32
sys_greatbelt_queue_set_port_drop_en(uint16 gport, bool enable, uint32 drop_type)
{

    uint32 cmd = 0;
    uint8 lchip = 0;
    uint8 queue_num = 0 ;
    uint16 queue_id =0;
    uint8 lport = 0;
    uint8 offset = 0;
    uint8 drop_chan = 0xFF;
    ctc_qos_queue_id_t queue;
    ds_egr_resrc_ctl_t ds_egr_resrc_ctl;
    q_mgr_reserved_channel_range_t qmgt_rsv_chan_rag;

    sal_memset(&ds_egr_resrc_ctl, 0, sizeof(ds_egr_resrc_ctl_t));
    sal_memset(&queue, 0, sizeof(queue));
    sal_memset(&qmgt_rsv_chan_rag, 0, sizeof(qmgt_rsv_chan_rag));

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    queue.gport = gport;
    if (lport < CTC_MAX_PHY_PORT)
    {
        queue.queue_type = CTC_QUEUE_TYPE_NETWORK_EGRESS;
    }
    else
    {
        queue.queue_type = CTC_QUEUE_TYPE_INTERNAL_PORT;
    }


    /* get drop channel */
    cmd =  DRV_IOR(QMgrReservedChannelRange_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &qmgt_rsv_chan_rag));
    if (qmgt_rsv_chan_rag.reserved_channel_valid0)
    {
        drop_chan = qmgt_rsv_chan_rag.reserved_channel_min0;
    }

    if(CTC_FLAG_ISSET(drop_type, SYS_QUEUE_DROP_TYPE_PROFILE))
    {
        queue_num = p_queue_master->channel[lchip][lport].queue_info.queue_num;
        for (offset = 0; offset < queue_num; offset++)
        {
            queue.queue_id = offset;
            CTC_ERROR_RETURN(_sys_greatbelt_queue_get_queue_id(lchip,
                                                               &queue,
                                                               &queue_id));

            cmd = DRV_IOR(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));

            ds_egr_resrc_ctl.grp_drop_prof_id_high = enable?1:0;
            ds_egr_resrc_ctl.egr_cond_dis_prof_id = enable?1:0;

            cmd = DRV_IOW(DsEgrResrcCtl_t, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, queue_id, cmd, &ds_egr_resrc_ctl));
        }
    }

    if(CTC_FLAG_ISSET(drop_type, SYS_QUEUE_DROP_TYPE_CHANNEL) && qmgt_rsv_chan_rag.reserved_channel_valid0)
    {
        /* add drop channel */
        if(enable)
        {
            sys_greatbelt_add_port_to_channel(gport, drop_chan);
        }
        else
        {
            sys_greatbelt_remove_port_from_channel(gport, drop_chan);
        }
    }

    return CTC_E_NONE;

}

/**
 @brief Queue dropping initialization.
*/
int32
sys_greatbelt_queue_drop_init(void)
{
    sys_greatbelt_opf_t opf;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint8 gchip = 0;

    lchip_num = sys_greatbelt_get_local_chip_num();
    CTC_ERROR_RETURN(sys_greatbelt_opf_init(OPF_QUEUE_DROP_PROFILE, lchip_num));

    sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        opf.pool_index = lchip;
        opf.pool_type = OPF_QUEUE_DROP_PROFILE;
        CTC_ERROR_RETURN(sys_greatbelt_opf_init_offset(&opf, 0, SYS_MAX_DROP_PROFILE_NUM));

        /* init queue shape hash table */
        p_queue_master->p_drop_profile_pool[lchip] =
        ctc_spool_create(SYS_DROP_PROFILE_BLOCK_NUM,
                         SYS_DROP_PROFILE_BLOCK_SIZE,
                         SYS_MAX_DROP_PROFILE_NUM,
                         sizeof(sys_queue_drop_profile_t),
                         _sys_greatbelt_queue_drop_profile_hash_make,
                         _sys_greatbelt_queue_drop_profile_hash_cmp);


    }

    CTC_ERROR_RETURN(_sys_greatbelt_queue_drop_default_init());

    /* init drop local phy port */
    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        sys_greatbelt_get_gchip_id(lchip, &gchip);
        CTC_ERROR_RETURN(sys_greatbelt_queue_set_port_drop_en(CTC_MAP_LPORT_TO_GPORT(gchip, SYS_RESERVE_PORT_ID_DROP),
                                                              TRUE, SYS_QUEUE_DROP_TYPE_ALL));
    }

    return CTC_E_NONE;
}

