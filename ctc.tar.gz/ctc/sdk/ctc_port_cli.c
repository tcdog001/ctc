/**
 @file ctc_port_cli.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-11-14

 @version v2.0

 The file apply clis of port module
*/

#include "ctc_api.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_port_cli.h"
#include "ctc_port_mapping_cli.h"

CTC_CLI(ctc_cli_port_set_default_cfg,
        ctc_cli_port_set_default_cfg_cmd,
        "port GPHYPORT_ID default-config",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Set port configure to default")
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    ret = ctc_port_set_default_cfg(gport);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_port_en,
        ctc_cli_port_set_port_en_cmd,
        "port GPHYPORT_ID port-en (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Set port state",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_port_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        ret = ctc_port_set_port_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}
CTC_CLI(ctc_cli_port_set_receive,
        ctc_cli_port_set_receive_cmd,
        "port GPHYPORT_ID receive (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Reception port state",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_receive_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        ret = ctc_port_set_receive_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_transmit,
        ctc_cli_port_set_transmit_cmd,
        "port GPHYPORT_ID transmit (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Transmission port state",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_transmit_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        ret = ctc_port_set_transmit_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

CTC_CLI(ctc_cli_port_set_bridge,
        ctc_cli_port_set_bridge_cmd,
        "port GPHYPORT_ID bridge (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "L2 bridge",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_bridge_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("disable", argv[1], 2))
    {
        ret = ctc_port_set_bridge_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_phy_if,
        ctc_cli_port_set_phy_if_cmd,
        "port GPHYPORT_ID phy-if (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Physical interface",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    bool enable  = FALSE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        enable = TRUE;
    }

    ret = ctc_port_set_phy_if_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_sub_if,
        ctc_cli_port_set_sub_if_cmd,
        "port GPHYPORT_ID sub-if (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Sub interface",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    bool enable  = FALSE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        enable = TRUE;
    }

    ret = ctc_port_set_sub_if_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_vlan_filtering,
        ctc_cli_port_set_vlan_filtering_cmd,
        "port GPHYPORT_ID vlan-filtering direction (ingress | egress | both)(enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Vlan filtering",
        "Filtering direction",
        "Ingress filtering",
        "Egress filtering",
        "Both igs and egs filtering",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_direction_t dir = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("in", argv[1], 2))
    {
        dir = CTC_INGRESS;
    }
    else if (0 == sal_memcmp("eg", argv[1], 2))
    {
        dir = CTC_EGRESS;
    }
    else if (0 == sal_memcmp("bo", argv[1], 2))
    {
        dir = CTC_BOTH_DIRECTION;
    }


    if (0 == sal_memcmp("en", argv[2], 2))
    {
        ret = ctc_port_set_vlan_filter_en(gport, dir, TRUE);
    }
    else if (0 == sal_memcmp("disable", argv[2], 2))
    {
        ret = ctc_port_set_vlan_filter_en(gport, dir, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_default_vlan,
        ctc_cli_port_set_default_vlan_cmd,
        "port GPHYPORT_ID default vlan VLAN_ID",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Default vlan tag",
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC)
{
    int32 ret = 0;
    uint16 vlan_id = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);
    CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[1]);


    ret = ctc_port_set_default_vlan(gport, vlan_id);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_vlan_ctl,
        ctc_cli_port_set_vlan_ctl_cmd,
        "port GPHYPORT_ID vlan-ctl (allow-all | drop-all-untagged | drop-all-tagged | drop-all | drop-wo-2tag \
    | drop-w-2tag | drop-stag | drop-non-stag | drop-only-stag | permit-only-stag |drop-all-ctag |drop-non-ctag \
    | drop-only-ctag | permit-only-ctag)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Vlan control",
        "Allow all packet",
        "Drop all untagged packet",
        "Drop all tagged packet",
        "Drop all packet",
        "Drop packet without 2 tag",
        "Drop packet with 2 tag",
        "Drop stagged packet",
        "Drop packet without stag",
        "Drop packet only stagged",
        "Permit packet only with stag",
        "Drop all packet with ctag",
        "Drop packet without ctag",
        "Drop packet only ctagged",
        "Permit packet only with ctag")
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_vlantag_ctl_t mode = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_strcmp("allow-all", argv[1]))
    {
        mode = CTC_VLANCTL_ALLOW_ALL_PACKETS;
    }
    else if (0 == sal_strcmp("drop-all-untagged", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_UNTAGGED;
    }
    else if (0 == sal_strcmp("drop-all-tagged", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_TAGGED;
    }
    else if (0 == sal_strcmp("drop-all", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL;
    }
    else if (0 == sal_strcmp("drop-wo-2tag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_PACKET_WITHOUT_TWO_TAG;
    }
    else if (0 == sal_strcmp("drop-w-2tag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_PACKET_WITH_TWO_TAG;
    }
    else if (0 == sal_strcmp("drop-stag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_SVLAN_TAG;
    }
    else if (0 == sal_strcmp("drop-non-stag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_NON_SVLAN_TAG;
    }
    else if (0 == sal_strcmp("drop-only-stag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ONLY_SVLAN_TAG;
    }
    else if (0 == sal_strcmp("permit-only-stag", argv[1]))
    {
        mode = CTC_VLANCTL_PERMIT_ONLY_SVLAN_TAG;
    }
    else if (0 == sal_strcmp("drop-all-ctag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_CVLAN_TAG;
    }
    else if (0 == sal_strcmp("drop-non-ctag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ALL_NON_CVLAN_TAG;
    }
    else if (0 == sal_strcmp("drop-only-ctag", argv[1]))
    {
        mode = CTC_VLANCTL_DROP_ONLY_CVLAN_TAG;
    }
    else if (0 == sal_strcmp("permit-only-ctag", argv[1]))
    {
        mode = CTC_VLANCTL_PERMIT_ONLY_CVLAN_TAG;
    }
    else
    {
        mode = CTC_VLANCTL_ALLOW_ALL_PACKETS;
    }


    ret = ctc_port_set_vlan_ctl(gport, mode);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_cross_connect,
        ctc_cli_port_set_cross_connect_cmd,
        "port GPHYPORT_ID port-cross-connect nhid NHID",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port cross connect",
        CTC_CLI_NH_ID_STR,
        "0xFFFFFFFF means disable port cross-connect")
{
    int32 ret = CTC_E_NONE;
    uint32 nhid = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    CTC_CLI_GET_UINT32("nhid", nhid, argv[1]);

    ret = ctc_port_set_cross_connect(gport, nhid);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_learning,
        ctc_cli_port_set_learning_cmd,
        "port GPHYPORT_ID learning (enable |disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Mac learning",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    bool learning_en = FALSE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        learning_en = TRUE;
    }

    ret = ctc_port_set_learning_en(gport, learning_en);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_vlan_domain,
        ctc_cli_port_set_vlan_domain_cmd,
        "port GPHYPORT_ID vlan-domain (cvlan | svlan)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Set vlan domain when the cvlan TPID is the same as svlan TPID",
        "Cvlan domain",
        "Svlan domain")
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_port_vlan_domain_type_t vlan_domain = CTC_PORT_VLAN_DOMAIN_SVLAN;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("cvlan", argv[1], 5))
    {
        vlan_domain = CTC_PORT_VLAN_DOMAIN_CVLAN;
    }


    ret = ctc_port_set_vlan_domain(gport, vlan_domain);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_stag_tpid_index,
        ctc_cli_port_set_stag_tpid_index_cmd,
        "port GPHYPORT_ID stag-tpid-index direction (ingress|egress|both) INDEX",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Stag TPID index point to stag TPID value",
        "Direction",
        "Ingress",
        "Egress",
        "Both direction",
        "<0-3>")
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 index = 0;
    ctc_direction_t dir = CTC_BOTH_DIRECTION;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);
    CTC_CLI_GET_UINT8("stpid index", index, argv[2]);

    if (CLI_CLI_STR_EQUAL("ingress", 1))
    {
        dir = CTC_INGRESS;
    }
    else if (CLI_CLI_STR_EQUAL("egress", 1))
    {
        dir = CTC_EGRESS;
    }


    ret = ctc_port_set_stag_tpid_index(gport, dir, index);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_dot1q_type,
        ctc_cli_port_set_dot1q_type_cmd,
        "port GPHYPORT_ID dot1q-type (untagged | cvlan-tagged | svlan-tagged | double-tagged)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port's type descript in 802.1q",
        "Packet transmit with untag",
        "Packet transmit with ctag",
        "Packet transmit with stag",
        "Packet transmit with both stag and ctag")
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_dot1q_type_t type = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("un", argv[1], 2))
    {
        type = CTC_DOT1Q_TYPE_NONE;
    }
    else if (0 == sal_memcmp("cvlan", argv[1], 2))
    {
        type = CTC_DOT1Q_TYPE_CVLAN;
    }
    else if (0 == sal_memcmp("svlan", argv[1], 2))
    {
        type = CTC_DOT1Q_TYPE_SVLAN;
    }
    else if (0 == sal_memcmp("double", argv[1], 2))
    {
        type = CTC_DOT1Q_TYPE_BOTH;
    }


    ret = ctc_port_set_dot1q_type(gport, type);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_untag_dft_vid_enable,
        ctc_cli_port_set_untag_dft_vid_enable_cmd,
        "port GPHYPORT_ID untag-default-vlan enable (untag-svlan | untag-cvlan)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Untag vlan id when transmit packet vid equal to PVID",
        CTC_CLI_ENABLE,
        "Untag vlan id on stag",
        "Untag vlan id on ctag")
{
    int32 ret;
    uint16 gport;
    bool is_untag_svlan = FALSE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("untag-svlan", argv[1], 7))
    {
        is_untag_svlan = TRUE;
    }


    ret = ctc_port_set_untag_dft_vid(gport, TRUE, is_untag_svlan);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_untag_dft_vid_disable,
        ctc_cli_port_set_untag_dft_vid_disable_cmd,
        "port GPHYPORT_ID untag-default-vlan disable",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Untag vlan id when transmit packet vid equal to PVID",
        CTC_CLI_DISABLE)
{
    int32 ret;
    uint16 gport;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    ret = ctc_port_set_untag_dft_vid(gport, FALSE, FALSE);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_protocol_vlan,
        ctc_cli_port_set_protocol_vlan_cmd,
        "port GPHYPORT_ID protocol-vlan (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Protocol vlan on port",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret;
    uint16 gport;
    bool enable = FALSE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("en", argv[1], 2))
    {
        enable = TRUE;
    }


    ret = ctc_port_set_protocol_vlan_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_vlan_mapping,
        ctc_cli_port_set_vlan_mapping_cmd,
        "port GPHYPORT_ID vlan-mapping (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Vlan mapping on port",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    bool enable = FALSE;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        enable = TRUE;
    }


    ret = ctc_port_set_vlan_mapping_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_vlan_classify,
        ctc_cli_port_set_vlan_classify_cmd,
        "port GPHYPORT_ID vlan-classify (mac|ipv4|ipv6|protocol) (enable policy POLICY_ID |disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Vlan classify",
        "Mac based vlan",
        "IPv4 based vlan",
        "IPv6 based vlan",
        "Protocol based vlan",
        CTC_CLI_ENABLE,
        "Vlan classify policy",
        "<0-63>",
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_vlan_class_type_t type;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("mac", 1))
    {
        type = CTC_VLAN_CLASS_MAC;
    }
    else if (CLI_CLI_STR_EQUAL("ipv4", 1))
    {
        type = CTC_VLAN_CLASS_IPV4;
    }
    else if (CLI_CLI_STR_EQUAL("ipv6", 1))
    {
        type = CTC_VLAN_CLASS_IPV6;
    }
    else
    {
        type = CTC_VLAN_CLASS_PROTOCOL;
    }


    if (CLI_CLI_STR_EQUAL("enable", 2))
    {
        ret = ctc_port_set_vlan_classify_enable(gport, type);
    }
    else
    {
        ret = ctc_port_set_vlan_classify_disable(gport, type);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret =%d, %s\n", ret, ctc_get_error_desc(ret));
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_blocking,
        ctc_cli_port_set_blocking_cmd,
        "port GPHYPORT_ID port-blocking {ucast-flooding | mcast-flooding | known-ucast-forwarding | known-mcast-forwarding | bcast-flooding} \
        (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port based blocking",
        "Unknown ucast flooding to this port",
        "Unknown mcast flooding to this port",
        "Known ucast forwarding to this port",
        "Known mcast forwarding to this port",
        "Broadcast flooding to this port",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 index = 0;
    ctc_port_restriction_t port_restriction;

    sal_memset(&port_restriction, 0, sizeof(ctc_port_restriction_t));

    port_restriction.mode = CTC_PORT_RESTRICTION_PORT_BLOCKING;
    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);
    index = CTC_CLI_GET_ARGC_INDEX("disable");
    if (index != 0xFF)
    {
        port_restriction.type = 0x1F;

        index = CTC_CLI_GET_ARGC_INDEX("ucast-flooding");
        if (index != 0xFF)
        {
            CTC_UNSET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_UNKNOW_UCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("mcast-flooding");
        if (index != 0xFF)
        {
            CTC_UNSET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_UNKNOW_MCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("known-ucast-forwarding");
        if (index != 0xFF)
        {
            CTC_UNSET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_KNOW_UCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("known-mcast-forwarding");
        if (index != 0xFF)
        {
            CTC_UNSET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_KNOW_MCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("bcast-flooding");
        if (index != 0xFF)
        {
            CTC_UNSET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_BCAST);
        }
    }
    else
    {
        port_restriction.type = 0;

        index = CTC_CLI_GET_ARGC_INDEX("ucast-flooding");
        if (index != 0xFF)
        {
            CTC_SET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_UNKNOW_UCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("mcast-flooding");
        if (index != 0xFF)
        {
            CTC_SET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_UNKNOW_MCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("known-ucast-forwarding");
        if (index != 0xFF)
        {
            CTC_SET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_KNOW_UCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("known-mcast-forwarding");
        if (index != 0xFF)
        {
            CTC_SET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_KNOW_MCAST);
        }

        index = CTC_CLI_GET_ARGC_INDEX("bcast-flooding");
        if (index != 0xFF)
        {
            CTC_SET_FLAG(port_restriction.type, CTC_PORT_BLOCKING_BCAST);
        }
    }

    ret = ctc_port_set_restriction(gport, &port_restriction);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_use_outer_ttl,
        ctc_cli_port_set_use_outer_ttl_cmd,
        "port GPHYPORT_ID use-outer-ttl (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "The decap packet will use outer TTL",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    bool enable = FALSE;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        enable = TRUE;
    }


    ret = ctc_port_set_use_outer_ttl(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_mac_en,
        ctc_cli_port_set_mac_en_cmd,
        "port GPHYPORT_ID mac (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port mac",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport;
    uint16 lport = 0;
    bool enable;

    lport = lport;
    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

#ifdef HUMBER
    /*for sgmac, should disable first*/
    if (TRUE == enable)
    {
        lport = CTC_MAP_GPORT_TO_LPORT(gport);
        if ((lport > 47) && (lport < 52))
        {
            ret = ctc_port_set_mac_en(gport, FALSE);
        }
    }
#endif

    ret = ret ? ret : ctc_port_set_mac_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_3ap_training_en,
        ctc_cli_port_set_3ap_training_en_cmd,
        "port GPHYPORT_ID 3ap-train (enable | init | done |disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "802.3ap training cfg flag",
        "Enable",
        "Init",
        "Done",
        "Disable")
{
    int32 ret = 0;
    uint16 gport;
    uint16 lport = 0;
    uint32 cfg_flag;

    lport = lport;
    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        cfg_flag = 1;
    }
    else if (CLI_CLI_STR_EQUAL("init", 1))
    {
        cfg_flag = 2;
    }
    else if (CLI_CLI_STR_EQUAL("done", 1))
    {
        cfg_flag = 3;
    }
    else
    {
        cfg_flag = 0;
    }

    ret = ctc_port_set_property(gport, CTC_PORT_PROP_3AP_TRAINING_EN, cfg_flag);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_port_set_cpumac_en,
        ctc_cli_port_set_cpumac_en_cmd,
        "port cpumac (enable | disable)",
        CTC_CLI_PORT_M_STR,
        "Cpu mac",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    bool enable;

    if (CLI_CLI_STR_EQUAL("enable", 0))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

    ret = ctc_port_set_cpu_mac_en(enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_speed,
        ctc_cli_port_set_speed_cmd,
        "port GPHYPORT_ID speed-mode (eth|fe|ge|sg)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port speed mode",
        "Ethernet port with 10M",
        "Fast Eth port with 100M",
        "GEth port with 1G",
        "GEth port with 2.5G")
{
    int32 ret = CLI_SUCCESS;
    uint32 gport;
    ctc_port_speed_t speed_mode = 0;

    CTC_CLI_GET_UINT32_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT32_VALUE);

    if (CLI_CLI_STR_EQUAL("eth", 1))
    {
        speed_mode = CTC_PORT_SPEED_10M;
    }
    else if (CLI_CLI_STR_EQUAL("fe", 1))
    {
        speed_mode = CTC_PORT_SPEED_100M;
    }
    else if (CLI_CLI_STR_EQUAL("sg", 1))
    {
        speed_mode = CTC_PORT_SPEED_2G5;
    }
    else if (CLI_CLI_STR_EQUAL("ge", 1))
    {
        speed_mode = CTC_PORT_SPEED_1G;
    }


    ret = ctc_port_set_speed(gport, speed_mode);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_flow_ctl,
        ctc_cli_port_set_flow_ctl_cmd,
        "port GPHYPORT_ID flow-ctl (priority-class PRI (pfc-class CLASS|) |) (ingress|egress|both)(enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Flow control",
        "Cos used for PFC",
        "<0-7>",
        "Receive pause frame",
        "Transmit pause frame",
        "Both receive and transmit",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index;
    uint16 gport = 0;
    uint8 priority_class = 0;
    uint8 pfc_class = 0;
    ctc_direction_t dir = 0;
    uint8 enable = 0;
    uint8 is_pfc = 0;
    ctc_port_fc_prop_t fc;

    sal_memset(&fc, 0, sizeof(fc));

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);


    index = CTC_CLI_GET_ARGC_INDEX("priority-class");
    if (0xFF != index)
    {
        is_pfc = 1;
        CTC_CLI_GET_UINT8("priority class", priority_class, argv[index + 1]);

        index = CTC_CLI_GET_ARGC_INDEX("pfc-class");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT8("pfc class", pfc_class, argv[index + 1]);
        }
        else
        {
           pfc_class =  priority_class;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if (0xFF != index)
    {
        dir = CTC_INGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress");
    if (0xFF != index)
    {
        dir = CTC_EGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("both");
    if (0xFF != index)
    {
        dir = CTC_BOTH_DIRECTION;
    }

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (0xFF != index)
    {
       enable = 1;
    }


    fc.gport  = gport;
    fc.priority_class    = priority_class;
    fc.enable = enable;
    fc.dir    = dir;
    fc.is_pfc = is_pfc;
    fc.pfc_class = pfc_class;
    ret = ctc_port_set_flow_ctl_en(&fc);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_show_flow_ctl,
        ctc_cli_port_show_flow_ctl_cmd,
        "show port GPHYPORT_ID flow-ctl",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Flow control")
{
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    ctc_port_fc_prop_t fc;
    char* desc[3] = {"Ingress", "Egress", "Both"};
    char* en[2] = {"Disable", "Enable"};

    sal_memset(&fc, 0, sizeof(fc));
    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    fc.gport  = gport;
    ret = ctc_port_get_flow_ctl_en(&fc);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("\n");
    if (fc.is_pfc)
    {
        ctc_cli_out(" gport:0x%04X is priority based flow contol, cos:%u.\n", gport, fc.priority_class);
        ctc_cli_out(" -------------------------------------------------\n");
    }
    else
    {
        ctc_cli_out(" gport:0x%04X is port based flow contol.\n", gport);
        ctc_cli_out(" -----------------------------------------\n");
    }

    ctc_cli_out(" %-12s%s\n", "Direction", "Value");
    ctc_cli_out(" -------------------\n", "Field", "Value");
    ctc_cli_out(" %-12s%s\n\n", desc[fc.dir], en[fc.enable]);

    return ret;
}

CTC_CLI(ctc_cli_port_set_preamble,
        ctc_cli_port_set_preamble_cmd,
        "port GPHYPORT_ID preamble BYTES",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port preamble",
        CTC_CLI_PORT_PREAMBLE_VAL)
{
    int32 ret = CLI_SUCCESS;
    uint16 gport;
    uint8 preamble;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT8_RANGE("preamble bytes", preamble, argv[1], 0, CTC_MAX_UINT8_VALUE);


    ret = ctc_port_set_preamble(gport, preamble);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_min_frame_size,
        ctc_cli_port_set_min_frame_size_cmd,
        "port GPHYPORT_ID min-frame-size SIZE",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Min frame size",
        CTC_CLI_PORT_MIN_FRAME_SIZE)
{
    int32 ret = CLI_SUCCESS;
    uint16 gport;
    uint8 size;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT8_RANGE("min frame size", size, argv[1], 0, CTC_MAX_UINT8_VALUE);


    ret = ctc_port_set_min_frame_size(gport, size);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_max_frame_size,
        ctc_cli_port_set_max_frame_size_cmd,
        "port GPHYPORT_ID max-frame-size SIZE",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Max frame size per port",
        CTC_CLI_PORT_MAX_FRAME_SIZE)
{
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    uint32 value = 0;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    CTC_CLI_GET_UINT16_RANGE("max frame size", value, argv[1], 0, CTC_MAX_UINT16_VALUE);


    ret = ctc_port_set_max_frame(gport, value);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_stretch_mode,
        ctc_cli_port_set_stretch_mode_cmd,
        "port GPHYPORT_ID stretch-mode (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Stretch mode(WAN mode)",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = CLI_SUCCESS;
    uint16 gport;
    bool enable = FALSE;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        enable = TRUE;
    }


    ret = ctc_port_set_stretch_mode_en(gport, enable);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_system_max_frame_size,
        ctc_cli_port_set_system_max_frame_size_cmd,
        "system max-frame-size (size0|size1|size2|size3|size4|size5|size6|size7) BYTES",
        "System attribution",
        "Max frame size to apply port select",
        "Max frame size0",
        "Max Frame size1",
        "Max Frame size2",
        "Max Frame size3",
        "Max frame size4",
        "Max Frame size5",
        "Max Frame size6",
        "Max Frame size7",
        CTC_CLI_PORT_MAX_FRAME_SIZE)
{
    int32 ret = CLI_SUCCESS;
    uint16 max_size;
    ctc_frame_size_t index = CTC_FRAME_SIZE_0;

    CTC_CLI_GET_UINT16_RANGE("max frame size", max_size, argv[1], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("size0", 0))
    {
        index = CTC_FRAME_SIZE_0;
    }
    else if (CLI_CLI_STR_EQUAL("size1", 0))
    {
        index = CTC_FRAME_SIZE_1;
    }
    else if (CLI_CLI_STR_EQUAL("size2", 0))
    {
        index = CTC_FRAME_SIZE_2;
    }
    else if (CLI_CLI_STR_EQUAL("size3", 0))
    {
        index = CTC_FRAME_SIZE_3;
    }
    else if (CLI_CLI_STR_EQUAL("size4", 0))
    {
        index = CTC_FRAME_SIZE_4;
    }
    else if (CLI_CLI_STR_EQUAL("size5", 0))
    {
        index = CTC_FRAME_SIZE_5;
    }
    else if (CLI_CLI_STR_EQUAL("size6", 0))
    {
        index = CTC_FRAME_SIZE_6;
    }
    else if (CLI_CLI_STR_EQUAL("size7", 0))
    {
        index = CTC_FRAME_SIZE_7;
    }

    ret = ctc_set_max_frame_size(index, max_size);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_show_system_max_frame_size,
        ctc_cli_port_show_system_max_frame_size_cmd,
        "show system max-frame-size",
        CTC_CLI_SHOW_STR,
        "System attribution",
        "Max frame size to apply port select")
{
    int32 ret = CLI_SUCCESS;
    uint8 size_idx = 0;
    uint16 val_16 = 0;

    ctc_cli_out("Show system max frame size.\n");
    ctc_cli_out("--------------\n");
    ctc_cli_out("%-8s%s\n", "Index", "Value");
    ctc_cli_out("--------------\n");

    for (size_idx = 0; size_idx < CTC_FRAME_SIZE_MAX; size_idx++)
    {
        ret = ctc_get_max_frame_size(size_idx, &val_16);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }

        ctc_cli_out("%-8u%u\n", size_idx, val_16);
    }
    ctc_cli_out("--------------\n");

    return CTC_E_NONE;
}

CTC_CLI(ctc_cli_port_set_all_mac_en,
        ctc_cli_port_set_all_mac_en_cmd,
        "port all mac (enable |disable)",
        CTC_CLI_PORT_M_STR,
        "All port",
        "Port mac",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip_num;
    uint8 chip_id;
    uint8 gchip;
    bool enable;
    uint16 port_id;
    uint16 gport;

    if (CLI_CLI_STR_EQUAL("enable", 0))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

    ctc_get_local_chip_num(&lchip_num);

    /*for sgmac, should disable first*/
    if (TRUE == enable)
    {
        for (chip_id = 0; chip_id < lchip_num; chip_id++)
        {
            ret = ctc_get_gchip_id(chip_id, &gchip);

            for (port_id = 48; port_id < CTC_MAX_PHY_PORT; port_id++)
            {
                gport = CTC_MAP_LPORT_TO_GPORT(gchip, port_id);
                ret = ret ? ret : ctc_port_set_mac_en(gport, FALSE);
            }
        }
    }

    for (chip_id = 0; chip_id < lchip_num; chip_id++)
    {
        ret = ctc_get_gchip_id(chip_id, &gchip);

        for (port_id = 0; port_id < MAX_PORT_NUM_PER_CHIP; port_id++)
        {
            gport = CTC_MAP_LPORT_TO_GPORT(gchip, port_id);
            ret   = ctc_port_set_mac_en(gport, enable);
            /* DRV_E_MAC_IS_NOT_USED:9912, DRV_E_DATAPATH_INVALID_PORT_ID:9908 */
            if ((ret < 0) && ((ret != -9912) && (ret != -9908)&&(ret!=CTC_E_MAC_NOT_USED)))
            {
                ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            }
        }
    }

    ret = ctc_port_set_cpu_mac_en(enable);
    if (ret < 0)
    {
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_pading,
        ctc_cli_port_set_pading_cmd,
        "port GPHYPORT_ID pading (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "L2 pading",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_pading_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("disable", argv[1], 2))
    {
        ret = ctc_port_set_pading_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_random_log,
        ctc_cli_port_set_random_log_cmd,
        "port GPHYPORT_ID random-log direction (ingress|egress|both)(enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port random log",
        "Flow direction",
        "Ingress port log",
        "Egress port log",
        "Both direction",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;
    ctc_direction_t dir = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("in", argv[1], 2))
    {
        dir = CTC_INGRESS;
    }
    else if (0 == sal_memcmp("eg", argv[1], 2))
    {
        dir = CTC_EGRESS;
    }
    else if (0 == sal_memcmp("bo", argv[1], 2))
    {
        dir = CTC_BOTH_DIRECTION;
    }


    if (0 == sal_memcmp("en", argv[2], 2))
    {
        ret = ctc_port_set_random_log_en(gport, dir, TRUE);
    }
    else if (0 == sal_memcmp("disable", argv[2], 2))
    {
        ret = ctc_port_set_random_log_en(gport, dir, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_random_threshold,
        ctc_cli_port_set_random_threshold_cmd,
        "port GPHYPORT_ID random-threshold direction (ingress|egress|both) THRESHOLD",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "The percentage of received packet for random log",
        "Flow direction ",
        "Ingress port random log percent",
        "Egress port random log percent",
        "Both direction",
        "Percent value, <0-100>")
{
    int32 ret = 0;
    uint16 gport = 0;
    uint16 threshold = 0;
    ctc_direction_t dir = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("in", argv[1], 2))
    {
        dir = CTC_INGRESS;
    }
    else if (0 == sal_memcmp("eg", argv[1], 2))
    {
        dir = CTC_EGRESS;
    }
    else if (0 == sal_memcmp("bo", argv[1], 2))
    {
        dir = CTC_BOTH_DIRECTION;
    }

    CTC_CLI_GET_UINT8_RANGE("threshold", threshold, argv[2], 0, CTC_MAX_UINT8_VALUE);


    ret = ctc_port_set_random_log_percent(gport, dir, threshold);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_srcdiscard,
        ctc_cli_port_set_srcdiscard_cmd,
        "port GPHYPORT_ID src-discard (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port src_discard",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_srcdiscard_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        ret = ctc_port_set_srcdiscard_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_loopback,
        ctc_cli_port_set_loopback_cmd,
        "port GPHYPORT_ID (loopback-to | tap-to) dst-port DST_GPORT (enable | disable) (swap-mac|)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port loopback",
        "Mac tap",
        "Dst port, if dst port equal src port, packet will loopback to self",
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "Swap-mac enable")
{
    int32 ret = 0;
    uint8 index = 0;
    ctc_port_lbk_param_t port_lbk;
    uint16 src_gport = 0;
    uint16 dst_gport = 0;

    sal_memset(&port_lbk, 0, sizeof(ctc_port_lbk_param_t));

    CTC_CLI_GET_UINT16("gport", src_gport, argv[0]);
    port_lbk.src_gport = src_gport;
    CTC_CLI_GET_UINT16("gport", dst_gport, argv[2]);
    port_lbk.dst_gport = dst_gport;

    if (0 == sal_memcmp("en", argv[3], 2))
    {
        port_lbk.lbk_enable = TRUE;
    }
    else if (0 == sal_memcmp("di", argv[3], 2))
    {
        port_lbk.lbk_enable = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("swap-mac");
    if (0xFF != index)
    {
        port_lbk.lbk_type = CTC_PORT_LBK_TYPE_SWAP_MAC;
    }
    else
    {
        port_lbk.lbk_type = CTC_PORT_LBK_TYPE_BYPASS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("loopback-to");
    if (index != 0xFF)
    {
        port_lbk.lbk_mode = CTC_PORT_LBK_MODE_CC;
    }

    index = CTC_CLI_GET_ARGC_INDEX("tap-to");
    if (index != 0xFF)
    {
        port_lbk.lbk_mode = CTC_PORT_LBK_MODE_TAP;
    }

    ret = ctc_port_set_loopback(&port_lbk);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_efm_lb_mode_enable,
        ctc_cli_port_efm_lb_mode_enable_cmd,
        "port GPHYPORT_ID efm-loop-back enable (redirect-to-cpu INDEX|)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "EFM loop-back mode",
        "Enable EFM loop-back mode this port",
        "Redirect to cpu",
        "Index <0-15>")
{
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    ctc_port_lbk_param_t port_lbk;

    sal_memset(&port_lbk, 0, sizeof(ctc_port_lbk_param_t));

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);


    port_lbk.src_gport = gport;
    port_lbk.dst_gport = gport;

    port_lbk.lbk_enable = TRUE;
    port_lbk.lbk_type   = CTC_PORT_LBK_TYPE_BYPASS;
    port_lbk.lbk_mode   = CTC_PORT_LBK_MODE_EFM;

    index = CTC_CLI_GET_ARGC_INDEX("redirect");
    if (index != 0xFF)
    {
        port_lbk.efm_to_cpu_en = TRUE;
        CTC_CLI_GET_UINT8_RANGE("index", port_lbk.efm_to_cpu_index, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    ret = ctc_port_set_loopback(&port_lbk);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_efm_lb_mode_disable,
        ctc_cli_port_efm_lb_mode_disable_cmd,
        "port GPHYPORT_ID efm-loop-back disable",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "EFM loop-back mode",
        "Disable EFM loop-back mode this port")
{
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    ctc_port_lbk_param_t port_lbk;

    sal_memset(&port_lbk, 0, sizeof(ctc_port_lbk_param_t));

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);


    port_lbk.src_gport  = gport;
    port_lbk.dst_gport  = gport;

    port_lbk.lbk_enable = FALSE;
    port_lbk.lbk_mode   = CTC_PORT_LBK_MODE_EFM;

    ret = ctc_port_set_loopback(&port_lbk);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_port_check_enable,
        ctc_cli_port_set_port_check_enable_cmd,
        "port GPHYPORT_ID port-check-enable (enable | disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Src port match check",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);


    if (0 == sal_memcmp("en", argv[1], 2))
    {
        ret = ctc_port_set_port_check_en(gport, TRUE);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        ret = ctc_port_set_port_check_en(gport, FALSE);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_system_ipg_size,
        ctc_cli_port_set_system_ipg_size_cmd,
        "system set ipg-index INDEX size SIZE",
        "System attribution",
        "Set",
        "Ipg index",
        "Value <0-3>",
        "Size",
        "Value <0-255>")
{
    int32 ret = 0;
    ctc_ipg_size_t index;
    uint8 size;

    CTC_CLI_GET_UINT32("ipg-index", index, argv[0]);
    CTC_CLI_GET_UINT8("size", size, argv[1]);

    ret = ctc_set_ipg_size(index, size);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_ipg_index,
        ctc_cli_port_set_ipg_index_cmd,
        "port GPHYPORT_ID ipg-index INDEX",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Ipg index",
        "Value <0-3>")
{
    int32 ret = 0;
    uint16 gport;
    ctc_ipg_size_t index;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    CTC_CLI_GET_UINT32("ipg-index", index, argv[1]);


    ret = ctc_port_set_ipg(gport, index);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_reflective_bridge,
        ctc_cli_port_set_reflective_bridge_cmd,
        "port GPHYPORT_ID reflective-bridge (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Reflective bridge",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport;
    bool enable = TRUE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("di", argv[1], 2))
    {
        enable = FALSE;
    }

    ret = ctc_port_set_reflective_bridge_en(gport, enable);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_isolation_id,
        ctc_cli_port_set_isolation_id_cmd,
        "port GPHYPORT_ID (isolation-group GROUP|) isolation-id (direction (ingress|egress|both)|) \
        ({ucast-flooding | mcast-flooding | known-ucast-forwarding | known-mcast-forwarding | bcast-flooding}|) \
        value VALUE",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port isolation group id",
        CTC_CLI_PORT_ISOLATION_GROUP_DESC,
        "Port isolation",
        "Flow direction ",
        "Ingress",
        "Egress",
        "Both direction",
        "Unknown ucast packet will be isolated",
        "Unknown mcast packet will be isolated",
        "Known ucast packet will be isolated",
        "Known mcast packet will be isolated",
        "Broadcast packet will be isolated",
        "Isolation ID value",
        "<0-31>, 0 means disable")
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 index = 0xFF;
    ctc_port_restriction_t port_restriction;

    sal_memset(&port_restriction, 0, sizeof(ctc_port_restriction_t));

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    port_restriction.mode = CTC_PORT_RESTRICTION_PORT_ISOLATION;
    port_restriction.type = CTC_PORT_ISOLATION_ALL;

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if (index != 0xFF)
    {
        port_restriction.dir = CTC_INGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress");
    if (index != 0xFF)
    {
        port_restriction.dir = CTC_EGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("both");
    if (index != 0xFF)
    {
        port_restriction.dir = CTC_BOTH_DIRECTION;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ucast-flooding");
    if (index != 0xFF)
    {
        port_restriction.type = port_restriction.type | CTC_PORT_ISOLATION_UNKNOW_UCAST;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mcast-flooding");
    if (index != 0xFF)
    {
        port_restriction.type = port_restriction.type | CTC_PORT_ISOLATION_UNKNOW_MCAST;
    }

    index = CTC_CLI_GET_ARGC_INDEX("known-mcast-forwarding");
    if (index != 0xFF)
    {
        port_restriction.type = port_restriction.type | CTC_PORT_ISOLATION_KNOW_MCAST;
    }

    index = CTC_CLI_GET_ARGC_INDEX("known-ucast-forwarding");
    if (index != 0xFF)
    {
        port_restriction.type = port_restriction.type | CTC_PORT_ISOLATION_KNOW_UCAST;
    }

    index = CTC_CLI_GET_ARGC_INDEX("bcast-flooding");
    if (index != 0xFF)
    {
        port_restriction.type = port_restriction.type | CTC_PORT_ISOLATION_BCAST;
    }

    CTC_CLI_GET_UINT16("isolation_id", port_restriction.isolated_id, argv[argc - 1]);

    index = CTC_CLI_GET_ARGC_INDEX("value");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("value", port_restriction.isolated_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("isolation-group");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("isolation group", port_restriction.isolate_group, argv[index + 1]);
    }
    else
    {
        port_restriction.isolate_group = port_restriction.isolated_id;
    }

    ret = ctc_port_set_restriction(gport, &port_restriction);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_mux_demux,
        ctc_cli_port_set_mux_demux_cmd,
        "port GPHYPORT_ID (mux|demux) (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Mux, port range <64-255>",
        "Demux, port range <0-51>",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = 0;
    uint16 gport;
    ctc_port_mux_demux_type_t type;
    bool enable = TRUE;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    if (0 == sal_memcmp("mu", argv[1], 2))
    {
        type = CTC_PORT_TYPE_MUX;

    }
    else
    {
        type = CTC_PORT_TYPE_DEMUX;
    }

    if (0 == sal_memcmp("di", argv[2], 2))
    {
        enable = FALSE;
    }


    ret = ctc_port_set_mux_demux_en(gport, type, enable);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_internal_port,
        ctc_cli_port_set_internal_port_cmd,
        "port set internal-port LOCAL_PORT gchip GCHIP type (iloop|eloop|discard|fwd port GPHYPORT_ID)",
        CTC_CLI_PORT_M_STR,
        "Set",
        "Internal port",
        "<64-255>",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC,
        "Type",
        "Iloop",
        "Eloop",
        "Discard",
        "Fwd",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = 0;
    ctc_internal_port_assign_para_t port_assign;

    sal_memset(&port_assign, 0, sizeof(port_assign));

    CTC_CLI_GET_UINT8("lport", port_assign.inter_port, argv[0]);
    CTC_CLI_GET_UINT8("gchip", port_assign.gchip, argv[1]);

    if (0 == sal_memcmp("il", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    }
    else if (0 == sal_memcmp("el", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ELOOP;
    }
    else if (0 == sal_memcmp("di", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_DISCARD;
    }
    else
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_FWD;
        CTC_CLI_GET_UINT16("gport", port_assign.fwd_gport, argv[4]);
    }

    ret = ctc_set_internal_port(&port_assign);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_allocate_internal_port,
        ctc_cli_port_allocate_internal_port_cmd,
        "port allocate internal-port gchip GCHIP type (iloop|eloop nhid NHID|discard|fwd port GPHYPORT_ID)",
        CTC_CLI_PORT_M_STR,
        "Allocate",
        "Internal port",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC,
        "Type",
        "Iloop",
        "Eloop",
        "NHID",
        CTC_CLI_NH_ID_STR,
        "Discard",
        "Fwd",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = 0;
    ctc_internal_port_assign_para_t port_assign;

    sal_memset(&port_assign, 0, sizeof(port_assign));

    CTC_CLI_GET_UINT8("gchip", port_assign.gchip, argv[0]);

    if (0 == sal_memcmp("il", argv[1], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    }
    else if (0 == sal_memcmp("el", argv[1], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ELOOP;
        CTC_CLI_GET_UINT32("Nhid", port_assign.nhid, argv[3]);
    }
    else if (0 == sal_memcmp("di", argv[1], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_DISCARD;
    }
    else
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_FWD;
        CTC_CLI_GET_UINT16("gport", port_assign.fwd_gport, argv[3]);
    }

    ret = ctc_alloc_internal_port(&port_assign);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("%% The allocate internal port is %d\n", port_assign.inter_port);

    return ret;
}

CTC_CLI(ctc_cli_port_release_internal_port,
        ctc_cli_port_release_internal_port_cmd,
        "port release internal-port LOCAL_PORT gchip GCHIP type (iloop|eloop|discard|fwd port GPHYPORT_ID)",
        CTC_CLI_PORT_M_STR,
        "Release",
        "Internal port",
        "64-255",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC,
        "Type",
        "Iloop",
        "Eloop",
        "Discard",
        "Fwd",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = 0;
    ctc_internal_port_assign_para_t port_assign;

    sal_memset(&port_assign, 0, sizeof(port_assign));

    CTC_CLI_GET_UINT8("lport", port_assign.inter_port, argv[0]);
    CTC_CLI_GET_UINT8("gchip", port_assign.gchip, argv[1]);

    if (0 == sal_memcmp("il", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    }
    else if (0 == sal_memcmp("el", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_ELOOP;
    }
    else if (0 == sal_memcmp("di", argv[2], 2))
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_DISCARD;
    }
    else
    {
        port_assign.type = CTC_INTERNAL_PORT_TYPE_FWD;
        CTC_CLI_GET_UINT16("gport", port_assign.fwd_gport, argv[4]);
    }

    ret = ctc_free_internal_port(&port_assign);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_show_ipg_size,
        ctc_cli_port_show_ipg_size_cmd,
        "show system ipg-index INDEX size",
        CTC_CLI_SHOW_STR,
        "System attribution",
        "Ipg index",
        "Value <0-3>",
        "Size")
{
    int32 ret = 0;
    ctc_ipg_size_t index;
    uint8 size;

    CTC_CLI_GET_UINT32("ipg-index", index, argv[0]);

    ret = ctc_get_ipg_size(index, &size);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("ipg size              :%d\n", size);

    return ret;
}

CTC_CLI(ctc_cli_port_show_port_mac,
        ctc_cli_port_show_port_mac_cmd,
        "show port GPHYPORT_ID port-mac",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port MAC")
{
    int32 ret = 0;
    uint16 gport_id = 0;
    mac_addr_t port_mac;

    CTC_CLI_GET_UINT16("gport", gport_id, argv[0]);

    ctc_cli_out("Show GPort:0x%04x\n", gport_id);
    ctc_cli_out("==============================\n");

    sal_memset(&port_mac, 0, sizeof(mac_addr_t));
    ret = ctc_port_get_port_mac(gport_id, &port_mac);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("Port MAC              :  %02x%02x.%02x%02x.%02x%02x\n", port_mac[0], port_mac[1], port_mac[2], port_mac[3], port_mac[4], port_mac[5]);

    return ret;
}

CTC_CLI(ctc_cli_port_show_port_info,
        ctc_cli_port_show_port_info_cmd,
        "show port GPHYPORT_ID (all | port-en | receive | transmit | bridge | default-vlan | port-cross-connect \
        | learning-enable |keep-vlan-tag| sub-if | phy-if | vlan-ctl | ingress-vlan-filtering | egress-vlan-filtering | \
        vlan-domain |ingress-stpid-index|egress-stpid-index | untag-defalt-vlan| dot1q-type| \
        use-outer-ttl|port-blocking (ucast-flooding|mcast-flooding|known-ucast-forwarding|known-mcast-forwarding|bcast-flooding ) |protocol-vlan|vlan-mapping|vlan-classify| \
        mac-en|signal-detect|3ap-status|speed-mode|preamble|min-frame-size|max-frame-size|stretch-mode|pading|ingress-random-log|egress-random-log| \
        ingress-random-threshold|egress-random-threshold|src-discard|port-check-enable|mac-link-status|ipg | ingress-isolation-id |\
        egress-isolation-id | isolation-id | reflective-bridge| mux| demux | ((scl-key-type scl-id SCL_ID | vlan-range) direction (ingress | egress)))",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Show all property",
        "Port state",
        "Reception port state",
        "Transmission port state",
        "L2 bridge",
        "Default vlan id",
        "Port cross connect",
        "Mac learning enable",
        "Keep vlan tag",
        "Routed port l3 only",
        "Route enable on port",
        "Vlan tag control",
        "Ingress vlan filtering",
        "Egress vlan filtering",
        "Vlan domain when STPID is the same as CTPID",
        "Ingress stag tpid index",
        "Egress stag tpid index",
        "Untag-defalt-vlan",
        "Port's type descript in 802.1q",
        "Use outer ttl in case of tuunel",
        "Port based blocking",
        "Unknown ucast flooding to this port",
        "Unknown mcast flooding to this port",
        "Known ucast forwarding to this port",
        "Known mcast forwarding to this port",
        "Broadcast flooding to this port",
        "Protocol vlan",
        "Vlan mapping",
        "Vlan classify",
        "Mac enable",
        "Signal detect",
        "802.3ap training status",
        "Speed mode",
        "Preamble value",
        "Min frame size",
        "Max frame size",
        "Stretch mode",
        "L2 pading",
        "Ingress random log",
        "Egress random log",
        "The percentage of received packet for Ingress random log",
        "The percentage of received packet for egress random log",
        "Src discard",
        "Enable to check src port match",
        "Mac link status",
        "Ipg index",
        "Ingress isolation ID",
        "Egress isolation ID",
        "Isolation Id",
        "Reflective bridge enable",
        "Mux",
        "Demux",
        "SCL key type",
        "SCL id",
        CTC_CLI_SCL_ID_VALUE,
        "Vlan Range",
        "Direction",
        "Ingress",
        "Egress")
{
    int32 ret = CLI_SUCCESS;
    uint32 gport;
    uint8 val_8 = 0;
    uint16 val_16 = 0;
    uint32 val_32 = 0;
    bool val_b = 0;
    bool val2_b = 0;
    ctc_ipg_size_t ipg_index = 0;
    char* str = NULL;
    uint8 index = 0xFF;
    uint8 show_all = 0;
    uint32 value = 0;
    ctc_port_restriction_t port_restrict;
    bool enable = FALSE;
    ctc_direction_t dir = CTC_INGRESS;
    ctc_port_scl_property_t port_scl_property;
    ctc_vlan_range_info_t vrange_info;
    ctc_port_scl_key_type_t scl_key_type;

    char* igs_scl_hash_key_type[CTC_PORT_IGS_SCL_HASH_TYPE_MAX] = {"disable", "dvid(port cvlan svlan)", "svid",
                                                                   "cvid", "svid-scos", "cvid-ccos",
                                                                   "mac-sa", "port macsa", "mac-da", "port-mac-da",
                                                                   "ipsa", "port-ipsa", "port", "L2", "tunnel",
                                                                   "tunnel-rpf", "ipv4 tunnel auto", "nvgre", "vxlan"};

    char* egs_scl_hash_key_type[] = {"disable", "dvid", "svid", "cvid", "svid-scos", "cvid-ccos", "port"};

    char* scl_key_type_desc[] = {"disable", "port", "cvid", "svid", "cvid-ccos", "svid-scos", "dvid",
                                "mac-sa", "mac-da", "ipv4", "ipv6", "ipsg based port and mac", "ipsg based port and ip",
                                "ipsg based ipv6", "ipv4/ipv6 in ipv4, 6to4, ISATAP, GRE with/without GRE key tunnel",
                                "auto tunnel for ipv4/ipv6 in ipv4, 6to4 and ISATAP",
                                "ipv6 tunnel", "rpf check for ipv4/ipv6 in ipv4, 6to4, ISATAP, GRE with/without GRE key tunnel",
                                "rpf check for ipv6 tunnel", "nvgre tunnel", "vxlan tunnel"};

    char* scl_tcam_key_type[] = {"disable", "layer2 tcam key", "layer2/layer3 tcam key", "layer3 tcam key", "vlan tcam key", "layer3 tcam key", "layer3 tcam key"};
    char mode_str[CTC_PORT_RESTRICTION_PORT_ISOLATION + 1][32] = {{"none"}, {"pvlan"}, {"port blocking"}, {"port isolation"}};
    char port_str[CTC_PORT_PVLAN_COMMUNITY + 1][32] = {{"none"}, {"promiscuous"}, {"isolated"}, {"community"}};

    sal_memset(&port_scl_property, 0, sizeof(ctc_port_scl_property_t));
    sal_memset(&port_restrict, 0, sizeof(ctc_port_restriction_t));
    sal_memset(&vrange_info, 0, sizeof(ctc_vlan_range_info_t));

    index = CTC_CLI_GET_ARGC_INDEX("all");
    if (index != 0xFF)
    {
        show_all = 1;
    }

    CTC_CLI_GET_UINT32("gport", gport, argv[0]);

    ctc_cli_out("%-45s:  0x%04x\n","Show GPort", gport);
    ctc_cli_out("--------------------------------------------------------\n");

    index = CTC_CLI_GET_ARGC_INDEX("port-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_port_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port enable", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("receive");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_receive_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Receive enable", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("transmit");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_transmit_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Transmit enable",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("bridge");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_bridge_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Bridge enable", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("default-vlan");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_default_vlan(gport, &val_16);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Default vlan",val_16);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("port-cross-connect");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_cross_connect(gport, &val_32);
        if (ret >= 0)
        {
            if (0xFFFFFFFF == val_32)
            {
                ctc_cli_out("%-45s:  %s\n", "Port cross connect", "Invalid");
            }
            else
            {
                ctc_cli_out("%-45s:  0x%X\n", "Port cross connect", val_32);
            }
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("learning-enable");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_learning_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Learning enable", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("keep-vlan-tag");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_keep_vlan_tag(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Keep vlan tag", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("phy-if");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_phy_if_en(gport, &val_16, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Phy-if enable", val_b);
        }

        if (TRUE == val_b)
        {
            ctc_cli_out("%-45s:  %u\n", "Phy-if L3IFID", val_16);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("sub-if");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_sub_if_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Sub-if enable", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan-ctl");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_ctl(gport, (ctc_vlantag_ctl_t*)&val_32);
        if (ret >= 0)
        {
            switch (val_32)
            {
            case 0:
                str = "allow-all";
                break;

            case 1:
                str = "drop-all-untagged";
                break;

            case 2:
                str = "drop-all-tagged";
                break;

            case 3:
                str = "drop-all";
                break;

            case 4:
                str = "drop-wo-2tag";
                break;

            case 5:
                str = "drop-w-2tag";
                break;

            case 6:
                str = "drop-stag";
                break;

            case 7:
                str = "drop-non-stag";
                break;

            case 8:
                str = "drop-only-stag";
                break;

            case 9:
                str = "permit-only-stag";
                break;

            case 10:
                str = "drop-all-ctag";
                break;

            case 11:
                str = "drop-non-ctag";
                break;

            case 12:
                str = "drop-only-ctag";
                break;

            case 13:
                str = "permit-only-ctag";
                break;

            case 14:
                str = "allow-all";
                break;

            default:
                break;
            }

            ctc_cli_out("%-45s:  %s\n", "Vlan control", str);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("untag-defalt-vlan");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_untag_dft_vid(gport, &val_b, &val2_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Untag default vid", val_b);
            ctc_cli_out("%-45s:  %u\n", "Untag svlan", val2_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress-vlan-filtering");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_filter_en(gport, CTC_INGRESS, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ingress vlan filtering", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress-vlan-filtering");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_filter_en(gport, CTC_EGRESS, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Egress vlan filtering", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan-domain");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_domain(gport, (ctc_port_vlan_domain_type_t*)&val_b);
        if (0 == val_b)
        {
            str = "svlan";
        }
        else
        {
            str = "cvlan";
        }

        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Vlan domain", str);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("dot1q-type");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_dot1q_type(gport, (ctc_dot1q_type_t*)&val_32);
        if (ret >= 0)
        {
            switch (val_32)
            {
            case CTC_DOT1Q_TYPE_NONE:
                str = "untagged";
                break;

            case CTC_DOT1Q_TYPE_CVLAN:
                str = "cvlan-tagged";
                break;

            case CTC_DOT1Q_TYPE_SVLAN:
                str = "svlan-tagged";
                break;

            case CTC_DOT1Q_TYPE_BOTH:
                str = "double-tagged";
                break;

            default:
                break;
            }

            ctc_cli_out("%-45s:  %s\n", "Dot1q-type",str);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("use-outer-ttl");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_use_outer_ttl(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Use outer ttl", val_b);
        }
    }

    if (show_all)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (CTC_PORT_RESTRICTION_PORT_BLOCKING == port_restrict.mode))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_UNKNOW_UCAST) ? 1 : 0;
            ctc_cli_out("Port blocking %-31s:  %u\n", "unknown ucast flood", value);

            value = (port_restrict.type & CTC_PORT_BLOCKING_UNKNOW_MCAST) ? 1 : 0;
            ctc_cli_out("Port blocking %-31s:  %u\n", "unknown mcast flood", value);

            value = (port_restrict.type & CTC_PORT_BLOCKING_KNOW_UCAST) ? 1 : 0;
            ctc_cli_out("Port blocking %-31s:  %u\n", "known ucast forwarding", value);

            value = (port_restrict.type & CTC_PORT_BLOCKING_KNOW_MCAST) ? 1 : 0;
            ctc_cli_out("Port blocking %-31s:  %u\n", "known mcast forwarding", value);

            value = (port_restrict.type & CTC_PORT_BLOCKING_BCAST) ? 1 : 0;
            ctc_cli_out("Port blocking %-31s:  %u\n", "bcast flood", value);
        }

        port_restrict.dir = CTC_INGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if (ret >= 0)
        {
            if (CTC_PORT_RESTRICTION_PVLAN == port_restrict.mode)
            {
                ctc_cli_out("%-45s:  %s\n", "Private vlan", port_str[port_restrict.type]);
            }
            else
            {
                ctc_cli_out("%-45s:  %s\n", "Private vlan", "disable");
            }

            if (CTC_PORT_RESTRICTION_PORT_ISOLATION == port_restrict.mode)
            {
                ctc_cli_out("%-45s:  %u\n", "Ingress port isolation id", port_restrict.isolate_group);
            }
            else
            {
                ctc_cli_out("%-45s:  %s\n", "Ingress port isolation id", "disable");
            }
        }

        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (CTC_PORT_RESTRICTION_PORT_ISOLATION == port_restrict.mode))
        {
            ctc_cli_out("%-45s:  %u\n", "Egress port isolation id", port_restrict.isolated_id);
        }
        else
        {
            ctc_cli_out("%-45s:  %s\n", "Egress port isolation id", "disable");
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ucast-flooding");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_BLOCKING))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_UNKNOW_UCAST) ? 1 : 0;
            ctc_cli_out("%-45s:  %u\n", "Unknown ucast flood block", value);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mcast-flooding");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_BLOCKING))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_UNKNOW_MCAST) ? 1 : 0;
            ctc_cli_out("%-45s:  %u\n", "Unknown mcast flood block", value);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("known-ucast-forwarding");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_BLOCKING))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_KNOW_UCAST) ? 1 : 0;
            ctc_cli_out("%-45s:  %u\n", "Known ucast forwarding block", value);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("known-mcast-forwarding");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_BLOCKING))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_KNOW_MCAST) ? 1 : 0;
            ctc_cli_out("%-45s:  %u\n", "Known mcast forwarding block", value);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("bcast-flooding");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_BLOCKING))
        {
            value = (port_restrict.type & CTC_PORT_BLOCKING_BCAST) ? 1 : 0;
            ctc_cli_out("%-45s:  %u\n", "Bcast flood block", value);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress-stpid-index");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_stag_tpid_index(gport, CTC_INGRESS, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ingress stag tpid index", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress-stpid-index");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_stag_tpid_index(gport, CTC_EGRESS, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Egress stag tpid index", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("protocol-vlan");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_protocol_vlan_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Protocol vlan",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan-mapping");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_mapping_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Vlan mapping",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan-classify");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_vlan_classify_enable(gport, (ctc_vlan_class_type_t*)&val_32);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n(0-mac, 1-ipv4, 2-ipv6, 3-protocl, 4-none)\n", "Vlan classify type", val_32);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_mac_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "MAC enable",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("signal-detect");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SIGNAL_DETECT, &val_32);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Signal detect", val_32);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("3ap-status");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_3AP_TRAINING_EN, &val_32);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "3ap Status", val_32);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("speed-mode");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_speed(gport, (ctc_port_speed_t*)&val_32);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Speed mode",val_32);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("preamble");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_preamble(gport, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Preamble", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("min-frame-size");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_min_frame_size(gport, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Min frame size", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("max-frame-size");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_max_frame(gport, (ctc_frame_size_t*)&val_32);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Max frame index",val_32);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("stretch-mode");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_stretch_mode_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Stretch mode", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("pading");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_pading_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Pading", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress-random-log");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_random_log_en(gport, CTC_INGRESS, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ingress random log",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress-random-log");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_random_log_en(gport, CTC_EGRESS, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Egress random log",val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress-random-threshold");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_random_log_percent(gport, CTC_INGRESS, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u%\n", "Ingress random log weight", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress-random-threshold");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_random_log_percent(gport, CTC_EGRESS, &val_8);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u*(1/2^32)\n", "Egress random log weight", val_8);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("src-discard");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_srcdiscard_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Src-discard", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("port-check-enable");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_port_check_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Src-match-check", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-link-status");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_mac_link_up(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "MAC-link-status", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipg");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_ipg(gport, &ipg_index);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ipg index", ipg_index);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ingress-isolation-id");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_INGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_ISOLATION))
        {
            ctc_cli_out("%-45s:  %u\n", "Port ingress isolation ID", port_restrict.isolated_id);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port ingress isolation", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress-isolation-id");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_ISOLATION))
        {
            ctc_cli_out("%-45s:  %u\n", "Port egress isolation ID", port_restrict.isolated_id);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port egress isolation", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("isolation-id");
    if (index != 0xFF)
    {
        port_restrict.dir = CTC_INGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_ISOLATION))
        {
            if (0 != port_restrict.isolated_id)
            {
                ctc_cli_out("%-45s:  %u\n", "Port ingress isolation ID", port_restrict.isolated_id);
            }
            else
            {
                ctc_cli_out("%-45s:  %u\n", "Port ingress isolation Group", port_restrict.isolate_group);
            }
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port ingress isolation", mode_str[port_restrict.mode]);
        }

        port_restrict.dir = CTC_EGRESS;
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PORT_ISOLATION))
        {
            ctc_cli_out("%-45s:  %u\n", "Port egress isolation ID", port_restrict.isolated_id);
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Port egress isolation", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("reflective-bridge");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_reflective_bridge_en(gport, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Reflective bridge", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mux");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_mux_demux_en(gport, CTC_PORT_TYPE_MUX, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "MUX", val_b);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("demux");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_mux_demux_en(gport, CTC_PORT_TYPE_DEMUX, &val_b);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "DEMUX", val_b);
        }
    }

    if ((ret < 0) && (!show_all))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    index = CTC_CLI_GET_ARGC_INDEX("scl-key-type");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8_RANGE("scl id", port_scl_property.scl_id, argv[index + 2], 0, CTC_MAX_UINT8_VALUE);

        if (CLI_CLI_STR_EQUAL("ingress", index + 4))
        {
            port_scl_property.direction = CTC_INGRESS;
        }
        else if (CLI_CLI_STR_EQUAL("egress", index + 4))
        {
            port_scl_property.direction = CTC_EGRESS;
        }

        ret = ctc_port_get_scl_property(gport, &port_scl_property);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }

        if (CTC_INGRESS == port_scl_property.direction)
        {
            ctc_cli_out("%-45s:  %s\n", "Scl hash key type", igs_scl_hash_key_type[port_scl_property.hash_type]);
        }
        else
        {
            ctc_cli_out("%-45s:  %s\n", "Scl hash key type", egs_scl_hash_key_type[port_scl_property.hash_type]);
        }

        ctc_cli_out("%-45s:  %s\n", "Scl tcam key type", scl_tcam_key_type[port_scl_property.tcam_type]);
        ctc_cli_out("%-45s:  %u\n", "ClassId en", port_scl_property.class_id_en);
        ctc_cli_out("%-45s:  %u\n", "ClassId", port_scl_property.class_id);
        ctc_cli_out("%-45s:  %u\n", "Use logic port en", port_scl_property.use_logic_port_en);

        ret = ctc_port_get_scl_key_type(gport, dir, port_scl_property.scl_id, &scl_key_type);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
        ctc_cli_out("%-45s:  %s\n", "Scl key type", scl_key_type_desc[scl_key_type]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vlan-range");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("ingress", index + 2))
        {
            dir = CTC_INGRESS;
        }
        else if (CLI_CLI_STR_EQUAL("egress", index + 2))
        {
            dir = CTC_EGRESS;
        }

        vrange_info.direction = dir;

        ret = ctc_port_get_vlan_range(gport, &vrange_info, &enable);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }

        if (!enable)
        {
            ctc_cli_out("%-45s:  %s\n", "Vlan range", "disable");
        }
        else
        {
            ctc_cli_out("%-45s:  %s\n", "Vlan range", "enable");
            ctc_cli_out("%-45s:  %u\n", "Vlan range group", vrange_info.vrange_grpid);
        }
    }

    if (show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ROUTE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Route-enable", value);
        }


        ret = ctc_port_get_property(gport, CTC_PORT_PROP_HW_LEARN_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Hw-learn", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_RAW_PKT_TYPE, &value);

        switch (value)
        {
        case CTC_PORT_RAW_PKT_ETHERNET:
            str = "ethernet";
            break;

        case CTC_PORT_RAW_PKT_IPV4:
            str = "ipv4";
            break;

        case CTC_PORT_RAW_PKT_IPV6:
            str = "ipv6";
            break;

        case CTC_PORT_RAW_PKT_NONE:
            str = "none";
            break;
        }

        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Raw-packet-type", str);
        }


        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.type == CTC_PORT_PVLAN_COMMUNITY) && (port_restrict.mode == CTC_PORT_RESTRICTION_PVLAN))
        {
            ctc_cli_out("%-45s:  %s\n", "Pvlan port type", port_str[port_restrict.type]);
            ctc_cli_out("%-45s:  %u\n", "Pvlan port isolated id", port_restrict.isolated_id);
        }
        else if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PVLAN))
        {
            ctc_cli_out("%-45s:  %s\n", "Pvlan port type", port_str[port_restrict.type]);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_TUNNEL_RPF_CHECK, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Tunnel-rpf-check", value);
        }


        ret = ctc_port_get_property(gport, CTC_PORT_PROP_RPF_TYPE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Rpf-type", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PKT_TAG_HIGH_PRIORITY, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Pkt-tag-high-priority", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_IPV6_LOOKUP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ipv6-lookup", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_IPV4_LOOKUP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ipv4-lookup", value);
        }


        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_USE_DEFAULT_LOOKUP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Use-default-lookup", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV6_TO_MAC, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ipv6-to-mac-key", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV4_TO_MAC, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ipv4-to-mac-key", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_TRILL_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Trill", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DISCARD_NON_TRIL_PKT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Discard-non-tril", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DISCARD_TRIL_PKT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Discard-tril", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REFLECTIVE_BRIDGE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Reflective-bridge", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FCOE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Fcoe", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FCOE_RPF_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Fcoe-rpf", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_STAG_COS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Replace-stag-cos", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_CTAG_COS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Replace-ctag-cos", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_DSCP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Replace-dscp", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_L3PDU_ARP_ACTION, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "L3pdu-arp-action", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_L3PDU_DHCP_ACTION, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "L3pdu-dhcp-action", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PTP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Ptp", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_IS_LEAF, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Is-leaf", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PRIORITY_TAG_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Priority-tag", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DEFAULT_PCP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Default-pcp", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DEFAULT_DEI, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Default-dei", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_NVGRE_MCAST_NO_DECAP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Nvgre-mcast-no-decap", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_VXLAN_MCAST_NO_DECAP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Vxlan-mcast-no-decap", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_HASH_FIELD_SEL_ID, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Scl-field-sel-id", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_QOS_POLICY, &value);

        switch (value)
        {
        case CTC_QOS_TRUST_PORT:
            str = "port";
            break;

        case CTC_QOS_TRUST_OUTER:
            str = "outer";
            break;

        case CTC_QOS_TRUST_COS:
            str = "cos";
            break;

        case CTC_QOS_TRUST_DSCP:
            str = "dscp";
            break;

        case CTC_QOS_TRUST_IP:
            str = "ip-prec";
            break;

        case CTC_QOS_TRUST_STAG_COS:
            str = "stag-cos";
            break;

        case CTC_QOS_TRUST_CTAG_COS:
            str = "ctag-cos";
            break;

        default:
            str = "unexpect!!!!!";
            break;

        }

        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %s\n", "Qos-trust", str);
        }



        ret = ctc_port_get_property(gport, CTC_PORT_PROP_AUTO_NEG_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port auto-neg", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINK_INTRRUPT_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port link change interrupt enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_MAC_TS_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port mac time stamp", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINKSCAN_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port linkscan enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_FAILOVER_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port aps failover enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINKAGG_FAILOVER_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Port linkagg failover enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SNOOPING_PARSER, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Snooping parser", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FLOW_LKUP_BY_OUTER_HEAD, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Flow lkup use outer", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_EXTERN_ENABLE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Extern enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_NVGRE_ENABLE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Nvgre enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_PORT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Metadata overwrite port", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_UDF, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Metadata overwrite udf", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SRC_MISMATCH_EXCEPTION_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Src mismatch exception en", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_EFD_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Efd en", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Add default vlan disable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LOGIC_PORT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Logic port", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_SELECT_GRP_ID, &value);
        if (ret >= 0)
        {
            if (0xFFFFFFFF == value)
            {
                ctc_cli_out("%-45s:  %s\n", "Aps select group", "disable");
            }
            else
            {
                ctc_cli_out("%-45s:  %u\n", "Aps select group", value);
            }
        }

       ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_SELECT_WORKING, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Aps select working path", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ERROR_CHECK, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Error check enable", value);
        }

        ret = ctc_port_get_property(gport, CTC_PORT_PROP_AUTO_NEG_MODE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-45s:  %u\n", "Auto neg mode", value);
        }

    }

    if ((ret < 0) && (!show_all))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_port_debug_on,
        ctc_cli_port_debug_on_cmd,
        "debug port (ctc|sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_PORT_M_STR,
        "CTC Layer",
        "SYS Layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = PORT_CTC;
    }
    else
    {
        typeenum = PORT_SYS;
    }

    ctc_debug_set_flag("port", "port", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_port_debug_off,
        ctc_cli_port_debug_off_cmd,
        "no debug port (ctc|sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_PORT_M_STR,
        "CTC Layer",
        "SYS Layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = PORT_CTC;
    }
    else
    {
        typeenum = PORT_SYS;
    }

    ctc_debug_set_flag("port", "port", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

/*    "Set low 8 bits for da port MAC",
    "Set da port MAC high 40 bits register select",
    "Set low 8 bits for sa port MAC",
    "Set sa port MAC high 40 bits register select",*/

CTC_CLI(ctc_cli_port_set_property,
        ctc_cli_port_set_property_cmd,
        "port GPHYPORT_ID property (((route-en| pkt-tag-high-priority | hw-learn | ipv6-lookup | ipv4-lookup | use-default-lookup | \
        ipv6-to-mac-key | ipv4-to-mac-key | trill | discard-non-tril | discard-tril | reflective-bridge | fcoe | fcoe-rpf | \
        replace-stag-cos| replace-ctag-cos | replace-dscp | l3pdu-arp-action | l3pdu-dhcp-action | tunnel-rpf-check | ptp | \
        rpf-type | is-leaf | priority-tag | default-pcp | default-dei | nvgre-mcast-no-decap | vxlan-mcast-no-decap | \
        linkscan-en |aps-failover | linkagg-failover |link-intr | mac-ts | scl-field-sel-id | snooping-parser |flow-lkup-use-outer | extern-en |nvgre-en |\
        metadata-overwrite-port | metadata-overwrite-udf | src-mismatch-exception-en | efd-en | add-default-vlan-dis | \
        aps-select-group | aps-select-working | error-check) value VALUE) \
        | logic-port value VALUE | \
        | (raw-packet-type ( none | ethernet | ipv4 | ipv6 )) | \
        (pvlan-type ( none | promiscuous | isolated | community isolation-id VALUE)) | \
        (qos-trust (port | outer | cos | dscp | ip-prec | stag-cos | ctag-cos))| \
        (auto-neg-mode (1000base-X| sgmii-slaver)))",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Property",
        "Route enable",
        "Packet tag take precedence over all",
        "Hardware learning",
        "Scl ipv6 lookup disable",
        "Scl ipv4 lookup disable",
        "Scl default lookup",
        "Scl MAC key is used for lookup instead of ipv6 key",
        "Scl MAC key is used for lookup instead of ipv4 key",
        "Set trill enable",
        "Set NON-TRILL packet discard",
        "Set TRILL packet discard",
        "Bridge to the same port enable",
        "FCoE enable",
        "FCoE RPF enable",
        "The STAG COS field is replaced by the classified COS result",
        "The CTAG COS field is replaced by the classified COS result",
        "The Dscp field is replace by qos mapping",
        "ARP packet processing type",
        "DHCP packet processing type",
        "RPF check for outer tunnel IP header is enabled",
        "Enable ptp",
        "Strict or loose",
        "This port connect with a leaf node",
        "Priority tagged packet will be sent out",
        "Default cos of vlan tag",
        "Default dei of vlan tag",
        "NvGRE Mcast packet will do not decapsulate",
        "VxLAN Mcast packet will do not decapsulate",
        "Port support linkscan function",
        "Aps failover enable",
        "Linkagg failover enable",
        "Pcs link change interrupt enable",
        "Timestamp",
        "Scl key field select id <0-3>",
        "Snooping parser",
        "If set,indicate tunnel packet will use outer header to do ACL/IPFIX flow lookup",
        "Extern en",
        "Nvgre enable",
        "Metadata overwrite port",
        "Metadata overwrite udf",
        "Source mismatch exception en",
        "Efd enable",
        "Add default vlan disable",
        "Aps select group id, 0xFFFFFFFF means disable aps select",
        "Aps select path, 0 means protecting path, else working path",
        "Mac error check",
        "Property value",
        "Value",
        "Logic port",
        "Value",
        "<0-0x3FFF>, 0xFFFF means disable",
        "Packet type",
        "Raw packet type disable",
        "Port parser ethernet raw packet",
        "Port only parser ipv4 raw packet",
        "Port only parser ipv6 raw packet",
        "Pvlan port type",
        "Port is none port",
        "Port is promiscuous port",
        "Port is isolated port",
        "Port is community port",
        "Community port isolated id",
        "0~15",
        "Qos trust policy",
        "Classifies ingress packets with the port default CoS value",
        "Classifies ingress packets with the outer priority value",
        "Classifies ingress packets with the packet CoS values",
        "Classifies ingress packets with the packet DSCP values",
        "Classifies ingress packets with the packet IP-Precedence values",
        "Classifies ingress packets with the packet Stag CoS values",
        "Classifies ingress packets with the packet Ctag CoS values",
        "Auto neg mode",
        "1000Base-X",
        "Sgmii-slaver")
{
    int32 ret = 0;
    uint16 gport;
    uint32 value = 0;
    uint8 index = 0xFF;
    ctc_port_restriction_t port_restriction;

    sal_memset(&port_restriction, 0, sizeof(ctc_port_restriction_t));

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("value");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("Property_value", value, argv[index + 1]);
    }

    if (CLI_CLI_STR_EQUAL("route-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_ROUTE_EN, value);
    }
    if (CLI_CLI_STR_EQUAL("pkt-tag-high-priority", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_PKT_TAG_HIGH_PRIORITY, value);
    }
    else if (CLI_CLI_STR_EQUAL("hw-learn", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_HW_LEARN_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("ipv6-lookup", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_IPV6_LOOKUP_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("ipv4-lookup", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_IPV4_LOOKUP_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("use-default-lookup", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_USE_DEFAULT_LOOKUP, value);
    }
    else if (CLI_CLI_STR_EQUAL("ipv6-to-mac-key", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV6_TO_MAC, value);
    }
    else if (CLI_CLI_STR_EQUAL("ipv4-to-mac-key", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV4_TO_MAC, value);
    }
    else if (CLI_CLI_STR_EQUAL("trill", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_TRILL_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("discard-non-tril", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_DISCARD_NON_TRIL_PKT, value);
    }
    else if (CLI_CLI_STR_EQUAL("discard-tril", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_DISCARD_TRIL_PKT, value);
    }
    else if (CLI_CLI_STR_EQUAL("reflective-bridge", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_REFLECTIVE_BRIDGE_EN, value);
    }
    else if ((CLI_CLI_STR_EQUAL("fcoe", 1))
             && (sal_strlen("fcoe") == sal_strlen(argv[1])))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_FCOE_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("fcoe-rpf", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_FCOE_RPF_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("replace-stag-cos", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_REPLACE_STAG_COS, value);
    }
    else if (CLI_CLI_STR_EQUAL("replace-ctag-cos", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_REPLACE_CTAG_COS, value);
    }
    else if (CLI_CLI_STR_EQUAL("replace-dscp", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_REPLACE_DSCP_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("l3pdu-arp-action", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_L3PDU_ARP_ACTION, value);
    }
    else if (CLI_CLI_STR_EQUAL("l3pdu-dhcp-action", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_L3PDU_DHCP_ACTION, value);
    }
    else if (CLI_CLI_STR_EQUAL("tunnel-rpf-check", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_TUNNEL_RPF_CHECK, value);
    }
    else if (CLI_CLI_STR_EQUAL("ptp", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_PTP_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("rpf-type", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_RPF_TYPE, value);
    }
    else if (CLI_CLI_STR_EQUAL("is-leaf", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_IS_LEAF, value);
    }
    else if (CLI_CLI_STR_EQUAL("priority-tag", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_PRIORITY_TAG_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("default-pcp", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_DEFAULT_PCP, value);
    }
    else if (CLI_CLI_STR_EQUAL("default-dei", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_DEFAULT_DEI, value);
    }
    else if (CLI_CLI_STR_EQUAL("nvgre-mcast-no-decap", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_NVGRE_MCAST_NO_DECAP, value);
    }
    else if (CLI_CLI_STR_EQUAL("vxlan-mcast-no-decap", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_VXLAN_MCAST_NO_DECAP, value);
    }
    else if (CLI_CLI_STR_EQUAL("mac-ts", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_MAC_TS_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("error-check", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_ERROR_CHECK, value);
    }
    else if (CLI_CLI_STR_EQUAL("scl-field-sel-id", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SCL_HASH_FIELD_SEL_ID, value);
    }
    else if (CLI_CLI_STR_EQUAL("raw-packet-type", 1))
    {
        if (CLI_CLI_STR_EQUAL("none", 2))
        {
            value = CTC_PORT_RAW_PKT_NONE;
        }
        else if (CLI_CLI_STR_EQUAL("ethernet", 2))
        {
            value = CTC_PORT_RAW_PKT_ETHERNET;
        }
        else if (CLI_CLI_STR_EQUAL("ipv4", 2))
        {
            value = CTC_PORT_RAW_PKT_IPV4;
        }
        else if (CLI_CLI_STR_EQUAL("ipv6", 2))
        {
            value = CTC_PORT_RAW_PKT_IPV6;
        }

        ret = ctc_port_set_property(gport, CTC_PORT_PROP_RAW_PKT_TYPE, value);
    }
    else if (CLI_CLI_STR_EQUAL("pvlan-type", 1))
    {
        port_restriction.mode = CTC_PORT_RESTRICTION_PVLAN;
        if (CLI_CLI_STR_EQUAL("none", 2))
        {
            port_restriction.type = CTC_PORT_PVLAN_NONE;
        }
        else if (CLI_CLI_STR_EQUAL("promiscuous", 2))
        {
            port_restriction.type = CTC_PORT_PVLAN_PROMISCUOUS;
        }
        else if (CLI_CLI_STR_EQUAL("isolated", 2))
        {
            port_restriction.type = CTC_PORT_PVLAN_ISOLATED;
        }
        else if (CLI_CLI_STR_EQUAL("community", 2))
        {
            port_restriction.type = CTC_PORT_PVLAN_COMMUNITY;
        }

        index = 0;
        index = CTC_CLI_GET_ARGC_INDEX("isolation-id");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("isolated_id", port_restriction.isolated_id, argv[index + 1]);
        }

        ret = ctc_port_set_restriction(gport, &port_restriction);
    }
    else if (CLI_CLI_STR_EQUAL("qos-trust", 1))
    {
        if (CLI_CLI_STR_EQUAL("port", 2))
        {
            value = CTC_QOS_TRUST_PORT;
        }
        else if (CLI_CLI_STR_EQUAL("outer", 2))
        {
            value = CTC_QOS_TRUST_OUTER;
        }
        else if (CLI_CLI_STR_EQUAL("cos", 2))
        {
            value = CTC_QOS_TRUST_COS;
        }
        else if (CLI_CLI_STR_EQUAL("dscp", 2))
        {
            value = CTC_QOS_TRUST_DSCP;
        }
        else if (CLI_CLI_STR_EQUAL("ip-prec", 2))
        {
            value = CTC_QOS_TRUST_IP;
        }
        else if (CLI_CLI_STR_EQUAL("stag-cos", 2))
        {
            value = CTC_QOS_TRUST_STAG_COS;
        }
        else if (CLI_CLI_STR_EQUAL("ctag-cos", 2))
        {
            value = CTC_QOS_TRUST_CTAG_COS;
        }

        ret = ctc_port_set_property(gport, CTC_PORT_PROP_QOS_POLICY, value);
    }

    else if (CLI_CLI_STR_EQUAL("auto-neg-mode", 1))
    {
        if (CLI_CLI_STR_EQUAL("1000base-X", 2))
        {
            value = CTC_PORT_AUTO_NEG_MODE_1000BASE_X;
        }
        else if (CLI_CLI_STR_EQUAL("sgmii-slaver", 2))
        {
            value = CTC_PORT_AUTO_NEG_MODE_SGMII_SLAVER;
        }

        ret = ctc_port_set_property(gport, CTC_PORT_PROP_AUTO_NEG_MODE, value);
    }

    else if (CLI_CLI_STR_EQUAL("linkscan-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_LINKSCAN_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("aps-failover", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_APS_FAILOVER_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("linkagg-failover", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_LINKAGG_FAILOVER_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("link-intr", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_LINK_INTRRUPT_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("snooping-parser", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SNOOPING_PARSER, value);
    }
    else if (CLI_CLI_STR_EQUAL("flow-lkup-use-outer", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_FLOW_LKUP_BY_OUTER_HEAD, value);
    }
    else if (CLI_CLI_STR_EQUAL("extern-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_EXTERN_ENABLE, value);
    }
    else if (CLI_CLI_STR_EQUAL("nvgre-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_NVGRE_ENABLE, value);
    }
    else if (CLI_CLI_STR_EQUAL("metadata-overwrite-port", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_PORT, value);
    }
    else if (CLI_CLI_STR_EQUAL("metadata-overwrite-udf", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_UDF, value);
    }
    else if (CLI_CLI_STR_EQUAL("src-mismatch-exception-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_SRC_MISMATCH_EXCEPTION_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("efd-en", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_EFD_EN, value);
    }
    else if (CLI_CLI_STR_EQUAL("add-default-vlan-dis", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, value);
    }
    else if (CLI_CLI_STR_EQUAL("logic-port", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_LOGIC_PORT, value);
    }
    else if (CLI_CLI_STR_EQUAL("aps-select-group", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_APS_SELECT_GRP_ID, value);
    }
    else if (CLI_CLI_STR_EQUAL("aps-select-working", 1))
    {
        ret = ctc_port_set_property(gport, CTC_PORT_PROP_APS_SELECT_WORKING, value);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

/*    "Mac-da-low-8bits value",
    "Mac-da-prefix-type value",
    "Low 8 bits for sa port MAC",
    "Sa port MAC high 40 bits register select",*/
CTC_CLI(ctc_cli_port_set_system_port_mac_prefix,
        ctc_cli_port_set_system_port_mac_prefix_cmd,
        "system set port-mac { prefix0 MAC | prefix1 MAC }",
        "System attribution",
        "Set",
        "Port MAC",
        "Port Prefix MAC 0",
        CTC_CLI_MAC_FORMAT,
        "Port Prefix MAC 1",
        "MAC address in HHHH.HHHH.HHHH format, high 32bits must same as port mac prefix 0")
{
    int32 ret   = 0;
    uint8 index = 0;
    ctc_port_mac_prefix_t prefix_mac;
    mac_addr_t          mac_addr;

    sal_memset(&prefix_mac, 0, sizeof(ctc_port_mac_prefix_t));

    index = CTC_CLI_GET_ARGC_INDEX("prefix0");
    if (index != 0xFF)
    {
        CTC_SET_FLAG(prefix_mac.prefix_type, CTC_PORT_MAC_PREFIX_MAC_0);
        sal_memset(&mac_addr, 0, sizeof(mac_addr_t));
        CTC_CLI_GET_MAC_ADDRESS("mac address", mac_addr, argv[index + 1]);
        sal_memcpy(prefix_mac.port_mac[0], mac_addr, sizeof(mac_addr_t));
    }

    index = CTC_CLI_GET_ARGC_INDEX("prefix1");
    if (index != 0xFF)
    {
        CTC_SET_FLAG(prefix_mac.prefix_type, CTC_PORT_MAC_PREFIX_MAC_1);
        sal_memset(&mac_addr, 0, sizeof(mac_addr_t));
        CTC_CLI_GET_MAC_ADDRESS("mac address", mac_addr, argv[index + 1]);

        sal_memcpy(prefix_mac.port_mac[1], mac_addr, sizeof(mac_addr_t));
    }

    ret = ctc_port_set_port_mac_prefix(&prefix_mac);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_port_mac_postfix,
        ctc_cli_port_set_port_mac_postfix_cmd,
        "port GPHYPORT_ID (prefix-index INDEX low-8bit-mac MAC|port-mac MAC)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Prefix port mac index",
        "Value <0-1>",
        "Port MAC low 8bit",
        "<0-255>",
        "Port MAC",
        CTC_CLI_MAC_FORMAT)
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 index = 0;
    uint8 mac   = 0;
    ctc_port_mac_postfix_t post_mac;

    sal_memset(&post_mac, 0, sizeof(ctc_port_mac_postfix_t));

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("port-mac");

    if (0xFF != index)
    {
        CTC_SET_FLAG(post_mac.prefix_type, CTC_PORT_MAC_PREFIX_48BIT);
        CTC_CLI_GET_MAC_ADDRESS("port-mac", post_mac.port_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("prefix-index");

    if (0xFF != index)
    {

        CTC_CLI_GET_UINT8("index", index, argv[index+1]);
        if (0 == index)
        {
            CTC_SET_FLAG(post_mac.prefix_type, CTC_PORT_MAC_PREFIX_MAC_0);
        }
        else if (1 == index)
        {
            CTC_SET_FLAG(post_mac.prefix_type, CTC_PORT_MAC_PREFIX_MAC_1);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("low-8bit-mac");

    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("mac", mac, argv[index + 1]);
        post_mac.low_8bits_mac = mac;
    }

    ret = ctc_port_set_port_mac_postfix(gport, &post_mac);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_show_port_property,
        ctc_cli_port_show_port_property_cmd,
        "show port GPHYPORT_ID property (all | route-en | pkt-tag-high-priority | hw-learn | \
        ipv6-lookup | ipv4-lookup | use-default-lookup | ipv6-to-mac-key | ipv4-to-mac-key | trill | discard-non-tril | discard-tril | \
        reflective-bridge | fcoe | fcoe-rpf | replace-stag-cos | replace-ctag-cos | replace-dscp | \
        l3pdu-arp-action | l3pdu-dhcp-action | tunnel-rpf-check | ptp | rpf-type | is-leaf | priority-tag | default-pcp | \
        default-dei | nvgre-mcast-no-decap | vxlan-mcast-no-decap | raw-packet-type | pvlan-type | qos-trust | auto-neg | \
        link-intr | mac-ts | linkscan-en | aps-failover | linkagg-failover | scl-field-sel-id | snooping-parser |flow-lkup-use-outer | extern-en | nvgre-en | \
        metadata-overwrite-port | metadata-overwrite-udf | src-mismatch-exception-en | efd-en|add-default-vlan-dis | logic-port | \
        aps-select-group | aps-select-working | error-check | auto-neg-mode)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Property",
        "Show all property",
        "Route enable",
        "Packet tag take precedence over all",
        "Hardware learning",
        "Scl ipv6 lookup disable",
        "Scl ipv4 lookup disable",
        "Scl default lookup",
        "Scl MAC key is used for lookup instead of ipv6 key",
        "Scl MAC key is used for lookup instead of ipv4 key",
        "Trill enable",
        "NON-TRILL packet discard",
        "TRILL packet discard",
        "Bridge to the same port enable",
        "FCoE enable",
        "FCoE RPF enable",
        "The STAG COS field is replaced by the classified COS result",
        "The CTAG COS field is replaced by the classified COS result",
        "The Dscp field is replaced by the qos mapping result",
        "ARP packet processing type",
        "DHCP packet processing type",
        "RPF check for outer tunnel IP header is enabled",
        "For untagged PTP packet and routedPort",
        "Strict or loose",
        "This port connect with a leaf node",
        "Priority tagged packet will be sent out",
        "Default cos of vlantag",
        "Default dei of vlantag",
        "NvGRE Mcast pacekt do not decapsulate",
        "VxLAN Mcast pacekt do not decapsulate",
        "Raw packet type",
        "Pvlan port type",
        "Qos trust policy",
        "auto neg",
        "link interrupt",
        "Timestamp",
        "Port linkscan function enable",
        "Aps failover enable",
        "Linkagg failover enable",
        "Scl key field select id",
        "Snooping parser",
        "If set,indicate tunnel packet will use outer header to do ACL/IPFIX flow lookup",
        "Entern enable",
        "nvgre enable",
        "Metadata overwrite port",
        "Metadata overwrite udf",
        "Src mismatch exception en",
        "Efd enable",
        "Add default vlan disable",
        "Logic port",
        "Aps select group id, 0xFFFFFFFF means disable aps select",
        "Aps select path, 0 means protecting path, else working path",
        "Mac error check",
        "Auto neg mode")
{
    int32 ret = 0;
    uint16 gport;
    uint32 value = FALSE;
    char* str = NULL;
    uint8 index = 0xFF;
    uint8 show_all = 0;
    ctc_port_restriction_t port_restrict;
    char mode_str[CTC_PORT_RESTRICTION_PORT_ISOLATION + 1][32] = {{"none"}, {"pvlan"}, {"port blocking"}, {"port isolation"}};
    char port_str[CTC_PORT_PVLAN_COMMUNITY + 1][32] = {{"none"}, {"promiscuous"}, {"isolated"}, {"community"}};

    sal_memset(&port_restrict, 0, sizeof(ctc_port_restriction_t));

    index = CTC_CLI_GET_ARGC_INDEX("all");
    if (index != 0xFF)
    {
        show_all = 1;
    }

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    ctc_cli_out("Show GPort                        :  0x%04x\n", gport);
    ctc_cli_out("-------------------------------------------\n");


    index = CTC_CLI_GET_ARGC_INDEX("route-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ROUTE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Route-enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("pkt-tag-high-priority");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PKT_TAG_HIGH_PRIORITY, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Pkt-tag-high-priority", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("hw-learn");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_HW_LEARN_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Hw-learn", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipv6-lookup");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_IPV6_LOOKUP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Ipv6-lookup", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipv4-lookup");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_IPV4_LOOKUP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Ipv4-lookup", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("use-default-lookup");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_USE_DEFAULT_LOOKUP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Use-default-lookup", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipv6-to-mac-key");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV6_TO_MAC, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Ipv6-to-mac-key", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipv4-to-mac-key");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_FORCE_IPV4_TO_MAC, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Ipv4-to-mac-key", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("trill");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_TRILL_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Trill", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("discard-non-tril");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DISCARD_NON_TRIL_PKT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Discard-non-tril", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("discard-tril");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DISCARD_TRIL_PKT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Discard-tril", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("reflective-bridge");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REFLECTIVE_BRIDGE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Reflective-bridge", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("fcoe");
    if (((index != 0xFF) && (sal_strlen("fcoe") == sal_strlen(argv[index]))) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FCOE_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Fcoe", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("fcoe-rpf");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FCOE_RPF_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Fcoe-rpf", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("replace-stag-cos");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_STAG_COS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Replace-stag-cos", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("replace-ctag-cos");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_CTAG_COS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Replace-ctag-cos", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("replace-dscp");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_REPLACE_DSCP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Replace-dscp", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("l3pdu-arp-action");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_L3PDU_ARP_ACTION, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "L3pdu-arp-action", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("l3pdu-dhcp-action");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_L3PDU_DHCP_ACTION, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "L3pdu-dhcp-action", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("tunnel-rpf-check");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_TUNNEL_RPF_CHECK, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Tunnel-rpf-check", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("ptp");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PTP_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Ptp", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("rpf-type");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_RPF_TYPE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Rpf-type", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-leaf");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_IS_LEAF, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Is-leaf", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("priority-tag");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_PRIORITY_TAG_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Priority-tag", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("default-pcp");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DEFAULT_PCP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Default-pcp", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("default-dei");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_DEFAULT_DEI, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Default-dei", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("nvgre-mcast-no-decap");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_NVGRE_MCAST_NO_DECAP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Nvgre-mcast-no-decap", value);
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("vxlan-mcast-no-decap");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_VXLAN_MCAST_NO_DECAP, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Vxlan-mcast-no-decap", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("scl-field-sel-id");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SCL_HASH_FIELD_SEL_ID, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Scl-field-sel-id", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("raw-packet-type");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_RAW_PKT_TYPE, &value);

        switch (value)
        {
        case CTC_PORT_RAW_PKT_ETHERNET:
            str = "ethernet";
            break;

        case CTC_PORT_RAW_PKT_IPV4:
            str = "ipv4";
            break;

        case CTC_PORT_RAW_PKT_IPV6:
            str = "ipv6";
            break;

        case CTC_PORT_RAW_PKT_NONE:
            str = "none";
            break;
        }

        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %s\n", "Raw-packet-type", str);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("pvlan-type");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_restriction(gport, &port_restrict);
        if ((ret >= 0) && (port_restrict.type == CTC_PORT_PVLAN_COMMUNITY) && (port_restrict.mode == CTC_PORT_RESTRICTION_PVLAN))
        {
            ctc_cli_out("%-34s:  %s\n", "Pvlan port type", port_str[port_restrict.type]);
            ctc_cli_out("%-34s:  %u\n", "Pvlan port isolated id", port_restrict.isolated_id);
        }
        else if ((ret >= 0) && (port_restrict.mode == CTC_PORT_RESTRICTION_PVLAN))
        {
            ctc_cli_out("%-34s:  %s\n", "Pvlan port type", port_str[port_restrict.type]);
            ctc_cli_out("This pvlan port can not have isolated id!\n");
        }
        else if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %s\n", "Port restriction type", mode_str[port_restrict.mode]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("qos-trust");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_QOS_POLICY, &value);

        switch (value)
        {
        case CTC_QOS_TRUST_PORT:
            str = "port";
            break;

        case CTC_QOS_TRUST_OUTER:
            str = "outer";
            break;

        case CTC_QOS_TRUST_COS:
            str = "cos";
            break;

        case CTC_QOS_TRUST_DSCP:
            str = "dscp";
            break;

        case CTC_QOS_TRUST_IP:
            str = "ip-prec";
            break;

        case CTC_QOS_TRUST_STAG_COS:
            str = "stag-cos";
            break;

        case CTC_QOS_TRUST_CTAG_COS:
            str = "ctag-cos";
            break;

        default:
            str = "unexpect!!!!!";
            break;

        }

        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %s\n", "Qos-trust", str);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("auto-neg");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_AUTO_NEG_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port auto-neg", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("link-intr");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINK_INTRRUPT_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port link change interrupt enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-ts");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_MAC_TS_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port mac time stamp", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("linkscan-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINKSCAN_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port linkscan enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("aps-failover");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_FAILOVER_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port aps failover enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("linkagg-failover");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LINKAGG_FAILOVER_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Port linkagg failover enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("snooping-parser");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SNOOPING_PARSER, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Snooping parser", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("flow-lkup-use-outer");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_FLOW_LKUP_BY_OUTER_HEAD, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Flow lkup use outer", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("extern-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_EXTERN_ENABLE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Extern enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("nvgre-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_NVGRE_ENABLE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Nvgre enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata-overwrite-port");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_PORT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Metadata overwrite port", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata-overwrite-udf");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_UDF, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Metadata overwrite udf", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("src-mismatch-exception-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_SRC_MISMATCH_EXCEPTION_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Src mismatch exception en", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("efd-en");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_EFD_EN, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Efd en", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("add-default-vlan-dis");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Add default vlan disable", value);
        }
    }


    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_LOGIC_PORT, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Logic port", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("aps-select-group");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_SELECT_GRP_ID, &value);
        if (ret >= 0)
        {
            if (0xFFFFFFFF == value)
            {
                ctc_cli_out("%-34s:  %s\n", "Aps select group", "disable");
            }
            else
            {
                ctc_cli_out("%-34s:  %u\n", "Aps select group", value);
            }
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("aps-select-working");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_APS_SELECT_WORKING, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Aps select working path", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("error-check");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_ERROR_CHECK, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Error check enable", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("auto-neg-mode");
    if ((index != 0xFF) || show_all)
    {
        ret = ctc_port_get_property(gport, CTC_PORT_PROP_AUTO_NEG_MODE, &value);
        if (ret >= 0)
        {
            ctc_cli_out("%-34s:  %u\n", "Auto neg mode", value);
        }
    }

    ctc_cli_out("------------------------------------------\n");

    if ((ret < 0) && (!show_all))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_dir_property,
        ctc_cli_port_set_dir_property_cmd,
        "port GPHYPORT_ID dir-property  \
        ( acl-en | acl-field-sel-id | acl-port-classid | acl-port-classid-0 | acl-port-classid-1 | acl-port-classid-2  \
        | acl-port-classid-3 | acl-ipv4-force-mac | acl-ipv6-force-mac | acl-force-use-ipv6 | acl-use-class \
        | service-acl-en | acl-hash-type | acl-tcam-type-0 | acl-tcam-type-1 | acl-tcam-type-2 | acl-tcam-type-3 \
        | acl-use-mapped-vlan | qos-domain | policer-valid \
        | stag-tpid-index | random-log-rate) direction (ingress|egress|both) value VALUE ",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Port property with direction",
        CTC_CLI_ACL_ENABLE_BITMAP,
        "Port acl hash field select id",
        "Port acl port classid",
        "Port acl port classid0",
        "Port acl port classid1",
        "Port acl port classid2",
        "Port acl port classid3",
        "Port acl ipv4-key force to mac-key",
        "Port acl ipv6-key force to mac-key",
        "Port acl force use ipv6",
        "Port acl use classid",
        "Port service acl enable",
        "Port acl hash type",
        "Port acl tcam type 0",
        "Port acl tcam type 1",
        "Port acl tcam type 2",
        "Port acl tcam type 3",
        "Acl use mapped vlan",
        "Port qos domain",
        "Port policer valid",
        "Svlan tpid index, the corresponding svlan tpid is in EpeL2TpidCtl",
        "Rate of random threshold,0-0x7fff",
        "Flow direction",
        "Ingress",
        "Egress",
        "Both direction",
        "Property value",
        "Value")
{
    uint8 index = 0;
    int32 ret = 0;
    uint16 gport = 0;
    uint32 value = 0;
    ctc_direction_t dir = CTC_INGRESS;
    uint32  prop = 0;

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);
    CTC_CLI_GET_UINT32("value", value, argv[argc - 1]);

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if (INDEX_VALID(index))
    {
        dir = CTC_INGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress");
    if (INDEX_VALID(index))
    {
        dir = CTC_EGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("both");
    if (INDEX_VALID(index))
    {
        dir = CTC_BOTH_DIRECTION;
    }

    if (CLI_CLI_STR_EQUAL("acl-en", 1))
    {
        prop = CTC_PORT_DIR_PROP_ACL_EN;
    }
    else if CLI_CLI_STR_EQUAL("acl-field-sel-id", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_HASH_FIELD_SEL_ID;
    }
    else if CTC_CLI_STR_EQUAL_ENHANCE("acl-port-classid", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_CLASSID;
    }
    else if CTC_CLI_STR_EQUAL_ENHANCE("acl-port-classid-0", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_CLASSID_0;
    }
    else if CTC_CLI_STR_EQUAL_ENHANCE("acl-port-classid-1", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_CLASSID_1;
    }
    else if CTC_CLI_STR_EQUAL_ENHANCE("acl-port-classid-2", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_CLASSID_2;
    }
    else if CTC_CLI_STR_EQUAL_ENHANCE("acl-port-classid-3", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_CLASSID_3;
    }
    else if CLI_CLI_STR_EQUAL("acl-ipv4-force-mac", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_IPV4_FORCE_MAC;
    }
    else if CLI_CLI_STR_EQUAL("acl-ipv6-force-mac", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_IPV6_FORCE_MAC;
    }
    else if CLI_CLI_STR_EQUAL("acl-force-use-ipv6", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_FORCE_USE_IPV6;
    }
    else if CLI_CLI_STR_EQUAL("acl-use-class", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_USE_CLASSID;
    }
    else if CLI_CLI_STR_EQUAL("service-acl-en", 1)
    {
        prop = CTC_PORT_DIR_PROP_SERVICE_ACL_EN;
    }
    else if CLI_CLI_STR_EQUAL("acl-hash-type", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_HASH_LKUP_TYPE;
    }
    else if CLI_CLI_STR_EQUAL("acl-tcam-type-0", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_0;
    }
    else if CLI_CLI_STR_EQUAL("acl-tcam-type-1", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_1;
    }
    else if CLI_CLI_STR_EQUAL("acl-tcam-type-2", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_2;
    }
    else if CLI_CLI_STR_EQUAL("acl-tcam-type-3", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_3;
    }
    else if CLI_CLI_STR_EQUAL("acl-use-mapped-vlan", 1)
    {
        prop = CTC_PORT_DIR_PROP_ACL_USE_MAPPED_VLAN;
    }
    else if (CLI_CLI_STR_EQUAL("qos-domain", 1))
    {
        prop = CTC_PORT_DIR_PROP_QOS_DOMAIN;
    }
    else if (CLI_CLI_STR_EQUAL("policer-valid", 1))
    {
        prop = CTC_PORT_DIR_PROP_PORT_POLICER_VALID;
    }
    else if (CLI_CLI_STR_EQUAL("stag-tpid-index", 1))
    {
        prop = CTC_PORT_DIR_PROP_STAG_TPID_INDEX;
    }
    else if (CLI_CLI_STR_EQUAL("random-log-rate", 1))
    {
        prop = CTC_PORT_DIR_PROP_RANDOM_LOG_RATE;
    }

    ret = ctc_port_set_direction_property(gport, prop, dir, value);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_show_port_dir_property,
        ctc_cli_port_show_port_dir_property_cmd,
        "show port GPHYPORT_ID dir-property (all \
        | acl-en | acl-field-sel-id | acl-port-classid | acl-port-classid-0 | acl-port-classid-1 | acl-port-classid-2 \
        | acl-port-classid-3 | acl-ipv4-force-mac | acl-ipv6-force-mac | acl-force-use-ipv6 | acl-use-class \
        | service-acl-en | acl-hash-type | acl-tcam-type-0 | acl-tcam-type-1 | acl-tcam-type-2 | acl-tcam-type-3 \
        | acl-use-mapped-vlan | qos-domain | policer-valid | stag-tpid-index | random-log-rate) \
        direction ( ingress | egress)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Property with direction",
        "All property",
        CTC_CLI_ACL_ENABLE_BITMAP,
        "Port acl hash field select id",
        "Port acl port classid",
        "Port acl port classid0",
        "Port acl port classid1",
        "Port acl port classid2",
        "Port acl port classid3",
        "Port acl ipv4-key force to mac-key",
        "Port acl ipv6-key force to mac-key",
        "Port acl force use ipv6",
        "Port acl use classid",
        "Port service acl enable",
        "Port acl hash type",
        "Port acl tcam type 0",
        "Port acl tcam type 1",
        "Port acl tcam type 2",
        "Port acl tcam type 3",
        "Acl use mapped vlan",
        "Port qos domain",
        "Port policer valid",
        "Svlan tpid index, the corresponding svlan tpid is in EpeL2TpidCtl",
        "Rate of random threshold,0-0x7fff",
        "Direction",
        "Ingress",
        "Egress")
{
    int32 ret = 0;
    uint16 gport;
    uint32 value;
    ctc_direction_t dir = 0;
    uint8 index = 0xFF;
    uint8 show_all = 0;

    index = CTC_CLI_GET_ARGC_INDEX("all");
    if (index != 0xFF)
    {
        show_all = 1;
    }

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    ctc_cli_out("==============================\n");

    if CLI_CLI_STR_EQUAL("in", 2)
    {
        dir = CTC_INGRESS;
        ctc_cli_out("Ingress:\n");
    }
    else if CLI_CLI_STR_EQUAL("eg", 2)
    {
        dir = CTC_EGRESS;
        ctc_cli_out("Egress:\n");
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-en");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-en             :  0x%x\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-field-sel-id");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_HASH_FIELD_SEL_ID, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-field-sel-id     :  0x%x\n", value);
        }
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-port-classid");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-port-classid   :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-port-classid-0");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID_0, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-port-classid-0   :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-port-classid-1");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID_1, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-port-classid-1   :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-port-classid-2");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID_2, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-port-classid-2   :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-port-classid-3");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID_3, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-port-classid-3   :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-ipv4-force-mac");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_IPV4_FORCE_MAC, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-ipv4-force-mac :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-ipv6-force-mac");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_IPV6_FORCE_MAC, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-ipv6-force-mac :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-force-use-ipv6");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_FORCE_USE_IPV6, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-force-use-ipv6 :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-use-class");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_USE_CLASSID, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-use-class      :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("service-acl-en");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_SERVICE_ACL_EN, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Service-acl-en     :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-hash-type");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_HASH_LKUP_TYPE, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-hash-type      :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-tcam-type-0");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_0, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-tcam-type-0    :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-tcam-type-1");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_1, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-tcam-type-1    :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-tcam-type-2");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_2, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-tcam-type-2    :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-tcam-type-3");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_3, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-tcam-type-3    :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("acl-use-mapped-vlan");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_ACL_USE_MAPPED_VLAN, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Acl-use-mapped-vlan:  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("qos-domain");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_QOS_DOMAIN, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Qos-domain         :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("policer-valid");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_PORT_POLICER_VALID, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Policer-valid      :  %d\n", value);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("stag-tpid-index");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_STAG_TPID_INDEX, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Stag-tpid-index      :  %d\n", value);
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("random-log-rate");
    if (INDEX_VALID(index) || show_all)
    {
        ret = ctc_port_get_direction_property(gport, CTC_PORT_DIR_PROP_RANDOM_LOG_RATE, dir, &value);
        if (ret >= 0)
        {
            ctc_cli_out("Random-log-rate      :  %d\n", value);
        }
    }

    ctc_cli_out("==============================\n");
    if ((ret < 0) && (!show_all))
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_scl_property,
        ctc_cli_port_set_scl_property_cmd,
        "port GPHYPORT_ID scl-key-type scl-id SCL_ID direction (ingress | egress) " \
        "type (cvid | svid | cvid-ccos | svid-scos | port | dvid | mac-sa | mac-da | ipv4 | ipv6| " \
        "ipsg-port-mac | ipsg-port-ip | ipsg-ipv6 | port-mac-da | l2 | ((tunnel-v6 | tunnel (auto|)) (rpf|)) | " \
        "nvgre | vxlan | vxlan-gpe | geneve | disable) (tcam-type (mac|ip|ip-single|vlan|tunnel|tunnel-rpf| disable) |) "\
        "((class-id CLASS_ID (hash-use-class-id|) | use-logic-port) |) (action-type (scl | flow | tunnel) |)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "SCL key type on port",
        "SCL id",
        CTC_CLI_SCL_ID_VALUE,
        "Direction",
        "Ingress",
        "Egress",
        "Hash Type",
        "Hash port cvlan",
        "Hash port svlan",
        "Hash port cvlan ccos",
        "Hash port svlan scos",
        "Hash port",
        "Hash port svlan cvlan",
        "Hash macsa",
        "Hash macda",
        "Hash ipsa",
        "Hash ipsa",
        "Hash port macsa",
        "Hash port ipsa",
        "Hash ipsa",
        "Hash port macda",
        "Hash l2",
        "IPv6 based IP tunnel only use tcam, layer3 tcam key",
        "IP tunnel for IPv4/IPv6 in IPv4, 6to4, ISATAP, GRE with/without key",
        "Auto tunnel, for 6to4, ISATAP, must use auto tunnel",
        "Rpf check for outer header only use tcam, if set, scl-id parameter must be 1",
        "NvGRE tunnel",
        "VxLAN tunnel",
        "VxLAN-GPE tunnel",
        "GENEVE tunnel",
        "Hash disable",
        "Tcam Type",
        "Tcam mac, layer2 tcam key",
        "Tcam ip, layer2/layer3 tcam key",
        "Tcam ip-single, layer3 tcam key",
        "Tcam vlan, vlan tcam key",
        "Tcam tunnel, tunnel tcam key",
        "Tcam tunnel rpf, tunnel rpf tcam key",
        "Tcam disable",
        "Class id",
        "<0-255>",
        "Hash lookup use class id",
        "Use logic port lookup",
        "Action type",
        "Normal SCL action",
        "Flow SCL action",
        "Tunnel Action")
{
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    uint8 index = 0xFF;
    ctc_port_scl_property_t port_scl_property;
    sal_memset(&port_scl_property, 0, sizeof(ctc_port_scl_property_t));

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT8_RANGE("scl id", port_scl_property.scl_id, argv[1], 0, CTC_MAX_UINT8_VALUE);

    index = 3; /* hash type*/
    if (CLI_CLI_STR_EQUAL("ingress", 2))
    {
        port_scl_property.direction = CTC_INGRESS;
        if (CLI_CLI_STR_EQUAL("dvid", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_2VLAN;
        }
        else if (CLI_CLI_STR_EQUAL("svid-scos", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_SVLAN_COS;
        }
        else if (CLI_CLI_STR_EQUAL("cvid-ccos", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_CVLAN_COS;
        }
        else if (CLI_CLI_STR_EQUAL("svid", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_SVLAN;
        }
        else if (CLI_CLI_STR_EQUAL("cvid", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_CVLAN;
        }
        else if (CLI_CLI_STR_EQUAL("mac-sa", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_MAC_SA;
        }
        else if (CLI_CLI_STR_EQUAL("mac-da", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_MAC_DA;
        }
        else if (CLI_CLI_STR_EQUAL("ipsg-port-mac", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_MAC_SA;
        }
        else if (CLI_CLI_STR_EQUAL("port-mac-da", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_MAC_DA;
        }
        else if (CLI_CLI_STR_EQUAL("ipv4", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_IP_SA;
        }
        else if (CLI_CLI_STR_EQUAL("ipv6", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_IP_SA;
        }
        else if (CLI_CLI_STR_EQUAL("ipsg-ipv6", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_IP_SA;
        }
        else if (CLI_CLI_STR_EQUAL("ipsg-port-ip", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_IP_SA;
        }
        else if (CLI_CLI_STR_EQUAL("l2", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_L2;
        }
        else if (CLI_CLI_STR_EQUAL("port", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT;
        }
        else if (CLI_CLI_STR_EQUAL("tunnel-v6", index))
        {
            if (0xFF != CTC_CLI_GET_ARGC_INDEX("rpf"))
            {
                port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_IP_SINGLE;
            }
            else
            {
                port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_IP_SINGLE;
            }

            port_scl_property.action_type = CTC_PORT_SCL_ACTION_TYPE_TUNNEL;
        }
        else if (CLI_CLI_STR_EQUAL("tunnel", index))
        {
            if (0xFF != CTC_CLI_GET_ARGC_INDEX("rpf"))
            {
                port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_TUNNEL_RPF;
            }
            else if (0xFF != CTC_CLI_GET_ARGC_INDEX("auto"))
            {
                port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_IPV4_TUNNEL_AUTO;
            }
            else
            {
                port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_TUNNEL;
            }

            port_scl_property.action_type= CTC_PORT_SCL_ACTION_TYPE_TUNNEL;
        }
        else if (CLI_CLI_STR_EQUAL("nvgre", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_NVGRE;
        }
        else if (CLI_CLI_STR_EQUAL("vxlan", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_VXLAN;
        }
        else if (CLI_CLI_STR_EQUAL("vxlan-gpe", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_VXLAN;
        }
        else if (CLI_CLI_STR_EQUAL("geneve", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_VXLAN;
        }
        else if (CLI_CLI_STR_EQUAL("disable", index))
        {
            port_scl_property.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_DISABLE;
        }
    }
    else if (CLI_CLI_STR_EQUAL("egress", 2))
    {
        port_scl_property.direction = CTC_EGRESS;
        if (CLI_CLI_STR_EQUAL("dvid", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT_2VLAN;
        }
        else if (CLI_CLI_STR_EQUAL("svid-scos", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT_SVLAN_COS;
        }
        else if (CLI_CLI_STR_EQUAL("cvid-ccos", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT_CVLAN_COS;
        }
        else if (CLI_CLI_STR_EQUAL("svid", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT_SVLAN;
        }
        else if (CLI_CLI_STR_EQUAL("cvid", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT_CVLAN;
        }
        else if (CLI_CLI_STR_EQUAL("port", index))
        {
            port_scl_property.hash_type = CTC_PORT_EGS_SCL_HASH_TYPE_PORT;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("tcam-type");
    if (INDEX_VALID(index))
    {
        index ++;
        if (CLI_CLI_STR_EQUAL("mac", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_MAC;
        }
        else if (CTC_CLI_STR_EQUAL_ENHANCE("ip", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_IP;
        }
        else if (CTC_CLI_STR_EQUAL_ENHANCE("ip-single", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_IP_SINGLE;
        }
        else if (CLI_CLI_STR_EQUAL("vlan", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_VLAN;
        }
        else if (CTC_CLI_STR_EQUAL_ENHANCE("tunnel", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_TUNNEL;
        }
        else if (CTC_CLI_STR_EQUAL_ENHANCE("tunnel-rpf", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_TUNNEL_RPF;
        }
        else if (CLI_CLI_STR_EQUAL("disable", index))
        {
            port_scl_property.tcam_type = CTC_PORT_IGS_SCL_TCAM_TYPE_DISABLE;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("class-id");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_UINT16("class id", port_scl_property.class_id, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("hash-use-class-id");
    if (INDEX_VALID(index))
    {
        port_scl_property.class_id_en = TRUE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("use-logic-port");
    if (INDEX_VALID(index))
    {
        port_scl_property.use_logic_port_en = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("action-type");
    if (INDEX_VALID(index))
    {
        index++;
        if (CLI_CLI_STR_EQUAL("scl", index))
        {
            port_scl_property.action_type = CTC_PORT_SCL_ACTION_TYPE_SCL;
        }
        else if (CTC_CLI_STR_EQUAL_ENHANCE("flow", index))
        {
            port_scl_property.action_type= CTC_PORT_SCL_ACTION_TYPE_FLOW;
        }
        else
        {
            port_scl_property.action_type= CTC_PORT_SCL_ACTION_TYPE_TUNNEL;
        }
    }

    ret = ctc_port_set_scl_property(gport, &port_scl_property);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

CTC_CLI(ctc_cli_port_set_auto_neg,
        ctc_cli_port_set_auto_neg_cmd,
        "port GPHYPORT_ID auto-neg (enable|disable)",
        CTC_CLI_PORT_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Auto-neg",
        "Enable",
        "Disable")
{
    int32 ret = CLI_SUCCESS;
    uint16 gport;
    uint32 value = 0;
    uint8 index = 0;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (index != 0xFF)
    {
        value = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("disable");
    if (index != 0xFF)
    {
        value = 0;
    }

    ret = ctc_port_set_auto_neg(gport, value);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_port_set_link_intr,
        ctc_cli_port_set_link_intr_cmd,
        "port GPHYPORT_ID mac link-intr (enable|disable)",
        CTC_CLI_INTR_M_STR,
        CTC_CLI_GPHYPORT_ID_DESC,
        "mac",
        "link change interrupt",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    int32 ret = CLI_SUCCESS;
    uint16 gport;
    uint32 value = 0;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    if (CLI_CLI_STR_EQUAL("enable", 1))
    {
        value = 1;
    }
    else
    {
        value = 0;
    }

    ret = ctc_port_set_link_intr(gport, value);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_show_port_cpu_mac_en,
        ctc_cli_show_port_cpu_mac_en_cmd,
        "show port cpumac enable",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PORT_M_STR,
        "cpu mac",
        "Enable")
{
    int32 ret = CLI_SUCCESS;
    bool enable = 0;

    ret = ctc_port_get_cpu_mac_en(&enable);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("cpu mac enable      :%d\n", enable);

    return ret;
}

int32
ctc_port_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_default_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_port_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_vlan_domain_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_receive_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_transmit_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_bridge_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_sub_if_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_phy_if_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_vlan_filtering_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_default_vlan_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_vlan_ctl_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_cross_connect_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_learning_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_stag_tpid_index_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_dot1q_type_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_untag_dft_vid_enable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_untag_dft_vid_disable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_protocol_vlan_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_vlan_mapping_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_vlan_classify_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_blocking_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_use_outer_ttl_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_mac_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_3ap_training_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_cpumac_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_all_mac_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_speed_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_flow_ctl_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_flow_ctl_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_preamble_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_min_frame_size_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_max_frame_size_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_stretch_mode_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_pading_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_random_log_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_random_threshold_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_srcdiscard_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_loopback_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_efm_lb_mode_enable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_efm_lb_mode_disable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_port_check_enable_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_ipg_index_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_isolation_id_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_reflective_bridge_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_mux_demux_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_internal_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_allocate_internal_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_release_internal_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_system_ipg_size_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_system_max_frame_size_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_port_set_system_port_mac_prefix_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_port_mac_postfix_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_port_mac_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_port_show_ipg_size_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_system_max_frame_size_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_port_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_debug_off_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_port_set_property_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_port_property_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_dir_property_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_show_port_dir_property_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_scl_property_cmd);
    //install_element(CTC_SDK_MODE, &ctc_cli_port_show_port_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_auto_neg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_show_port_cpu_mac_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_port_set_link_intr_cmd);

    return CLI_SUCCESS;
}

