/**
 @file ctc_humber_ipuc.c

 @date 2009-12-30

 @version v2.0


*/
/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "ctc_const.h"
#include "ctc_error.h"

#include "ctc_ipuc.h"
#include "sys_humber_ipuc.h"
#include "sys_humber_nexthop_api.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
/****************************************************************************
 *
* Function
*
*****************************************************************************/

int32
ctc_humber_ipuc_init(uint8 lchip, void* ipuc_global_cfg)
{
    return sys_humber_ipuc_init();
}

int32
ctc_humber_ipuc_add(uint8 lchip, ctc_ipuc_param_t* p_ipuc_param)
{
    return sys_humber_ipuc_add(p_ipuc_param);
}

int32
ctc_humber_ipuc_remove(uint8 lchip, ctc_ipuc_param_t* p_ipuc_param)
{
    return sys_humber_ipuc_remove(p_ipuc_param);
}

int32
ctc_humber_ipuc_add_default_entry(uint8 lchip, uint8 ip_ver, uint32 nh_id)
{
    return sys_humber_ipuc_add_default_entry(ip_ver, nh_id);
}

int32
ctc_humber_ipuc_add_tunnel(uint8 lchip, ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param)
{
    return sys_humber_ipuc_add_tunnel(p_ipuc_tunnel_param);
}

int32
ctc_humber_ipuc_remove_tunnel(uint8 lchip, ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param)
{
    return sys_humber_ipuc_remove_tunnel(p_ipuc_tunnel_param);
}

int32
ctc_humber_ipuc_ipv6_enable(uint8 lchip, bool enable)
{
    return CTC_E_NONE;
}

int32
ctc_humber_ipuc_cpu_rpf_check(uint8 lchip, bool enable)
{
    return sys_humber_ipuc_cpu_rpf_check(enable);
}

int32
ctc_humber_ipuc_set_route_ctl(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop)
{
    sys_humber_ipuc_set_route_ctl(p_global_prop);
    return CTC_E_NONE;
}

int32
ctc_humber_ipuc_set_lookup_ctl(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop)
{
    sys_humber_ipuc_set_lookup_ctl(p_global_prop);
    return CTC_E_NONE;
}

int32
ctc_humber_ipuc_set_global_property(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop)
{
    return sys_humber_ipuc_set_global_property(p_global_prop);
}

