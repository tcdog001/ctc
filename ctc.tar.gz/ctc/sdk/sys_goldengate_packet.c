/**
 @file ctc_goldengate_packet.c

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-11-25

 @version v2.0

 This file define sys functions

*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "ctc_error.h"
#include "ctc_macro.h"
#include "ctc_debug.h"
#include "ctc_packet.h"
#include "ctc_parser.h"
#include "ctc_oam.h"
#include "ctc_qos.h"
#include "ctc_crc.h"
#include "ctc_goldengate_packet.h"
#include "sys_goldengate_common.h"
#include "sys_goldengate_packet.h"
#include "sys_goldengate_packet_priv.h"
#include "sys_goldengate_dma.h"
#include "sys_goldengate_chip.h"
#include "sys_goldengate_vlan.h"

#include "sys_goldengate_nexthop_api.h"
#include "sys_goldengate_nexthop.h"
#include "sys_goldengate_stacking.h"

#include "drv_lib.h"
#include "drv_chip_ctrl.h"
#include "drv_chip_agent.h"

/****************************************************************************
*
* Defines and Macros
*
*****************************************************************************/
#define SYS_PACKET_ENCAP_LOOP_NHPTR(lport,ttl_valid) (((lport & 0x80) << 16) |(ttl_valid<<7)| (lport & 0x7F))
/****************************************************************************
*
* Global and Declaration
*
*****************************************************************************/
sys_pkt_master_t* p_pkt_master[CTC_MAX_LOCAL_CHIP_NUM] = {NULL};

extern char* sys_goldengate_reason_2Str(uint16 reason_id);

/****************************************************************************
*
* Function
*
*****************************************************************************/
static int32
_sys_goldengate_packet_dump(uint8 lchip, uint8* data, uint32 len)
{
    uint32 cnt = 0;
    char line[256] = {'\0'};
    char tmp[32] = {'\0'};

    if (0 == len)
    {
        return CTC_E_NONE;
    }

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt % 16) == 0)
        {
            if (cnt != 0)
            {
                SYS_PKT_DUMP("%s", line);
            }

            sal_memset(line, 0, sizeof(line));
            if (cnt == 0)
            {
                sal_sprintf(tmp, "0x%04x:  ", cnt);
            }
            else
            {
                sal_sprintf(tmp, "\n0x%04x:  ", cnt);
            }
            sal_strcat(line, tmp);
        }

        sal_sprintf(tmp, "%02x", data[cnt]);
        sal_strcat(line, tmp);

        if ((cnt % 2) == 1)
        {
            sal_strcat(line, " ");
        }
    }

    SYS_PKT_DUMP("%s", line);
    SYS_PKT_DUMP("\n");

    return CTC_E_NONE;
}

static int32
_sys_goldengate_packet_dump_header(uint8 lchip, ctc_pkt_rx_t  *p_rx_info)
{
    char* p_str_tmp = NULL;
    char str[40] = {0};

    SYS_PKT_DUMP("-----------------------------------------------\n");
    SYS_PKT_DUMP("Packet Header Raw Info(Length : %d): \n", CTC_PKT_HEADER_LEN);
    SYS_PKT_DUMP("-----------------------------------------------\n");

    p_str_tmp = sys_goldengate_reason_2Str(p_rx_info->rx_info.reason);
    sal_sprintf((char*)&str, "%s%s%d%s", p_str_tmp, "(ID:", p_rx_info->rx_info.reason, ")");

    SYS_PKT_DUMP("%-20s: %s\n", "cpu reason", (char*)&str);

    /*source*/
    SYS_PKT_DUMP("%-20s: 0x%.04x\n", "src port", p_rx_info->rx_info.src_port);
    SYS_PKT_DUMP("%-20s: %d\n", "src svid", p_rx_info->rx_info.src_svid);
    SYS_PKT_DUMP("%-20s: %d\n", "src cvid", p_rx_info->rx_info.src_cvid);
    SYS_PKT_DUMP("%-20s: %d\n", "src cos", p_rx_info->rx_info.src_cos);
    SYS_PKT_DUMP("%-20s: %d\n", "vrf", p_rx_info->rx_info.vrfid);
    SYS_PKT_DUMP("%-20s: %d\n", "fid", p_rx_info->rx_info.fid);
    SYS_PKT_DUMP("%-20s: %d\n", "ttl", p_rx_info->rx_info.ttl);
    SYS_PKT_DUMP("%-20s: %d\n", "priority", p_rx_info->rx_info.priority);
    SYS_PKT_DUMP("%-20s: %d\n", "color", p_rx_info->rx_info.color);
    SYS_PKT_DUMP("%-20s: %d\n", "hash value", p_rx_info->rx_info.hash);
    SYS_PKT_DUMP("%-20s: %d\n", "critical packet", p_rx_info->rx_info.is_critical);
    SYS_PKT_DUMP("%-20s: %d\n", "packet type", p_rx_info->rx_info.packet_type);
    SYS_PKT_DUMP("%-20s: %d\n", "payload offset", p_rx_info->rx_info.payload_offset);
    SYS_PKT_DUMP("%-20s: %d\n", "buffer log victim packet",CTC_FLAG_ISSET(p_rx_info->rx_info.flags, CTC_PKT_FLAG_BUFFER_VICTIM_PKT));
    SYS_PKT_DUMP("%-20s: %d\n", "operation type", p_rx_info->rx_info.oper_type);
    SYS_PKT_DUMP("%-20s: %d\n", "logic src port", p_rx_info->rx_info.logic_src_port);
    SYS_PKT_DUMP("%-20s: %d\n", "meta data", p_rx_info->rx_info.meta_data);
    SYS_PKT_DUMP("%-20s: %d\n", "mac unknown", CTC_FLAG_ISSET(p_rx_info->rx_info.flags, CTC_PKT_FLAG_UNKOWN_MACDA));

    if (p_rx_info->rx_info.oper_type == CTC_PKT_OPER_OAM)
    {
        SYS_PKT_DUMP("\n");
        SYS_PKT_DUMP("oam info:\n");
        SYS_PKT_DUMP("%-20s: %d\n", "oam type", p_rx_info->rx_info.oam.type);
        SYS_PKT_DUMP("%-20s: %d\n", "mep index", p_rx_info->rx_info.oam.mep_index);
    }

    if (p_rx_info->rx_info.oper_type == CTC_PKT_OPER_PTP)
    {
        SYS_PKT_DUMP("\n");
        SYS_PKT_DUMP("ptp info:\n");
        SYS_PKT_DUMP("%-20s: %d\n", "seconds", p_rx_info->rx_info.ptp.ts.seconds);
        SYS_PKT_DUMP("%-20s: %d\n", "nanoseconds", p_rx_info->rx_info.ptp.ts.nanoseconds);
    }

    if ((p_rx_info->pkt_buf) && (p_rx_info->pkt_buf[0].data))
    {
        SYS_PKT_DUMP("\n");
        CTC_ERROR_RETURN(_sys_goldengate_packet_dump(lchip, (p_rx_info->pkt_buf[0].data), CTC_PKT_HEADER_LEN));
    }

    SYS_PKT_DUMP("-----------------------------------------------\n");

    return CTC_E_NONE;
}


static inline int32
_sys_goldengate_packet_swap32(uint32* data, int32 len, uint32 hton)
{
    int32 cnt = 0;

    for (cnt = 0; cnt < len; cnt++)
    {
        if (hton)
        {
            data[cnt] = sal_htonl(data[cnt]);
        }
        else
        {
            data[cnt] = sal_ntohl(data[cnt]);
        }
    }

    return CTC_E_NONE;
}

char*
_sys_packet_mode_str(uint32 mode)
{
    switch (mode)
    {
    case CTC_PKT_MODE_DMA:
        return "DMA";

    case CTC_PKT_MODE_ETH:
        return "ETH";

    default:
        return "Invalid";
    }
}

static INLINE int32
_sys_goldengate_packet_bit62_to_ts(uint8 lchip, uint32 ns_only_format, uint64 ts_61_0, ctc_packet_ts_t* p_ts)
{
    if (ns_only_format)
    {
        /* [61:0] nano seconds */
        p_ts->seconds = ts_61_0 / 1000000000ULL;
        p_ts->nanoseconds = ts_61_0 % 1000000000ULL;
    }
    else
    {
        /* [61:30] seconds + [29:0] nano seconds */
        p_ts->seconds = (ts_61_0 >> 30) & 0xFFFFFFFFULL;
        p_ts->nanoseconds = ts_61_0 & 0x3FFFFFFFULL;
    }

    return CTC_E_NONE;
}

static INLINE int32
_sys_goldengate_packet_ts_to_bit62(uint8 lchip, uint32 ns_only_format, ctc_packet_ts_t* p_ts, uint64* p_ts_61_0)
{
    if (ns_only_format)
    {
        /* [61:0] nano seconds */
        *p_ts_61_0 = p_ts->seconds * 1000000000ULL + p_ts->nanoseconds;
    }
    else
    {
        /* [61:30] seconds + [29:0] nano seconds */
        *p_ts_61_0 = ((uint64)(p_ts->seconds) << 30) | ((uint64)p_ts->nanoseconds);
    }

    return CTC_E_NONE;
}




static int
_sys_godengate_dword_reverse_copy(uint32* dest, uint32* src, uint32 len)
{
    uint32 i = 0;
    for (i = 0; i < len; i++)
    {
        *(dest + i) = *(src + (len - i - 1));
    }
    return 0;
}

static int
_sys_godengate_byte_reverse_copy(uint8* dest, uint8* src, uint32 len)
{
    uint32 i = 0;
    for (i = 0; i < len; i++)
    {
        *(dest + i) = *(src + (len - 1 - i));
    }
    return 0;
}

static int32
_sys_goldengate_packet_rx_dump(uint8 lchip, ctc_pkt_rx_t* p_pkt_rx)
{
    uint32 len = 0;

    if (CTC_BMP_ISSET(p_pkt_master[lchip]->reason_bm, p_pkt_rx->rx_info.reason))
    {
        if (p_pkt_rx->pkt_len < CTC_PKT_HEADER_LEN)
        {
            SYS_PKT_DUMP("Packet length is too small!!!Pkt len: %d\n",p_pkt_rx->pkt_len);
            return CTC_E_EXCEED_MIN_SIZE;
        }

        if (p_pkt_master[lchip]->header_en[p_pkt_rx->rx_info.reason])
        {
            CTC_ERROR_RETURN(_sys_goldengate_packet_dump_header(lchip, p_pkt_rx));
        }

        if (p_pkt_rx->pkt_len - CTC_PKT_HEADER_LEN < SYS_PKT_BUF_PKT_LEN)
        {
            len = p_pkt_rx->pkt_len- CTC_PKT_HEADER_LEN;
        }
        else
        {
            len = SYS_PKT_BUF_PKT_LEN;
        }

        SYS_PKT_DUMP("\n-----------------------------------------------\n");
        SYS_PKT_DUMP("Packet Info(Length : %d):\n", (p_pkt_rx->pkt_len-CTC_PKT_HEADER_LEN));
        SYS_PKT_DUMP("-----------------------------------------------\n");
        CTC_ERROR_RETURN(_sys_goldengate_packet_dump(lchip, (p_pkt_rx->pkt_buf[0].data+CTC_PKT_HEADER_LEN), len));
    }

    return 0;
}

static int32
_sys_goldengate_packet_txinfo_to_rawhdr(uint8 lchip, ctc_pkt_tx_t* p_pkt_tx, uint32* p_raw_hdr_net)
{
    uint32 bheader[CTC_PKT_HEADER_LEN/4] = {0};
    uint32* p_raw_hdr              = bheader;
    uint32 dest_map                = 0;
    uint16 vlan_ptr                = 0;
    uint8* pkt_data                = NULL;
    uint8 gchip                    = 0;
    uint32 lport                   = 0;
    uint8 hash                     = 0;
    uint8 src_gchip                = 0;
    uint8 packet_type              = 0;
    uint8 priority                 = 0;
    uint8 color                    = 0;
    uint32 src_port                = 0;
    uint32 next_hop_ptr            = 0;
    uint32 ts_37_0_tmp[2]                 = {0};
    uint64 ts_37_0                 = 0;
    uint64 ts_61_38                = 0;
    uint64 ts_61_0                 = 0;
    uint32 offset_ns = 0;
    uint32 offset_s = 0;
    uint64 offset = 0;
    TsEngineOffsetAdj_m ptp_offset_adjust;
    drv_work_platform_type_t platform_type = MAX_WORK_PLATFORM;
    ctc_pkt_info_t* p_tx_info = NULL;

    sal_memset(&ptp_offset_adjust, 0, sizeof(ptp_offset_adjust));
    sal_memset(p_raw_hdr, 0, CTC_PKT_HEADER_LEN);
    p_tx_info = &p_pkt_tx->tx_info;

    if (p_tx_info->priority >= 64)
    {
        return CTC_E_INVALID_PARAM;
    }

    drv_get_platform_type(&platform_type);

    /* Must be inited */
    SetMsPacketHeader(V , packetType_f     , p_raw_hdr , p_tx_info->packet_type);
    SetMsPacketHeader(V , fromCpuOrOam_f   , p_raw_hdr , TRUE);
    SetMsPacketHeader(V , operationType_f  , p_raw_hdr , p_tx_info->oper_type);
    SetMsPacketHeader(V , criticalPacket_f , p_raw_hdr , p_tx_info->is_critical);
    SetMsPacketHeader(V , sourceCos_f      , p_raw_hdr , p_tx_info->src_cos);
    SetMsPacketHeader(V , ttl_f            , p_raw_hdr , p_tx_info->ttl);
    SetMsPacketHeader(V , macKnown_f       , p_raw_hdr , TRUE);
    SetMsPacketHeader(V , fid_f, p_raw_hdr , p_tx_info->fid);

    /*Set oamuse fid lookup */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_OAM_USE_FID))
    {
        SetMsPacketHeader(V, oamUseFid_f, p_raw_hdr, TRUE);
    }

   /*Set Vlan domain */
    if (p_tx_info->vlan_domain == CTC_PORT_VLAN_DOMAIN_SVLAN)
    {
        SetMsPacketHeader(V, outerVlanIsCVlan_f, p_raw_hdr, FALSE);
    }
    else  if (p_tx_info->vlan_domain == CTC_PORT_VLAN_DOMAIN_CVLAN)
    {
        SetMsPacketHeader(V, outerVlanIsCVlan_f, p_raw_hdr, TRUE);
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    /* Next_hop_ptr and DestMap*/
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_BYPASS))
    {
        /* GG Bypass NH is 8W  and egress edit mode*/
        SetMsPacketHeader(V, bypassIngressEdit_f, p_raw_hdr, TRUE);
        SetMsPacketHeader(V, nextHopExt_f, p_raw_hdr, TRUE);
        CTC_ERROR_RETURN(sys_goldengate_nh_get_resolved_offset(lchip, SYS_NH_RES_OFFSET_TYPE_BYPASS_NH, &next_hop_ptr));
    }
    else
    {
        if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_VALID))
        {
            next_hop_ptr = p_tx_info->nh_offset;
            if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_IS_8W))
            {
                SetMsPacketHeader(V, nextHopExt_f, p_raw_hdr, TRUE);
            }
        }
        else
        {
            /* GG Bridge NH is 4W */
            SetMsPacketHeader(V, nextHopExt_f, p_raw_hdr, FALSE);
            CTC_ERROR_RETURN(sys_goldengate_nh_get_resolved_offset(lchip, SYS_NH_RES_OFFSET_TYPE_BRIDGE_NH, &next_hop_ptr));
        }
    }

    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_MCAST))
    {
        dest_map = SYS_ENCODE_MCAST_NON_IPE_DESTMAP(p_tx_info->dest_group_id);
        next_hop_ptr = 0;
    }
    else
    {
        if (CTC_IS_LINKAGG_PORT(p_tx_info->dest_gport))
        {
            dest_map = SYS_ENCODE_DESTMAP(CTC_LINKAGG_CHIPID, p_tx_info->dest_gport&0xFF);
        }
        else
        {
            gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
            if (CTC_IS_CPU_PORT(p_tx_info->dest_gport))
            {
                dest_map = SYS_ENCODE_EXCP_DESTMAP(gchip, SYS_PKT_CPU_QDEST_BY_DMA);
            }
            else
            {
                dest_map = SYS_ENCODE_DESTMAP(gchip, SYS_MAP_CTC_GPORT_TO_DRV_LPORT(p_tx_info->dest_gport));
            }
        }
    }
    SetMsPacketHeader(V, destMap_f, p_raw_hdr, dest_map);
    SetMsPacketHeader(V, nextHopPtr_f, p_raw_hdr, next_hop_ptr);

    /* SrcPort */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_PORT_VALID))
    {
        src_port = p_tx_info->src_port;
    }
    else
    {
        sys_goldengate_get_gchip_id(lchip, &src_gchip);
        src_port = CTC_MAP_LPORT_TO_GPORT(src_gchip, SYS_RSV_PORT_OAM_CPU_ID);
    }
    src_port = SYS_MAP_CTC_GPORT_TO_DRV_GPORT(src_port);
    SetMsPacketHeader(V, sourcePort_f, p_raw_hdr, src_port);

    /* Svid */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID))
    {
        SetMsPacketHeader(V, srcVlanId_f, p_raw_hdr, p_tx_info->src_svid);
        SetMsPacketHeader(V, srcVlanPtr_f, p_raw_hdr, p_tx_info->src_svid);
        SetMsPacketHeader(V, stagAction_f, p_raw_hdr, CTC_VLAN_TAG_OP_ADD);
        SetMsPacketHeader(V, svlanTagOperationValid_f, p_raw_hdr, TRUE);
    }

    /* Cvid */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID))
    {
        SetMsPacketHeader(V, u1_normal_srcCvlanId_f, p_raw_hdr, p_tx_info->src_cvid);
        SetMsPacketHeader(V, srcVlanPtr_f, p_raw_hdr, p_tx_info->src_cvid);
        SetMsPacketHeader(V, u1_normal_cTagAction_f, p_raw_hdr, CTC_VLAN_TAG_OP_ADD);
        SetMsPacketHeader(V, u1_normal_cvlanTagOperationValid_f, p_raw_hdr, TRUE);
    }

    /* Linkagg Hash*/
    if (CTC_IS_LINKAGG_PORT(p_tx_info->dest_gport))
    {
        if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_HASH_VALID))
        {
            hash = p_tx_info->hash;
        }
        else
        {
            pkt_data = (uint8*)p_raw_hdr_net + CTC_PKT_HEADER_LEN;
            hash = ctc_crc_calculate_crc8(pkt_data, 12, 0);
        }
        SetMsPacketHeader(V, headerHash_f, p_raw_hdr, hash);
    }

    /* PHB priority + color */
    priority = (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_PRIORITY)) ? p_tx_info->priority : 63;
    SetMsPacketHeader(V, _priority_f, p_raw_hdr, priority);
    color = (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_PRIORITY)) ? p_tx_info->color : CTC_QOS_COLOR_GREEN;
    SetMsPacketHeader(V, color_f, p_raw_hdr, color);


    /* Iloop */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_INGRESS_MODE))
    {
        gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
        lport = SYS_MAP_CTC_GPORT_TO_DRV_LPORT(p_tx_info->dest_gport);
        /* dest_map is ILOOP */
        dest_map = SYS_ENCODE_DESTMAP(gchip, SYS_RSV_PORT_ILOOP_ID);
        dest_map = dest_map | (lport&0x100); /*sliceId*/
        SetMsPacketHeader(V, destMap_f, p_raw_hdr, dest_map);

        /* nexthop_ptr is lport */
        next_hop_ptr = SYS_PACKET_ENCAP_LOOP_NHPTR(lport, 0);;
        SetMsPacketHeader(V, nextHopPtr_f, p_raw_hdr, next_hop_ptr);
    }

 /* OAM Operation*/
    if (CTC_PKT_OPER_OAM == p_tx_info->oper_type)
    {
        SetMsPacketHeader(V, u1_oam_oamType_f, p_raw_hdr, p_tx_info->oam.type);
        SetMsPacketHeader(V, u1_oam_rxOam_f, p_raw_hdr, FALSE);
        SetMsPacketHeader(V, u1_oam_entropyLabelExist_f, p_raw_hdr, FALSE);
        SetMsPacketHeader(V, u1_oam_isEloopPkt_f, p_raw_hdr, FALSE);


        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM))
        {
            SetMsPacketHeader(V, u1_oam_dmEn_f, p_raw_hdr, TRUE);
            SetMsPacketHeader(V, u1_dmtx_dmOffset_f, p_raw_hdr, p_tx_info->oam.dm_ts_offset);
        }
        else
        {
            SetMsPacketHeader(V, u1_oam_dmEn_f, p_raw_hdr, FALSE);
        }

        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM))
        {
            SetMsPacketHeader(V, u1_oam_linkOam_f, p_raw_hdr, TRUE);
        }

        /* TPOAM Y.1731 Section need not append 13 label */
        if (CTC_OAM_TYPE_ACH == p_tx_info->oam.type)        {

            SetMsPacketHeader(V, u2_oam_mipEn_f, p_raw_hdr, TRUE);
            /* only ACH encapsulation need to change packet_type */
            if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL))
            {
                SetMsPacketHeader(V, u1_oam_galExist_f, p_raw_hdr, TRUE);
                packet_type = CTC_PARSER_PKT_TYPE_MPLS;
            }
            else
            {
                packet_type = CTC_PARSER_PKT_TYPE_RESERVED;
            }
            SetMsPacketHeader(V, packetType_f, p_raw_hdr, packet_type);
        }

        /* set for UP MEP */
        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP))
        {
            if (CTC_OAM_TYPE_ETH != p_tx_info->oam.type)
            {
                /* only Eth OAM support UP MEP */
                return CTC_E_INVALID_DIR;
            }

            SetMsPacketHeader(V, u1_oam_isUp_f, p_raw_hdr, TRUE);
            gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
            lport = SYS_MAP_CTC_GPORT_TO_DRV_LPORT(p_tx_info->dest_gport);
            /* dest_map is ILOOP */
            dest_map = SYS_ENCODE_DESTMAP(gchip, SYS_RSV_PORT_ILOOP_ID);
            dest_map = dest_map | (lport&0x100);/*SliceId*/
            SetMsPacketHeader(V, destMap_f, p_raw_hdr, dest_map);

            next_hop_ptr = SYS_PACKET_ENCAP_LOOP_NHPTR(lport, (p_tx_info->ttl != 0));
            SetMsPacketHeader(V, nextHopPtr_f, p_raw_hdr, next_hop_ptr);

            /* src vlan_ptr is vlan_ptr by vid */
            sys_goldengate_vlan_get_vlan_ptr(lchip, p_tx_info->oam.vid, &vlan_ptr);
            SetMsPacketHeader(V, srcVlanPtr_f, p_raw_hdr, vlan_ptr);

        }

        /* set bypass MIP port */
        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_TX_MIP_TUNNEL))
        {
            /* bypass OAM packet to MIP configured port; otherwise, packet will send to CPU again */
            SetMsPacketHeader(V, u1_oam_oamType_f, p_raw_hdr, CTC_OAM_TYPE_NONE);
            SetMsPacketHeader(V, oamTunnelEn_f, p_raw_hdr, TRUE);
        }
    }
    else if (CTC_PKT_OPER_PTP == p_tx_info->oper_type)
    {
        /* 7. get PTP */
        /*  DM Timestamp Bits Mapping
            Timestamp               Field Name          BIT Width   BIT Base
            dmTimestamp[37:0]       timestamp           38          0
            dmTimestamp[61:38]      u3_other_timestamp  24          38
         */
        _sys_goldengate_packet_ts_to_bit62(lchip, TRUE, &p_tx_info->ptp.ts, &ts_61_0);

        if (CTC_PTP_CORRECTION == p_tx_info->ptp.oper)
        {
            GetTsEngineOffsetAdj(A, offsetNs_f, &ptp_offset_adjust, &offset_ns);
            GetTsEngineOffsetAdj(A, offsetSecond_f, &ptp_offset_adjust, &offset_s);
            offset = offset_s * 1000000000ULL + offset_ns;
            if (ts_61_0 >= offset)
            {
                ts_61_0 = ts_61_0 -offset;
            }
            else
            {
                return CTC_E_INVALID_PARAM;
            }
        }

        ts_37_0 = ts_61_0 & 0x3FFFFFFFFFULL;
        ts_37_0_tmp[0] = (uint32)ts_37_0;
        ts_37_0_tmp[1] = (ts_37_0 >> 32);
        ts_61_38 = (ts_61_0 >> 38) & 0xFFFFFFULL;
        SetMsPacketHeader(A, timestamp_f, p_raw_hdr, &ts_37_0_tmp);
        SetMsPacketHeader(V, u3_other_timestamp_f, p_raw_hdr, ts_61_38);

        if (CTC_PTP_CAPTURE_ONLY == p_tx_info->ptp.oper)
        {
            SetMsPacketHeader(V, u1_ptp_ptpCaptureTimestamp_f, p_raw_hdr, TRUE);
            SetMsPacketHeader(V, u1_ptp_ptpSequenceId_f, p_raw_hdr, p_tx_info->ptp.seq_id);
        }
        else if (CTC_PTP_REPLACE_ONLY == p_tx_info->ptp.oper)
        {
            SetMsPacketHeader(V, u1_ptp_ptpReplaceTimestamp_f, p_raw_hdr, TRUE);
            SetMsPacketHeader(V, u1_ptp_ptpOffset_f, p_raw_hdr, p_tx_info->ptp.ts_offset);
        }
        else if (CTC_PTP_CORRECTION == p_tx_info->ptp.oper)
        {
            SetMsPacketHeader(V, u1_ptp_ptpReplaceTimestamp_f, p_raw_hdr, TRUE);
            SetMsPacketHeader(V, u1_ptp_ptpUpdateResidenceTime_f, p_raw_hdr, TRUE);
            SetMsPacketHeader(V, u1_ptp_ptpOffset_f, p_raw_hdr, p_tx_info->ptp.ts_offset);
        }
        else
        {
            /* CTC_PTP_NULL_OPERATION */
        }
    }
    else if (CTC_PKT_OPER_C2C == p_tx_info->oper_type)
    {
        SetMsPacketHeader(V, bypassIngressEdit_f, p_raw_hdr, 1);
        SetMsPacketHeader(V, u1_c2c_c2cCheckDisable_f, p_raw_hdr, 0);
    }

    if(CTC_PKT_MODE_ETH == p_pkt_tx->mode)
    {
        /*6bytes MACDA + 6 bytes MACSA + 4 bytes VLAN Tag + 2 bytes EtherType + 40 bytes bridge header*/
        SetMsPacketHeader(V, packetOffset_f, p_raw_hdr, 58);
    }


    if (platform_type == HW_PLATFORM)
    {
        CTC_ERROR_RETURN(_sys_godengate_dword_reverse_copy(p_raw_hdr_net, p_raw_hdr, CTC_PKT_HEADER_LEN/4));
        CTC_ERROR_RETURN(_sys_goldengate_packet_swap32((uint32*)p_raw_hdr_net, CTC_PKT_HEADER_LEN / 4, FALSE))
    }
    else
    {
        CTC_ERROR_RETURN(_sys_godengate_byte_reverse_copy((uint8*)p_raw_hdr_net, (uint8*)p_raw_hdr, CTC_PKT_HEADER_LEN));
    }

    return CTC_E_NONE;
}


static int32
_sys_goldengate_packet_rawhdr_to_rxinfo(uint8 lchip, uint32* p_raw_hdr_net, ctc_pkt_rx_t* p_pkt_rx)
{
    uint32 bheader[CTC_PKT_HEADER_LEN/4] = {0};
    uint32* p_raw_hdr = bheader;
    uint32 dest_map                = 0;
    uint64 ts_37_0                 = 0;
    uint64 ts_61_38                = 0;
    uint64 ts_61_0                 = 0;
    uint32 ts_37_0_tmp[2]                 = {0};
    uint32 ns_only_format          = FALSE;
    uint8 gchip                    = 0;
    uint16 lport                   = 0;
    uint32 src_port                = 0;
    uint32 next_hop_ptr            = 0;
    ctc_pkt_info_t* p_rx_info      = NULL;
    uint32 offset_ns = 0;
    uint32 offset_s = 0;
    TsEngineOffsetAdj_m ptp_offset_adjust;

    p_rx_info = &p_pkt_rx->rx_info;

    CTC_ERROR_RETURN(_sys_godengate_dword_reverse_copy((uint32*)bheader, (uint32*)p_raw_hdr_net, CTC_PKT_HEADER_LEN/4));
    CTC_ERROR_RETURN(_sys_goldengate_packet_swap32((uint32*)p_raw_hdr, CTC_PKT_HEADER_LEN / 4, FALSE));

    sal_memset(p_rx_info, 0, sizeof(ctc_pkt_info_t));
    sal_memset(&ptp_offset_adjust, 0, sizeof(ptp_offset_adjust));

    /* Must be inited */
    p_rx_info->packet_type    = GetMsPacketHeader(V, packetType_f, p_raw_hdr);
    p_rx_info->oper_type      = GetMsPacketHeader(V, operationType_f, p_raw_hdr);
    p_rx_info->priority       = GetMsPacketHeader(V, _priority_f, p_raw_hdr);
    p_rx_info->color          = GetMsPacketHeader(V, color_f, p_raw_hdr);
    p_rx_info->src_cos        = GetMsPacketHeader(V, sourceCos_f, p_raw_hdr);
    p_rx_info->fid          = GetMsPacketHeader(V, fid_f, p_raw_hdr);
    p_rx_info->payload_offset = GetMsPacketHeader(V, packetOffset_f, p_raw_hdr);
    p_rx_info->ttl            = GetMsPacketHeader(V, ttl_f, p_raw_hdr);
    p_rx_info->is_critical    = GetMsPacketHeader(V, criticalPacket_f, p_raw_hdr);
    p_rx_info->logic_src_port  = GetMsPacketHeader(V, logicSrcPort_f, p_raw_hdr);

    if (!GetMsPacketHeader(V, macKnown_f, p_raw_hdr))
    {
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_UNKOWN_MACDA);
    }

    if (GetMsPacketHeader(V, u1_normal_metadataType_f, p_raw_hdr) == 0x01)
    {
        /*meta*/
        p_rx_info->meta_data= GetMsPacketHeader(V, u1_normal_metadata_f, p_raw_hdr);
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_METADATA_VALID);
    }
    else if (GetMsPacketHeader(V, u1_normal_metadataType_f, p_raw_hdr) == 0)
    {
        /*vrfid*/
        p_rx_info->vrfid= GetMsPacketHeader(V, u1_normal_metadata_f, p_raw_hdr);
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_VRFID_VALID);
    }

    src_port                  = GetMsPacketHeader(V, sourcePort_f, p_raw_hdr);
    if (SYS_DRV_IS_LINKAGG_PORT(src_port))
    {
        p_rx_info->src_chip = ((src_port >> 11) & 0x18 ) | ((src_port >> 6) & 0x07);
        p_rx_info->src_port = (src_port & 0x3E3F);  /* clear 0xC1C0 for chipId */
    }
    else
    {
        p_rx_info->src_chip = SYS_DRV_GPORT_TO_GCHIP(src_port);
        p_rx_info->src_port = src_port;
    }

    p_rx_info->src_port = SYS_MAP_DRV_GPORT_TO_CTC_GPORT(p_rx_info->src_port);

    /* RX Reason from next_hop_ptr */
    next_hop_ptr = GetMsPacketHeader(V, nextHopPtr_f, p_raw_hdr);
    p_rx_info->reason = CTC_PKT_CPU_REASON_GET_BY_NHPTR(next_hop_ptr);

    /* DestMap */
    dest_map = GetMsPacketHeader(V, destMap_f, p_raw_hdr);
    if (CTC_IS_BIT_SET(dest_map, 17))
    {
        /* { mcast(1'b1), 1'b0, mcastGroupId[15:0] } */
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_MCAST);
        p_rx_info->dest_group_id = (dest_map & 0xFFFF);
    }
    else
    {
        /* { mcast(1'b0), destChipId[4:0], queueSelType[2:0], destId[8:0] } */
        gchip = (dest_map >> 12) & 0x1F;
        lport = (dest_map & 0x1FF);
        p_rx_info->dest_gport = SYS_MAP_DRV_LPORT_TO_CTC_GPORT(gchip, lport);
    }

    /* Source svlan */
    p_rx_info->src_svid = GetMsPacketHeader(V, srcVlanId_f, p_raw_hdr);
    if (p_rx_info->src_svid)
    {
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
    }

    /* Source cvlan */
    if (CTC_PKT_OPER_NORMAL == p_rx_info->oper_type)
    {
        p_rx_info->src_cvid = GetMsPacketHeader(V, u1_normal_srcCvlanId_f, p_raw_hdr);
        if (p_rx_info->src_cvid)
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID);
        }
    }

    /* OAM */
    if (CTC_PKT_OPER_OAM == p_rx_info->oper_type)
    {
        p_rx_info->oam.type = GetMsPacketHeader(V, u1_oam_oamType_f, p_raw_hdr);
        p_rx_info->oam.mep_index = GetMsPacketHeader(V, u1_oam_mepIndex_f, p_raw_hdr);

        if (GetMsPacketHeader(V, u1_oam_isUp_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP);
        }

        if (GetMsPacketHeader(V, u1_oam_lmReceivedPacket_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_LM);
        }

        if (GetMsPacketHeader(V, u1_oam_linkOam_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM);
        }

        if (GetMsPacketHeader(V, u1_oam_dmEn_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM);
        }

        if (GetMsPacketHeader(V, u1_oam_galExist_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL);
        }

        if (GetMsPacketHeader(V, u2_oam_mipEn_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_MIP);
        }

        /* get timestamp offset in bytes for DM */
        if (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM))
        {
            /*  DM Timestamp Bits Mapping
                Timestamp               Field Name          BIT Width   BIT Base
                dmTimestamp[37:0]       timestamp           38          0
                dmTimestamp[61:38]      u3_other_timestamp  24          38
             */
            GetMsPacketHeader(A, timestamp_f, p_raw_hdr, &ts_37_0_tmp);
            ts_37_0 = ts_37_0_tmp[1];
            ts_37_0 <<= 32;
            ts_37_0 |= ts_37_0_tmp[0];

            ts_61_38 = GetMsPacketHeader(V, u3_other_timestamp_f, p_raw_hdr);

            ts_61_0 = ((uint64)(ts_37_0) << 0)
                    | ((uint64)(ts_61_38) << 38);
            ns_only_format = FALSE;
            _sys_goldengate_packet_bit62_to_ts(lchip, ns_only_format, ts_61_0, &p_rx_info->oam.dm_ts);
        }

        if (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_LM))
        {
            p_rx_info->oam.lm_fcl = GetMsPacketHeader(V, u3_oam_rxtxFcl_f, p_raw_hdr);
            p_rx_info->oam.lm_fcl = (p_rx_info->oam.lm_fcl << 8) + GetMsPacketHeader(V, u1_oam_rxtxFcl_f, p_raw_hdr);
        }

        /* get svid from vlan_ptr for Up MEP/Up MIP */
        if (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP))
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
            p_rx_info->src_svid = GetMsPacketHeader(V, srcVlanPtr_f, p_raw_hdr);
        }
    }
    else if (CTC_PKT_CPU_REASON_PTP == p_rx_info->reason)
    {
        /* PTP */
        /*  DM Timestamp Bits Mapping
            Timestamp               Field Name          BIT Width   BIT Base
            dmTimestamp[37:0]       timestamp           38          0
            dmTimestamp[61:38]      u3_other_timestamp  24          38
         */
        GetMsPacketHeader(A, timestamp_f, p_raw_hdr, &ts_37_0_tmp);
        ts_37_0 = ts_37_0_tmp[1];
        ts_37_0 <<= 32;
        ts_37_0 |= ts_37_0_tmp[0];
        ts_61_38 = GetMsPacketHeader(V, u3_other_timestamp_f, p_raw_hdr);

        ts_61_0 = ((uint64)(ts_37_0) << 0)
                | ((uint64)(ts_61_38) << 38);

        GetTsEngineOffsetAdj(A, offsetNs_f, &ptp_offset_adjust, &offset_ns);
        GetTsEngineOffsetAdj(A, offsetSecond_f, &ptp_offset_adjust, &offset_s);
        ts_61_0 = ts_61_0 + offset_s * 1000000000ULL + offset_ns;
        _sys_goldengate_packet_bit62_to_ts(lchip, TRUE, ts_61_0, &p_rx_info->ptp.ts);
    }
    else if (CTC_PKT_OPER_C2C == p_rx_info->oper_type)
    {
        /* Stacking*/
        p_rx_info->reason       = CTC_PKT_CPU_REASON_FWD_CPU;
        p_rx_info->src_port     = GetMsPacketHeader(V, u1_c2c_stackingSrcPort_f, p_raw_hdr);
        p_rx_info->src_port     = SYS_MAP_DRV_GPORT_TO_CTC_GPORT(p_rx_info->src_port);

        if (CTC_FLAG_ISSET(p_rx_info->flags, CTC_PKT_FLAG_MCAST))
        {
            CTC_UNSET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_MCAST);
            p_rx_info->dest_group_id = 0;
        }
        p_rx_info->vrfid = 0;
    }

    if (p_rx_info->reason == CTC_PKT_CPU_REASON_MONITOR_BUFFER_LOG)
    {
        if (GetMsPacketHeader(V, sourceCfi_f, p_raw_hdr))
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_BUFFER_VICTIM_PKT);
        }
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_rx(uint8 lchip, ctc_pkt_rx_t* p_pkt_rx)
{
    int32 ret = 0;

    ret = (sys_goldengate_packet_decap(lchip, p_pkt_rx));
    if (ret < 0)
    {
        SYS_PKT_DUMP("packet decap Error!ret:%d\n", ret);
       // return ret;
    }

    if (p_pkt_rx->rx_info.reason < CTC_PKT_CPU_REASON_MAX_COUNT)
    {
        p_pkt_master[lchip]->stats.rx[p_pkt_rx->rx_info.reason]++;
    }

    _sys_goldengate_packet_rx_dump(lchip, p_pkt_rx);

    if ((p_pkt_rx->rx_info.reason - CTC_PKT_CPU_REASON_OAM) == CTC_OAM_EXCP_LEARNING_BFD_TO_CPU)
    {
        if (p_pkt_master[lchip]->oam_rx_cb)
        {
            p_pkt_master[lchip]->oam_rx_cb(lchip, p_pkt_rx);
        }
    }

    if (p_pkt_master[lchip]->cfg.rx_cb)
    {
        p_pkt_master[lchip]->cfg.rx_cb(p_pkt_rx);
    }

    if (p_pkt_master[lchip]->buf_id  < SYS_PKT_BUF_MAX)
    {
        p_pkt_master[lchip]->pkt_buf[p_pkt_master[lchip]->buf_id].pkt_len = p_pkt_rx->pkt_len;

        if (p_pkt_rx->pkt_buf->len <= SYS_PKT_BUF_PKT_LEN)
        {
            sal_memcpy(p_pkt_master[lchip]->pkt_buf[p_pkt_master[lchip]->buf_id].pkt_data,
                       p_pkt_rx->pkt_buf->data,
                       p_pkt_rx->pkt_buf->len);
        }

        p_pkt_master[lchip]->buf_id++;
        if (p_pkt_master[lchip]->buf_id == SYS_PKT_BUF_MAX)
        {
            p_pkt_master[lchip]->buf_id = 0;
        }

    }

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_tx(uint8 lchip, ctc_pkt_tx_t* p_pkt_tx)
{

    CTC_PTR_VALID_CHECK(p_pkt_tx);
    p_pkt_tx->lchip = lchip;

    if (p_pkt_tx->mode > CTC_PKT_MODE_ETH)
    {
        return CTC_E_INTR_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(sys_goldengate_packet_encap(lchip, p_pkt_tx));

    if (CTC_PKT_MODE_ETH == p_pkt_tx->mode)
    {
        if (p_pkt_master[lchip]->cfg.socket_tx_cb )
        {
            p_pkt_master[lchip]->cfg.socket_tx_cb(p_pkt_tx);
        }
        else
        {
            SYS_PKT_DUMP("Do not support Socket Tx!\n");
            return CTC_E_UNEXPECT;
        }
    }
    else if (CTC_PKT_MODE_DMA == p_pkt_tx->mode)
    {
        if (p_pkt_master[lchip]->cfg.dma_tx_cb )
        {
            CTC_ERROR_RETURN(p_pkt_master[lchip]->cfg.dma_tx_cb(p_pkt_tx));
        }
        else
        {
            SYS_PKT_DUMP("Do not support Dma Tx!\n");
            return CTC_E_UNEXPECT;
        }
    }

    if (CTC_FLAG_ISSET(p_pkt_tx->tx_info.flags, CTC_PKT_FLAG_MCAST))
    {
         p_pkt_master[lchip]->stats.mc_tx++;
    }
    else
    {
         p_pkt_master[lchip]->stats.uc_tx++;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_encap(uint8 lchip, ctc_pkt_tx_t* p_pkt_tx)
{
    ms_packet_header_t* p_raw_hdr = NULL;
    sys_goldengate_cpumac_header_t* p_cpumac_hdr = NULL;
    uint32 cmd = 0;
    IpeHeaderAdjustCtl_m ipe_header_adjust_ctl;
    uint16 tpid = 0;

    CTC_PTR_VALID_CHECK(p_pkt_tx);

    SYS_PKT_DBG_FUNC();

    /* 1. encode packet header */
    p_raw_hdr = (ms_packet_header_t*)ctc_packet_skb_push(&p_pkt_tx->skb, CTC_PKT_HEADER_LEN);

    CTC_ERROR_RETURN(_sys_goldengate_packet_txinfo_to_rawhdr(lchip, p_pkt_tx, (uint32*)p_raw_hdr));

    if (CTC_PKT_MODE_ETH == p_pkt_tx->mode)
    {
        cmd = DRV_IOR(IpeHeaderAdjustCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_header_adjust_ctl));

        tpid = GetIpeHeaderAdjustCtl(V, headerTpid_f, &ipe_header_adjust_ctl);

        /* 2. encode CPUMAC Header */
        p_cpumac_hdr = (sys_goldengate_cpumac_header_t*)ctc_packet_skb_push(&p_pkt_tx->skb, CTC_PKT_CPUMAC_LEN);
        p_cpumac_hdr->macda[0] = p_pkt_master[lchip]->cpu_mac_sa[0];
        p_cpumac_hdr->macda[1] = p_pkt_master[lchip]->cpu_mac_sa[1];
        p_cpumac_hdr->macda[2] = p_pkt_master[lchip]->cpu_mac_sa[2];
        p_cpumac_hdr->macda[3] = p_pkt_master[lchip]->cpu_mac_sa[3];
        p_cpumac_hdr->macda[4] = p_pkt_master[lchip]->cpu_mac_sa[4];
        p_cpumac_hdr->macda[5] = p_pkt_master[lchip]->cpu_mac_sa[5];
        p_cpumac_hdr->macsa[0] = p_pkt_master[lchip]->cpu_mac_da[0];
        p_cpumac_hdr->macsa[1] = p_pkt_master[lchip]->cpu_mac_da[1];
        p_cpumac_hdr->macsa[2] = p_pkt_master[lchip]->cpu_mac_da[2];
        p_cpumac_hdr->macsa[3] = p_pkt_master[lchip]->cpu_mac_da[3];
        p_cpumac_hdr->macsa[4] = p_pkt_master[lchip]->cpu_mac_da[4];
        p_cpumac_hdr->macsa[5] = p_pkt_master[lchip]->cpu_mac_da[5];
        p_cpumac_hdr->vlan_tpid = sal_htons(tpid);
        p_cpumac_hdr->vlan_vid = sal_htons(0x23);
        p_cpumac_hdr->type = sal_htons(0x5A5A);
    }

    /* add stats */
    p_pkt_master[lchip]->stats.encap++;

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_decap(uint8 lchip, ctc_pkt_rx_t* p_pkt_rx)
{
    ds_t raw_hdr;
    ds_t* p_raw_hdr = &raw_hdr;
    uint16 eth_hdr_len = 0;
    uint16 pkt_hdr_len = 0;
    uint16 stk_hdr_len = 0;

    CTC_PTR_VALID_CHECK(p_pkt_rx);

    SYS_PKT_DBG_FUNC();
    SYS_PKT_DBG_INFO("len %d, buf_count %d \n", p_pkt_rx->pkt_len,
                     p_pkt_rx->buf_count);

    /* 1. check packet length */
    /* ethernet has 20 Bytes L2 header */
    if (CTC_PKT_MODE_ETH == p_pkt_rx->mode)
    {
        eth_hdr_len = CTC_PKT_CPUMAC_LEN;
    }
    else
    {
        eth_hdr_len = 0;
    }

    pkt_hdr_len = CTC_PKT_HEADER_LEN;

    if (p_pkt_rx->pkt_len < (eth_hdr_len + pkt_hdr_len))
    {
        return DRV_E_WRONG_SIZE;
    }

    if (p_pkt_rx->pkt_buf[0].len < (eth_hdr_len + pkt_hdr_len))
    {
        return DRV_E_WRONG_SIZE;
    }

    p_pkt_rx->eth_hdr_len = eth_hdr_len;
    p_pkt_rx->pkt_hdr_len = pkt_hdr_len;
    /* 2. decode raw header */
    sal_memcpy(p_raw_hdr, p_pkt_rx->pkt_buf[0].data + eth_hdr_len, CTC_PKT_HEADER_LEN);

    /* 3. convert raw header to rx_info */
    CTC_ERROR_RETURN(_sys_goldengate_packet_rawhdr_to_rxinfo(lchip, (uint32*)p_raw_hdr, p_pkt_rx));

    CTC_ERROR_RETURN(sys_goldengate_stacking_get_stkhdr_len(lchip, p_pkt_rx->rx_info.src_port, p_pkt_rx->rx_info.src_chip, &stk_hdr_len));
    p_pkt_rx->stk_hdr_len = stk_hdr_len;

    /* add stats */
    p_pkt_master[lchip]->stats.decap++;

    return CTC_E_NONE;
}

/**
 @brief Display packet
*/
int32
sys_goldengate_packet_stats_dump(uint8 lchip)
{
    uint16 idx = 0;
    uint32 rx = 0;
    char* p_str_tmp = NULL;
    char str[40] = {0};
    uint32 reason_cnt = 0;

    if (p_pkt_master[lchip] == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PKT_DUMP("Packet Tx Statistics:\n");
    SYS_PKT_DUMP("------------------------------\n");
    SYS_PKT_DUMP("%-20s: %d \n", "Total TX Count", (p_pkt_master[lchip]->stats.uc_tx+p_pkt_master[lchip]->stats.mc_tx));

    if ((p_pkt_master[lchip]->stats.uc_tx) || (p_pkt_master[lchip]->stats.mc_tx))
    {
        SYS_PKT_DUMP("--%-18s: %d \n", "Uc Count", p_pkt_master[lchip]->stats.uc_tx);
        SYS_PKT_DUMP("--%-18s: %d \n", "Mc Count", p_pkt_master[lchip]->stats.mc_tx);
    }

    SYS_PKT_DUMP("\n");

    for (idx  = 0; idx  < CTC_PKT_CPU_REASON_MAX_COUNT; idx ++)
    {
        rx += p_pkt_master[lchip]->stats.rx[idx];
    }

    SYS_PKT_DUMP("Packet Rx Statistics:\n");
    SYS_PKT_DUMP("------------------------------\n");
    SYS_PKT_DUMP("%-20s: %d \n", "Total RX Count", rx);
    SYS_PKT_DUMP("\n");
    SYS_PKT_DUMP("%-20s\n", "Detail RX Count");

    if (rx)
    {
        for (idx  = 0; idx  < CTC_PKT_CPU_REASON_MAX_COUNT; idx ++)
        {
            reason_cnt = p_pkt_master[lchip]->stats.rx[idx];

            if (reason_cnt)
            {
                p_str_tmp = sys_goldengate_reason_2Str(idx);
                sal_sprintf((char*)&str, "%s%s%d%s", p_str_tmp, "(ID:", idx, ")");

                SYS_PKT_DUMP("%-20s: %d \n", (char*)&str, reason_cnt);
            }
        }
    }

    return CTC_E_NONE;
}


int32
sys_goldengate_packet_stats_clear(uint8 lchip)
{
    if (p_pkt_master[lchip] == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    sal_memset(&p_pkt_master[lchip]->stats, 0, sizeof(sys_pkt_stats_t));

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_set_reason_log(uint8 lchip, uint16 reason_id, uint8 enable, uint8 is_all, uint8 is_detail)
{
    uint16 index = 0;

    if ((reason_id >= CTC_PKT_CPU_REASON_MAX_COUNT) && !is_all)
    {
        return CTC_E_EXCEED_MAX_SIZE;
    }

    if (enable)
    {
        if (is_all)
        {
            for (index = 0; index < CTC_PKT_CPU_REASON_MAX_COUNT; index++)
            {
                CTC_BMP_SET(p_pkt_master[lchip]->reason_bm, index);
                p_pkt_master[lchip]->header_en[index] = is_detail;
            }
        }
        else
        {
            CTC_BMP_SET(p_pkt_master[lchip]->reason_bm, reason_id);
            p_pkt_master[lchip]->header_en[reason_id] = is_detail;
        }
    }
    else
    {
        if (is_all)
        {
            for (index = 0; index < CTC_PKT_CPU_REASON_MAX_COUNT; index++)
            {
                CTC_BMP_UNSET(p_pkt_master[lchip]->reason_bm, index);
                p_pkt_master[lchip]->header_en[index] = is_detail;
            }
        }
        else
        {
            CTC_BMP_UNSET(p_pkt_master[lchip]->reason_bm, reason_id);
            p_pkt_master[lchip]->header_en[reason_id] = is_detail;
        }
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_buffer_dump(uint8 lchip, uint8 buf_cnt, uint8 flag)
{
    uint8 buf_id = 0;
    uint8 idx = 0;
    if (p_pkt_master[lchip] == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(buf_cnt, SYS_PKT_BUF_MAX);

    if (!CTC_IS_BIT_SET(flag, 0))
    {
        CTC_BIT_SET(flag, 0);
        buf_cnt = SYS_PKT_BUF_MAX;
    }

    buf_id = p_pkt_master[lchip]->buf_id;

    while(buf_cnt)
    {
        buf_id = buf_id? (buf_id - 1):(SYS_PKT_BUF_MAX - 1);
        buf_cnt--;

        if (p_pkt_master[lchip]->pkt_buf[buf_id].pkt_len)
        {
            uint8 len = 0;
            SYS_PKT_DUMP("Packet No.%d, Pkt len: %d\n", idx++, p_pkt_master[lchip]->pkt_buf[buf_id].pkt_len);

            if (CTC_IS_BIT_SET(flag, 1))
            {
                ctc_pkt_rx_t pkt_rx;
                ds_t raw_hdr;

                sal_memset(&pkt_rx, 0, sizeof(pkt_rx));
                sal_memset(raw_hdr, 0, sizeof(raw_hdr));
                sal_memcpy(raw_hdr, p_pkt_master[lchip]->pkt_buf[buf_id].pkt_data, CTC_PKT_HEADER_LEN);

                /* convert raw header to rx_info */
                CTC_ERROR_RETURN(_sys_goldengate_packet_rawhdr_to_rxinfo(lchip, (uint32*)&raw_hdr, &pkt_rx));
                CTC_ERROR_RETURN(_sys_goldengate_packet_dump_header(lchip, &pkt_rx));

                _sys_goldengate_packet_dump(lchip, p_pkt_master[lchip]->pkt_buf[buf_id].pkt_data, CTC_PKT_HEADER_LEN);
            }

            if (CTC_IS_BIT_SET(flag, 0))
            {
                SYS_PKT_DUMP("-----------------------------------------------\n");
                SYS_PKT_DUMP("Packet Info(Length : %d):\n", (p_pkt_master[lchip]->pkt_buf[buf_id].pkt_len-CTC_PKT_HEADER_LEN));
                SYS_PKT_DUMP("-----------------------------------------------\n");

                /*print packet*/
                len = (p_pkt_master[lchip]->pkt_buf[buf_id].pkt_len <= SYS_PKT_BUF_PKT_LEN)?
                (p_pkt_master[lchip]->pkt_buf[buf_id].pkt_len-CTC_PKT_HEADER_LEN): (SYS_PKT_BUF_PKT_LEN-CTC_PKT_HEADER_LEN);
                CTC_ERROR_RETURN(_sys_goldengate_packet_dump(lchip, p_pkt_master[lchip]->pkt_buf[buf_id].pkt_data+CTC_PKT_HEADER_LEN, len));
            }
        }

    }

    return CTC_E_NONE;

}

int32
sys_goldengate_packet_buffer_clear(uint8 lchip)
{
    if (p_pkt_master[lchip] == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    sal_memset(&p_pkt_master[lchip]->pkt_buf, 0, sizeof(p_pkt_master[lchip]->pkt_buf));
    p_pkt_master[lchip]->buf_id = 0;

    return CTC_E_NONE;
}

int32
sys_goldengate_packet_register_tx_cb(uint8 lchip, CTC_PKT_TX_CALLBACK tx_cb)
{
    if (NULL == p_pkt_master[lchip])
    {
        return CTC_E_NOT_INIT;
    }

     p_pkt_master[lchip]->cfg.dma_tx_cb = tx_cb;

    return CTC_E_NONE;
}

static int32
sys_goldengate_packet_eadp_dump_gg_header(uint8 lchip, ms_packet_header_t* p_header)
{
    SYS_PKT_DBG_INFO("\nGoldengate Header Information\n");
    SYS_PKT_DBG_INFO("------------------------------------------------------------\n");
    SYS_PKT_DBG_INFO("dest_map %d, source_port %d, logic_src_port %d, packet_type %d\n"
                 "next_hop_ptr %d, src_vlan_id %d, src_vlan_ptr %d, priority %d\n",
                 p_header->dest_map, p_header->source_port, (
                 p_header->logic_src_port_13_7<<7|p_header->logic_src_port_6_0), p_header->packet_type,
                 p_header->next_hop_ptr, p_header->src_vlan_id_11<<11|p_header->src_vlan_id_10_0,
                 p_header->src_vlan_ptr, p_header->priority);
    SYS_PKT_DBG_INFO("------------------------------------------------------------\n");

    return CTC_E_NONE;
}

#ifdef _SAL_LINUX_UM
int32
sys_goldengate_packet_eadp_rx_dump(uint8* pkt, uint32 mode, uint32 pkt_len)
{
    ms_packet_header_t header;
    uint8 lchip = 0;

    sal_memset(&header, 0, sizeof(header));
    CTC_ERROR_RETURN(_chip_agent_decode_gg_header(pkt, pkt_len, &header));
    CTC_ERROR_RETURN(sys_goldengate_packet_eadp_dump_gg_header(lchip, &header));

    return CTC_E_NONE;
}

int32
sys_goldengate_set_pkt_rx_cb(uint8 lchip, CTC_PKT_RX_CALLBACK cb)
{
    if (!p_pkt_master[lchip])
    {
        return CTC_E_INVALID_PTR;
    }
    p_pkt_master[lchip]->cfg.rx_cb = cb;
    return CTC_E_NONE;
}


int32
sys_goldengate_get_pkt_rx_cb(uint8 lchip, void** cb)
{
    if (!p_pkt_master[lchip])
    {
        return CTC_E_INVALID_PTR;
    }
    *cb = p_pkt_master[lchip]->cfg.rx_cb;
    return CTC_E_NONE;
}
#endif

int32
sys_goldengate_packet_register_internal_rx_cb(uint8 lchip, SYS_PKT_RX_CALLBACK oam_rx_cb)
{
    if (NULL == p_pkt_master[lchip])
    {
        return CTC_E_NOT_INIT;
    }

    p_pkt_master[lchip]->oam_rx_cb = oam_rx_cb;
    return CTC_E_NONE;
}

int32
sys_goldengate_packet_init(uint8 lchip, void* p_global_cfg)
{
    ctc_pkt_global_cfg_t* p_pkt_cfg = (ctc_pkt_global_cfg_t*)p_global_cfg;
    mac_addr_t mac_sa = {0xFE, 0xFD, 0x0, 0x0, 0x0, 0x1};
    mac_addr_t mac_da = {0xFE, 0xFD, 0x0, 0x0, 0x0, 0x0};

    /* 2. allocate interrupt master */
    if (p_pkt_master[lchip])
    {
        return CTC_E_NONE;
    }

    p_pkt_master[lchip] = (sys_pkt_master_t*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(sys_pkt_master_t));
    if (NULL == p_pkt_master[lchip])
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_pkt_master[lchip], 0, sizeof(sys_pkt_master_t));

    /*Need provide callback function for packet rx*/
    if (p_pkt_cfg->rx_cb == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    sal_memcpy(&p_pkt_master[lchip]->cfg, p_pkt_cfg, sizeof(ctc_pkt_global_cfg_t));

    sal_memcpy(p_pkt_master[lchip]->cpu_mac_sa, mac_sa, sizeof(mac_sa));
    sal_memcpy(p_pkt_master[lchip]->cpu_mac_da, mac_da, sizeof(mac_da));
#ifdef _SAL_LINUX_UM
    drv_register_pkt_rx_cb(sys_goldengate_packet_eadp_rx_dump);
#endif
    sys_goldengate_packet_register_tx_cb(lchip, sys_goldengate_dma_pkt_tx);
#if 0
    sys_goldengate_get_chip_cpumac(lchip, p_pkt_master[lchip]->cpu_mac_sa, p_pkt_master[lchip]->cpu_mac_da);
#endif

    return CTC_E_NONE;
}

