/**
 @file ctc_greatbelt_ipmc.c

 @date 2010-01-25

 @version v2.0


*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctc_const.h"
#include "ctc_error.h"
#include "ctc_avl_tree.h"
#include "ctc_hash.h"
#include "ctc_ipmc.h"
#include "sys_greatbelt_ipmc.h"
#include "sys_greatbelt_ipmc_db.h"

/****************************************************************************
 *
* Function
*
*****************************************************************************/

/**
 @brief Init ipmc module, including global variable, ipmc database, etc.

 @param[in] ipmc_global_cfg   ipmc global config information, use struct ctc_ipmc_global_cfg_t to set max vrf id (ipv4, ipv6)

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_init(uint8 lchip, void* ipmc_global_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_ipmc_init());

    return CTC_E_NONE;
}

/**
 @brief Add an ipmc multicast group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_add_group(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_add_group(p_group);
}

/**
 @brief Remove an ipmc group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_remove_group(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_remove_group(p_group);
}

/**
 @brief Add members to an ipmc group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_add_member(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_add_member(p_group);
}

/**
 @brief Remove members from an ipmc group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_remove_member(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_remove_member(p_group);
}

/**
 @brief Update the RPF interface of the group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_update_rpf(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_update_rpf(p_group);
}

/**
 @brief Get info of the group

 @param[in] p_group     An pointer reference to an ipmc group

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_get_group_info(uint8 lchip, ctc_ipmc_group_info_t* p_group)
{
    return sys_greatbelt_ipmc_get_group_info(p_group);
}

/**
 @brief Add the default action for both ipv4 and ipv6 ipmc.

 @param[in] ip_version     IPv4 or IPv6.

 @param[in] type           Indicates send to cpu or drop only.

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_add_default_entry(uint8 lchip, uint8 ip_version, ctc_ipmc_default_action_t type)
{
    return sys_greatbelt_ipmc_add_default_entry(ip_version, type);
}

/**
 @brief Set ipv4 and ipv6 force route register for force mcast ucast or bridge.

 @param[in] p_data   An point reference to ctc_ipmc_force_route_t.

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_set_mcast_force_route(uint8 lchip, ctc_ipmc_force_route_t* p_data)
{
    return sys_greatbelt_ipmc_set_mcast_force_route(p_data);
}

/**
 @brief Get ipv4 and ipv6 mcast force route.

 @param[in, out] p_data   An point reference to ctc_ipmc_v4_force_route_t.

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_get_mcast_force_route(uint8 lchip, ctc_ipmc_force_route_t* p_data)
{
    return sys_greatbelt_ipmc_get_mcast_force_route(p_data);
}

/**
 @brief Traverse all ipmc entry

 @param[in] ip_ver ip version of the ipmc route, 0 IPV4, 1 IPV6

 @param[in] fn callback function to deal with all the ipmc entry

 @param[in] user_data data used by the callback function

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_ipmc_traverse(uint8 lchip, uint8 ip_ver, ctc_ipmc_traverse_fn fn, void* user_data)
{
    return sys_greatbelt_ipmc_traverse(ip_ver, fn, user_data);
}

