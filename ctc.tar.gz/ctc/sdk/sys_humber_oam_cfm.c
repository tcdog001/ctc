/**
 @file sys_humber_oam_cfm.c

 @date 2010-3-9

 @version v2.0

  This file contains ethernet oam(cfm and Y.1731) sys layer function implementation
*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctc_oam.h"             /* ctc layer oam ds */
#include "ctc_error.h"

#include "sys_humber_oam.h"      /* sys ds for all oam sub modules */
#include "sys_humber_oam_cfm.h"  /* sys layer function declaration of cmf oam functions */
#include "sys_humber_oam_hash.h"
#include "sys_humber_oam_cfm_db.h"
#include "sys_humber_chip.h"
#include "sys_humber_opf.h"
#include "sys_humber_vlan.h"
#include "sys_humber_port.h"
#include "sys_humber_nexthop_api.h"
#include "sys_humber_nexthop.h"

#include "drv_io.h"
#include "drv_humber.h"

#define DISABLE_PASSIVE_CHANNEL 0

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/

/****************************************************************************
 *
* Function
*
*****************************************************************************/

/**
 @brief   initilization for ethernet oam
*/
int32
sys_humber_eth_oam_init(ctc_oam_global_t* oam_global)
{
    int32 ret = 0;

    SYS_OAM_DBG_FUNC();

    /*if no resource, disable oam module*/
    ret = sys_humber_oam_resource_check();
    if (ret < 0)
    {
        return CTC_E_NONE;
    }

    /* input param check */
    CTC_PTR_VALID_CHECK(oam_global)

    CTC_ERROR_RETURN(sys_humber_oam_master_init(oam_global));  /* init oma master if it's not ready */

    if (SYS_HUMBER_ETH_OAM_MASTER) /* ether oam already inited */
    {
        return CTC_E_NONE;
    }

    CTC_ERROR_RETURN(_sys_humber_eth_oam_init_db(oam_global));
    CTC_ERROR_RETURN(_sys_humber_eth_oam_init_regs(oam_global));

    return CTC_E_NONE;
}

/**
 @brief   set global parameter for ethernet oam
*/
int32
sys_humber_eth_oam_set_global_parameter(uint8 param_type, void* param_value)
{
    uint8* larger_interval_to_cpu_ptr = NULL;
    ctc_oam_eth_senderid_t* sender_id_ptr = NULL;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    CTC_PTR_VALID_CHECK(param_value)

    SYS_OAM_DBG_FUNC();
    OAM_LOCK;

    switch (param_type)
    {
    case CTC_OAM_Y1731_CFG_TYPE_BIG_CCM_INTERVAL_TO_CPU:
        larger_interval_to_cpu_ptr = (uint8*)param_value;
        if (*larger_interval_to_cpu_ptr > SYS_HUMBER_OAM_MAX_CCM_INTERVAL)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_INVALID_MEP_CCM_INTERVAL;
        }

        /* write asic */
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_larger_ccm_interval_in_asic(*larger_interval_to_cpu_ptr), OAM_UNLOCK);
        break;

    case CTC_OAM_Y1731_CFG_TYPE_SENDER_ID:
        sender_id_ptr = (ctc_oam_eth_senderid_t*)param_value;
        /* write asic */
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_sender_id_in_asic(sender_id_ptr), OAM_UNLOCK);
        break;

    default:
        OAM_UNLOCK;
        return CTC_E_OAM_INVALID_GLOBAL_PARAM_TYPE;
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set defect bitmap enabling rdi
*/
static int32
_sys_humber_eth_oam_set_rdi_enable_defect_bitmap(uint8 rdi_enable_defect_bitmap)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    uint32 cmd = 0;
    uint32 field_value = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    SYS_OAM_DBG_FUNC();

    local_chip_num = sys_humber_get_local_chip_num();
    field_value = rdi_enable_defect_bitmap;
    cmd = DRV_IOW(IOC_REG, OAM_RX_PROC_ETHER_CTL, OAM_RX_PROC_ETHER_CTL_ETHER_DEFECT_TO_RDI);

    OAM_LOCK;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(drv_reg_ioctl(lchip, 0, cmd, &field_value), OAM_UNLOCK);
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set exception en
*/
static int32
_sys_humber_eth_oam_set_exception_to_cpu(uint32 exception_bitmap)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    uint32 cmd = 0;
    uint32 field_value = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    SYS_OAM_DBG_FUNC();

    local_chip_num = sys_humber_get_local_chip_num();
    field_value = exception_bitmap;
    cmd = DRV_IOW(IOC_REG, OAM_HDR_EDIT_CTL, OAM_HDR_EDIT_CTL_CPU_EXCEPTION_EN);

    OAM_LOCK;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(drv_reg_ioctl(lchip, 0, cmd, &field_value), OAM_UNLOCK);
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set aps msg
*/
static int32
_sys_humber_eth_oam_set_aps_msg(uint32 aps_bitmap)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    uint32 cmd = 0;
    oamproc_oam_upd_aps_ctl_t   oamproc_oam_upd_aps_ctl;

    SYS_HUMBER_ETH_OAM_INIT_CHECK
    SYS_OAM_DBG_FUNC();

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&oamproc_oam_upd_aps_ctl, 0, sizeof(oamproc_oam_upd_aps_ctl));

        cmd = DRV_IOR(IOC_REG, OAMPROC_OAM_UPD_APS_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oamproc_oam_upd_aps_ctl));

        oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask = 0;
        oamproc_oam_upd_aps_ctl.eth_mep_aps_sig_fail_mask  = 0;

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_INTF_STATE))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask, 0);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_PORT_STATE))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask, 1);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_RDI))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask, 2);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_D_LOC))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask, 3);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_D_UNEXP_PERIOD))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_rmep_aps_sig_fail_mask, 4);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_D_MEG_LVL))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_mep_aps_sig_fail_mask, 0);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_D_MISMERGE))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_mep_aps_sig_fail_mask, 1);
        }

        if (CTC_FLAG_ISSET(aps_bitmap, CTC_OAM_TRIG_APS_MSG_FLAG_D_UNEXP_MEP))
        {
            CTC_BIT_SET(oamproc_oam_upd_aps_ctl.eth_mep_aps_sig_fail_mask, 2);
        }

        cmd = DRV_IOW(IOC_REG, OAMPROC_OAM_UPD_APS_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oamproc_oam_upd_aps_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief   add ma id for ethernet oam
*/
int32
sys_humber_eth_oam_add_maid(ctc_oam_maid_t* p_maid)
{
    uint8 lchip              = 0;
    uint8 local_chip_num     = 0;
    uint8 entry_index        = 0;
    uint32 cmd               = 0;
    uint8 maid_entry_num     = 0;
    uint32 opf_maid_offset   = SYS_HUMBER_OAM_INVALID_MAID_INDEX;
    sys_eth_oam_maid_t* sys_eth_oam_maid = NULL;

    sys_humber_opf_t opf;
    oam_ds_ma_name_t oam_ds_ma_name;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    CTC_PTR_VALID_CHECK(SYS_HUMBER_ETH_OAM_MASTER->maid_list)

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_maid)

    SYS_OAM_DBG_FUNC();

    /* get the entry number and check the length and length type */
    switch (SYS_HUMBER_ETH_OAM_GLOBAL->maid_len_format)
    {
    case CTC_OAM_MAID_LEN_16BYTES:
        maid_entry_num = 2;
        break;

    case CTC_OAM_MAID_LEN_32BYTES:
        maid_entry_num = 4;
        break;

    case CTC_OAM_MAID_LEN_48BYTES:
        maid_entry_num = 6;
        break;

    default:
        break;
    }

    if (p_maid->maid_len > maid_entry_num * 8)
    {
        SYS_OAM_DBG_INFO("Invalid maid_len: 0x%x\n", p_maid->maid_len);
        return CTC_E_OAM_MAID_LENGTH_INVALID;
    }

    /* search the maid sw list, see if maid already created */
    if (_sys_humber_eth_oam_get_maid_in_db(SYS_HUMBER_ETH_OAM_MASTER->maid_list, p_maid))
    {
        SYS_OAM_DBG_INFO("Maid: '%s', len: 0x%x already exist\n", p_maid->maid, p_maid->maid_len);
        return CTC_E_OAM_MAID_ENTRY_EXIST;
    }

    sys_eth_oam_maid = (sys_eth_oam_maid_t*)mem_malloc(MEM_OAM_MODULE, sizeof(sys_eth_oam_maid_t));
    if (sys_eth_oam_maid == NULL)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(sys_eth_oam_maid, 0, sizeof(sys_eth_oam_maid_t));

#define FREE_MAID \
    { \
        mem_free(sys_eth_oam_maid); \
        OAM_UNLOCK; \
    }

    OAM_LOCK;

    /* get availabe maid offset from opf */
    opf.pool_type  = OPF_OAM_MA_NAME;
    opf.pool_index = 0;
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(sys_humber_opf_alloc_offset(&opf, maid_entry_num, &opf_maid_offset), FREE_MAID);
    SYS_OAM_DBG_INFO("New maid allocated with index: 0x%x, entry num: 0x%x\n", opf_maid_offset, maid_entry_num);

    /* get the input values and store in db */
    sys_eth_oam_maid->maid_index = opf_maid_offset & 0xffff;
    sys_eth_oam_maid->maid_len   = p_maid->maid_len;
    sal_memcpy(sys_eth_oam_maid->maid, p_maid->maid, CTC_OAM_MAX_MAID_LEN);

    ctc_slist_add_tail(SYS_HUMBER_ETH_OAM_MASTER->maid_list, &(sys_eth_oam_maid->head));

#define DELETE_NODE_FREE_MAID \
    { \
        ctc_slist_delete_node(SYS_HUMBER_ETH_OAM_MASTER->maid_list, &(sys_eth_oam_maid->head)); \
        mem_free(sys_eth_oam_maid); \
        OAM_UNLOCK; \
    }

    /* write maid into asic table */
    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&oam_ds_ma_name, 0, sizeof(oam_ds_ma_name));
        cmd = DRV_IOW(IOC_TABLE, OAM_DS_MA_NAME, DRV_ENTRY_FLAG);

        for (entry_index = 0; entry_index < maid_entry_num; entry_index++)
        {
            oam_ds_ma_name.ma_id_umc0 = sys_eth_oam_maid->maid[entry_index * 8] << 24 | sys_eth_oam_maid->maid[entry_index * 8 + 1] << 16
                | sys_eth_oam_maid->maid[entry_index * 8 + 2] << 8 | sys_eth_oam_maid->maid[entry_index * 8 + 3];
            oam_ds_ma_name.ma_id_umc1 = sys_eth_oam_maid->maid[entry_index * 8 + 4] << 24 | sys_eth_oam_maid->maid[entry_index * 8 + 5] << 16
                | sys_eth_oam_maid->maid[entry_index * 8 + 6] << 8 | sys_eth_oam_maid->maid[entry_index * 8 + 7];
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(drv_tbl_ioctl(lchip, opf_maid_offset + entry_index, cmd, &oam_ds_ma_name), DELETE_NODE_FREE_MAID);
        }
    }

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   remove ma id for ethernet oam
*/
int32
sys_humber_eth_oam_remove_maid(ctc_oam_maid_t* p_maid)
{
    uint8 lchip              = 0;
    uint8 local_chip_num     = 0;
    uint8 entry_index        = 0;
    uint32 cmd               = 0;
    uint8 maid_entry_num     = 0;
    sys_eth_oam_maid_t* sys_eth_oam_maid = NULL;

    sys_humber_opf_t opf;
    oam_ds_ma_name_t oam_ds_ma_name;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    CTC_PTR_VALID_CHECK(SYS_HUMBER_ETH_OAM_MASTER->maid_list)

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_maid)

    SYS_OAM_DBG_FUNC();

    /* get the entry number and check the length and length type */
    switch (SYS_HUMBER_ETH_OAM_GLOBAL->maid_len_format)
    {
    case CTC_OAM_MAID_LEN_16BYTES:
        maid_entry_num = 2;
        break;

    case CTC_OAM_MAID_LEN_32BYTES:
        maid_entry_num = 4;
        break;

    case CTC_OAM_MAID_LEN_48BYTES:
        maid_entry_num = 6;
        break;

    default:
        break;
    }

    OAM_LOCK;
    /* search the maid sw list, see if maid already created */
    sys_eth_oam_maid = _sys_humber_eth_oam_get_maid_in_db(SYS_HUMBER_ETH_OAM_MASTER->maid_list, p_maid);
    if (!sys_eth_oam_maid)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_MAID_ENTRY_NOT_FOUND;
    }

    /* write maid into asic table */
    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&oam_ds_ma_name, 0, sizeof(oam_ds_ma_name));
        cmd = DRV_IOW(IOC_TABLE, OAM_DS_MA_NAME, DRV_ENTRY_FLAG);

        for (entry_index = 0; entry_index < maid_entry_num; entry_index++)
        {
            oam_ds_ma_name.ma_id_umc0 = 0;
            oam_ds_ma_name.ma_id_umc1 = 0;
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(drv_tbl_ioctl(lchip, sys_eth_oam_maid->maid_index + entry_index, cmd, &oam_ds_ma_name), OAM_UNLOCK);
        }
    }

    /* free maid offset from opf */
    opf.pool_type  = OPF_OAM_MA_NAME;
    opf.pool_index = 0;
    sys_humber_opf_free_offset(&opf, maid_entry_num, sys_eth_oam_maid->maid_index);

    /* delete maid from list */
    ctc_slist_delete_node(SYS_HUMBER_ETH_OAM_MASTER->maid_list, &(sys_eth_oam_maid->head));

    mem_free(sys_eth_oam_maid);
    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   add mep lookup chan for ethernet oam
*/
int32
sys_humber_eth_oam_add_lmep_lkup_chan(ctc_oam_chan_t* p_chan)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint8 local_chip_num  = 0;
    bool both_entry_exist = TRUE;

#if DISABLE_PASSIVE_CHANNEL
    ctc_oam_chan_t passive_chan;
#endif
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;
    uint16 ccm_vlan_id  = 0;
    uint8  master_gchip = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter */
    CTC_PTR_VALID_CHECK(p_chan);

    gport         = p_chan->key.u.eth.gport;
    vlan_id       = p_chan->key.u.eth.vlan_id;
    ccm_vlan_id = vlan_id;
    if (p_chan->key.u.eth.ccm_vlan_id_valid)
    {
        ccm_vlan_id = p_chan->key.u.eth.ccm_vlan_id;
    }

    is_up         = CTC_FLAG_ISSET(p_chan->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_chan->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);
    master_gchip  = p_chan->u.eth_chan.master_gchip;

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, ccm_vlan=%d, dir=%d, link_oam=%d, master-gchip=%d\n",
                     gport, vlan_id, ccm_vlan_id, is_up, is_link_oam, master_gchip);

    CTC_GLOBAL_PORT_CHECK(gport);
    /* Check gport for link oam */
    if (is_link_oam)
    {
        /* gport must be local physical port */
        if (CTC_IS_LINKAGG_PORT(gport))
        {
            SYS_OAM_DBG_INFO("lmep_lkup_chan->lmep_chan_key.gport must be physical port for link oam\n");
            return CTC_E_INVALID_GLOBAL_PORT;
        }

        if (!sys_humber_chip_is_local(SYS_MAP_GPORT_TO_GCHIP(gport), &lchip))
        {
            SYS_OAM_DBG_INFO("lmep_lkup_chan->lmep_chan_key.gport must be local chip and port for link oam\n");
            return CTC_E_CHIP_IS_REMOTE;
        }

        if (is_up)
        {
            SYS_OAM_DBG_INFO("lmep_lkup_chan->lmep_chan_key.direction must be down for link oam\n");
            return CTC_E_OAM_CHAN_NOT_DOWN_DIRECTION;
        }
    }

    if (CTC_IS_LINKAGG_PORT(gport))
    {
        CTC_GLOBAL_CHIPID_CHECK(master_gchip)
    }

    /* check vlan id if not link oam */
    if (!is_link_oam)
    {
        CTC_ERROR_RETURN(sys_humber_vlan_range_check_under_mode(vlan_id));
        CTC_VLAN_RANGE_CHECK(ccm_vlan_id);
    }

#if DISABLE_PASSIVE_CHANNEL
    sal_memset(&passive_chan, 0, sizeof(passive_chan));
    sal_memcpy(&passive_chan, p_chan, sizeof(ctc_oam_chan_t));
    if (is_up)
    {
        CTC_UNSET_FLAG(passive_chan.key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }
    else
    {
        CTC_SET_FLAG(passive_chan.key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }

#endif

#define ROLL_BACK_ADD_ACTIVE_CHAN \
    { \
        _sys_humber_eth_oam_remove_chan(lchip, p_chan); \
        OAM_UNLOCK; \
    }

    if (!CTC_IS_LINKAGG_PORT(gport))
    {
        SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

        /* get entry status */
        OAM_LOCK;

        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_chan->key));
        if (!sys_chan) /* chan not found, insert new */
        {
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_new_chan(lchip, p_chan, SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER), OAM_UNLOCK);
#if DISABLE_PASSIVE_CHANNEL
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_new_chan(lchip, &passive_chan, SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE), ROLL_BACK_ADD_ACTIVE_CHAN);
#endif
        }
        else
        {
            if (sys_chan->entry_status >= SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER) /* entry exists*/
            {
                OAM_UNLOCK;
                return CTC_E_OAM_CHAN_ENTRY_EXIST;
            }
            else /* entry needs overwirte */
            {
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_build_chan_data(lchip, p_chan, sys_chan), OAM_UNLOCK);
                sys_chan->entry_status = SYS_HUMBER_OAM_HASH_ENTRY_PASSIVE_OVERWRITE_BY_USER;
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_chan_and_key_to_asic(lchip, sys_chan), OAM_UNLOCK);
            }
        }

        OAM_UNLOCK;
    }
    else /* gport is link agg */
    {
        local_chip_num = sys_humber_get_local_chip_num();
        OAM_LOCK;

        for (lchip = 0; lchip < local_chip_num; lchip++)
        {
            sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_chan->key));
            if (!sys_chan) /* chan not found, insert new */
            {
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_new_chan(lchip, p_chan, SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER), OAM_UNLOCK);
#if DISABLE_PASSIVE_CHANNEL
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_new_chan(lchip, &passive_chan, SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE), ROLL_BACK_ADD_ACTIVE_CHAN);
#endif
                both_entry_exist = FALSE;
            }
            else
            {
                if (sys_chan->entry_status >= SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER) /* entry exists*/
                {
                    continue;
                }
                else /* entry needs overwirte */
                {
                    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_build_chan_data(lchip, p_chan, sys_chan), OAM_UNLOCK);
                    sys_chan->entry_status = SYS_HUMBER_OAM_HASH_ENTRY_PASSIVE_OVERWRITE_BY_USER;
                    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_chan_and_key_to_asic(lchip, sys_chan), OAM_UNLOCK);

                    both_entry_exist = FALSE;
                }
            }
        }

        OAM_UNLOCK;

        if (both_entry_exist)
        {
            return CTC_E_OAM_CHAN_ENTRY_EXIST;
        }
    }

    return CTC_E_NONE;
}

/**
 @brief   remove mep lookup chan for ethernet oam
*/
int32
sys_humber_eth_oam_remove_lmep_lkup_chan(ctc_oam_chan_t* p_chan)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint8 local_chip_num  = 0;
    bool both_entry_empty = TRUE;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan            = NULL;

#if DISABLE_PASSIVE_CHANNEL
    sys_eth_oam_lmep_lkup_chan_t* sys_passive_chan     = NULL;
    ctc_oam_chan_t passive_chan;
#endif

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;
    uint8  master_gchip = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_chan);

    gport         = p_chan->key.u.eth.gport;
    vlan_id       = p_chan->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_chan->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_chan->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);
    master_gchip  = p_chan->u.eth_chan.master_gchip;

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, master-gchip=%d\n", gport, vlan_id,
                     is_up, is_link_oam, master_gchip);

    CTC_GLOBAL_PORT_CHECK(gport)
#if DISABLE_PASSIVE_CHANNEL
    /* prepair passive chan data */
    sal_memset(&passive_chan, 0, sizeof(passive_chan));
    sal_memcpy(&passive_chan, p_chan, sizeof(ctc_oam_chan_t));
    if (is_up)
    {
        CTC_UNSET_FLAG(passive_chan.key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }
    else
    {
        CTC_SET_FLAG(passive_chan.key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    }

#endif
    if (!CTC_IS_LINKAGG_PORT(gport))
    {
        SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

        OAM_LOCK;
        /* get entry status */
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_chan->key));
        if (!sys_chan)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        if (CTC_SLISTCOUNT(sys_chan->lmep_list) > 0)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_LMEP_EXIST;
        }

        if (sys_chan->entry_status == SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

#if DISABLE_PASSIVE_CHANNEL

        /* check the passive chan status */
        sys_passive_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(passive_chan.key));
        if (!sys_passive_chan)
        {
            SYS_OAM_DBG_INFO("Passive chan not found for removing lmep chan\n");
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND; /* passive chan deleted by wrong operation, this should never happen*/
        }

        if (sys_passive_chan->entry_status == SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE) /* delete both chan and its passive */
        {
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_chan), OAM_UNLOCK);
            _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan);
            _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
            mem_free(sys_chan);

            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_passive_chan), OAM_UNLOCK);
            _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_passive_chan);
            _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_passive_chan);
            mem_free(sys_passive_chan);

        }
        else /* passive is created or overwrite by user, change this chan's status to SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE */
        {
            SYS_OAM_DBG_INFO("Chan is not removed because its passive is created by user, only change status\n");
            sys_chan->entry_status = SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE;
        }

#else
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_chan), OAM_UNLOCK);
        _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan);
        _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
        mem_free(sys_chan);
#endif

        OAM_UNLOCK;
    }
    else /* gport is link agg */
    {
        OAM_LOCK;
        local_chip_num = sys_humber_get_local_chip_num();

        for (lchip = 0; lchip < local_chip_num; lchip++)
        {
            /* get entry status */
            sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_chan->key));
            if (!sys_chan)
            {
                SYS_OAM_DBG_INFO("Chan not found on chip 0x%x for linkagg\n", lchip);
                continue;
            }

            if (sys_chan->entry_status == SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE)
            {
                SYS_OAM_DBG_INFO("Chan created by sdk for chip 0x%x, will not remove by user\n", lchip);
                continue;
            }

            if (CTC_SLISTCOUNT(sys_chan->lmep_list) > 0)
            {
                OAM_UNLOCK;
                return CTC_E_OAM_CHAN_LMEP_EXIST;
            }

#if DISABLE_PASSIVE_CHANNEL
            /* check the passive chan status */
            sys_passive_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(passive_chan.key));
            if (!sys_passive_chan)
            {
                SYS_OAM_DBG_INFO("Passive chan deleted by wrong operation, this should never happen\n");
                OAM_UNLOCK;
                return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
            }

            if (sys_passive_chan->entry_status == SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE) /* delete both chan and its passive */
            {
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_chan), OAM_UNLOCK);
                _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan);
                _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
                mem_free(sys_chan);

                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_passive_chan), OAM_UNLOCK);
                _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_passive_chan);
                _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_passive_chan);
                mem_free(sys_passive_chan);
            }
            else /* change this chan's status to SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE */
            {
                SYS_OAM_DBG_INFO("Chan is not removed because its passive is created by user, only change status\n");
                sys_chan->entry_status = SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE;
            }

#else
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_chan_and_key_from_asic(lchip, sys_chan), OAM_UNLOCK);
            _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan);
            _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
            mem_free(sys_chan);
#endif

            both_entry_empty = FALSE;
        }

        if (both_entry_empty)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        OAM_UNLOCK;
    }

    return CTC_E_NONE;
}

/**
 @brief   add local mep
*/
int32
sys_humber_eth_oam_add_lmep(ctc_oam_lmep_t* p_lmep)
{

    uint8 lchip = 0;

#if DISABLE_PASSIVE_CHANNEL
    uint8 lchip_index    = 0;
    uint8 local_chip_num = 0;
#endif
    sys_eth_oam_maid_t* sys_maid = NULL;
    sys_eth_oam_lmep_t* sys_lmep = NULL;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    bool need_add_lmep = FALSE;

    ctc_oam_y1731_lmep_t* p_eth_lmep = NULL;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

#define ROLL_BACK_MEM_FREE_UNLOCK \
    { \
        if (sys_lmep) \
        { \
            mem_free(sys_lmep); \
        } \
        OAM_UNLOCK; \
    }

#define ROLL_BACK_ADD_LMEP_TO_DB_AND_ASIC \
    { \
        if (sys_lmep) \
        { \
            _sys_humber_eth_oam_remove_lmep_from_db_and_asic(lchip, sys_chan, sys_lmep); \
            mem_free(sys_lmep); \
        } \
        OAM_UNLOCK; \
    }

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    p_eth_lmep = &(p_lmep->u.y1731_lmep);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)
    CTC_GLOBAL_PORT_CHECK(p_eth_lmep->ccm_gport_id)
    /* check tipid */
    if (p_eth_lmep->tpid_index < CTC_PARSER_L2_TPID_SVLAN_TPID_0 || p_eth_lmep->tpid_index > CTC_PARSER_L2_TPID_SVLAN_TPID_3)
    {
        return CTC_E_OAM_INVALID_MEP_TPID_INDEX;
    }

    /* check md level */
    if (is_link_oam)
    {
        if (p_lmep->key.u.eth.md_level > 0) /* linkoam always level 0*/
        {
            return CTC_E_OAM_INVALID_MD_LEVEL;
        }
    }
    else /* service oam */
    {
        if (p_lmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL || p_lmep->key.u.eth.md_level < 1)
        {
            return CTC_E_OAM_INVALID_MD_LEVEL;
        }
    }

    /* check ccm interval */
    if (p_eth_lmep->ccm_interval < SYS_HUMBER_OAM_MIN_CCM_INTERVAL || p_eth_lmep->ccm_interval > SYS_HUMBER_OAM_MAX_CCM_INTERVAL)
    {
        return CTC_E_OAM_INVALID_MEP_CCM_INTERVAL;
    }

    /* check mep id */
    if (p_eth_lmep->mep_id < SYS_HUMBER_OAM_MIN_MEP_ID || p_eth_lmep->mep_id > SYS_HUMBER_OAM_MAX_MEP_ID)
    {
        return CTC_E_OAM_INVALID_MEP_ID;
    }

    OAM_LOCK;
    /* search if maid exists in db, get the maid index */
    sys_maid = _sys_humber_eth_oam_get_maid_in_db(SYS_HUMBER_ETH_OAM_MASTER->maid_list, &(p_lmep->maid));
    if (!sys_maid)
    {
        SYS_OAM_DBG_INFO("Maid not found for '%s', len: 0x%x\n", p_lmep->maid.maid, p_lmep->maid.maid_len);
        OAM_UNLOCK;
        return CTC_E_OAM_MAID_ENTRY_NOT_FOUND;
    }

    if (CTC_IS_LINKAGG_PORT(gport)) /* add mep on master chip and update passive chan on all local chips */
    {
        /* sys chan lookup, linkagg's chan is on all chip, use chip 0 for lookup */
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(0, &(p_lmep->key));
        if (!sys_chan)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        if (sys_chan->master_gchip != SYS_MAP_GPORT_TO_GCHIP(p_eth_lmep->ccm_gport_id))
        {
            OAM_UNLOCK;
            return CTC_E_OAM_TX_GPORT_AND_MASTER_GCHIP_NOT_MATCH;
        }

        if (sys_humber_chip_is_local(sys_chan->master_gchip, &lchip)) /* add mep only to master chip */
        {
            need_add_lmep = TRUE;
            SYS_OAM_DBG_INFO("master gchip %d is on local chip %d for linkagg 0x%04x\n", sys_chan->master_gchip, lchip, gport);
        }
    }
    else
    {
        if (!sys_humber_chip_is_local(SYS_MAP_GPORT_TO_GCHIP(gport), &lchip))
        {
            OAM_UNLOCK;
            return CTC_E_CHIP_IS_REMOTE;
        }

        if (gport != p_eth_lmep->ccm_gport_id)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_TX_GPORT_AND_CHAN_GPORT_NOT_MATCH;
        }

        need_add_lmep = TRUE;
    }

    if (need_add_lmep) /* add mep on master chip for linkagg or local chip for physical port */
    {
        SYS_OAM_DBG_INFO("Searching chan on local chip %d\n", lchip);
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
        if (!sys_chan)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        if (sys_chan->entry_status < SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        /* search if lmep already exists in db */
        if (_sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level))
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_LMEP_EXIST;
        }

        sys_lmep = (sys_eth_oam_lmep_t*)mem_malloc(MEM_OAM_MODULE, sizeof(sys_eth_oam_lmep_t));
        if (!sys_lmep)
        {
            SYS_OAM_DBG_INFO("no new memory for sys lmep\n");
            OAM_UNLOCK;
            return CTC_E_NO_MEMORY;
        }

        sal_memset(sys_lmep, 0, sizeof(sys_eth_oam_lmep_t));

        /* create lmep list if needed */
        if (!sys_chan->lmep_list)
        {
            sys_chan->lmep_list = ctc_slist_new();
        }

        if (!sys_chan->lmep_list)
        {
            SYS_OAM_DBG_INFO("no new memory for lmep list\n");
            mem_free(sys_lmep);
            OAM_UNLOCK;
            return CTC_E_NO_MEMORY;
        }

        /* add lmep to db and asic */
        sys_lmep->maid = sys_maid;
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_lmep_to_db_and_asic(lchip, p_lmep, sys_chan, sys_lmep), ROLL_BACK_MEM_FREE_UNLOCK);
        /* update chan */
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_update_chan_in_asic_for_add_lmep(lchip, sys_chan, sys_lmep), ROLL_BACK_ADD_LMEP_TO_DB_AND_ASIC);
    }

#if DISABLE_PASSIVE_CHANNEL
    /* update passive chan */
    if (CTC_IS_LINKAGG_PORT(gport))
    {
        local_chip_num = sys_humber_get_local_chip_num();

        for (lchip_index = 0; lchip_index < local_chip_num; lchip_index++)
        {
            sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip_index, &(p_lmep->key));
            if (!sys_chan)
            {
                OAM_UNLOCK;
                return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
            }

            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_update_passive_chan_in_asic_for_add_lmep(lchip_index, sys_chan, p_eth_lmep, p_lmep->key.u.eth.md_level), ROLL_BACK_ADD_LMEP_TO_DB_AND_ASIC);
            SYS_OAM_DBG_INFO("Passive chan updated for chip 0x%x on linkagg 0x%x vlan 0x%x\n", lchip_index, gport, vlan_id);
        }
    }
    else
    {
        if (!sys_chan)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        SYS_OAM_DBG_INFO("Passive chan updated for chip 0x%x on port 0x%x vlan 0x%x\n", lchip, gport, vlan_id);
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_update_passive_chan_in_asic_for_add_lmep(lchip, sys_chan, p_eth_lmep, p_lmep->key.u.eth.md_level), ROLL_BACK_ADD_LMEP_TO_DB_AND_ASIC);
    }

#endif
    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   remove local mep
*/
int32
sys_humber_eth_oam_remove_lmep(ctc_oam_lmep_t* p_lmep)
{
    uint8 lchip = 0;

#ifdef DISABLE_PASSIVE_CHAN
    uint8 lchip_index = 0;
    uint8 local_chip_num = 0;
#endif

    ctc_oam_y1731_lmep_t* p_eth_lmep = NULL;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    bool need_remove_lmep = FALSE;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    p_eth_lmep = &(p_lmep->u.y1731_lmep);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)
    /* check md level */
    if (p_lmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    if (!_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip))
    {
        need_remove_lmep = TRUE; /* chip is local for non-link agg gport or master gchip for linkagg */
    }

    OAM_LOCK;

    if (need_remove_lmep)
    {
        /* sys chan lookup */
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
        if (!sys_chan)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }

        /* search the lmep list in chan */
        sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
        if (!sys_lmep)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
        }

        /* check if lmep hash rmep list */
        if (CTC_SLISTCOUNT(sys_lmep->rmep_list) > 0)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_RMEP_EXIST;
        }

        /* remove lmep from db and asic */
        _sys_humber_eth_oam_remove_lmep_from_db_and_asic(lchip, sys_chan, sys_lmep);

        /* free lmep list if necessary */
        if (CTC_SLISTCOUNT(sys_chan->lmep_list) == 0)
        {
            ctc_slist_free(sys_chan->lmep_list);
            sys_chan->lmep_list = NULL;
        }

        /* free the lmep data */
        mem_free(sys_lmep);
    }

#if DISABLE_PASSIVE_CHANNEL
    if (sys_chan)
    {
        /* update passive chan */
        if (CTC_IS_LINKAGG_PORT(gport))
        {
            /* update all local chip's passive chan */
            local_chip_num = sys_humber_get_local_chip_num();

            for (lchip_index = 0; lchip_index < local_chip_num; lchip_index++)
            {
                SYS_OAM_DBG_INFO("Passive chan updated for chip 0x%x on linkagg 0x%x vlan 0x%x\n", lchip_index, gport, vlan_id);
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_update_passive_chan_in_asic_for_remove_lmep(lchip_index, sys_chan), OAM_UNLOCK);
            }
        }
        else
        {
            SYS_OAM_DBG_INFO("Passive chan updated for chip 0x%x on port 0x%x vlan 0x%x\n", lchip, gport, vlan_id);
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_update_passive_chan_in_asic_for_remove_lmep(lchip, sys_chan), OAM_UNLOCK);
        }
    }

#endif
    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   enable local mep
*/
int32
sys_humber_eth_oam_enable_mep(ctc_oam_update_t* p_lmep, bool enable)
{
    uint8 lchip = 0;
    uint8 status_to_set = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    if (p_lmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    if (enable)
    {
        status_to_set = 1;
    }
    else
    {
        status_to_set = 0;
    }

    if (sys_lmep->active != status_to_set)
    {
        sys_lmep->active = status_to_set;
        /* update asic table for lmep */
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_enable_lmep_in_asic(lchip, sys_lmep), OAM_UNLOCK);
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   enable mep's ccm function
*/
int32
sys_humber_eth_oam_enable_ccm(ctc_oam_update_t* p_lmep, bool enable)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    if (p_lmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    SYS_OAM_DBG_INFO("Searching sys chan in lchip %d\n", lchip);
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    if (enable)
    {
        sys_lmep->ccm_en = 1;
    }
    else
    {
        sys_lmep->ccm_en = 0;
    }

    /* update asic table for lmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_enable_lmep_ccm_in_asic(lchip, sys_lmep), OAM_UNLOCK);

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   enable mep's delay measurement function
*/
int32
sys_humber_eth_oam_enable_dm(ctc_oam_update_t* p_lmep, bool enable)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    if (p_lmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    if (sys_lmep->enable_pm == 1)
    {
        if (enable)
        {
            OAM_UNLOCK;
            return CTC_E_NONE;
        }
        else
        {
            sys_lmep->enable_pm = 0;
        }
    }
    else
    {
        if (!enable)
        {
            OAM_UNLOCK;
            return CTC_E_NONE;
        }
        else
        {
            sys_lmep->enable_pm = 1;
        }
    }

    /* update asic table for lmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_enable_lmep_dm_in_asic(lchip, sys_lmep), OAM_UNLOCK);

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   add remote mep
*/
int32
sys_humber_eth_oam_add_rmep(ctc_oam_rmep_t* p_rmep)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;

    ctc_oam_y1731_rmep_t* p_eth_rmep = NULL;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

#define ROLL_BACK_RMEP_DATA_BUILD \
    { \
        mem_free(sys_rmep); \
        OAM_UNLOCK; \
    }

#define ROLL_BACK_RMEP_WRITE_KEY \
    { \
        ctc_slist_delete_node(sys_lmep->rmep_list, &(sys_rmep->head)); \
        _sys_humber_eth_oam_free_rmep_index(lchip, sys_rmep); \
        mem_free(sys_rmep); \
        OAM_UNLOCK; \
    }

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_rmep);

    gport         = p_rmep->key.u.eth.gport;
    vlan_id       = p_rmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    p_eth_rmep = &(p_rmep->u.y1731_rmep);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_rmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)
    /* check md level */
    if (p_rmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    /* check mep id */
    if (p_eth_rmep->rmep_id < SYS_HUMBER_OAM_MIN_MEP_ID || p_eth_rmep->rmep_id > SYS_HUMBER_OAM_MAX_MEP_ID)
    {
        return CTC_E_OAM_INVALID_MEP_ID;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_rmep->key, &lchip));

    OAM_LOCK;

    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_rmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* lookup local mep in sys chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_rmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    /* lookup rmep list in the locam mep */
    if (_sys_humber_eth_oam_get_rmep_in_lmep(sys_lmep, p_eth_rmep))
    {
        OAM_UNLOCK;
        return CTC_E_OAM_RMEP_EXIST;
    }

    /* build rmep data */
    sys_rmep = (sys_eth_oam_rmep_t*)mem_malloc(MEM_OAM_MODULE, sizeof(sys_eth_oam_rmep_t));
    if (!sys_rmep)
    {
        OAM_UNLOCK;
        return CTC_E_NO_MEMORY;
    }

    sal_memset(sys_rmep, 0, sizeof(sys_eth_oam_rmep_t));

    if (!sys_lmep->rmep_list)
    {
        sys_lmep->rmep_list = ctc_slist_new();
    }

    if (!sys_lmep->rmep_list)
    {
        mem_free(sys_rmep);
        OAM_UNLOCK;
        return CTC_E_NO_MEMORY;
    }

    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_build_rmep_data(p_rmep->key.mep_type, p_eth_rmep, sys_lmep, sys_rmep), ROLL_BACK_RMEP_DATA_BUILD);

    /* build rmep asic index, in none-p2p mode, need to write the rmep key */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_build_rmep_index(lchip, sys_rmep), ROLL_BACK_RMEP_DATA_BUILD);
    /* add rmep to db (to the local mep's rmep list) */
    ctc_slist_add_tail(sys_lmep->rmep_list, &(sys_rmep->head));

    /* add rmep info to db */
    if (!ctc_vector_add(SYS_HUMBER_OAM_MASTER->mep_vector[lchip], sys_rmep->rmep_index, sys_rmep))
    {
        ROLL_BACK_RMEP_WRITE_KEY;
        return CTC_E_OAM_MEP_INDEX_VECTOR_ADD_FAIL;
    }

    /* write the rmep table in asic */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_rmep_to_asic(lchip, p_eth_rmep, sys_lmep, sys_rmep), ROLL_BACK_RMEP_WRITE_KEY);

    /* write rmep key and chan to asic if needed */
    if (!SYS_HUMBER_ETH_OAM_GLOBAL->is_p2p_mode)
    {
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_rmep_key_and_chan_to_asic(lchip, sys_lmep, sys_rmep), ROLL_BACK_RMEP_WRITE_KEY);
    }

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   remove remote mep
*/
int32
sys_humber_eth_oam_remove_rmep(ctc_oam_rmep_t* p_rmep)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;

    ctc_oam_y1731_rmep_t* p_eth_rmep = NULL;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_rmep);

    gport         = p_rmep->key.u.eth.gport;
    vlan_id       = p_rmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    p_eth_rmep = &(p_rmep->u.y1731_rmep);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_rmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)
    /* check md level */
    if (p_rmep->key.u.eth.md_level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    /* check mep id */
    if (p_eth_rmep->rmep_id > SYS_HUMBER_OAM_MAX_MEP_ID || p_eth_rmep->rmep_id < SYS_HUMBER_OAM_MIN_MEP_ID)
    {
        return CTC_E_OAM_INVALID_MEP_ID;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_rmep->key, &lchip));

    OAM_LOCK;

    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_rmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* lookup local mep in sys chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_rmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    /* lookup rmep list in the locam mep */
    sys_rmep = _sys_humber_eth_oam_get_rmep_in_lmep(sys_lmep, p_eth_rmep);
    if (!sys_rmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_RMEP_NOT_FOUND;
    }

    /* write rmep key and chan to asic if needed */
    if (!SYS_HUMBER_ETH_OAM_GLOBAL->is_p2p_mode)
    {
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_rmep_key_and_chan_from_asic(lchip, sys_rmep), OAM_UNLOCK);
    }

    /* invalidate rmep table from asic */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_remove_rmep_from_asic(lchip, sys_rmep), OAM_UNLOCK);

    /* del rmep info from db */
    ctc_vector_del(SYS_HUMBER_OAM_MASTER->mep_vector[lchip], sys_rmep->rmep_index);

    /* free rmep index from opf */
    _sys_humber_eth_oam_free_rmep_index(lchip, sys_rmep);

    /* delete rmep node from lmep's rmep list */
    ctc_slist_delete_node(sys_lmep->rmep_list, &(sys_rmep->head));
    if (CTC_SLISTCOUNT(sys_lmep->rmep_list) == 0)
    {
        ctc_slist_free(sys_lmep->rmep_list);
        sys_lmep->rmep_list = NULL;
    }

    /* free rmep db node */
    mem_free(sys_rmep);

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   enable remote mep
*/
int32
sys_humber_eth_oam_enable_rmep(ctc_oam_update_t* p_rmep, bool enable)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;
    uint8 status_to_set = 0;

    ctc_oam_y1731_rmep_t eth_rmep;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_rmep);

    sal_memset(&eth_rmep, 0, sizeof(eth_rmep));

    gport         = p_rmep->key.u.eth.gport;
    vlan_id       = p_rmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_rmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_rmep->key, &lchip));

    OAM_LOCK;
    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_rmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* lookup local mep in sys chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_rmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    /* lookup rmep list in the locam mep */
    eth_rmep.rmep_id = p_rmep->rmep_id;
    sys_rmep = _sys_humber_eth_oam_get_rmep_in_lmep(sys_lmep, &eth_rmep);
    if (!sys_rmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_RMEP_NOT_FOUND;
    }

    if (enable)
    {
        status_to_set = 1;
    }
    else
    {
        status_to_set = 0;
    }

    if (sys_rmep->active != status_to_set)
    {
        /* update asic table for rmep */
        sys_rmep->active = status_to_set;
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_enable_rmep_in_asic(lchip, sys_rmep), OAM_UNLOCK);
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   clear remote mep sequence number fail counter
*/
int32
sys_humber_eth_oam_clear_rmep_seq_num_fail_counter(ctc_oam_update_t* p_rmep)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;

    ctc_oam_y1731_rmep_t eth_rmep;
    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_rmep);

    sal_memset(&eth_rmep, 0, sizeof(eth_rmep));

    gport         = p_rmep->key.u.eth.gport;
    vlan_id       = p_rmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_rmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_rmep->key.u.eth.md_level);

    CTC_GLOBAL_PORT_CHECK(gport)

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_rmep->key, &lchip));

    OAM_LOCK;
    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_rmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* lookup local mep in sys chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_rmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    /* lookup rmep list in the locam mep */
    eth_rmep.rmep_id = p_rmep->rmep_id;
    sys_rmep = _sys_humber_eth_oam_get_rmep_in_lmep(sys_lmep, &eth_rmep);
    if (!sys_rmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_RMEP_NOT_FOUND;
    }

    /* update asic table for rmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_clear_rmep_seq_num_fail_in_asic(lchip, sys_rmep), OAM_UNLOCK);

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set if ethernet oam is enabled on this port
*/
int32
sys_humber_eth_oam_set_port_oam_en(uint16 gport, ctc_direction_t dir, bool enable)
{
    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x\n", gport);

    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)
    if (CTC_IS_LINKAGG_PORT(gport))
    {
        return CTC_E_INVALID_GLOBAL_PORT;
    }

    /* call the sys interface from port module */
    switch (dir)
    {
    case CTC_INGRESS:
        CTC_ERROR_RETURN(sys_humber_port_set_igs_oam_valid(gport, enable));
        break;

    case CTC_EGRESS:
        CTC_ERROR_RETURN(sys_humber_port_set_egs_oam_valid(gport, enable));
        break;

    case CTC_BOTH_DIRECTION:
        CTC_ERROR_RETURN(sys_humber_port_set_igs_oam_valid(gport, enable));
        CTC_ERROR_RETURN(sys_humber_port_set_egs_oam_valid(gport, enable));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief   set max md level on this port
*/
int32
sys_humber_eth_oam_set_port_max_level(uint16 gport, ctc_direction_t dir, uint8 level)
{
    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x\n", gport);

    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)
    if (CTC_IS_LINKAGG_PORT(gport))
    {
        return CTC_E_INVALID_GLOBAL_PORT;
    }

    /* md level check */
    if (level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    /* call the sys interface from port module */
    switch (dir)
    {
    case CTC_INGRESS:
        CTC_ERROR_RETURN(sys_humber_port_set_igs_oam_max_md_level(gport, level));
        break;

    case CTC_EGRESS:
        CTC_ERROR_RETURN(sys_humber_port_set_egs_oam_max_md_level(gport, level));
        break;

    case CTC_BOTH_DIRECTION:
        CTC_ERROR_RETURN(sys_humber_port_set_igs_oam_max_md_level(gport, level));
        CTC_ERROR_RETURN(sys_humber_port_set_egs_oam_max_md_level(gport, level));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief   set if tunnel enabled or not on this port
*/
int32
sys_humber_eth_oam_set_port_tunnel_en(uint16 gport, bool enable)
{
    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK
    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, enable=0x%x\n", gport, enable);

    if (CTC_IS_LINKAGG_PORT(gport))
    {
        return CTC_E_INVALID_GLOBAL_PORT;
    }

    /* call the sys interface from port module */
    CTC_ERROR_RETURN(sys_humber_port_set_oam_tunnel_en(gport, enable));

    return CTC_E_NONE;
}

/**
 @brief   set max md level on vlan
*/
int32
sys_humber_eth_oam_set_vlan_max_level(uint16 vlan_id, ctc_direction_t dir, uint8 level)
{
    sys_vlan_info_t vlan_info;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("vlan_id=0x%x, dirt=0x%x, level=0x%x\n", vlan_id, dir, level);

    /* md level check */
    if (level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    /* call the sys interface from vlan module */
    sal_memset(&vlan_info, 0, sizeof(vlan_info));
    vlan_info.vlan_ptr_type = SYS_VLAN_PTR_TYPE_VID;
    vlan_info.vid = vlan_id;

    switch (dir)
    {
    case CTC_INGRESS:
        CTC_ERROR_RETURN(sys_humber_vlan_set_md_level(&vlan_info, level));
        break;

    case CTC_EGRESS:
        CTC_ERROR_RETURN(sys_humber_vlan_set_egress_md_level(&vlan_info, level));
        break;

    case CTC_BOTH_DIRECTION:
        CTC_ERROR_RETURN(sys_humber_vlan_set_md_level(&vlan_info, level));
        CTC_ERROR_RETURN(sys_humber_vlan_set_egress_md_level(&vlan_info, level));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief   set ethernet oam enabled or not on vlan
*/
int32
sys_humber_eth_oam_set_vlan_oam_en(uint16 vlan_id, ctc_direction_t dir, bool enable)
{
    sys_vlan_info_t vlan_info;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("vlan_id=0x%x, dir=0x%x, enable=0x%x\n", vlan_id, dir, enable);

    /* call the sys interface from vlan module */
    sal_memset(&vlan_info, 0, sizeof(vlan_info));
    vlan_info.vlan_ptr_type = SYS_VLAN_PTR_TYPE_VID;
    vlan_info.vid = vlan_id;

    switch (dir)
    {
    case CTC_INGRESS:
        CTC_ERROR_RETURN(sys_humber_vlan_set_ether_oam_valid(&vlan_info, enable));
        break;

    case CTC_EGRESS:
        CTC_ERROR_RETURN(sys_humber_vlan_set_egress_ether_oam_valid(&vlan_info, enable));
        break;

    case CTC_BOTH_DIRECTION:
        CTC_ERROR_RETURN(sys_humber_vlan_set_ether_oam_valid(&vlan_info, enable));
        CTC_ERROR_RETURN(sys_humber_vlan_set_egress_ether_oam_valid(&vlan_info, enable));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief   set ethernet oam's md level on edge port
*/
int32
sys_humber_eth_oam_config_edge_port(uint16 gport, uint8 level)
{
    uint8 lchip = 0;
    uint8 local_chip_num  = 0;

    ctc_oam_key_t oam_key;
    sys_eth_oam_key_t passive_chan_key;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_humber_opf_t opf;

#define ROLL_BACK_MEM_ALLOC \
    { \
        mem_free(sys_chan); \
        OAM_UNLOCK; \
    }

#define ROLL_BACK_BUILD_INDEX_MEM_ALLOC \
    { \
        _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan); \
        mem_free(sys_chan); \
        OAM_UNLOCK; \
    }

#define ROLL_BACK_INSERT_EDGE_CHAN_DB \
    { \
        _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan); \
        _sys_humber_eth_oam_free_chan_key_index_and_type(lchip, sys_chan); \
        mem_free(sys_chan); \
        OAM_UNLOCK; \
    }

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, level=0x%x\n", gport, level);

    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)

    /* md level check */
    if (level > SYS_HUMBER_OAM_MAX_MD_LEVEL)
    {
        return CTC_E_OAM_INVALID_MD_LEVEL;
    }

    sal_memset(&oam_key, 0, sizeof(ctc_oam_key_t));
    oam_key.u.eth.gport   = gport;
    oam_key.u.eth.vlan_id = 0;
    CTC_SET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);

    sal_memset(&passive_chan_key, 0, sizeof(sys_eth_oam_key_t));
    passive_chan_key.gport     = gport;
    passive_chan_key.vlan_id   = 0; /* mask this field */
    passive_chan_key.direction = 1; /*always is up mep */
    passive_chan_key.link_oam  = 0;

    OAM_LOCK;
    if (CTC_IS_LINKAGG_PORT(gport)) /* config passive up mep chan all local chip */
    {
        local_chip_num = sys_humber_get_local_chip_num();

        for (lchip = 0; lchip < local_chip_num; lchip++)
        {
            sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(oam_key));
            if (!sys_chan) /* chan not found, insert new */
            {
                sys_chan = (sys_eth_oam_lmep_lkup_chan_t*)mem_malloc(MEM_OAM_MODULE, sizeof(sys_eth_oam_lmep_lkup_chan_t));
                if (!sys_chan)
                {
                    SYS_OAM_DBG_INFO("no new memory for sys chan in line %d\n", __LINE__);
                    OAM_UNLOCK;
                    return CTC_E_NO_MEMORY;
                }

                sal_memset(sys_chan, 0, sizeof(sys_eth_oam_lmep_lkup_chan_t));

                /* build tcam key */
                sys_chan->asic_index_type = SYS_HUMBER_OAM_ASIC_TCAM;
                opf.pool_type  = OPF_OAM_TCAM_KEY;
                opf.pool_index = lchip;

                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(sys_humber_opf_alloc_offset(&opf, 1, &sys_chan->asic_key_index), ROLL_BACK_MEM_ALLOC);

                sal_memcpy(&(sys_chan->lmep_chan_key), &(passive_chan_key), sizeof(sys_eth_oam_key_t));

                /* insert this chan to db */
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_chan_to_db(lchip, sys_chan), ROLL_BACK_BUILD_INDEX_MEM_ALLOC);

                /* write this chan's key and associate table */
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_edge_port_chan_and_key_to_asic(lchip, sys_chan, level), ROLL_BACK_INSERT_EDGE_CHAN_DB);
            }
            else
            {
                /* overwrite this chan's key and associate table */
                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_edge_port_chan_and_key_to_asic(lchip, sys_chan, level), OAM_UNLOCK);
            }
        }
    }
    else /* config passive up mep chan on local chip */
    {
        if (!sys_humber_chip_is_local(SYS_MAP_GPORT_TO_GCHIP(gport), &lchip))
        {
            OAM_UNLOCK;
            return CTC_E_CHIP_IS_REMOTE;
        }

        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(oam_key));
        if (!sys_chan) /* chan not found, insert new */
        {
            sys_chan = (sys_eth_oam_lmep_lkup_chan_t*)mem_malloc(MEM_OAM_MODULE, sizeof(sys_eth_oam_lmep_lkup_chan_t));
            if (!sys_chan)
            {
                SYS_OAM_DBG_INFO("no new memory for sys chan in line %d\n", __LINE__);
                OAM_UNLOCK;
                return CTC_E_NO_MEMORY;
            }

            sal_memset(sys_chan, 0, sizeof(sys_eth_oam_lmep_lkup_chan_t));

            /* build tcam key */
            sys_chan->asic_index_type = SYS_HUMBER_OAM_ASIC_TCAM;
            opf.pool_type  = OPF_OAM_TCAM_KEY;
            opf.pool_index = lchip;

            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(sys_humber_opf_alloc_offset(&opf, 1, &sys_chan->asic_key_index), mem_free(sys_chan));

            sal_memcpy(&(sys_chan->lmep_chan_key), &(passive_chan_key), sizeof(sys_eth_oam_key_t));

            /* insert this chan to db */
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_chan_to_db(lchip, sys_chan), ROLL_BACK_BUILD_INDEX_MEM_ALLOC);

            /* write this chan's key and associate table */
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_edge_port_chan_and_key_to_asic(lchip, sys_chan, level), ROLL_BACK_INSERT_EDGE_CHAN_DB);
        }
        else
        {
            /* write this chan's key and associate table */
            SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_add_edge_port_chan_and_key_to_asic(lchip, sys_chan, level), OAM_UNLOCK);
        }
    }

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   remove edge port configuration
*/
int32
sys_humber_eth_oam_remove_edge_port(uint16 gport)
{
    uint8 lchip = 0;
    uint8 local_chip_num  = 0;
    ctc_oam_key_t oam_key;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_humber_opf_t opf;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x\n", gport);

    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)

    sal_memset(&oam_key, 0, sizeof(ctc_oam_key_t));
    oam_key.u.eth.gport   = gport;
    oam_key.u.eth.vlan_id = 0;
    CTC_SET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);

    OAM_LOCK;
    if (CTC_IS_LINKAGG_PORT(gport)) /* remove passive up mep chan all local chip */
    {
        local_chip_num = sys_humber_get_local_chip_num();

        for (lchip = 0; lchip < local_chip_num; lchip++)
        {
            sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(oam_key));
            if (!sys_chan) /* chan not found, continue */
            {
                continue;
            }
            else
            {
                /* remove chan from asic */
                _sys_humber_eth_oam_remove_edge_port_chan_and_key_from_asic(lchip, sys_chan);

                /* free tcam opf */
                opf.pool_type  = OPF_OAM_TCAM_KEY;
                opf.pool_index = lchip;
                sys_humber_opf_free_offset(&opf, 1, sys_chan->asic_key_index);

                /* delete this chan from db */
                _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
                mem_free(sys_chan);
            }
        }
    }
    else /* remove passive up mep chan on local chip */
    {
        if (!sys_humber_chip_is_local(SYS_MAP_GPORT_TO_GCHIP(gport), &lchip))
        {
            OAM_UNLOCK;
            return CTC_E_CHIP_IS_REMOTE;
        }

        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(oam_key));
        if (!sys_chan) /* chan not found, insert new */
        {
            OAM_UNLOCK;
            return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
        }
        else
        {
            /* remove chan from asic */
            _sys_humber_eth_oam_remove_edge_port_chan_and_key_from_asic(lchip, sys_chan);

            /* free tcam opf */
            opf.pool_type  = OPF_OAM_TCAM_KEY;
            opf.pool_index = lchip;
            sys_humber_opf_free_offset(&opf, 1, sys_chan->asic_key_index);

            /* delete this chan from db */
            _sys_humber_eth_oam_remove_chan_from_db(lchip, sys_chan);
            mem_free(sys_chan);
        }
    }

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   set mep's tx cos
*/
int32
sys_humber_eth_oam_set_mep_tx_cos(ctc_oam_update_t* p_lmep, uint8 cos)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    if (cos > 7)
    {
        return CTC_E_OAM_INVALID_MEP_COS;
    }

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    /* update asic table for lmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_lmep_tx_cos_in_asic(lchip, sys_lmep, cos), OAM_UNLOCK);

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   update all mep's port status
*/
int32
sys_humber_eth_oam_update_port_status(uint16 gport, uint16 vlan_id, ctc_oam_eth_port_status_t port_status)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    ctc_oam_key_t oam_key;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep = NULL;
    ctc_slistnode_t* slist_node = NULL;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan_id=%d, port_status=%d\n", gport, vlan_id, port_status);

    /* gport and vlan id check */
    CTC_GLOBAL_PORT_CHECK(gport)
    CTC_ERROR_RETURN(sys_humber_vlan_range_check_under_mode(vlan_id));

    sal_memset(&oam_key, 0, sizeof(ctc_oam_key_t));
    oam_key.u.eth.gport   = gport;
    oam_key.u.eth.vlan_id = vlan_id;

    local_chip_num = sys_humber_get_local_chip_num();
    OAM_LOCK;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        /*Down Mep*/
        CTC_UNSET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &oam_key);
        if (sys_chan && sys_chan->lmep_list)
        {
            CTC_SLIST_LOOP(sys_chan->lmep_list, slist_node)
            {
                sys_lmep = _ctc_container_of(slist_node, sys_eth_oam_lmep_t, head);

                if (sys_lmep->mep_on_cpu)
                {
                    continue;
                }

                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_mep_port_status_in_asic(lchip, sys_lmep->ma_index, port_status), OAM_UNLOCK);
            }
        }

        /*UP Mep*/
        CTC_SET_FLAG(oam_key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
        sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &oam_key);
        if (sys_chan && sys_chan->lmep_list)
        {
            CTC_SLIST_LOOP(sys_chan->lmep_list, slist_node)
            {
                sys_lmep = _ctc_container_of(slist_node, sys_eth_oam_lmep_t, head);

                if (sys_lmep->mep_on_cpu)
                {
                    continue;
                }

                SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_mep_port_status_in_asic(lchip, sys_lmep->ma_index, port_status), OAM_UNLOCK);
            }
        }
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   update all mep's interface status
*/
int32
sys_humber_eth_oam_update_interface_status(uint16 gport, ctc_oam_eth_interface_status_t intf_status)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    sys_eth_oam_lmep_intf_status_t sys_intf_status;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, intf_status=%d\n", gport, intf_status);

    /* gport check */
    CTC_GLOBAL_PORT_CHECK(gport)

    sys_intf_status.gport = gport;
    sys_intf_status.intf_status = intf_status;

    local_chip_num = sys_humber_get_local_chip_num();

    OAM_LOCK;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sys_intf_status.lchip = lchip;

        /* search all the sys_lmep for channel with gport and vlan_id */
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(ctc_hash_traverse(SYS_HUMBER_ETH_OAM_MASTER->lmep_lkup_chan_hash[lchip], _sys_humber_eth_oam_tranvers_hash_and_set_interface_status, &sys_intf_status), OAM_UNLOCK);
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   clear lmep's defect status
*/
int32
sys_humber_eth_oam_clear_lmep_rdi(ctc_oam_update_t* p_lmep)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    uint32 d_loc = 0;
    uint32 cmd   = 0;
    sys_eth_oam_rmep_t* sys_rmep   = NULL;
    ctc_slistnode_t* ctc_slistnode = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_lmep);

    gport         = p_lmep->key.u.eth.gport;
    vlan_id       = p_lmep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_lmep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_lmep->key.u.eth.md_level);

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_lmep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_lmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_lmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    /* check all the rmep d_loc defect status */
    if (!sys_lmep->rmep_list)
    {
        OAM_UNLOCK;
        return CTC_E_NONE;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_ETH_RMEP, DS_ETH_RMEP_D_LOC);

    for (ctc_slistnode = sys_lmep->rmep_list->head; ctc_slistnode; ctc_slistnode = ctc_slistnode->next)
    {
        sys_rmep = _ctc_container_of(ctc_slistnode, sys_eth_oam_rmep_t, head);
        SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(drv_tbl_ioctl(lchip, sys_rmep->rmep_index, cmd, &d_loc), OAM_UNLOCK);
        if (d_loc)
        {
            OAM_UNLOCK;
            return CTC_E_OAM_RMEP_D_LOC_PRESENT;
        }
    }

    /* update asic table for lmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_clear_lmep_rdi_in_asic(lchip, sys_lmep), OAM_UNLOCK);

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   show chan related indexes
*/
int32
sys_oam_cfm_show_chan_index(ctc_oam_key_t* oam_key)
{
    uint8 lchip = 0;
    uint8 level = 0;
    uint32 chan_index = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;
    ctc_slistnode_t* ctc_slistnode         = NULL;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter */
    CTC_PTR_VALID_CHECK(oam_key)
    CTC_GLOBAL_PORT_CHECK(oam_key->u.eth.gport);

    /*CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(chan_key, &lchip));*/

    OAM_LOCK;
    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, oam_key);
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    SYS_OAM_DBG_DUMP("sys_chan->asic_key_index: %d, sys_chan->asic_index_type: %d\n", sys_chan->asic_key_index, sys_chan->asic_index_type);
    chan_index = _sys_humber_eth_oam_get_associated_chan_index(sys_chan->asic_key_index, sys_chan->asic_index_type);
    SYS_OAM_DBG_DUMP("Chan key index: 0x%x, key tpye: 0x%x, associated chan index: 0x%x\n", sys_chan->asic_key_index, sys_chan->asic_index_type, chan_index);

    /* lookup local mep in sys chan */
    for (level = 0; level < 8; level++)
    {
        sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, level);
        if (sys_lmep)
        {
            SYS_OAM_DBG_DUMP("  Level %d: lmep index 0x%x, ma index 0x%x\n", level, sys_lmep->mep_index, sys_lmep->ma_index);

            /* lookup rmep list in the locam mep */
            if (sys_lmep->rmep_list)
            {
                for (ctc_slistnode = sys_lmep->rmep_list->head; ctc_slistnode; ctc_slistnode = ctc_slistnode->next)
                {
                    sys_rmep = _ctc_container_of(ctc_slistnode, sys_eth_oam_rmep_t, head);
                    SYS_OAM_DBG_DUMP("    rmep index 0x%x, rmep id 0x%x\n", sys_rmep->rmep_index, sys_rmep->rmep_id);
                }
            }
        }
    }

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set aps signal fail state for local mep or its related remote mep
*/
int32
sys_humber_eth_oam_set_aps_signal_fail_state(ctc_oam_update_t* p_update_mep, sys_oam_signal_fail_mep_type_t mep_type, bool state)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;

    uint8  is_up        = 0;
    uint8  is_link_oam  = 0;
    uint16 gport        = 0;
    uint16 vlan_id      = 0;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_update_mep);

    gport         = p_update_mep->key.u.eth.gport;
    vlan_id       = p_update_mep->key.u.eth.vlan_id;
    is_up         = CTC_FLAG_ISSET(p_update_mep->key.flag, CTC_OAM_KEY_FLAG_UP_MEP);
    is_link_oam   = CTC_FLAG_ISSET(p_update_mep->key.flag, CTC_OAM_KEY_FLAG_LINK_SECTION_OAM);

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("gport=0x%x, vlan=%d, dir=%d, link_oam=%d, level=%d\n", gport, vlan_id,
                     is_up, is_link_oam, p_update_mep->key.u.eth.md_level);

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_update_mep->key, &lchip));

    OAM_LOCK;
    /* sys chan lookup */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_update_mep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* search the lmep list in chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_update_mep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    MEP_INDEX_ON_CPU_CHECK(sys_lmep)

    /* update asic table for lmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_set_aps_signal_fail_state_in_asic(lchip, sys_lmep, mep_type, state), OAM_UNLOCK);

    OAM_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief   get eth oam rmep's mac addr in hardware
*/
int32
sys_humber_eth_oam_get_rmep_mac_addr(ctc_oam_rmep_t* p_rmep, mac_addr_t rmep_mac_addr)
{
    uint8 lchip = 0;
    sys_eth_oam_lmep_lkup_chan_t* sys_chan = NULL;
    sys_eth_oam_lmep_t* sys_lmep           = NULL;
    sys_eth_oam_rmep_t* sys_rmep           = NULL;

    ctc_oam_y1731_rmep_t eth_rmep;

    /* check if eth oam has inited */
    SYS_HUMBER_ETH_OAM_INIT_CHECK

    /* check input paramter pointer */
    CTC_PTR_VALID_CHECK(p_rmep)
    CTC_PTR_VALID_CHECK(rmep_mac_addr)

    sal_memset(&eth_rmep, 0, sizeof(eth_rmep));

    SYS_OAM_DBG_FUNC();
    SYS_OAM_DBG_INFO("level=%d\n", p_rmep->key.u.eth.md_level);

    CTC_ERROR_RETURN(_sys_humber_oam_get_local_chip_for_chan(&p_rmep->key, &lchip));

    OAM_LOCK;
    /* lookup the sys chan */
    sys_chan = _sys_humber_eth_oam_get_sys_chan_in_db(lchip, &(p_rmep->key));
    if (!sys_chan)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_ENTRY_NOT_FOUND;
    }

    /* lookup local mep in sys chan */
    sys_lmep = _sys_humber_eth_oam_get_lmep_in_sys_chan_with_level(sys_chan, p_rmep->key.u.eth.md_level);
    if (!sys_lmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_CHAN_LMEP_NOT_FOUND;
    }

    /* lookup rmep list in the locam mep */
    eth_rmep.rmep_id = p_rmep->u.y1731_rmep.rmep_id;
    sys_rmep = _sys_humber_eth_oam_get_rmep_in_lmep(sys_lmep, &eth_rmep);
    if (!sys_rmep)
    {
        OAM_UNLOCK;
        return CTC_E_OAM_RMEP_NOT_FOUND;
    }

    /* get asic table for rmep */
    SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(_sys_humber_eth_oam_get_rmep_mac_addr_in_asic(lchip, sys_rmep, rmep_mac_addr), OAM_UNLOCK);

    OAM_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief   set if all oam pkt to cpu
*/
int32
sys_humber_oam_set_relay_all_pkt_to_cpu(bool enable)
{
    uint8 lchip  = 0;
    uint8 local_chip_num = 0;
    uint32 cmd           = 0;
    uint32 field_value = 0;

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        if (enable)
        {
            field_value = 1;
        }
        else
        {
            field_value = 0;
        }

        cmd = DRV_IOW(IOC_REG, OAM_HDR_ADJUST_CTL, OAM_HDR_ADJUST_CTL_RELAY_ALL_TO_CPU);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));
    }

    return CTC_E_NONE;
}

/**
 @brief   set oam tx tpid
*/
int32
sys_humber_oam_set_tx_vlan_tpid(uint8 tpid_index, uint16 tpid)
{
    uint8 lchip  = 0;
    uint8 local_chip_num = 0;
    uint32 cmd           = 0;
    oam_tx_proc_ether_ctl_t oam_tx_proc_ether_ctl;

    if (tpid_index > 1)
    {
        return CTC_E_OAM_INVALID_MEP_TPID_INDEX;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        cmd = DRV_IOR(IOC_REG, OAM_TX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_tx_proc_ether_ctl));

        switch (tpid_index)
        {
        case 0:
            oam_tx_proc_ether_ctl.tpid0      = tpid;
            break;

        case 1:
            oam_tx_proc_ether_ctl.tpid1      = tpid;
            break;

        case 2:
            oam_tx_proc_ether_ctl.tpid2      = tpid;
            break;

        case 3:
            oam_tx_proc_ether_ctl.tpid3      = tpid;
            break;

        default:
            break;
        }

        cmd = DRV_IOW(IOC_REG, OAM_TX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_tx_proc_ether_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief   get oam tx tpid
*/
int32
sys_humber_oam_get_tx_vlan_tpid(uint8 tpid_index,       uint16* tpid)
{
    uint32 cmd = 0;
    oam_tx_proc_ether_ctl_t oam_tx_proc_ether_ctl;

    if (tpid_index > 3)
    {
        return CTC_E_OAM_INVALID_MEP_TPID_INDEX;
    }

    cmd = DRV_IOR(IOC_REG, OAM_TX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &oam_tx_proc_ether_ctl));

    switch (tpid_index)
    {
    case 0:
        *tpid = oam_tx_proc_ether_ctl.tpid0;
        break;

    case 1:
        *tpid = oam_tx_proc_ether_ctl.tpid1;
        break;

    case 2:
        *tpid = oam_tx_proc_ether_ctl.tpid2;
        break;

    case 3:
        *tpid = oam_tx_proc_ether_ctl.tpid3;
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief   set oam rx tpid
*/
int32
sys_humber_oam_set_rx_vlan_tpid(uint8 tpid_index, uint16 tpid)
{
    uint8 lchip  = 0;
    uint8 local_chip_num = 0;
    uint32 cmd           = 0;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    if (tpid_index > 1)
    {
        return CTC_E_OAM_INVALID_MEP_TPID_INDEX;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        cmd = DRV_IOR(IOC_REG, OAM_PARSER_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_parser_ether_ctl));

        switch (tpid_index)
        {
        case 0:
            oam_parser_ether_ctl.svlan_tpid0      = tpid;
            break;

        case 1:
            oam_parser_ether_ctl.cvlan_tpid       = tpid;
            break;

        default:
            break;
        }

        cmd = DRV_IOW(IOC_REG, OAM_PARSER_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_parser_ether_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief   get oam rx tpid
*/
int32
sys_humber_oam_get_rx_vlan_tpid(uint8 tpid_index, uint16* tpid)
{
    uint32 cmd = 0;
    oam_parser_ether_ctl_t oam_parser_ether_ctl;

    if (tpid_index > 3)
    {
        return CTC_E_OAM_INVALID_MEP_TPID_INDEX;
    }

    cmd = DRV_IOR(IOC_REG, OAM_PARSER_ETHER_CTL, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &oam_parser_ether_ctl));

    switch (tpid_index)
    {
    case 0:
        *tpid = oam_parser_ether_ctl.svlan_tpid0;
        break;

    case 1:
        *tpid = oam_parser_ether_ctl.cvlan_tpid;
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_humber_eth_oam_set_property(ctc_oam_property_t* p_prop)
{
    ctc_oam_y1731_prop_t* p_eth_prop   = NULL;
    ctc_oam_com_property_t* p_common = NULL;

    SYS_OAM_DBG_FUNC();

    CTC_PTR_VALID_CHECK(p_prop);

    if (CTC_OAM_PROPERTY_TYPE_COMMON == p_prop->oam_pro_type)
    {
        p_common = &p_prop->u.common;

        switch (p_common->cfg_type)
        {
        case CTC_OAM_COM_PRO_TYPE_DEFECT_TO_RDI:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_rdi_enable_defect_bitmap(p_common->value));
            break;

        case CTC_OAM_COM_PRO_TYPE_EXCEPTION_TO_CPU:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_exception_to_cpu(p_common->value));
            break;

        case CTC_OAM_COM_PRO_TYPE_TRIG_APS_MSG:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_aps_msg(p_common->value));
            break;

        default:
            return CTC_E_NOT_SUPPORT;
        }
    }
    else
    {
        p_eth_prop = &p_prop->u.y1731;

        switch (p_eth_prop->cfg_type)
        {
        case CTC_OAM_Y1731_CFG_TYPE_PORT_OAM_EN:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_set_port_oam_en(p_eth_prop->gport, p_eth_prop->dir, p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_PORT_TUNNEL_EN:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_set_port_tunnel_en(p_eth_prop->gport, p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_ALL_TO_CPU:
            CTC_ERROR_RETURN(
                sys_humber_oam_set_relay_all_pkt_to_cpu(p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_TX_VLAN_TPID:
            CTC_ERROR_RETURN(
                sys_humber_oam_set_tx_vlan_tpid((p_eth_prop->value >> 16) & 0xFF, p_eth_prop->value & 0xFFFF));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_RX_VLAN_TPID:
            CTC_ERROR_RETURN(
                sys_humber_oam_set_rx_vlan_tpid((p_eth_prop->value >> 16) & 0xFF, p_eth_prop->value & 0xFFFF));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_VLAN_OAM_EN:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_set_vlan_oam_en(p_eth_prop->vlan_id, p_eth_prop->dir,
                                                   p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_VLAN_MAX_LEVEL:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_set_vlan_max_level(p_eth_prop->vlan_id, p_eth_prop->dir,
                                                      p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_PORT_MAX_LEVEL:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_set_port_max_level(p_eth_prop->gport, p_eth_prop->dir,
                                                      p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_ADD_EDGE_PORT:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_config_edge_port(p_eth_prop->gport, p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_REMOVE_EDGE_PORT:
            CTC_ERROR_RETURN(
                sys_humber_eth_oam_remove_edge_port(p_eth_prop->gport));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_BIG_CCM_INTERVAL_TO_CPU:
            CTC_ERROR_RETURN(
                _sys_humber_eth_oam_set_larger_ccm_interval_in_asic(p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_SENDER_ID:
            {
                ctc_oam_eth_senderid_t* p_sender_id = NULL;
                p_sender_id = (ctc_oam_eth_senderid_t*)p_eth_prop->p_value;
                CTC_ERROR_RETURN(_sys_humber_eth_oam_set_sender_id_in_asic(p_sender_id));
                break;
            }

        case CTC_OAM_Y1731_CFG_TYPE_BRIDGE_MAC:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_bridge_mac_in_asic(p_eth_prop->p_value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_LBM_PROC_IN_ASIC:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_lbm_proc_in_asic(p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_LBR_SA_USE_LBM_DA:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_lbr_sa_use_da_in_asic(p_eth_prop->value));
            break;

        case CTC_OAM_Y1731_CFG_TYPE_LBR_SA_SHARE_MAC:
            CTC_ERROR_RETURN(_sys_humber_eth_oam_set_lbr_sa_bridge_mac_mode_in_asic(p_eth_prop->value));
            break;

        default:
            return CTC_E_NOT_SUPPORT;
        }
    }

    return CTC_E_NONE;
}

int32
sys_humber_eth_oam_update_lmep(ctc_oam_update_t* lmep)
{
    bool enable = FALSE;

    CTC_PTR_VALID_CHECK(lmep);

    switch (lmep->update_type)
    {
    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_MEP_EN:
        enable = lmep->update_value ? TRUE : FALSE;
        CTC_ERROR_RETURN(sys_humber_eth_oam_enable_mep(lmep, enable));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_CCM_EN:
        enable = lmep->update_value ? TRUE : FALSE;
        CTC_ERROR_RETURN(sys_humber_eth_oam_enable_ccm(lmep, enable));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_DM_EN:
        enable = lmep->update_value ? TRUE : FALSE;
        CTC_ERROR_RETURN(sys_humber_eth_oam_enable_dm(lmep, enable));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_TX_COS_EXP:
        CTC_ERROR_RETURN(sys_humber_eth_oam_set_mep_tx_cos(lmep, lmep->update_value));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_PORT_STATUS:

        CTC_ERROR_RETURN(sys_humber_eth_oam_update_port_status(lmep->key.u.eth.gport,
                                                               lmep->key.u.eth.vlan_id,
                                                               lmep->update_value));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_IF_STATUS:
        CTC_ERROR_RETURN(sys_humber_eth_oam_update_interface_status(lmep->key.u.eth.gport,
                                                                    lmep->update_value));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_RDI:
        CTC_ERROR_RETURN(sys_humber_eth_oam_clear_lmep_rdi(lmep));

        break;

    case CTC_OAM_Y1731_LMEP_UPDATE_TYPE_LMEP_SF_STATE:
        CTC_ERROR_RETURN(sys_humber_eth_oam_set_aps_signal_fail_state(lmep,
                                                                      SYS_ETH_OAM_LOCAL_MEP,
                                                                      lmep->update_value));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_humber_eth_oam_update_rmep(ctc_oam_update_t* rmep)
{
    bool enable = FALSE;

    CTC_PTR_VALID_CHECK(rmep);

    switch (rmep->update_type)
    {
    case CTC_OAM_Y1731_RMEP_UPDATE_TYPE_MEP_EN:
        enable = rmep->update_value ? TRUE : FALSE;
        CTC_ERROR_RETURN(sys_humber_eth_oam_enable_rmep(rmep, enable));
        break;

    case CTC_OAM_Y1731_RMEP_UPDATE_TYPE_SEQ_FAIL_CLEAR:
        CTC_ERROR_RETURN(sys_humber_eth_oam_clear_rmep_seq_num_fail_counter(rmep));
        break;

    case CTC_OAM_Y1731_RMEP_UPDATE_TYPE_RMEP_SF_STATE:
        CTC_ERROR_RETURN(sys_humber_eth_oam_set_aps_signal_fail_state(rmep,
                                                                      SYS_ETH_OAM_REMOTE_MEP,
                                                                      rmep->update_value));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

