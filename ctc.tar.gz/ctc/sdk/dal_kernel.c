/**
 @file dal_kernal.c

 @date 2012-10-18

 @version v2.0


*/
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/types.h>
#include <asm/io.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <asm/irq.h>
#include <linux/poll.h>
#include <linux/wait.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>
#include <linux/rtnetlink.h>
#include <linux/bug.h>

#include "dal_kernel.h"
#include "dal_mpool.h"
#include "dal.h"

MODULE_AUTHOR("Centec Networks Inc.");
MODULE_DESCRIPTION("DAL kernel module");
MODULE_LICENSE("GPL");

/* DMA memory pool size */
static char* dma_pool_size;
static dal_access_type_t g_dal_access = DAL_PCIE_MM;

module_param(dma_pool_size, charp, 0);
MODULE_PARM_DESC(dma_pool_size,
                 "Specify DMA memory pool size (default 4MB)");

dal_op_t g_dal_op =
{
    pci_read: dal_pci_read,
    pci_write: dal_pci_write,
    pci_conf_read: dal_pci_conf_read,
    pci_conf_write: dal_pci_conf_write,
    i2c_read: NULL,
    i2c_write: NULL,
    interrupt_register: dal_interrupt_register,
    interrupt_unregister: dal_interrupt_unregister,
    interrupt_set_en: dal_interrupt_set_en,
    interrupt_set_msi_cap: dal_kernel_set_msi_enable,
    logic_to_phy: dal_logic_to_phy,
    phy_to_logic: dal_phy_to_logic,
    dma_alloc: dal_dma_alloc,
    dma_free: dal_dma_free,
};

/*****************************************************************************
 * defines
 *****************************************************************************/
#define MB_SIZE 0x100000
#define CTC_MAX_INTR_NUM 6

#define MEM_MAP_RESERVE SetPageReserved
#define MEM_MAP_UNRESERVE ClearPageReserved

#define CTC_VENDOR_VID 0xc001
#define CTC_GREATBELT_DEVICE_ID 0x03e8

#define MEM_MAP_RESERVE SetPageReserved
#define MEM_MAP_UNRESERVE ClearPageReserved

#define CTC_POLL_INTERRUPT_STR "poll_intr"
#define DAL_MAX_CHIP_NUM   2                   /* [GB] used */
#define VIRT_TO_PAGE(p)     virt_to_page((p))
#define DAL_UNTAG_BLOCK         0
#define DAL_DISCARD_BLOCK      1
#define DAL_MATCHED_BLOCK     2
#define DAL_CUR_MATCH_BLOCk 3

#define M_INTR_HANDLER_IMPLEMENT(idx) static irqreturn_t \
intr##idx##_handler(int irq, void* dev_id) \
{ \
    int irq_idx = idx; \
    disable_irq_nosync(irq); \
    sal_sem_give(dal_isr[idx].p_inr_sem);  \
    return IRQ_HANDLED; \
}


/*****************************************************************************
 * typedef
 *****************************************************************************/
/* Control Data */
typedef struct dal_adapter {
    struct net_device *dev;
} dal_adapter_t;

typedef struct dal_isr_s
{
    int irq;
    void (* isr)(void*);
    void* isr_data;
    int trigger;
    wait_queue_head_t wqh;
    sal_sem_t*  p_inr_sem;
    sal_task_t*  p_intr_thread;
} dal_isr_t;

struct dal_intr_para_s
{
    int16 intr_idx;
    int16 prio;
};
typedef struct dal_intr_para_s dal_intr_para_t;

typedef struct dal_kernel_dev_s
{
    struct list_head list;
    struct pci_dev* pci_dev;

    /* PCI I/O mapped base address */
    uintptr logic_address;

    /* Physical address */
    uintptr phys_address;
} dal_kern_dev_t;

typedef struct _dma_segment
{
    struct list_head list;
    unsigned long req_size;     /* Requested DMA segment size */
    unsigned long blk_size;     /* DMA block size */
    unsigned long blk_order;    /* DMA block size in alternate format */
    unsigned long seg_size;     /* Current DMA segment size */
    unsigned long seg_begin;    /* Logical address of segment */
    unsigned long seg_end;      /* Logical end address of segment */
    unsigned long* blk_ptr;     /* Array of logical DMA block addresses */
    int blk_cnt_max;            /* Maximum number of block to allocate */
    int blk_cnt;                /* Current number of blocks allocated */
} dma_segment_t;

typedef irqreturn_t (*p_func) (int irq, void* dev_id);

/***************************************************************************
 *declared
 ***************************************************************************/

/*****************************************************************************
 * global variables
 *****************************************************************************/
static dal_kern_dev_t dal_dev[DAL_MAX_CHIP_NUM];
static dal_isr_t dal_isr[CTC_MAX_INTR_NUM];
static int dal_chip_num = 0;
static int dal_intr_num = 0;
static int use_high_memory = 0;
static dal_mpool_mem_t* dma_pool = NULL;
static unsigned int* dma_virt_base = NULL;
static uintptr dma_phy_base = 0;
static unsigned int dma_mem_size = 0x800000;
static unsigned int msi_irq_base = 0;
static unsigned int msi_irq_num = 0;
static unsigned int msi_used = 0;
static dal_adapter_t *dal_adpt = NULL;

static LIST_HEAD(_dma_seg);
static int dal_debug = 0;
module_param(dal_debug, int, 0);
MODULE_PARM_DESC(dal_debug, "Set debug level (default 0)");

static struct pci_device_id dal_id_table[] =
{
    {PCI_DEVICE(CTC_VENDOR_VID, CTC_GREATBELT_DEVICE_ID)},
	{PCI_DEVICE(0xcb10, 0xc010)},
    {0, },
};

p_func intr_handler_fun[CTC_MAX_INTR_NUM];

M_INTR_HANDLER_IMPLEMENT(0);
M_INTR_HANDLER_IMPLEMENT(1);
M_INTR_HANDLER_IMPLEMENT(2);
M_INTR_HANDLER_IMPLEMENT(3);
M_INTR_HANDLER_IMPLEMENT(4);
M_INTR_HANDLER_IMPLEMENT(5);

/*****************************************************************************
 * macros
 *****************************************************************************/
#define VERIFY_CHIP_INDEX(n)  (n < dal_chip_num)

#define _KERNEL_INTERUPT_PROCESS

int32_t
dal_op_init(dal_op_t* p_dal_op)
{
    /*kernel mode */
    unsigned char op_cnt = 0;
    unsigned char index = 0;

    op_cnt = sizeof(dal_op_t)/4;

    /* if dal op is provided by user , using user defined */
    if (p_dal_op)
    {
        for (index = 0; index < op_cnt; index++)
        {
            if (*((u_int32_t*)p_dal_op + index))
            {
                *((u_int32_t*)&g_dal_op + index) = *((u_int32_t*)p_dal_op + index);
            }
        }
    }

    dal_mpool_init();

    return DAL_E_NONE;
}

/* interrupt thread */
static void
dal_intr_thread(void* param)
{
    unsigned int para = (uintptr)param;
    dal_intr_para_t* p_para = (dal_intr_para_t*)&para;
    int32 ret = 0;
    int32 intr_idx = 0;
    dal_isr_t* intr_handler = NULL;
    intr_idx = p_para->intr_idx;
    intr_handler = (dal_isr_t*)&(dal_isr[intr_idx]);

    /*for many chips in one board, there interrupt line should merge together */
    while (1)
    {
        ret = sal_sem_take(dal_isr[intr_idx].p_inr_sem, SAL_SEM_FOREVER);
        if (0 != ret)
        {
            continue;
        }

        intr_handler->isr((void*)&(intr_idx));
    }
}

int
dal_interrupt_register(unsigned int irq, int prio, void (* isr)(void*), void* data)
{
    int ret;
    unsigned char str[16];
    unsigned char* int_name = NULL;
    int use_msi = 0;
    uintptr para = 0;
    dal_intr_para_t* p_para = (dal_intr_para_t*)&para;
    int intr_idx = 0;

    if (dal_intr_num >= CTC_MAX_INTR_NUM)
    {
        printk("Interrupt numbers exceeds max.\n");
        return -1;
    }

    if (msi_used)
    {
        /* for msi interrupt, irq means msi irq index */
        irq = msi_irq_base + irq;
        int_name = "dal_msi";
    }
    else
    {
        int_name = "dal_intr";
    }

    intr_idx = (uintptr)data;

    p_para->intr_idx = (int16)intr_idx;
    p_para->prio = (int16)prio;

    dal_isr[dal_intr_num].irq = irq;
    dal_isr[dal_intr_num].isr = isr;
    dal_isr[dal_intr_num].isr_data = data;

    ret = sal_sem_create(&dal_isr[dal_intr_num].p_inr_sem, 0);
    if (ret < 0)
    {
        return ret;
    }

    sal_task_create(&dal_isr[dal_intr_num].p_intr_thread,
                    int_name,
                    SAL_DEF_TASK_STACK_SIZE,
                    prio,
                    dal_intr_thread,
                    (void*)para);

    if ((ret = request_irq(irq,
                           intr_handler_fun[dal_intr_num],
                           IRQF_DISABLED,
                           int_name,
                           &dal_isr[dal_intr_num])) < 0)
    {
        printk("Cannot request irq %d, ret %d.\n", irq, ret);
    }

    if (0 == ret)
    {
        dal_intr_num++;
    }

    return ret;
}

int
dal_interrupt_unregister(unsigned int irq)
{
    int intr_idx = 0;
    int find_flag = 0;

    if (msi_used)
    {
        /* for msi interrupt, irq means msi irq index */
        irq = msi_irq_base + irq;
    }

    /* get intr device index */
    for (intr_idx = 0; intr_idx < CTC_MAX_INTR_NUM; intr_idx++)
    {
        if (dal_isr[intr_idx].irq == irq)
        {
            find_flag = 1;
            break;
        }
    }

    if (find_flag == 0)
    {
        printk ("<0>irq%d is not registered! unregister failed \n", irq);
        return -1;
    }

    free_irq(irq, &dal_isr[intr_idx]);

    dal_intr_num--;

    return 0;
}

int
dal_interrupt_set_en(unsigned int irq, unsigned int enable)
{
    if ( msi_used)
    {
        irq = msi_irq_base;
    }

    enable ? enable_irq(irq) : disable_irq_nosync(irq);

    return 0;
}

static int
_dal_set_msi_enabe(unsigned int msi_num)
{
    int ret = 0;
    int lchip = 0;

    if (msi_num == 1)
    {
        for (lchip = 0; lchip < DAL_MAX_CHIP_NUM; lchip++)
        {
            ret = pci_enable_msi(dal_dev[lchip].pci_dev);
            if (ret)
            {
                pci_disable_msi(dal_dev[lchip].pci_dev);
                msi_used = 0;
            }
        }

        msi_irq_base = dal_dev[0].pci_dev->irq;
        msi_irq_num = 1;
    }
    else
    {
        for (lchip = 0; lchip < DAL_MAX_CHIP_NUM; lchip++)
        {
            ret = pci_enable_msi_block(dal_dev[lchip].pci_dev, msi_num);
            if (ret)
            {
                pci_disable_msi(dal_dev[lchip].pci_dev);
                msi_used = 0;
            }
        }

        msi_irq_base = dal_dev[0].pci_dev->irq;
        msi_irq_num = msi_num;
    }

    return 0;
}

static int
_dal_set_msi_disable(void)
{
    int ret = 0;
    int lchip = 0;

    for (lchip = 0; lchip < DAL_MAX_CHIP_NUM; lchip++)
    {
        pci_disable_msi(dal_dev[lchip].pci_dev);
    }

    msi_irq_base = 0;
    msi_irq_num = 0;

    return 0;
}

/*enable parameter is used in kernel mode, for user mode useless */
int
dal_kernel_set_msi_enable(unsigned int enable, unsigned int msi_num)
{
    int ret = 0;
    unsigned int used_num = 0;

    used_num = (enable)?msi_num:0;

    if (used_num > 0)
    {
        msi_used = 1;
        ret = _dal_set_msi_enabe(used_num);
    }
    else
    {
        used_num = 0;
        ret = _dal_set_msi_disable();
    }

    return ret;
}

int
dal_set_msi_cap(unsigned long msi_num)
{
    int ret = 0;

    ret =  dal_kernel_set_msi_enable(1, msi_num);

    return ret;
}

#define _KERNEL_DMA_PROCESS

uintptr
dal_logic_to_phy(unsigned char lchip, void* laddr)
{
    if (dma_mem_size)
    {
        /* dma memory is a contiguous block */
        if (laddr)
        {
            return dma_phy_base + ((uintptr)(laddr) - (uintptr)(dma_virt_base));
        }

        return 0;
    }

    return virt_to_bus(laddr);
}

void*
dal_phy_to_logic(unsigned char lchip, uintptr paddr)
{
    if (dma_mem_size)
    {
        /* dma memory is a contiguous block */
        return (void*)(paddr ? (char*)dma_virt_base + (paddr - dma_phy_base) : NULL);
    }

    return bus_to_virt(paddr);
}

unsigned int*
dal_dma_alloc(unsigned char lchip, int size, int type)
{
    return dal_mpool_alloc(dma_pool, size, type);
}

void
dal_dma_free(unsigned char lchip, void* ptr)
{
    return dal_mpool_free(dma_pool, ptr);
}

/*
 * Function: _dal_dma_segment_free
 */

/*
 * Function: _find_largest_segment
 *
 * Purpose:
 *    Find largest contiguous segment from a pool of DMA blocks.
 * Parameters:
 *    dseg - DMA segment descriptor
 * Returns:
 *    0 on success, < 0 on error.
 * Notes:
 *    Assembly stops if a segment of the requested segment size
 *    has been obtained.
 *
 *    Lower address bits of the DMA blocks are used as follows:
 *       0: Untagged
 *       1: Discarded block
 *       2: Part of largest contiguous segment
 *       3: Part of current contiguous segment
 */
static int
_dal_find_largest_segment(dma_segment_t* dseg)
{
    int i, j, blks, found;
    unsigned long seg_begin;
    unsigned long seg_end;
    unsigned long seg_tmp;

    blks = dseg->blk_cnt;

    /* Clear all block tags */
    for (i = 0; i < blks; i++)
    {
        dseg->blk_ptr[i] &= ~3;
    }

    for (i = 0; i < blks && dseg->seg_size < dseg->req_size; i++)
    {
        /* First block must be an untagged block */
        if ((dseg->blk_ptr[i] & 3) == DAL_UNTAG_BLOCK)
        {
            /* Initial segment size is the block size */
            seg_begin = dseg->blk_ptr[i];
            seg_end = seg_begin + dseg->blk_size;
            dseg->blk_ptr[i] |= DAL_CUR_MATCH_BLOCk;

            /* Loop looking for adjacent blocks */
            do
            {
                found = 0;

                for (j = i + 1; j < blks && (seg_end - seg_begin) < dseg->req_size; j++)
                {
                    seg_tmp = dseg->blk_ptr[j];
                    /* Check untagged blocks only */
                    if ((seg_tmp & 3) == DAL_UNTAG_BLOCK)
                    {
                        if (seg_tmp == (seg_begin - dseg->blk_size))
                        {
                            /* Found adjacent block below current segment */
                            dseg->blk_ptr[j] |= DAL_CUR_MATCH_BLOCk;
                            seg_begin = seg_tmp;
                            found = 1;
                        }
                        else if (seg_tmp == seg_end)
                        {
                            /* Found adjacent block above current segment */
                            dseg->blk_ptr[j] |= DAL_CUR_MATCH_BLOCk;
                            seg_end += dseg->blk_size;
                            found = 1;
                        }
                    }
                }
            }
            while (found);

            if ((seg_end - seg_begin) > dseg->seg_size)
            {
                /* The current block is largest so far */
                dseg->seg_begin = seg_begin;
                dseg->seg_end = seg_end;
                dseg->seg_size = seg_end - seg_begin;

                /* Re-tag current and previous largest segment */
                for (j = 0; j < blks; j++)
                {
                    if ((dseg->blk_ptr[j] & 3) == DAL_CUR_MATCH_BLOCk)
                    {
                        /* Tag current segment as the largest */
                        dseg->blk_ptr[j] &= ~1;
                    }
                    else if ((dseg->blk_ptr[j] & 3) == DAL_MATCHED_BLOCK)
                    {
                        /* Discard previous largest segment */
                        dseg->blk_ptr[j] ^= 3;
                    }
                }
            }
            else
            {
                /* Discard all blocks in current segment */
                for (j = 0; j < blks; j++)
                {
                    if ((dseg->blk_ptr[j] & 3) == DAL_CUR_MATCH_BLOCk)
                    {
                        dseg->blk_ptr[j] &= ~2;
                    }
                }
            }
        }
    }

    return 0;
}

/*
 * Function: _alloc_dma_blocks
 */
static int
_dal_alloc_dma_blocks(dma_segment_t* dseg, int blks)
{
    int i, start;
    unsigned long addr;

    if (dseg->blk_cnt + blks > dseg->blk_cnt_max)
    {
        printk("No more DMA blocks\n");
        return -1;
    }

    start = dseg->blk_cnt;
    dseg->blk_cnt += blks;

    for (i = start; i < dseg->blk_cnt; i++)
    {
        addr = __get_free_pages(GFP_ATOMIC, dseg->blk_order);
        if (addr)
        {
            dseg->blk_ptr[i] = addr;
        }
        else
        {
            printk("DMA allocation failed\n");
            return -1;
        }
    }

    return 0;
}

/*
 * Function: _dal_dma_segment_alloc
 */
static dma_segment_t*
_dal_dma_segment_alloc(unsigned int size, unsigned int blk_size)
{
    dma_segment_t* dseg;
    int i, blk_ptr_size;
    uintptr page_addr;
    struct sysinfo si;

    /* Sanity check */
    if (size == 0 || blk_size == 0)
    {
        return NULL;
    }

    /* Allocate an initialize DMA segment descriptor */
    if ((dseg = kmalloc(sizeof(dma_segment_t), GFP_ATOMIC)) == NULL)
    {
        return NULL;
    }

    memset(dseg, 0, sizeof(dma_segment_t));
    dseg->req_size = size;
    dseg->blk_size = PAGE_ALIGN(blk_size);

    while ((PAGE_SIZE << dseg->blk_order) < dseg->blk_size)
    {
        dseg->blk_order++;
    }

    si_meminfo(&si);
    dseg->blk_cnt_max = (si.totalram << PAGE_SHIFT) / dseg->blk_size;
    blk_ptr_size = dseg->blk_cnt_max * sizeof(unsigned long);
    /* Allocate an initialize DMA block pool */
    dseg->blk_ptr = kmalloc(blk_ptr_size, GFP_KERNEL);
    if (dseg->blk_ptr == NULL)
    {
        kfree(dseg);
        return NULL;
    }

    memset(dseg->blk_ptr, 0, blk_ptr_size);
    /* Allocate minimum number of blocks */
    _dal_alloc_dma_blocks(dseg, dseg->req_size / dseg->blk_size);

    /* Allocate more blocks until we have a complete segment */
    do
    {
        _dal_find_largest_segment(dseg);
        if (dseg->seg_size >= dseg->req_size)
        {
            break;
        }
    }
    while (_dal_alloc_dma_blocks(dseg, 8) == 0);

    /* Reserve all pages in the DMA segment and free unused blocks */
    for (i = 0; i < dseg->blk_cnt; i++)
    {
        if ((dseg->blk_ptr[i] & 3) == 2)
        {
            dseg->blk_ptr[i] &= ~3;

            for (page_addr = dseg->blk_ptr[i];
                 page_addr < dseg->blk_ptr[i] + dseg->blk_size;
                 page_addr += PAGE_SIZE)
            {
                MEM_MAP_RESERVE(VIRT_TO_PAGE((void*)page_addr));
            }
        }
        else if (dseg->blk_ptr[i])
        {
            dseg->blk_ptr[i] &= ~3;
            free_pages(dseg->blk_ptr[i], dseg->blk_order);
            dseg->blk_ptr[i] = 0;
        }
    }

    return dseg;
}

/*
 * Function: _dal_dma_segment_free
 */
static void
_dal_dma_segment_free(dma_segment_t* dseg)
{
    int i;
    uintptr page_addr;

    if (dseg->blk_ptr)
    {
        for (i = 0; i < dseg->blk_cnt; i++)
        {
            if (dseg->blk_ptr[i])
            {
                for (page_addr = dseg->blk_ptr[i];
                     page_addr < dseg->blk_ptr[i] + dseg->blk_size;
                     page_addr += PAGE_SIZE)
                {
                    MEM_MAP_UNRESERVE(VIRT_TO_PAGE((void*)page_addr));
                }

                free_pages(dseg->blk_ptr[i], dseg->blk_order);
            }
        }

        kfree(dseg->blk_ptr);
        kfree(dseg);
    }
}

/*
 * Function: -dal_pgalloc
 */
static void*
_dal_pgalloc(unsigned int size)
{
    dma_segment_t* dseg;
    unsigned int blk_size;

    blk_size = (size < DMA_BLOCK_SIZE) ? size : DMA_BLOCK_SIZE;
    if ((dseg = _dal_dma_segment_alloc(size, blk_size)) == NULL)
    {
        return NULL;
    }

    if (dseg->seg_size < size)
    {
        /* If we didn't get the full size then forget it */
        printk("Notice: Can not get enough memory for requset!!\n");
        printk("actual size:0x%lx, request size:0x%x\n", dseg->seg_size, size);
        //-_dal_dma_segment_free(dseg);
        //-return NULL;
    }

    list_add(&dseg->list, &_dma_seg);
    return (void*)dseg->seg_begin;
}

/*
 * Function: _dal_pgfree
 */
static int
_dal_pgfree(void* ptr)
{
    struct list_head* pos;

    list_for_each(pos, &_dma_seg)
    {
        dma_segment_t* dseg = list_entry(pos, dma_segment_t, list);

        if (ptr == (void*)dseg->seg_begin)
        {
            list_del(&dseg->list);
            _dal_dma_segment_free(dseg);
            return 0;
        }
    }
    return -1;
}

static void
dal_alloc_dma_pool(int size)
{
    if (use_high_memory)
    {
        dma_phy_base = virt_to_bus(high_memory);
        dma_virt_base = ioremap_nocache(dma_phy_base, size);
    }
    else
    {
#ifndef DMA_MEM_MODE_PLATFORM
        /* Get DMA memory from kernel */
        dma_virt_base = _dal_pgalloc(size);
        printk("<0>_dal_pgalloc return 0x%p\r\n", dma_virt_base);
        dma_phy_base = virt_to_bus(dma_virt_base);
        printk("<0>Dma physical address 0x%p\r\n", dma_phy_base);
        printk("<0>Using SDK malloc Dma memory pool!!\n");
        if (((dma_phy_base + dma_mem_size) >> 32) != 0)
        {
            printk("Dma malloc memory over 4G space, cannot support!!!!!! \n");
            return -1;
        }
#endif
        //dma_virt_base = ioremap_nocache(dma_phy_base, size);
        //printk("after ioremap_nocache return %p\r\n", dma_virt_base);
    }
}

#define _KERNEL_DAL_IO
int
dal_pci_read(unsigned char lchip, unsigned int offset, unsigned int* value)
{
    if (!VERIFY_CHIP_INDEX(lchip))
    {
        WARN_ON(1);
        return -1;
    }

    *value = *(volatile unsigned int*)(dal_dev[lchip].logic_address + offset);
    return 0;
}

int
dal_pci_write(unsigned char lchip, unsigned int offset, unsigned int value)
{
    if (!VERIFY_CHIP_INDEX(lchip))
    {
        WARN_ON(1);
        return -1;
    }

    *(volatile unsigned int*)(dal_dev[lchip].logic_address + offset) = value;
    return 0;
}

int
dal_pci_conf_read(unsigned char lchip, unsigned int offset, unsigned int* value)
{
    if (!VERIFY_CHIP_INDEX(lchip))
    {
        return -1;
    }

    pci_read_config_dword(dal_dev[lchip].pci_dev, offset, value);
    return 0;
}

int
dal_pci_conf_write(unsigned char lchip, unsigned int offset, unsigned int value)
{
    if (!VERIFY_CHIP_INDEX(lchip))
    {
        return -1;
    }

    pci_write_config_dword(dal_dev[lchip].pci_dev, offset, value);
    return 0;
}

int
dal_user_read_pci_conf(unsigned long arg)
{
    dal_pci_cfg_ioctl_t dal_cfg;

    if (copy_from_user(&dal_cfg, (void*)arg, sizeof(dal_pci_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    if (dal_pci_conf_read(dal_cfg.chip_id, dal_cfg.offset, &dal_cfg.value))
    {
        printk("dal_pci_conf_read failed.\n");
        return -EFAULT;
    }

    if (copy_to_user((dal_pci_cfg_ioctl_t*)arg, (void*)&dal_cfg, sizeof(dal_pci_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    return 0;
}

int
linux_dal_mmap0(struct file* flip, struct vm_area_struct* vma)
{
    size_t size = vma->vm_end - vma->vm_start;
    unsigned long pfn;

    printk("linux_dal0_mmap begin.\n");

    pfn = (dal_dev[0].phys_address) >> PAGE_SHIFT;

    vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
    if (remap_pfn_range(vma, vma->vm_start, pfn, size, vma->vm_page_prot))
    {
        return -EAGAIN;
    }

    printk("linux_dal_mmap0 finish.\n");

    return 0;
}

int
dal_user_write_pci_conf(unsigned long arg)
{
    dal_pci_cfg_ioctl_t dal_cfg;

    if (copy_from_user(&dal_cfg, (void*)arg, sizeof(dal_pci_cfg_ioctl_t)))
    {
        return -EFAULT;
    }

    return dal_pci_conf_write(dal_cfg.chip_id, dal_cfg.offset, dal_cfg.value);
}

int
linux_dal_probe(struct pci_dev* pdev, const struct pci_device_id* id)
{
    dal_kern_dev_t* dev = NULL;
    int bar = 0;
    int ret = 0;
    unsigned int temp = 0;
    unsigned int lchip = 0;

    printk(KERN_WARNING "********found dal device deviceid:%d*****\n", dal_chip_num);

    dev = &dal_dev[dal_chip_num];
    if (NULL == dev)
    {
        printk("Cannot obtain PCI resources\n");
    }

    lchip = dal_chip_num;
    dal_chip_num++;

    if (dal_chip_num > DAL_MAX_CHIP_NUM)
    {
        printk("Exceed max local chip num\n");
        return -1;
    }

    dev->pci_dev = pdev;

    if (pci_enable_device(pdev) < 0)
    {
        printk("Cannot enable PCI device: vendor id = %x, device id = %x\n",
               pdev->vendor, pdev->device);
    }

    ret = pci_set_dma_mask(pdev, DMA_BIT_MASK(64));
    if (ret)
    {
    	ret = pci_set_dma_mask(pdev, DMA_BIT_MASK(32));
    	if (ret) {
    		printk("Could not set PCI DMA Mask\n");
    		return ret;
    	}
    }

    if (pci_request_regions(pdev, DAL_NAME) < 0)
    {
        printk("Cannot obtain PCI resources\n");
    }

    dev->phys_address = pci_resource_start(pdev, bar);
    dev->logic_address = (ulong)ioremap_nocache(dev->phys_address,
                                                pci_resource_len(dev->pci_dev, bar));

    dal_pci_read(lchip, 0x48, &temp);
    if (((temp >> 8) & 0xffff) == 0x3412)
    {
        printk("Little endian Cpu detected!!! \n");
        dal_pci_write(lchip, 0x48, 0xFFFFFFFF);
    }

    dal_pci_read(lchip, 0x48, &temp);

#ifdef DMA_MEM_MODE_PLATFORM
    dma_virt_base = dma_alloc_coherent(&dev->pci_dev->dev, dma_mem_size,
                                       &dma_phy_base, GFP_KERNEL);

    if (((dma_phy_base + dma_mem_size) >> 32) != 0)
    {
        printk("Dma malloc memory over 4G space, cannot support!!!!!! \n");
        return - 1;
    }

    printk(KERN_WARNING "########Using DMA_MEM_MODE_PLATFORM \n");
#endif
    pci_set_master(pdev);

    printk(KERN_WARNING "########Dma alloc physical address:0x"PRIx64" dma_mem_size:%d, logic_addr:%p\n", dma_phy_base, dma_mem_size, dma_virt_base);

    printk(KERN_WARNING "linux_dal_probe end \n");

    return 0;
}


static int
linux_dal_get_device(unsigned long arg)
{
    dal_user_dev_t user_dev;
    int chip_id = 0;

    if (copy_from_user(&user_dev, (void*)arg, sizeof(user_dev)))
    {
        return -EFAULT;
    }

    user_dev.chip_num = dal_chip_num;
    chip_id = user_dev.chip_id;

    if (chip_id < dal_chip_num)
    {
        user_dev.phy_base0 = (unsigned int)dal_dev[chip_id].phys_address;
        #ifdef PHYS_ADDR_IS_64BIT
        user_dev.phy_base1 = (unsigned int)(dal_dev[chip_id].phys_address >> 32);
        #else
        user_dev.phy_base1 = 0;
        #endif
    }

    if (copy_to_user((dal_user_dev_t*)arg, (void*)&user_dev, sizeof(user_dev)))
    {
        return -EFAULT;
    }

    return 0;
}

/* get dma information */
int32
dal_get_dma_info(void* p_info)
{
    dma_info_t* p_dma = NULL;

    p_dma = (dma_info_t*)p_info;

    p_dma->phy_base = (unsigned int)dma_phy_base;
    p_dma->phy_base_hi = 0;
    p_dma->size = dma_mem_size;

    return 0;
}

#ifdef CONFIG_COMPAT
static long
linux_dal_ioctl(struct file* file,
                unsigned int cmd, unsigned long arg)
#else
static int
linux_dal_ioctl(struct inode* inode, struct file* file,
                unsigned int cmd, unsigned long arg)
#endif
{
    switch (cmd)
    {
#if 0
    case CMD_READ_CHIP:
        return linux_dal_read(arg);

    case CMD_WRITE_CHIP:
        return linux_dal_write(arg);

#endif

    case CMD_GET_DEVICES:
        return linux_dal_get_device(arg);

    case CMD_PCI_CONFIG_READ:
        return dal_user_read_pci_conf(arg);

    case CMD_PCI_CONFIG_WRITE:
        return dal_user_write_pci_conf(arg);

		break;

    default:
        break;
    }

    return 0;
}

void
linux_dal_remove(struct pci_dev* pdev)
{
    pci_release_regions(pdev);
    pci_disable_device(pdev);
}

static struct file_operations fops_dal =
{
    .owner = THIS_MODULE,
#ifdef CONFIG_COMPAT
    .compat_ioctl = linux_dal_ioctl,
    .mmap = linux_dal_mmap0,
#else
    .ioctl = linux_dal_ioctl,
    .mmap = linux_dal_mmap0,
#endif
};

static struct pci_driver linux_dal_driver =
{
    .name = DAL_NAME,
    .id_table = dal_id_table,
    .probe = linux_dal_probe,
    .remove = linux_dal_remove,
};

extern int32 userinit(int32 is_ctc_shell);

static int __init
linux_kernel_init(void)
{
    int ret;

    ret = pci_register_driver(&linux_dal_driver);
    if (ret < 0)
    {
        printk(KERN_WARNING "Register ASIC PCI driver failed, ret %d\n", ret);
        return ret;
    }

    ret = register_chrdev(DAL_DEV_MAJOR, "linux_dal0", &fops_dal);
    if (ret < 0)
    {
        printk(KERN_WARNING "Register linux_dal device, ret %d\n", ret);
        return ret;
    }

    /* Get DMA memory pool size */
    if (dma_pool_size)
    {
        if ((dma_pool_size[strlen(dma_pool_size) - 1] & ~0x20) == 'M')
        {
            dma_mem_size = simple_strtoul(dma_pool_size, NULL, 0);
            dma_mem_size *= MB_SIZE;
        }
        else
        {
            printk("DMA memory pool size must be specified as e.g. dma_pool_size=8M\n");
        }

        if (dma_mem_size & (dma_mem_size - 1))
        {
            printk("dma_mem_size must be a power of 2 (1M, 2M, 4M, 8M etc.)\n");
            dma_mem_size = 0;
        }
    }

    if (dma_mem_size)
    {
        dal_alloc_dma_pool(dma_mem_size);
        dma_pool = dal_mpool_create(dma_virt_base, dma_mem_size);
        if (!dma_pool)
        {
            printk("Create mpool fail, dma_pool:%p \n", dma_pool);
            return -1;
        }
    }

#if 0
    printk("linux_dal_init: dma_virt_base %p dma_phy_base %d 0x%p %d\r\n",
        dma_virt_base, dma_phy_base, dma_pool, dma_mem_size);
#endif
    /* init interrupt function */
    intr_handler_fun[0] = intr0_handler;
    intr_handler_fun[1] = intr1_handler;
    intr_handler_fun[2] = intr2_handler;
    intr_handler_fun[3] = intr3_handler;
    intr_handler_fun[4] = intr4_handler;
    intr_handler_fun[5] = intr5_handler;

    ret = userinit(1);

    return ret;
}

extern void
ctc_vty_close(void);

static void __exit
linux_kernel_exit(void)
{
    int intr_idx = 0;
    int intr_num = 0;

    intr_num = dal_intr_num;

    for (intr_idx = 0; intr_idx < intr_num; intr_idx++)
    {
        dal_interrupt_unregister(dal_isr[intr_idx].irq);
    }

    pci_unregister_driver(&linux_dal_driver);
    unregister_chrdev(DAL_DEV_MAJOR, "linux_dal0");

    ctc_vty_close();
}

/* set device access type, must be configured before dal_op_init */
int32_t
dal_set_device_access_type(dal_access_type_t device_type)
{
    if (device_type >= DAL_MAX_ACCESS_TYPE)
    {
        return DAL_E_INVALID_ACCESS;
    }

    g_dal_access = device_type;
    return 0;
}

/* get device access type */
int32_t
dal_get_device_access_type(dal_access_type_t* p_device_type)
{
    *p_device_type = g_dal_access;
    return 0;
}

module_init(linux_kernel_init);
module_exit(linux_kernel_exit);

