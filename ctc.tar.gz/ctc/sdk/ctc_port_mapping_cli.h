
/**
 @file ctc_port_mapping_cli.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-10-24

 @version v2.0

 This file contains port cli
*/
#ifndef _CTC_CLI_PORT_MAPPING_CLI_H
#define _CTC_CLI_PORT_MAPPING_CLI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_cli.h"

extern uint32
ctc_get_port_from_port_mapping(uint32 gport, uint8 is_gport);

extern uint32
ctc_get_port_from_port_unmapping(uint32 gport);

extern int32
ctc_port_mapping_cli_init();

/* map device-port to chip-port */
#define CTC_PORT_MAPPING(gport, is_gport) \
    gport = ctc_get_port_from_port_mapping(gport, is_gport)

/*map humber-port to device-port */
#define CTC_PORT_UNMAPPING(gport) \
    gport = ctc_get_port_from_port_unmapping(gport)

#ifdef __cplusplus
}
#endif

#endif

