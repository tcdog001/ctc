/**
 @file sys_humber_chip.c

 @date 2009-10-19

 @version v2.0

 The file define APIs of chip of sys layer
*/
/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "ctc_error.h"
#include "sys_humber_chip.h"
#include "sys_humber_ftm.h"
#include "sys_humber_port.h"
#include "sys_humber_queue_enq.h"

#include "drv_io.h"
#include "drv_humber.h"
#include "drv_humber_data_path.h"
#include "drv_humber_parity_error.h"

/****************************************************************************
 *
 * Global and static
 *
 *****************************************************************************/
sys_chip_master_t* p_chip_master = NULL;
extern sys_port_master_t* p_port_master;

/****************************************************************************
 *
 * Function
 *
 *****************************************************************************/

/**
 @brief The function is to initialize the chip module and set the local chip number of the linecard
*/
int32
sys_humber_chip_init(uint8 lchip_num)
{
    int32 ret;

    if (NULL != p_chip_master)
    {
        return CTC_E_NONE;
    }

    if (lchip_num > CTC_MAX_LOCAL_CHIP_NUM)
    {
        return CTC_E_INVALID_CHIP_NUM;
    }

    p_chip_master = (sys_chip_master_t*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(sys_chip_master_t));

    if (NULL == p_chip_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_chip_master, 0, sizeof(sys_chip_master_t));

    p_chip_master->lchip_num    = lchip_num;
    sal_memset(p_chip_master->g_chip_id, CTC_INVALID_CHIPID, sizeof(uint8) * CTC_MAX_LOCAL_CHIP_NUM);

    /*mutex*/
    ret = sal_mutex_create(&(p_chip_master->p_chip_mutex));
    if (ret || (!p_chip_master->p_chip_mutex))
    {
        ret = CTC_E_FAIL_CREATE_MUTEX;
        mem_free(p_chip_master);
        return ret;
    }

    ret = drv_init(lchip_num);
    if (ret < 0)
    {
        mem_free(p_chip_master);
        ret = CTC_E_DRV_FAIL;
    }

    return ret;
}

/**
 @brief The function is to initialize datapath
*/
int32
sys_humber_data_path_init(ctc_chip_reset_cb reset_cb, ctc_chip_datapath_t* chip_datapath,
                          char* datapath_config_file)
{
    int32 ret;
    drv_chip_info_t drv_chip_info;
    drv_work_platform_type_t platform_type;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(chip_datapath);

    ret = drv_get_platform_type(&platform_type);
    if (ret < 0)
    {
        return CTC_E_INVALID_PARAM;
    }

    if (platform_type == SW_SIM_PLATFORM)
    {
        drv_humber_init_sw_emu(chip_datapath->chip_id);
        return CTC_E_NONE;
    }

    sal_memset(&drv_chip_info, 0, sizeof(drv_chip_info_t));
    drv_chip_info.chip_io_type  = CHIP_IO_PCI;
    drv_chip_info.chip_type     = chip_datapath->chip_type;
    drv_chip_info.cpumac_speed  = chip_datapath->cpumac_speed;
    drv_chip_info.ptp_quanta    = chip_datapath->ptp_quanta;

    CTC_ERROR_RETURN(drv_humber_init_total(reset_cb, drv_chip_info, datapath_config_file));

    return CTC_E_NONE;
}

/**
 @brief The function is to initialize the parity error
*/
int32
sys_humber_parity_error_init(void)
{
    uint8 lchip = 0, lchip_num = 0;

    drv_chip_parity_error_init_t drv_parity_error;
    uint8 is_ext_sram_en = 0;
    sys_alloc_info_t* p_alloc_info;

    CTC_ERROR_RETURN(sys_alloc_get_ext_sram_en(&is_ext_sram_en));
    p_alloc_info = sys_alloc_get_alloc_info_ptr();

    drv_parity_error.is_ext_sram_en = is_ext_sram_en;
    drv_parity_error.is_hash_48ksize = p_alloc_info->is_hash_48ksize;

    lchip_num = p_chip_master->lchip_num;

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        drv_parity_error.chip_id = lchip;

        CTC_ERROR_RETURN(drv_humber_mem_mapping_init(&drv_parity_error));
    }

    return CTC_E_NONE;
}

/**
 @brief The function is to get the local chip num
*/
uint8
sys_humber_get_local_chip_num(void)
{
    if (NULL == p_chip_master)
    {
        return 0;
    }

    return p_chip_master->lchip_num;
}

/**
 @brief The function is to set chip's global chip id
*/
int32
sys_humber_set_gchip_id(uint8 lchip_id, uint8 gchip_id)
{
    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    if (lchip_id >= p_chip_master->lchip_num)
    {
        return CTC_E_INVALID_LOCAL_CHIPID;
    }

    CTC_GLOBAL_CHIPID_CHECK(gchip_id);

    p_chip_master->g_chip_id[lchip_id] = gchip_id;

    return CTC_E_NONE;
}

/**
 @brief The function is to get chip's global chip id
*/
int32
sys_humber_get_gchip_id(uint8 lchip_id, uint8* gchip_id)
{
    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(gchip_id);

    *gchip_id = p_chip_master->g_chip_id[lchip_id];

    return CTC_E_NONE;
}

int32
sys_humber_chip_set_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    if (NULL == phy_mapping_para)
    {
        return CTC_E_INVALID_PTR;
    }

    sal_memcpy(p_chip_master->port_mdio_mapping_tbl, phy_mapping_para->port_mdio_mapping_tbl,
               CTC_MAX_PHY_PORT);

    sal_memcpy(p_chip_master->port_phy_mapping_tbl, phy_mapping_para->port_phy_mapping_tbl,
               CTC_MAX_PHY_PORT);

    return CTC_E_NONE;
}

int32
sys_humber_chip_get_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    SYS_CHIP_DBG_FUNC();
    if (NULL == phy_mapping_para)
    {
        return CTC_E_INVALID_PTR;
    }

    sal_memcpy(phy_mapping_para->port_mdio_mapping_tbl,  p_chip_master->port_mdio_mapping_tbl,
               CTC_MAX_PHY_PORT);

    sal_memcpy(phy_mapping_para->port_phy_mapping_tbl,  p_chip_master->port_phy_mapping_tbl,
               CTC_MAX_PHY_PORT);

    return CTC_E_NONE;
}

int32
sys_humber_chip_get_phy_mdio(uint16 gport, uint8* mdio_bus, uint8* phy_addr)
{

    if ((gport > CTC_MAX_PHY_PORT - 1))
    {
        return CTC_E_INVALID_PARAM;
    }

    *mdio_bus = p_chip_master->port_mdio_mapping_tbl[gport];
    *phy_addr = p_chip_master->port_phy_mapping_tbl[gport];

    return CTC_E_NONE;
}

/**
 @brief The function is to judge whether the chip is local
*/
bool
sys_humber_chip_is_local(uint8 gchip_id, uint8* lchip_id)
{
    uint8 chip_id;

    if (NULL == p_chip_master)
    {
        *lchip_id = CTC_INVALID_CHIPID;
        return FALSE;
    }

    for (chip_id = 0; chip_id < p_chip_master->lchip_num; chip_id++)
    {
        if ((gchip_id != CTC_INVALID_CHIPID) && (p_chip_master->g_chip_id[chip_id] == gchip_id))
        {
            *lchip_id = chip_id;
            return TRUE;
        }
    }

    *lchip_id = CTC_INVALID_CHIPID;
    return FALSE;
}

/**
 @brief The function is to set chip's global cfg

*/
int32
sys_humber_set_chip_global_cfg(ctc_chip_global_cfg_t* chip_cfg)
{
    int32 cmd_sa, cmd_da, cmd_ctl, cmd_type;

    cpu_mac_sa_t cpu_macsa;
    cpu_mac_da_t cpu_macda;
    cpu_mac_ctl_t mac_ctl;
    cpu_mac_type_t mac_type;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(chip_cfg);

    if (chip_cfg->lchip > p_chip_master->lchip_num)
    {
        return CTC_E_INVALID_LOCAL_CHIPID;
    }

    sal_memset(&cpu_macsa, 0, sizeof(cpu_mac_sa_t));
    sal_memset(&cpu_macda, 0, sizeof(cpu_mac_da_t));
    sal_memset(&mac_ctl, 0, sizeof(cpu_mac_ctl_t));
    sal_memset(&mac_type, 0, sizeof(cpu_mac_type_t));

    cpu_macsa.cpu_mac_sa31_to0 = chip_cfg->cpu_mac_sa[2] << 24 | chip_cfg->cpu_mac_sa[3] << 16 | chip_cfg->cpu_mac_sa[4] << 8 | chip_cfg->cpu_mac_sa[5];
    cpu_macsa.cpu_mac_sa47_to32 = chip_cfg->cpu_mac_sa[0] << 8 | chip_cfg->cpu_mac_sa[1];

    cpu_macda.cpu_mac0_da31_to0 = chip_cfg->cpu_mac_da[0][2] << 24 | chip_cfg->cpu_mac_da[0][3] << 16 | chip_cfg->cpu_mac_da[0][4] << 8 | chip_cfg->cpu_mac_da[0][5];
    cpu_macda.cpu_mac0_da47_to32 = chip_cfg->cpu_mac_da[0][0] << 8 | chip_cfg->cpu_mac_da[0][1];

    cpu_macda.cpu_mac1_da31_to0 = chip_cfg->cpu_mac_da[1][2] << 24 | chip_cfg->cpu_mac_da[1][3] << 16 | chip_cfg->cpu_mac_da[1][4] << 8 | chip_cfg->cpu_mac_da[1][5];
    cpu_macda.cpu_mac1_da47_to32 = chip_cfg->cpu_mac_da[1][0] << 8 | chip_cfg->cpu_mac_da[1][1];

    cpu_macda.cpu_mac2_da31_to0 = chip_cfg->cpu_mac_da[2][2] << 24 | chip_cfg->cpu_mac_da[2][3] << 16 | chip_cfg->cpu_mac_da[2][4] << 8 | chip_cfg->cpu_mac_da[2][5];
    cpu_macda.cpu_mac2_da47_to32 = chip_cfg->cpu_mac_da[2][0] << 8 | chip_cfg->cpu_mac_da[2][1];

    cpu_macda.cpu_mac3_da31_to0 = chip_cfg->cpu_mac_da[3][2] << 24 | chip_cfg->cpu_mac_da[3][3] << 16 | chip_cfg->cpu_mac_da[3][4] << 8 | chip_cfg->cpu_mac_da[3][5];
    cpu_macda.cpu_mac3_da47_to32 = chip_cfg->cpu_mac_da[3][0] << 8 | chip_cfg->cpu_mac_da[3][1];

    cpu_macda.cpu_mac4_da31_to0 = chip_cfg->cpu_mac_da[4][2] << 24 | chip_cfg->cpu_mac_da[4][3] << 16 | chip_cfg->cpu_mac_da[4][4] << 8 | chip_cfg->cpu_mac_da[4][5];
    cpu_macda.cpu_mac4_da47_to32 = chip_cfg->cpu_mac_da[4][0] << 8 | chip_cfg->cpu_mac_da[4][1];

    cpu_macda.cpu_mac5_da31_to0 = chip_cfg->cpu_mac_da[5][2] << 24 | chip_cfg->cpu_mac_da[5][3] << 16 | chip_cfg->cpu_mac_da[5][4] << 8 | chip_cfg->cpu_mac_da[5][5];
    cpu_macda.cpu_mac5_da47_to32 = chip_cfg->cpu_mac_da[5][0] << 8 | chip_cfg->cpu_mac_da[5][1];

    cpu_macda.cpu_mac6_da31_to0 = chip_cfg->cpu_mac_da[6][2] << 24 | chip_cfg->cpu_mac_da[6][3] << 16 | chip_cfg->cpu_mac_da[6][4] << 8 | chip_cfg->cpu_mac_da[6][5];
    cpu_macda.cpu_mac6_da47_to32 = chip_cfg->cpu_mac_da[6][0] << 8 | chip_cfg->cpu_mac_da[6][1];

    cpu_macda.cpu_mac7_da31_to0 = chip_cfg->cpu_mac_da[7][2] << 24 | chip_cfg->cpu_mac_da[7][3] << 16 | chip_cfg->cpu_mac_da[7][4] << 8 | chip_cfg->cpu_mac_da[7][5];
    cpu_macda.cpu_mac7_da47_to32 = chip_cfg->cpu_mac_da[7][0] << 8 | chip_cfg->cpu_mac_da[7][1];

    mac_ctl.ingress_remove_en = 1;
    mac_ctl.egress_add_en = 1;
    mac_ctl.egress_fifo_afull_thrd = 0x12;

    mac_type.cpu_mac_type = 0x5A5A;

    cmd_sa = DRV_IOW(IOC_REG, CPU_MAC_SA, DRV_ENTRY_FLAG);
    cmd_da = DRV_IOW(IOC_REG, CPU_MAC_DA, DRV_ENTRY_FLAG);
    cmd_ctl = DRV_IOW(IOC_REG, CPU_MAC_CTL, DRV_ENTRY_FLAG);
    cmd_type = DRV_IOW(IOC_REG, CPU_MAC_TYPE, DRV_ENTRY_FLAG);

    CTC_ERROR_RETURN(drv_reg_ioctl(chip_cfg->lchip, 0, cmd_sa, &cpu_macsa));
    CTC_ERROR_RETURN(drv_reg_ioctl(chip_cfg->lchip, 0, cmd_da, &cpu_macda));
    CTC_ERROR_RETURN(drv_reg_ioctl(chip_cfg->lchip, 0, cmd_ctl, &mac_ctl));
    CTC_ERROR_RETURN(drv_reg_ioctl(chip_cfg->lchip, 0, cmd_type, &mac_type));

    return CTC_E_NONE;

}

int32
sys_humber_get_chip_clock(uint16* freq)
{
    *freq = drv_humber_get_core_freq(0);

    return CTC_E_NONE;
}

static int32
_sys_humber_chip_hss4g_macro_enable(uint8 lchip, uint8 lserdes_id, ctc_serdes_mode_t serdes_mode)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;
    uint32 hss_div_sel, width, rate;
    uint8 lport;
    uint32 hss_ready;

    table_id = HSS_N0_CTL + lserdes_id;
    /* 1.  -------- Cfg Hss4G ---------*/
    /* 1.1 ---cfg Hss4G PLL power up ---*/
    field_id = HSS_N0_CTL_CFG_N0_HSS_PDWN_PLL;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /* 1.2 ---cfg all link of Rx/Tx power up in one macro ---*/
    for (lport = 0; lport < CTC_MAC_NUM_PER_MACRO; lport++)
    {
        if ((lport % CTC_MAC_NUM_PER_MACRO) < 4)
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + ((lport % CTC_MAC_NUM_PER_MACRO) * 16);
        }
        else
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + 4 * 16 + ((lport % CTC_MAC_NUM_PER_MACRO) - 4) * 15;
        }

        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        field_id = HSS_N0_CTL_CFG_N0_TXA_PWR_DWN + (lport * 13);
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    }

    /* 2.  -------- Release Hss4G reset ---------*/
    field_id = HSS_N0_CTL_CFG_N0_HSS_RESET;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*3. ------ set Hss4G reset  -------*/
    field_val = 1;
    field_id = HSS_N0_CTL_CFG_N0_HSS_RESET;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*4. -- cfg Hss4G control regs, modify DivSel, Rx/Tx width, Rx/Tx Rate --*/
    width = 1;
    if (serdes_mode == CTC_SERDES_MODE_1G25)
    {
        hss_div_sel = 2;
        rate = 1;
    }
    else
    {
        hss_div_sel = 3;
        rate = 0;
    }

    /*4.1 --- modify DivSel ---*/
    field_id = HSS_N0_CTL_CFG_N0_HSS_DIV_SEL;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &hss_div_sel);

    for (lport = 0; lport < CTC_MAC_NUM_PER_MACRO; lport++)
    {
        /*4.2 --- modify rx width --- */
        if ((lport % CTC_MAC_NUM_PER_MACRO) < 4)
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_WIDTH + ((lport % CTC_MAC_NUM_PER_MACRO) * 16);
        }
        else
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_WIDTH + 3 * 16 + ((lport % CTC_MAC_NUM_PER_MACRO) - 3) * 15;
        }

        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &width);
        /*4.3 --- modify rx rate --- */
        if ((lport % CTC_MAC_NUM_PER_MACRO) < 4)
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_RATE + ((lport % CTC_MAC_NUM_PER_MACRO) * 16);
        }
        else
        {
            field_id = HSS_N0_CTL_CFG_N0_RXA_RATE + 3 * 16 + ((lport % CTC_MAC_NUM_PER_MACRO) - 3) * 15;
        }

        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &rate);
        /*4.4 --- modify tx width --- */
        field_id = HSS_N0_CTL_CFG_N0_TXA_WIDTH + (lport * 13);
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &width);
        /*4.5 --- modify tx rate --- */
        field_id = HSS_N0_CTL_CFG_N0_TXA_RATE + (lport * 13);
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &rate);
    }

    /*5. ------ release Hss4G reset ------*/
    field_val = 0;
    field_id = HSS_N0_CTL_CFG_N0_HSS_RESET;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*6. -- wait HSS PLL lock and HssReady asserted --*/
    sal_task_sleep(10);
    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_READY;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &hss_ready);
    if (hss_ready != 1)
    {
        return CTC_E_CHECK_HSS_READY_FAIL;
    }
    else
    {
        return ret;
    }
}

static int32
_sys_humber_chip_hss4g_macro_disable(uint8 lchip, uint8 lserdes_id)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 1;

    /*1. ------ cfg Hss4G PLL power down  -------*/
    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_PDWN_PLL;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
    return ret;
}

int32
sys_humber_serdes_set_mode(uint16 gserdes_id, ctc_serdes_mode_t serdes_mode)
{
    uint8 lchip;
    uint8 lport, lserdes_id, lport_idx;
    int32 ret = CTC_E_NONE;
    ctc_port_mac_type_t mac_type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GSERDESID_TO_LSERDESID(gserdes_id, lchip, lserdes_id);
    lport = lserdes_id * CTC_MAC_NUM_PER_MACRO;

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    PORT_LOCK;
    mac_type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    if (CTC_PORT_MAC_GMAC == mac_type)
    {
        /*If cpumac use internal refclk, not allow to change Macro 5 serdes mode to 3.125G*/
        if (drv_humber_cpumac_use_internal_refclk(lchip) && (lport == DRV_CPUMAC_CLK_SERDES))
        {
            if (serdes_mode == CTC_SERDES_MODE_1G25)
            {
                ret = CTC_E_NONE;
            }
            else
            {
                ret = CTC_E_CANT_CHANGE_SERDES_MODE;
            }
        }
        else
        {
            /*1. set all gmac in one macro disable*/
            for (lport_idx = lport; lport_idx < lport + CTC_MAC_NUM_PER_MACRO; lport_idx++)
            {
                ret = ret ? ret : sys_humber_port_set_gmac_en(lchip, lport_idx, 0);
            }

            /*2. set hss4g disable*/
            ret = ret ? ret : _sys_humber_chip_hss4g_macro_disable(lchip, lserdes_id);
            /*3. set hss4g enable*/
            ret = ret ? ret : _sys_humber_chip_hss4g_macro_enable(lchip, lserdes_id, serdes_mode);

            /*4. set gmac enable*/
            for (lport_idx = lport; lport_idx < lport + CTC_MAC_NUM_PER_MACRO; lport_idx++)
            {
                p_port_master->igs_port_prop[lchip][lport_idx].serdes_mode = serdes_mode;
                /*When cfg serdes mode to 3.125G, speed mode should cfg to 2.5GE. */
                if (CTC_SERDES_MODE_3G125 == serdes_mode)
                {
                    p_port_master->igs_port_prop[lchip][lport_idx].speed_mode = CTC_PORT_SPEED_2G5;
                }
                else
                {
                    p_port_master->igs_port_prop[lchip][lport_idx].speed_mode = CTC_PORT_SPEED_1G;
                }

                ret = ret ? ret : sys_humber_port_set_gmac_en(lchip, lport_idx, p_port_master->igs_port_prop[lchip][lport_idx].port_mac_en);
            }
        }
    }
    else
    {
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_serdes_get_mode(uint16 gserdes_id, ctc_serdes_mode_t* serdes_mode)
{
    uint8 lchip;
    uint8 lport, lserdes_id;
    int32 ret = CTC_E_NONE;
    ctc_port_mac_type_t mac_type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GSERDESID_TO_LSERDESID(gserdes_id, lchip, lserdes_id);
    lport = lserdes_id * CTC_MAC_NUM_PER_MACRO;

    PORT_LOCK;
    mac_type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    if (CTC_PORT_MAC_GMAC == mac_type)
    {
        *serdes_mode = p_port_master->igs_port_prop[lchip][lport].serdes_mode;
    }
    else
    {
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;
    return ret;
}

int32
sys_humber_datapath_set_mode(uint8 gchip, ctc_chip_datapath_mode_t datapath_mode)
{
    int32 ret = CTC_E_NONE;
    uint8 lport, index;
    uint8 lchip = 0;

    if ((NULL == p_chip_master) || (NULL == p_port_master))
    {
        return CTC_E_NOT_INIT;
    }

    if (TRUE != sys_humber_chip_is_local(gchip, &lchip))
    {
        return CTC_E_INVALID_LOCAL_CHIPID;
    }

    switch (datapath_mode)
    {
    case CTC_CHIP_48G_PLUS_4TG:

        /* before switch to 48-4, port1~7 and port 13~15 should add to normal channel */
        for (lport = 1; lport < 8; lport++)
        {
            ret = sys_humber_add_port_to_channel(lport, lport);
            if (CTC_E_NONE != ret)
            {
                SYS_CHIP_DBG_INFO("swith port to normal channel error: %d\n", lport);

                /* rollback */
                do
                {
                    sys_humber_add_port_to_channel(lport, SYS_DROP_CHANNEL_ID_START);
                    lport--;
                }
                while (lport);

                return ret;
            }
        }

        for (lport = 13; lport < 16; lport++)
        {
            ret = sys_humber_add_port_to_channel(lport, lport);
            if (CTC_E_NONE != ret)
            {
                SYS_CHIP_DBG_INFO("swith port to normal channel error: %d\n", lport);

                /* rollback */
                do
                {
                    sys_humber_add_port_to_channel(lport, SYS_DROP_CHANNEL_ID_START);
                    lport--;
                }
                while (lport >= 13);

                return ret;
            }
        }

        ret = drv_humber_config_48G_4XG(lchip);
        if (CTC_E_NONE == ret)
        {
            for (index = 0; index < 4; index++)
            {
                lport = index * 12;
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_GMAC;
                p_port_master->egs_port_prop[lchip][lport].tx_threshold = 10;
                p_port_master->egs_port_prop[lchip][lport].pading_en = 1;
                p_port_master->igs_port_prop[lchip][lport].speed_mode = CTC_PORT_SPEED_1G;
                p_port_master->igs_port_prop[lchip][lport].serdes_mode = CTC_SERDES_MODE_1G25;

                drv_humber_set_xgmac_enable(lchip, index, 0);
            }

            /*48-4mode, port1~7 and port13~15 should enable */
            for (lport = 1; lport < 8; lport++)
            {
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_GMAC;
            }

            for (lport = 13; lport < 16; lport++)
            {
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_GMAC;
            }
        }

        break;

    case CTC_CHIP_36G_PLUS_6TG:

        /* before switch to 36-6, port1~7 and port 13~15 should add to reserve channel */
        for (lport = 1; lport < 8; lport++)
        {
            ret = sys_humber_add_port_to_channel(lport, SYS_DROP_CHANNEL_ID_START);
            if (CTC_E_NONE != ret)
            {
                SYS_CHIP_DBG_INFO("swith port to rsv channel error: %d\n", lport);

                /* rollback */
                do
                {
                    sys_humber_add_port_to_channel(lport, lport);
                    lport--;
                }
                while (lport);

                return ret;
            }
        }

        for (lport = 13; lport < 16; lport++)
        {
            ret = sys_humber_add_port_to_channel(lport, SYS_DROP_CHANNEL_ID_START);
            if (CTC_E_NONE != ret)
            {
                SYS_CHIP_DBG_INFO("swith port to rsv channel error: %d\n", lport);

                /* rollback */
                do
                {
                    sys_humber_add_port_to_channel(lport, lport);
                    lport--;
                }
                while (lport >= 13);

                return ret;
            }
        }

        ret = drv_humber_config_36G_6XG(lchip);
        if (CTC_E_NONE == ret)
        {
            for (index = 0; index < 2; index++)
            {
                lport = index * 12;
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_XGMAC;
                p_port_master->egs_port_prop[lchip][lport].tx_threshold = 7;
                p_port_master->egs_port_prop[lchip][lport].pading_en = 1;
                p_port_master->igs_port_prop[lchip][lport].speed_mode = CTC_PORT_SPEED_2G5;
                p_port_master->igs_port_prop[lchip][lport].serdes_mode = CTC_SERDES_MODE_3G125;

                drv_humber_set_xgmac_enable(lchip, index, 1);
            }

            /* 36-6mode, port1~7 and port13~15 should disable */
            for (lport = 1; lport < 8; lport++)
            {
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_MAX;
            }

            for (lport = 13; lport < 16; lport++)
            {
                p_port_master->igs_port_prop[lchip][lport].port_mac_type = CTC_PORT_MAC_MAX;
            }
        }

        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    p_chip_master->datapath_mode[lchip] = datapath_mode;

    return ret;
}

int32
sys_humber_datapath_get_mode(uint8 gchip, ctc_chip_datapath_mode_t* pmode)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;

    if (NULL == pmode)
    {
        return CTC_E_NOT_INIT;
    }

    if (TRUE != sys_humber_chip_is_local(gchip, &lchip))
    {
        return CTC_E_INVALID_LOCAL_CHIPID;
    }

    *pmode = p_chip_master->datapath_mode[lchip];

    return ret;
}

int32
sys_humber_chip_write_gephy_reg(uint16 gport, ctc_chip_gephy_para_t* gephy_para)
{
    uint8 mdio_bus = 0;
    uint8 phy_addr = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = 0;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 cmd_done;
    uint32 timeout = 256;
    xgmac2_xgmac_mdio_cmd_t mdio_cmd;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(gephy_para);

    SYS_CHIP_DBG_FUNC();

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    ret = sys_humber_chip_get_phy_mdio(lport, &mdio_bus, &phy_addr);
    if (CTC_E_NONE != ret)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_CHIP_DBG_INFO("gport:%d, phyreg:%d, mdio_bus:%d, phy_addr:%d, value:%d\n", gport, gephy_para->reg,
                      mdio_bus, phy_addr, gephy_para->val);

    if ((SYS_CHIP_MDIO_BUS0 != mdio_bus) && (SYS_CHIP_MDIO_BUS1 != mdio_bus))
    {
        SYS_CHIP_DBG_INFO("mdio bus mismatch, mdio bus: %d\n", mdio_bus);
        return CTC_E_INVALID_PARAM;
    }

    PORT_LOCK;

    /* the first mdio op skip check cmd_done status */
    if (0 == p_chip_master->mdio_used[mdio_bus])
    {
        p_chip_master->mdio_used[mdio_bus] = 1;
    }
    else
    {
        /* read mdio status */
        table_id = XGMAC0_XGMAC_MDIO_CMD_STATUS + 36 * mdio_bus;
        field_id = XGMAC0_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);

        do
        {
            ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
            if (CTC_E_NONE != ret)
            {
                PORT_UNLOCK;
                return ret;
            }

            timeout--;
        }
        while ((!cmd_done) && (timeout));

        if (!cmd_done)
        {
            SYS_CHIP_DBG_INFO("read gephy mdio status timeout!\n");
            PORT_UNLOCK;
            return CTC_E_CHIP_TIME_OUT;
        }
    }

    mdio_cmd.st = SYS_CHIP_MDIO_ST_1G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_1G_WRITE;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = gephy_para->reg;
    mdio_cmd.data = gephy_para->val;
    mdio_cmd.rsv_0 = 0x0;

    /* write mdio op cmd */
    table_id = XGMAC0_XGMAC_MDIO_CMD + 36 * mdio_bus;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write gephy mdio write cmd failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    PORT_UNLOCK;
    return CTC_E_NONE;
}

int32
sys_humber_chip_read_gephy_reg(uint16 gport, ctc_chip_gephy_para_t* gephy_para)
{
    uint8 mdio_bus = 0;
    uint8 phy_addr = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = 0;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 cmd_done;
    uint32 timeout = 256;
    xgmac2_xgmac_mdio_cmd_t mdio_cmd;
    uint32 value = 0;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(gephy_para);

    SYS_CHIP_DBG_FUNC();

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    ret = sys_humber_chip_get_phy_mdio(lport, &mdio_bus, &phy_addr);
    if (CTC_E_NONE != ret)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_CHIP_DBG_INFO("gport:%d, phyreg:%d, mdio_bus:%d, phy_addr:%d\n", gport, gephy_para->reg,
                      mdio_bus, phy_addr);

    if ((SYS_CHIP_MDIO_BUS0 != mdio_bus) && (SYS_CHIP_MDIO_BUS1 != mdio_bus))
    {
        SYS_CHIP_DBG_INFO("mdio bus mismatch, mdio bus: %d\n", mdio_bus);
        return CTC_E_INVALID_PARAM;
    }

    PORT_LOCK;
    /* the first mdio op skip check cmd_done status */
    if (0 == p_chip_master->mdio_used[mdio_bus])
    {
        p_chip_master->mdio_used[mdio_bus] = 1;
    }
    else
    {
        /* read mdio status */
        table_id = XGMAC0_XGMAC_MDIO_CMD_STATUS + 36 * mdio_bus;
        field_id = XGMAC0_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);

        do
        {
            ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
            if (CTC_E_NONE != ret)
            {
                PORT_UNLOCK;
                return ret;
            }

            timeout--;
        }
        while ((!cmd_done) && (timeout));

        if (!cmd_done)
        {
            SYS_CHIP_DBG_INFO("read gephy mdio status timeout!\n");
            PORT_UNLOCK;
            return CTC_E_CHIP_TIME_OUT;
        }
    }

    mdio_cmd.st = SYS_CHIP_MDIO_ST_1G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_1G_READ;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = gephy_para->reg;
    mdio_cmd.data = 0xffff;
    mdio_cmd.rsv_0 = 0x0;

    /* write mdio op cmd */
    table_id = XGMAC0_XGMAC_MDIO_CMD + 36 * mdio_bus;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write gephy mdio read cmd failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    /* read mdio status */
    timeout = 256;
    table_id = XGMAC0_XGMAC_MDIO_CMD_STATUS + 36 * mdio_bus;
    field_id = XGMAC0_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);

    do
    {
        ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
        if (CTC_E_NONE != ret)
        {
            PORT_UNLOCK;
            return ret;
        }

        timeout--;
    }
    while ((!cmd_done) && (timeout));

    if (!cmd_done)
    {
        SYS_CHIP_DBG_INFO("read gephy mdio status timeout!\n");
        PORT_UNLOCK;
        return CTC_E_CHIP_TIME_OUT;
    }

    /* read data */
    table_id = XGMAC0_XGMAC_MDIO_RD_DATA + 36 * mdio_bus;
    field_id = XGMAC0_XGMAC_MDIO_RD_DATA_XGMAC_MDIO_RD_DATA;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &value);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("read gephy mdio data failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    gephy_para->val = value;

    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_chip_write_xgphy_reg(uint16 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    uint8 mdio_bus = 0;
    uint8 phy_addr = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 cmd_done;
    uint32 timeout = 256;
    xgmac2_xgmac_mdio_cmd_t mdio_cmd;
    int32 ret = 0;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(xgphy_para);

    SYS_CHIP_DBG_FUNC();

    if (0 == xgphy_para->devno)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    ret = sys_humber_chip_get_phy_mdio(lport, &mdio_bus, &phy_addr);
    if (CTC_E_NONE != ret)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_CHIP_DBG_INFO("gport:%d, phyreg:%d, devno:%d,mdio_bus:%d, phy_addr:%d, value:%d\n", gport, xgphy_para->reg,
                      xgphy_para->devno, mdio_bus, phy_addr, xgphy_para->val);

    if (SYS_CHIP_MDIO_BUS2 != mdio_bus)
    {
        SYS_CHIP_DBG_INFO("mdio bus mismatch, mdio bus: %d\n", mdio_bus);
        return CTC_E_INVALID_PARAM;
    }

    PORT_LOCK;
    /* the first mdio op skip check cmd_done status */
    if (0 == p_chip_master->mdio_used[mdio_bus])
    {
        p_chip_master->mdio_used[mdio_bus] = 1;
    }
    else
    {
        /* read mdio status */
        table_id = XGMAC2_XGMAC_MDIO_CMD_STATUS;
        field_id = XGMAC2_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);

        do
        {
            ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
            if (CTC_E_NONE != ret)
            {
                PORT_UNLOCK;
                return ret;
            }

            timeout--;
        }
        while ((!cmd_done) && (timeout));

        if (!cmd_done)
        {
            SYS_CHIP_DBG_INFO("read gephy mdio status timeout!\n");
            PORT_UNLOCK;
            return CTC_E_CHIP_TIME_OUT;
        }
    }

    /* write mdio op cmd: send address */
    mdio_cmd.st = SYS_CHIP_MDIO_ST_10G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_10G_ADDR;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = xgphy_para->devno;
    mdio_cmd.data = xgphy_para->reg;
    mdio_cmd.rsv_0 = 0x0;

    cmd = DRV_IOW(IOC_REG, XGMAC2_XGMAC_MDIO_CMD, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write xgphy mdio address failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    /* read mdio status */
    timeout = 256;
    table_id = XGMAC2_XGMAC_MDIO_CMD_STATUS;
    field_id = XGMAC2_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);

    do
    {
        ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
        if (CTC_E_NONE != ret)
        {
            PORT_UNLOCK;
            return ret;
        }

        timeout--;
    }
    while ((!cmd_done) && (timeout));

    if (!cmd_done)
    {
        SYS_CHIP_DBG_INFO("read xgphy mdio status timeout!\n");
        PORT_UNLOCK;
        return CTC_E_CHIP_TIME_OUT;
    }

    mdio_cmd.st = SYS_CHIP_MDIO_ST_10G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_10G_WRITE;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = xgphy_para->devno;
    mdio_cmd.data = xgphy_para->val;
    mdio_cmd.rsv_0 = 0x0;

    /* write mdio op cmd: send data */
    cmd = DRV_IOW(IOC_REG, XGMAC2_XGMAC_MDIO_CMD, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write xgphy mdio data failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_chip_read_xgphy_reg(uint16 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    uint8 mdio_bus = 0;
    uint8 phy_addr = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 cmd_done;
    uint32 timeout = 256;
    xgmac2_xgmac_mdio_cmd_t mdio_cmd;
    int32 ret = 0;
    uint32 value = 0;

    if (NULL == p_chip_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(xgphy_para);

    SYS_CHIP_DBG_FUNC();

    if (0 == xgphy_para->devno)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    ret = sys_humber_chip_get_phy_mdio(lport, &mdio_bus, &phy_addr);
    if (CTC_E_NONE != ret)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_CHIP_DBG_INFO("gport:%d, phyreg:%d, devno:%d,mdio_bus:%d, phy_addr:%d\n", gport, xgphy_para->reg,
                      xgphy_para->devno, mdio_bus, phy_addr);

    if (SYS_CHIP_MDIO_BUS2 != mdio_bus)
    {
        SYS_CHIP_DBG_INFO("mdio bus mismatch, mdio bus: %d\n", mdio_bus);
        return CTC_E_INVALID_PARAM;
    }

    PORT_LOCK;

    /* the first mdio op skip check cmd_done status */
    if (0 == p_chip_master->mdio_used[mdio_bus])
    {
        p_chip_master->mdio_used[mdio_bus] = 1;
    }
    else
    {
        /* read mdio status */
        table_id = XGMAC2_XGMAC_MDIO_CMD_STATUS;
        field_id = XGMAC2_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);

        do
        {
            ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
            if (CTC_E_NONE != ret)
            {
                PORT_UNLOCK;
                return ret;
            }

            timeout--;
        }
        while ((!cmd_done) && (timeout));

        if (!cmd_done)
        {
            SYS_CHIP_DBG_INFO("read gephy mdio status timeout!\n");
            PORT_UNLOCK;
            return CTC_E_CHIP_TIME_OUT;
        }
    }

    /* send address */
    mdio_cmd.st = SYS_CHIP_MDIO_ST_10G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_10G_ADDR;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = xgphy_para->devno;
    mdio_cmd.data = xgphy_para->reg;
    mdio_cmd.rsv_0 = 0x0;

    cmd = DRV_IOW(IOC_REG, XGMAC2_XGMAC_MDIO_CMD, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write xgphy mdio address failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    /* read mdio status */
    timeout = 256;
    table_id = XGMAC2_XGMAC_MDIO_CMD_STATUS;
    field_id = XGMAC2_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);

    do
    {
        ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
        if (CTC_E_NONE != ret)
        {
            PORT_UNLOCK;
            return ret;
        }

        timeout--;
    }
    while ((!cmd_done) && (timeout));

    if (!timeout)
    {
        SYS_CHIP_DBG_INFO("read xgphy mdio status timeout!\n");
        PORT_UNLOCK;
        return CTC_E_CHIP_TIME_OUT;
    }

    /* send read command */
    mdio_cmd.st = SYS_CHIP_MDIO_ST_10G;
    mdio_cmd.op = SYS_CHIP_MDIO_OP_10G_READ;
    mdio_cmd.prtad = phy_addr;
    mdio_cmd.devad = xgphy_para->devno;
    mdio_cmd.data = 0xffff;
    mdio_cmd.rsv_0 = 0x0;

    cmd = DRV_IOW(IOC_REG, XGMAC2_XGMAC_MDIO_CMD, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &mdio_cmd);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("write xgphy mdio read cmd failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    /* read mdio status */
    timeout = 256;
    table_id = XGMAC2_XGMAC_MDIO_CMD_STATUS;
    field_id = XGMAC2_XGMAC_MDIO_CMD_STATUS_MDIO_CMD_DONE;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);

    do
    {
        ret = drv_reg_ioctl(lchip, 0, cmd, &cmd_done);
        if (CTC_E_NONE != ret)
        {
            PORT_UNLOCK;
            return ret;
        }

        timeout--;
    }
    while ((!cmd_done) && (timeout));

    if (!timeout)
    {
        SYS_CHIP_DBG_INFO("read xgphy mdio status timeout!\n");
        PORT_UNLOCK;
        return CTC_E_CHIP_TIME_OUT;
    }

    /* read data */
    cmd = DRV_IOR(IOC_REG, XGMAC2_XGMAC_MDIO_RD_DATA, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &value);
    if (CTC_E_NONE != ret)
    {
        SYS_CHIP_DBG_INFO("read xgphy mdio data failed!\n");
        PORT_UNLOCK;
        return ret;
    }

    xgphy_para->val = value;

    PORT_UNLOCK;

    return CTC_E_NONE;
}

