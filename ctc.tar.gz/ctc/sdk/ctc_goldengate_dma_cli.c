/**
 @file ctc_dma_cli.c

 @date 2012-3-20

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_api.h"
#include "ctc_dma.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_goldengate_dma_cli.h"
#include "ctc_port_mapping_cli.h"

extern int32
sys_goldengate_dma_show_status(uint8 lchip);
extern int32
sys_goldengate_dma_show_desc(uint8 lchip, uint8 chan_id, uint32 start_idx, uint32 end_idx);
extern int32
sys_goldengate_dma_function_pause(uint8 lchip, uint8 chan_id, uint8 en);
extern int32
sys_goldengate_dma_set_chan_en(uint8 lchip, uint8 chan_id, uint8 chan_en);
extern int32
sys_goldengate_dma_table_rw(uint8 lchip, uint8 is_read, uint32 addr, uint16 entry_len, uint16 entry_num, uint32* p_value);

int32
ctc_dump8(uintptr addr, uint32 len)
{
    uint8* data = (uint8*)addr;
    uint32 cnt = 0;
    char line[256];
    char tmp[256];

    if (0 == len)
    {
        return CTC_E_NONE;
    }

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt % 16) == 0)
        {
            if (cnt != 0)
            {
                ctc_cli_out("%s", line);
            }

            sal_memset(line, 0, sizeof(line));
            sal_sprintf(tmp, "\n%p:  ", (void*)(addr + cnt));
            if (sal_strlen(tmp) > 32)
            {
                tmp[32] = '\0';
            }
            sal_strcat(line, tmp);
        }

        sal_sprintf(tmp, "%02X", data[cnt]);
        if (sal_strlen(tmp) > 32)
        {
            tmp[32] = '\0';
        }
        sal_strcat(line, tmp);

        if ((cnt % 2) == 1)
        {
            sal_strcat(line, " ");
        }
    }

    ctc_cli_out("%s", line);
    ctc_cli_out("\n");

    return CTC_E_NONE;
}

CTC_CLI(ctc_cli_gg_dma_show_status,
        ctc_cli_gg_dma_show_status_cmd,
        "show dma status (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DMA_M_STR,
        "State for global config",
        "Detail",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint32 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    ret = sys_goldengate_dma_show_status(lchip);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gg_dma_mem_dump,
        ctc_cli_gg_dma_mem_dump_cmd,
        "dma mem dump addr ADDR len LEN (lchip LCHIP|)",
        "dma",
        "memory",
        "dump",
        "address",
        "address value",
        "dump mem len",
        "len value",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    uintptr addr = 0;
    uint32 len = 0;
    uint32 index = 0;
    uint8 lchip = 0;

    ctc_cli_out("Memory Dump:\n");

    /* parser fid */
    CTC_CLI_GET_UINT32("address", addr, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    /* parser key index */
    CTC_CLI_GET_UINT32("len", len, argv[1]);

    if (0)
    {
        for (index = 0; index < len; index++)
        {
            ctc_cli_out("%08X   ", *((uint32*)addr+index));

            if (((index+1) %8) == 0)
            {
                ctc_cli_out("\n");
            }
        }
    }
    else
    {
        ctc_dump8(addr, len);
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_show_dma_desc,
        ctc_cli_gg_show_dma_desc_cmd,
        "show dma desc (stats|packet-rx chan CHAN|packet-tx chan CHAN|table-r|table-w|ipfix|hashdump|sdc|learning|monitor) (start-idx START) (end-idx END) (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        "DMA module",
        "Descriptor",
        "Stats descriptor",
        "Packet RX descriptor",
        "DMA channel",
        "DMA channel ID",
        "Packet TX descriptor",
        "DMA channel",
        "DMA channel ID",
        "Table read descriptor",
        "Table write descriptor",
        "Ipfix descriptor",
        "HashDump descriptor",
        "Sdc descriptor",
        "Learning descriptor",
        "Monitor descriptor",
        "Start desc index",
        "Start value",
        "End desc index",
        "End value",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    uint8 index = 0;
    uint32 start_idx = 0;
    uint32 end_idx = 0;
    uint8 chan_id = 0;
    int32 ret = 0;
    uint8 lchip = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    if (0 == sal_strcmp(argv[0], "stats"))
    {
        chan_id = 8;
    }
    else if(0 == sal_strcmp(argv[0], "packet-rx"))
    {
        index = CTC_CLI_GET_ARGC_INDEX("chan");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8("chan id", chan_id, argv[index + 1]);
        }
    }
    //xupc
    else if(0 == sal_strcmp(argv[0], "packet-tx"))
    {
        index = CTC_CLI_GET_ARGC_INDEX("chan");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8("chan id", chan_id, argv[index + 1]);
        }
    }
    else if(0 == sal_strcmp(argv[0], "table-r"))
    {
        chan_id = 7;
    }
    else if(0 == sal_strcmp(argv[0], "table-w"))
    {
        chan_id = 6;
    }
    else if(0 == sal_strcmp(argv[0], "ipfix"))
    {
        chan_id = 13;
    }
    else if(0 == sal_strcmp(argv[0], "hashdump"))
    {
        chan_id = 12;
    }
    else if(0 == sal_strcmp(argv[0], "sdc"))
    {
        chan_id = 14;
    }
    else if(0 == sal_strcmp(argv[0], "learning"))
    {
        chan_id = 11;
    }
    else if(0 == sal_strcmp(argv[0], "monitor"))
    {
        chan_id = 15;
    }
    else if(0 == sal_strcmp(argv[0], "internal"))
    {
        chan_id = 9;
    }
    else if(0 == sal_strcmp(argv[0], "queue"))
    {
        chan_id = 10;
    }
    else
    {
        return CLI_ERROR;
    }

    index = CTC_CLI_GET_ARGC_INDEX("start-idx");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("start idx", start_idx, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("end-idx");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("end idx", end_idx, argv[index + 1]);
    }

    ret = sys_goldengate_dma_show_desc(lchip, chan_id, start_idx, end_idx);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));

        return ret;
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_gg_dma_func_pause,
        ctc_cli_gg_dma_func_pause_cmd,
        "dma set (packet-rx|packet-tx|table-r|table-w|ipfix|hashdump|sdc|learning|monitor) (pause|resume) (lchip LCHIP|)",
        "DMA module",
        "Set",
        "Packet RX",
        "Packet TX",
        "Table read",
        "Table write",
        "Ipfix",
        "HashDump",
        "Sdc",
        "Learning",
        "Monitor",
        "Func Pause",
        "Func Resume",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8 is_pause = 0;
    uint8 chan_id = 0;
    uint32 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    if(0 == sal_strcmp(argv[0], "packet-rx"))
    {
        chan_id = 0;
    }
    else if(0 == sal_strcmp(argv[0], "packet-tx"))
    {
        chan_id = 4;
    }
    else if(0 == sal_strcmp(argv[0], "table-r"))
    {
        chan_id = 7;
    }
    else if(0 == sal_strcmp(argv[0], "table-w"))
    {
        chan_id = 6;
    }
    else if(0 == sal_strcmp(argv[0], "ipfix"))
    {
        chan_id = 13;
    }
    else if(0 == sal_strcmp(argv[0], "hashdump"))
    {
        chan_id = 12;
    }
    else if(0 == sal_strcmp(argv[0], "sdc"))
    {
        chan_id = 14;
    }
    else if(0 == sal_strcmp(argv[0], "learning"))
    {
        chan_id = 11;
    }
    else if(0 == sal_strcmp(argv[0], "monitor"))
    {
        chan_id = 15;
    }
    else
    {
        return CLI_ERROR;
    }

    if(0 == sal_strcmp(argv[1], "pause"))
    {
        is_pause = 1;
    }
    else
    {
        is_pause = 0;
    }

    if(0 == sal_strcmp(argv[0], "packet-rx"))
    {
        for(chan_id = 0;chan_id<4;chan_id++)
        {
            ret = sys_goldengate_dma_function_pause(lchip, chan_id, is_pause);
            if (ret)
            {
                ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
                return CLI_ERROR;
            }
        }
    }
    else if(0 == sal_strcmp(argv[0], "packet-tx"))
    {
        for(chan_id = 4;chan_id<6;chan_id++)
        {
            ret = sys_goldengate_dma_function_pause(lchip, chan_id, is_pause);
            if (ret)
            {
                ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
                return CLI_ERROR;
            }
        }
    }
    else
    {
        ret = sys_goldengate_dma_function_pause(lchip, chan_id, is_pause);
        if (ret)
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_gg_dma_func_en,
        ctc_cli_gg_dma_func_en_cmd,
        "dma set (packet-rx|packet-tx|table-r|table-w|ipfix|hashdump|sdc|learning|monitor) (enable|disable) (lchip LCHIP|)",
        "DMA module",
        "Set",
        "Packet RX",
        "Packet TX",
        "Table read",
        "Table write",
        "Ipfix",
        "HashDump",
        "Sdc",
        "Learning",
        "Monitor",
        "Func Enable",
        "Func Disable",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8 is_en = 0;
    uint8 chan_id = 0;
    uint32 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    if(0 == sal_strcmp(argv[0], "packet-rx"))
    {
        chan_id = 0;
    }
    else if(0 == sal_strcmp(argv[0], "packet-tx"))
    {
        chan_id = 4;
    }
    else if(0 == sal_strcmp(argv[0], "table-r"))
    {
        chan_id = 7;
    }
    else if(0 == sal_strcmp(argv[0], "table-w"))
    {
        chan_id = 6;
    }
    else if(0 == sal_strcmp(argv[0], "ipfix"))
    {
        chan_id = 13;
    }
    else if(0 == sal_strcmp(argv[0], "hashdump"))
    {
        chan_id = 12;
    }
    else if(0 == sal_strcmp(argv[0], "sdc"))
    {
        chan_id = 14;
    }
    else if(0 == sal_strcmp(argv[0], "learning"))
    {
        chan_id = 11;
    }
    else if(0 == sal_strcmp(argv[0], "monitor"))
    {
        chan_id = 15;
    }
    else
    {
        return CLI_ERROR;
    }

    if(0 == sal_strcmp(argv[1], "enable"))
    {
        is_en = 1;
    }
    else
    {
        is_en = 0;
    }

    if(0 == sal_strcmp(argv[0], "packet-rx"))
    {
        for(chan_id = 0;chan_id<4;chan_id++)
        {
            ret = sys_goldengate_dma_set_chan_en(lchip, chan_id, is_en);
            if (ret)
            {
                ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
                return CLI_ERROR;
            }
        }
    }
    else if(0 == sal_strcmp(argv[0], "packet-tx"))
    {
        for(chan_id = 4;chan_id<6;chan_id++)
        {
            ret = sys_goldengate_dma_set_chan_en(lchip, chan_id, is_en);
            if (ret)
            {
                ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
                return CLI_ERROR;
            }
        }
    }
    else
    {
        ret = sys_goldengate_dma_set_chan_en(lchip, chan_id, is_en);
        if (ret)
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return CLI_SUCCESS;
}

#ifdef SDK_IN_USERMODE
CTC_CLI(ctc_cli_gg_dma_tbl_wr,
        ctc_cli_gg_dma_tbl_wr_cmd,
        "dma write table TBL_ADDR entry-len LEN entry-num NUM (lchip LCHIP|)",
        CTC_CLI_DMA_M_STR,
        "Write table",
        "Asic table",
        "Table address",
        "Length of entry, unit:bytes",
        "Value <1-65535>",
        "Length of system buffer",
        "Value <1-65535>",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)

{
    int32 ret       = CLI_SUCCESS;
    uint8 lchip = 0;
    uint32 index = 0;
    uint32 data = 0;
    uint32 buffer_len = 0;
    uint32 addr = 0;
    uint16 entry_len = 0;
    uint16 num = 0;
    uint32* buffer = NULL;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    CTC_CLI_GET_UINT32_RANGE("table addr", addr, argv[0], 0, CTC_MAX_UINT32_VALUE);

    CTC_CLI_GET_UINT16_RANGE("table entry length", entry_len, argv[1], 0, CTC_MAX_UINT16_VALUE);

    CTC_CLI_GET_UINT16_RANGE("number of entry", num, argv[2], 0, CTC_MAX_UINT16_VALUE);

    buffer_len = entry_len*num;

    buffer = (uint32*)mem_malloc(MEM_CLI_MODULE, buffer_len);
    if (NULL == buffer)
    {
        ctc_cli_out("%% Alloc  memory  failed \n");
        return CLI_ERROR;
    }

    sal_memset(buffer, 0, buffer_len);

    for(index = 0; index < buffer_len/4; index++)
    {
        ctc_cli_out("Please Input %dst Data:  \n", index);
        scanf("%x", &data);
        buffer[index] = data;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    ret = sys_goldengate_dma_table_rw(lchip, 0, addr, entry_len, num, buffer);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    mem_free(buffer);
    return ret;
}
#endif

CTC_CLI(ctc_cli_gg_dma_tbl_rd,
        ctc_cli_gg_dma_tbl_rd_cmd,
        "dma read table TBL_ADDR entry-len LEN entry-num NUM (lchip LCHIP|)",
        CTC_CLI_DMA_M_STR,
        "read table",
        "Asic table",
        "Table address",
        "Length of entry, unit:bytes",
        "Value <1-65535>",
        "Number of Entry",
        "Value <1-65535>",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret       = CLI_SUCCESS;
    uint8 lchip = 0;
    uint32 index = 0;
    uint16 num = 0;
    uint16 entry_num = 0;
    uint32 buf_len = 0;
    uint32 addr = 0;
    uint16 entry_len = 0;
    uint32* buffer = NULL;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    CTC_CLI_GET_UINT32_RANGE("table addr", addr, argv[0], 0, CTC_MAX_UINT32_VALUE);

    CTC_CLI_GET_UINT16_RANGE("table entry length", entry_len, argv[1], 0, CTC_MAX_UINT16_VALUE);

    CTC_CLI_GET_UINT16_RANGE("number of entry", entry_num, argv[2], 0, CTC_MAX_UINT16_VALUE);

    buf_len = (entry_len*entry_num);

    buffer = mem_malloc(MEM_CLI_MODULE, buf_len);
    if (NULL == buffer)
    {
        ctc_cli_out("%% Alloc  memory  failed \n");
        return CLI_ERROR;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    sal_memset(buffer, 0, buf_len);

    ret = sys_goldengate_dma_table_rw(lchip, 1, addr, entry_len, entry_num, buffer);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("DMA Read Table Result: \n");

    for (index = 0; index < entry_num; index++)
    {
        ctc_cli_out("Entry Index: %d \n", index);
        for (num = 0; num < (entry_len)/4; num++)
        {
            ctc_cli_out("0x%08x  ", buffer[index*(entry_len)/4 + num]);
        }
        ctc_cli_out("\n");
    }

    mem_free(buffer);
    return ret;
}


int32
ctc_goldengate_dma_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_show_status_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_mem_dump_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_show_dma_desc_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_func_pause_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_func_en_cmd);
#ifdef SDK_IN_USERMODE
    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_tbl_wr_cmd);
#endif
    install_element(CTC_SDK_MODE, &ctc_cli_gg_dma_tbl_rd_cmd);

    return 0;
}

