#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_tblreg_wr_cli.h"

#include "drv_tbl_reg.h"
#include "drv_io.h"
#include "drv_enum.h"

extern int8 ctc_table_str[MaxTblId_t][CTC_GREATBELT_TR_BUF_SIZE];

uint32 g_ctc_table_data[32];

#define _GLB_ENABLE_DBGSHOW_

#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG        0
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG        1
#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL        2
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL        3
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG        4
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL        5
#define CTC_DIAG_TBLREG_CHIP_LIST_REG            6
#define CTC_DIAG_TBLREG_CHIP_LIST_TBL            7

typedef struct
{
    uintptr  param[5];
    uint8    buf[CTC_GREATBELT_TR_BUF_SIZE];
    uint8    buf2[CTC_GREATBELT_TR_BUF_SIZE];
    uint32  step;
} ctc_dbg_tblreg_show_req_t;

char*
_tbl_type_to_str(ext_content_type_t type)
{
    switch (type)
    {
    case EXT_INFO_TYPE_NORMAL:
        return "RAM";

    case EXT_INFO_TYPE_TCAM:
        return "TCAM";

    case EXT_INFO_TYPE_DYNAMIC:
        return "DYNAMIC";

    default:
        return "Invalid";
    }
}


char*
_tbl_slice_type_to_str(ds_slice_type_t type)
{
    switch (type)
    {
    case SLICE_Share:
        return "SHARE";

    case SLICE_Duplicated:
        return "DUPLICATE";

    case SLICE_Cascade:
        return "CASCADE";

    case SLICE_PreCascade:
        return "PreCASCADE";

    case SLICE_Default:
        return "Default";

    default:
        return "Invalid";
    }
}


char*
ctc_dbg_tblreg_dump_list_one(uint32 tbl_id, uint32* first_flag)
{
    tables_info_t* tbl_ptr = NULL;
    ext_content_type_t ext_type = 0;
    char tmp[8];
    char tbl_name[CTC_GREATBELT_TR_BUF_SIZE];

    tbl_ptr = TABLE_INFO_PTR(tbl_id);
    if (tbl_ptr->ptr_ext_info)
    {
        ext_type = tbl_ptr->ptr_ext_info->ext_content_type;
    }

    if (*first_flag)
    {
        if (1 == tbl_ptr->addr_num)
        {
            ctc_cli_out("%-5s %-10s %-6s %-7s %-7s %-6s %-7s %-7s %-20s\n",
                        "TblID", "Address",  "Number", "EntrySZ", "KeySZ", "Fields", "Type", "Slice", "Name");
            ctc_cli_out("----------------------------------------------------------------------------------\n");
        }
        else
        {
        }
        *first_flag = FALSE;
    }

    sal_memset(tmp, 0, sizeof(tmp));

    if (drv_table_is_tcam_key(tbl_id))
    {
        if (TABLE_ENTRY_SIZE(tbl_id) == TCAM_KEY_SIZE(tbl_id))
        {
            sal_snprintf(tmp, 7, "%d", TCAM_KEY_SIZE(tbl_id));
        }
        else
        {
            sal_snprintf(tmp, 7, "*%d", TCAM_KEY_SIZE(tbl_id));
        }
    }

    drv_get_tbl_string_by_id(tbl_id, (char*)tbl_name);
    ctc_cli_out("%-5d 0x%08x %-6d %-7d %-7s %-6d %-7s %-9s %-20s\n",
                tbl_id, tbl_ptr->addrs[0],  tbl_ptr->entry,
                tbl_ptr->word, tmp, tbl_ptr->field_num, _tbl_type_to_str(ext_type),
                _tbl_slice_type_to_str(tbl_ptr->slicetype),tbl_name);

    return CLI_SUCCESS;
}

int32
show_ram_table_by_data_table_addr( uint32 tbl_id, uint32 index, uint32* data_entry, uint32 addr)
{
    uint32 value[DRV_MAX_ARRAY_NUM] = {0};
    uint8 uint32_id = 0;
    fields_t* fld_ptr = NULL;
    int32 fld_idx = 0;

    tables_info_t* tbl_ptr = NULL;

    tbl_ptr = TABLE_INFO_PTR(tbl_id);
    ctc_cli_out("\n");

     /* non-TCAM */
    ctc_cli_out("%-6s %-10s %-10s %-6s %-10s Index(%d) Address(0x%08x)\n", "FldID", "Value", "Mask", "BitLen", "Name", index, addr);
    ctc_cli_out("----------------------------------------------------------------------------------\n");


    for (fld_idx = 0; fld_idx < tbl_ptr->field_num; fld_idx++)
    {
        sal_memset(value, 0 , DRV_MAX_ARRAY_NUM * 4);
        fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);

        drv_get_field(tbl_id, fld_idx, data_entry, value);
        ctc_cli_out("%-6d 0x%08x %-10s %-6d %-10s\n", fld_idx, value[0], "", fld_ptr->bits, fld_ptr->ptr_field_name);
        for (uint32_id = 1; uint32_id < ((fld_ptr->bits + 31)/32); uint32_id ++)
        {
            ctc_cli_out("%-6s 0x%08x \n", " ", value[uint32_id]);
        }

    }
    ctc_cli_out("----------------------------------------------------------------------------------\n");

    ctc_cli_out("%-6s %-10s  %-10s \n", "Word",  "Addr", "Value");
    for (uint32_id = 0; uint32_id < TABLE_ENTRY_SIZE(tbl_id) / DRV_BYTES_PER_WORD; uint32_id ++)
    {
        ctc_cli_out("%-6d 0x%08x 0x%08x\n", uint32_id, addr + uint32_id*4, *(data_entry + uint32_id));
    }

    ctc_cli_out("\n");

    return CLI_SUCCESS;
}


int32
show_ram_table_by_data_table_id( uint32 tbl_id, uint32 index, uint32* data_entry)
{
    int32  ret = 0;
    uint32 addr = 0;

    ret = drv_table_get_hw_addr(tbl_id, index, &addr, FALSE);
    if (ret < 0)
    {
        ctc_cli_out("%% get table_id %d index %d address fail\n", tbl_id, index);
        return CLI_ERROR;
    }

    show_ram_table_by_data_table_addr(tbl_id, index, data_entry, addr);

    return CLI_SUCCESS;
}

int32
write_ram_table_by_data_table_id( uint32 tbl_id, uint32 index, uint32* data_entry)
{
    int32  ret = CLI_SUCCESS;
    uint32 cmd = 0;

    if (drv_table_is_tcam_key(tbl_id)
        || drv_table_is_lpm_tcam_key(tbl_id))
    {

    }
    else
    {
        cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
        ret = drv_ioctl(0, index, cmd, data_entry);
    }

    return ret;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(char* tbl_name, uint32 id, uint32 detail)
{
    tables_info_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;
    uint8 seg_id = 0;

    tbl_ptr = TABLE_INFO_PTR(id);
    ctc_dbg_tblreg_dump_list_one(id, &first_flag);
    ctc_cli_out("----------------------------------------------------------------------------------\n");
    if (detail)
    {
        /* descrption */
        ctc_cli_out("%-5s %-5s %-4s %-4s %-6s %-8s %-30s\n",
                "TblID", "FldID","Word", "Bit", "SegLen","TotalLen", "Name");

        /* value */
        for (fld_idx = 0; fld_idx < tbl_ptr->field_num; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);

            ctc_cli_out("%-5d %-5d %-4d %-4d %-6d %-8d %-30s\n",
                id,
                fld_idx,
                fld_ptr->ptr_seg[0].word_offset,
                fld_ptr->ptr_seg[0].start,
                fld_ptr->ptr_seg[0].bits,
                fld_ptr->bits,
                fld_ptr->ptr_field_name);
            for (seg_id = 1; seg_id < fld_ptr->seg_num; seg_id ++)
            {
                ctc_cli_out("%-11s %-4d %-4d %-6d \n",
                " ",
                fld_ptr->ptr_seg[seg_id].word_offset,
                fld_ptr->ptr_seg[seg_id].start,
                fld_ptr->ptr_seg[seg_id].bits);
            }
        }

        ctc_cli_out("\n");
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl_db(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 tbl_id = 0;
    uint32 detail = 0;
    char* tbl_name = NULL;

    detail = req->param[2];

    tbl_name = (char*)req->buf;
    if(DRV_E_NONE != drv_get_tbl_id_by_string(&tbl_id, tbl_name))
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CLI_ERROR;
    }

    ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(tbl_name, tbl_id, detail);
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CLI_SUCCESS;
}


int32
show_tcam_table_by_data_table_id(uint32 tbl_id, uint32 index, uint32* data_entry, uint32* mask_entry)
{
    uint32 value[DRV_MAX_ARRAY_NUM] = {0};
    uint32 mask[DRV_MAX_ARRAY_NUM] = {0};
    uint8 uint32_id = 0;
    fields_t* fld_ptr = NULL;
    int32 fld_idx = 0;

    tables_info_t* tbl_ptr = NULL;

    tbl_ptr = TABLE_INFO_PTR(tbl_id);
    ctc_cli_out("\n");

    uint32 addr = 0;

        /* TCAM */
    ctc_cli_out("%-6s %-10s %-10s %-6s %-10s Index(%d)\n", "FldID", "Value", "Mask", "BitLen", "Name", index);
    ctc_cli_out("----------------------------------------------------------------------------------\n");

    for (fld_idx = 0; fld_idx < tbl_ptr->field_num; fld_idx++)
    {
        sal_memset(value, 0 , sizeof(DRV_MAX_ARRAY_NUM * 4));
        sal_memset(mask, 0 , sizeof(DRV_MAX_ARRAY_NUM * 4));
        fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
        drv_get_field(tbl_id, fld_idx, data_entry, value);
        drv_get_field(tbl_id, fld_idx, mask_entry, mask);
        ctc_cli_out("%-6d 0x%08x 0x%08x %-6d %-10s\n", fld_idx, value[0], mask[0], fld_ptr->bits, fld_ptr->ptr_field_name);

        for (uint32_id = 1; uint32_id < ((fld_ptr->bits + 31)/32); uint32_id ++)
        {
            ctc_cli_out("%-6s 0x%08x 0x%08x\n", " ", value[uint32_id], mask[uint32_id]);
        }
    }
    ctc_cli_out("----------------------------------------------------------------------------------\n");

    drv_tcam_key_get_hw_addr(tbl_id, index, TRUE, &addr);
    ctc_cli_out("%-6s %-10s  %-10s \n", "Word",  "Addr", "Value");
    for (uint32_id = 0; uint32_id < TABLE_ENTRY_SIZE(tbl_id) / DRV_BYTES_PER_WORD; uint32_id ++)
    {
        ctc_cli_out("%-6d 0x%08x 0x%08x\n", uint32_id, addr + uint32_id*4, *(data_entry + uint32_id));
    }

    ctc_cli_out("\n");


    return CLI_SUCCESS;

}

int32
gdb_show( uint32 tbl_id, uint32* data_entry)
{
    if (drv_table_is_tcam_key(tbl_id)
        || drv_table_is_lpm_tcam_key(tbl_id))
    {
        return show_tcam_table_by_data_table_id(tbl_id, 0, data_entry, data_entry);
    }
    else
    {
        return show_ram_table_by_data_table_addr(tbl_id, 0, data_entry, 0);
    }

    return CLI_SUCCESS;

}

int32
gdb_read( uint32 tbl_id, uint32 index)
{
    uint32 cmd = 0;
    uint8  chip =0;
    tbl_entry_t entry;
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};

    if (drv_table_is_tcam_key(tbl_id)
        || drv_table_is_lpm_tcam_key(tbl_id))
    {
        entry.data_entry = data_entry;
        entry.mask_entry = mask_entry;
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        drv_ioctl(chip, index, cmd, &entry);
        return show_tcam_table_by_data_table_id(tbl_id, index, data_entry, mask_entry);
    }
    else
    {
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        drv_ioctl(chip, index, cmd, &data_entry);
        return show_ram_table_by_data_table_id(tbl_id, index, data_entry);
    }


    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    char* tbl_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    uint32 num = 0;
    uint32 step = 0;
    uint32 tbl_id = 0;
    int32 ret = 0;
    uint32 cmd = 0;
    tbl_entry_t entry;
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};
    tables_info_t* tbl_ptr = NULL;
    int32 i = 0;
    uint32 index = 0;


    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    step = req->step;
    tbl_name = (char*)req->buf;

    if(DRV_E_NONE != drv_get_tbl_id_by_string(&tbl_id, tbl_name))
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CLI_ERROR;
    }

    tbl_ptr = TABLE_INFO_PTR(tbl_id);

    for (i = 0; i < num; i++)
    {
        index = (start_index + (i * step));
        if (index >= tbl_ptr->entry)
        {
            ctc_cli_out("%% Index %d out-of-range %d\n", index, tbl_ptr->entry);
            break;
        }

        if (drv_table_is_tcam_key(tbl_id)
            || drv_table_is_lpm_tcam_key(tbl_id))
        {
            entry.data_entry = data_entry;
            entry.mask_entry = mask_entry;
            cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
            drv_ioctl(chip, index, cmd, &entry);
            show_tcam_table_by_data_table_id(tbl_id, index, data_entry, mask_entry);
        }
        else
        {
            cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
            ret = drv_ioctl(chip, index, cmd, &data_entry);
            show_ram_table_by_data_table_id(tbl_id, index, data_entry);
        }
    }
#endif /* _GLB_ENABLE_DBGSHOW_ */
    if (ret < 0)
    {
        ctc_cli_out("%% Read index %d failed %d\n", index, ret);
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    char* reg_name = NULL;
    char* fld_name = NULL;
    uint8 chip = 0;
    int32 index = 0;
    uint32 reg_tbl_id = 0;
    uint32* p_value = NULL;
    uint32 mask[4] = {0};
    uint32 value[128] = {0};
    uint32 cmd = 0;
    int32 ret = 0;
    tables_info_t* tbl_ptr = NULL;
    uint32 fld_id = 0;
    int32 fld_ok = FALSE;
    uint32 max_index_num = 0;
    uint32 reg_or_tbl = (CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG == req->param[0]) ? REGISTER_ID : TABLE_ID;
    tbl_entry_t field_entry;
    int32 array_idx = 0;

    chip = req->param[1];
    index = req->param[2];
    fld_id = req->param[3];
    p_value =(uint32*) req->param[4];
    reg_name = (char*)req->buf;
    fld_name = (char*)req->buf2;

    ctc_cli_out("Write %s field %d chip %d index %d value ",
                reg_name, fld_id, chip, index);
    for (array_idx = DRV_MAX_ARRAY_NUM -1 ; array_idx >= 0 ; array_idx--)
    {
        ctc_cli_out("0x%0x ", p_value[array_idx]);
    }
    ctc_cli_out("\n");

    if(DRV_E_NONE != drv_get_tbl_id_by_string(&reg_tbl_id, reg_name))
    {
        ctc_cli_out("%% Not found %s\n", reg_name);
        return CLI_ERROR;
    }
    if (fld_name[0])
    {
        if(DRV_E_NONE != drv_get_field_id_by_string(reg_tbl_id, &fld_id,fld_name))
        {
            ctc_cli_out("%% Not found %s\n", fld_name);
            return CLI_ERROR;
        }
    }

    tbl_ptr = TABLE_INFO_PTR(reg_tbl_id);
    if (fld_id < tbl_ptr->field_num)
    {
        fld_ok = TRUE;
    }

    max_index_num = tbl_ptr->entry;

    if (!fld_ok)
    {
        ctc_cli_out("%% %s has no field %d\n", reg_name, fld_id);
        return CLI_SUCCESS;
    }

    if (index >= max_index_num)
    {
        ctc_cli_out("%% Index %d out-of-range %d\n", index, max_index_num);
        return CLI_SUCCESS;
    }


    cmd = DRV_IOR(reg_tbl_id, DRV_ENTRY_FLAG);
    if (drv_table_is_tcam_key(reg_tbl_id)||(drv_table_is_lpm_tcam_key(reg_tbl_id)))
    {
        field_entry.data_entry = value;
        field_entry.mask_entry = mask;
        ret = DRV_IOCTL(chip, index, cmd, &field_entry);
    }
    else
    {
        ret = DRV_IOCTL(chip, index, cmd, value);
    }

    drv_set_field(reg_tbl_id, fld_id, value, p_value);

    cmd = DRV_IOW(reg_tbl_id, DRV_ENTRY_FLAG);

    if (drv_table_is_tcam_key(reg_tbl_id)||(drv_table_is_lpm_tcam_key(reg_tbl_id))
        || ((DsEthMep_t == reg_tbl_id) || (DsEthRmep_t == reg_tbl_id)
        || (DsBfdMep_t == reg_tbl_id) || (DsBfdRmep_t == reg_tbl_id)))
    {
        field_entry.data_entry = value;
        field_entry.mask_entry = mask;
        ret = DRV_IOCTL(chip, index, cmd, &field_entry);
    }
    else
    {
        ret = DRV_IOCTL(chip, index, cmd, value);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% Write %s index %d failed %d\n", (REGISTER_ID == reg_or_tbl) ? "tbl" : "reg", index, ret);
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CLI_SUCCESS;
}

int32
_str_to_upper(char* str)
{
    uint32  i = 0;

    /* convert the alphabets to upper case before comparison */
    for (i = 0; i < sal_strlen((char*)str); i++)
    {
        if (sal_isalpha((int)str[i]) && sal_islower((int)str[i]))
        {
            str[i] = sal_toupper(str[i]);
        }
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(ctc_dbg_tblreg_show_req_t* req)
{
#define CTC_GREATBELT_LIST_MAX_NUM   256
    uint32  ids[CTC_GREATBELT_LIST_MAX_NUM];
    char    upper_name[CTC_GREATBELT_TR_BUF_SIZE];
    char    upper_name1[CTC_GREATBELT_TR_BUF_SIZE];
    uint32  i = 0;
    uint32  id_index = 0;
    uint32  first_flag = TRUE;
    char* p_char = NULL;

    sal_memset(ids, 0, sizeof(ids));
    sal_memset(upper_name, 0, sizeof(upper_name));

    if (0 == sal_strlen((char*)req->buf))
    {
        /* list all */
        ctc_cli_out("List all %d entries\n", MaxTblId_t);

        for (i = 0; i < MaxTblId_t; i++)
        {
            ctc_dbg_tblreg_dump_list_one(i, &first_flag);
        }

        return CLI_SUCCESS;
    }

    sal_strncpy((char*)upper_name, (char*)req->buf, CTC_GREATBELT_TR_BUF_SIZE);
    _str_to_upper(upper_name);

    for (i = 0; i < MaxTblId_t; i++)
    {
        drv_get_tbl_string_by_id(i, (char*)upper_name1);
        _str_to_upper(upper_name1);

        p_char = (char*)sal_strstr((char*)upper_name1, (char*)upper_name);
        if (p_char)
        {
            if (sal_strlen((char*)upper_name1) == sal_strlen((char*)upper_name))
            {
                /* list full matched */
                ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(upper_name1, i, TRUE);
                return CLI_SUCCESS;
            }

            ids[id_index] = i;
            id_index++;
            if (id_index >= CTC_GREATBELT_LIST_MAX_NUM)
            {
                ctc_cli_out("Too much matched, only display first %d entries. \n", id_index);
                break;
            }
        }
    }

    if (id_index == 0)
    {
        ctc_cli_out("%% Not found %s \n", req->buf);
        return CLI_SUCCESS;
    }

    ctc_cli_out("Found %d matched entries \n", id_index);

    for (i = 0; i < id_index; i++)
    {
        /* list matched */
        ctc_dbg_tblreg_dump_list_one(ids[i], &first_flag);
    }

    return CLI_SUCCESS;
}


int32 ctc_dbg_show_brgHdr(uint32 type)
{
    uint32 data[10];
    uint32 cmd = 0;

    switch(type)
    {
    case 0:
            cmd = DRV_IOR(EpeHdrAdjBrgHdrFifo0_t, 6);
            drv_ioctl(0, 0, cmd, data);

        break;

    case 1:
    default:
        return 0;
    }

    show_ram_table_by_data_table_addr(MsPacketHeader_t, 0, data, 0);

    return 0;
}



int32
ctc_dbg_tblreg_dump_chip(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_

    switch (req->param[0])
    {
    case CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL:
        ctc_dbg_tblreg_dump_chip_read_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG:
    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL:
        ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_LIST_REG:
    case CTC_DIAG_TBLREG_CHIP_LIST_TBL:
        ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(req);
        break;

    default:
        break;
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CLI_SUCCESS;
}

CTC_CLI(show_cli_tbl_reg,
        show_cli_tbl_reg_cmd,
        "show tbl-id TBL_ID",
        CTC_CLI_SHOW_STR,
        "Table or register id",
        "Table id value <0-MaxTblId_t>")
{
    uint32 id = 0;
    int32 ret = 0;
    char    buf[CTC_GREATBELT_TR_BUF_SIZE];

    CTC_CLI_GET_UINT32_RANGE("Table/Reg Index", id, argv[0], 0, MaxTblId_t);

    ret = drv_get_tbl_string_by_id(id, buf);

    if (CLI_SUCCESS == ret)
    {
        ctc_cli_out("----------------------------------\n");
        ctc_cli_out("ID:%d ------> %s\n", id, buf);
        ctc_cli_out("----------------------------------\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(show_cli_brg_header,
        show_cli_brg_header_cmd,
        "show brg-hdr epe",
        "Show",
        "packet header",
        "epe")
{
    ctc_dbg_show_brgHdr(0);
    return CLI_SUCCESS;
}

int32
ctc_tblreg_wr_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &show_cli_tbl_reg_cmd);
    install_element(cli_tree_mode, &show_cli_brg_header_cmd);

    return CLI_SUCCESS;
}

