/**
 @file sys_greatbelt_aclqos_policer.c

 @date 2009-10-16

 @version v2.0

*/

/****************************************************************************
  *
  * Header Files
  *
  ****************************************************************************/
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_macro.h"
#include "ctc_qos.h"
#include "ctc_debug.h"

#include "sys_greatbelt_chip.h"
#include "sys_greatbelt_port.h"
#include "sys_greatbelt_qos.h"

#include "sys_greatbelt_qos_class.h"
#include "sys_greatbelt_qos_policer.h"
#include "sys_greatbelt_queue_enq.h"
#include "sys_greatbelt_queue_shape.h"
#include "sys_greatbelt_queue_sch.h"
#include "sys_greatbelt_queue_drop.h"

#include "drv_io.h"
#include "drv_lib.h"

/****************************************************************************
  *
  * Defines and Macros
  *
  ****************************************************************************/

/*init*/
extern int32
sys_greatbelt_qos_init(void* p_glb_parm)
{
    int32 ret = CTC_E_NONE;
    ctc_qos_global_cfg_t* glb_parm = NULL;

    if (NULL == p_glb_parm)
    {
        glb_parm = (ctc_qos_global_cfg_t*)mem_malloc(MEM_QUEUE_MODULE, sizeof(ctc_qos_global_cfg_t));
        if (NULL == glb_parm)
        {
            return CTC_E_NO_MEMORY;
        }

        sal_memset(glb_parm, 0, sizeof(glb_parm));

        glb_parm->queue_num_per_network_port     = 8;
        glb_parm->queue_num_per_internal_port    = 8;
        glb_parm->queue_num_per_ingress_service  = 4;
        glb_parm->queue_num_per_cpu_reason_group = 8;
        glb_parm->queue_aging_time               = 30;
        p_glb_parm = glb_parm;
    }

    CTC_ERROR_GOTO(sys_greatbelt_qos_class_init(), ret, error);

    CTC_ERROR_GOTO(sys_greatbelt_qos_policer_init(), ret, error);

    CTC_ERROR_GOTO(sys_greatbelt_queue_enq_init(p_glb_parm), ret, error);

    CTC_ERROR_GOTO(sys_greatbelt_queue_shape_init(), ret, error);

    CTC_ERROR_GOTO(sys_greatbelt_queue_sch_init(), ret, error);

    CTC_ERROR_GOTO(sys_greatbelt_queue_drop_init(), ret, error);
error:
    mem_free(glb_parm);
    return ret;
}

/*policer*/
extern int32
sys_greatbelt_qos_set_policer(ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_policer_set(p_policer));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_policer(ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_policer_get(p_policer));
    return CTC_E_NONE;
}

/*shape*/
extern int32
sys_greatbelt_qos_set_shape(ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(_sys_greatbelt_qos_set_shape(p_shape));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_shape(ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(_sys_greatbelt_qos_get_shape(p_shape));
    return CTC_E_NONE;
}

/*schedule*/
extern int32
sys_greatbelt_qos_set_sched(ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(_sys_greatbelt_qos_set_sched(p_sched));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_sched(ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(_sys_greatbelt_qos_get_sched(p_sched));
    return CTC_E_NONE;
}

/*mapping*/
extern int32
sys_greatbelt_qos_set_domain_map(ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_domain_map_set(p_domain_map));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_domain_map(ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_domain_map_get(p_domain_map));
    return CTC_E_NONE;
}

/*global param*/
extern int32
sys_greatbelt_qos_set_global_config(ctc_qos_glb_cfg_t* p_glb_cfg)
{
    switch (p_glb_cfg->cfg_type)
    {
    case CTC_QOS_GLB_CFG_POLICER_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_update_enable(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_STATS_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_stats_enable(p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_POLICER_IPG_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_ipg_enable(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_SEQENCE_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_sequential_enable(p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_QUE_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_queue_shape_enable(p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_GROUP_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_group_shape_enable(p_glb_cfg->u.value));
        break;

    case  CTC_QOS_GLB_CFG_PORT_SHAPE_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_port_shape_enable(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_SHAPE_IPG_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_shape_ipg_enable(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_FLOW_FIRST_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_flow_first((p_glb_cfg->u.value >> 16) & 0xFFFF, (p_glb_cfg->u.value & 0xFFFF)));
        break;

    case CTC_QOS_GLB_CFG_RESRC_MGR_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_resrc_mgr_en(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_QUE_STATS_EN:
        return CTC_E_NOT_SUPPORT;
        break;


    case CTC_QOS_GLB_CFG_PHB_MAP:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_phb(&p_glb_cfg->u.phb_map));
        break;

    case CTC_QOS_GLB_CFG_REASON_SHAPE_PKT_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_reason_shp_base_pkt_en(p_glb_cfg->u.value));
        break;

    case CTC_QOS_GLB_CFG_POLICER_HBWP_SHARE_EN:
        CTC_ERROR_RETURN(
            sys_greatbelt_qos_set_policer_hbwp_share_enable(p_glb_cfg->u.value));
        break;


    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_global_config(ctc_qos_glb_cfg_t* p_glb_cfg)
{
    return CTC_E_NONE;
}

/*queue*/
extern int32
sys_greatbelt_qos_set_queue(ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_queue_set(p_que_cfg));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_queue(ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_queue_get(p_que_cfg));
    return CTC_E_NONE;
}

/*drop*/
extern int32
sys_greatbelt_qos_set_drop_scheme(ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_greatbelt_queue_set_drop(p_drop));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_get_drop_scheme(ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_greatbelt_queue_get_drop(p_drop));
    return CTC_E_NONE;
}

/*stats*/
extern int32
sys_greatbelt_qos_query_queue_stats(ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_queue_stats_query(p_queue_stats));
    return CTC_E_NONE;
}

/*stats*/
extern int32
sys_greatbelt_qos_clear_queue_stats(ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_queue_stats_clear(p_queue_stats));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_query_policer_stats(ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_policer_stats_query(p_policer_stats));
    return CTC_E_NONE;
}

extern int32
sys_greatbelt_qos_clear_policer_stats(ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_policer_stats_clear(p_policer_stats));
    return CTC_E_NONE;
}

