/**
 @file ctc_greatbelt_stacking.c

 @date 2012-3-14

 @version v2.0
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_error.h"
#include "ctc_greatbelt_stacking.h"
#include "sys_greatbelt_stacking.h"
/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/
/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/

int32
ctc_greatbelt_stacking_create_trunk(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_create_trunk(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_destroy_trunk(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_destroy_trunk(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_add_trunk_port(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_add_trunk_port(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_remove_trunk_port(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_remove_trunk_port(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_add_trunk_rchip(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_add_trunk_rchip(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_remove_trunk_rchip(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_remove_trunk_rchip(p_trunk));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_set_property(uint8 lchip, ctc_stacking_property_t* p_prop)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_set_property(p_prop));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_get_property(uint8 lchip, ctc_stacking_property_t* p_prop)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_get_property(p_prop));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_keeplive_add_member(uint8 lchip, ctc_stacking_keeplive_t* p_keeplive)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_keeplive_add_member(p_keeplive));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_keeplive_remove_member(uint8 lchip, ctc_stacking_keeplive_t* p_keeplive)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_keeplive_remove_member(p_keeplive));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stacking_init(uint8 lchip, void* p_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_stacking_init(p_cfg));

    return CTC_E_NONE;
}

