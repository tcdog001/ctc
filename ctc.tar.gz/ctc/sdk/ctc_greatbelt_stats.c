/**
 @file ctc_greatbelt_stats.c

 @date 2009-12-22

 @version v2.0

*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_greatbelt_stats.h"
#include "sys_greatbelt_stats.h"
/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
/****************************************************************************
 *
* Function
*
*****************************************************************************/

int32
ctc_greatbelt_stats_init(uint8 lchip, void* stats_global_cfg)
{
    ctc_stats_global_cfg_t stats_cfg;

    sal_memset(&stats_cfg, 0, sizeof(stats_cfg));

    if(stats_global_cfg == NULL)
    {
        /* stats init */
        stats_cfg.stats_bitmap = CTC_STATS_QUEUE_DEQ_STATS
            | CTC_STATS_QUEUE_DROP_STATS
            | CTC_STATS_FLOW_POLICER_STATS;
        stats_cfg.policer_stats_num = 1024;

       stats_global_cfg = &stats_cfg;
    }
    CTC_ERROR_RETURN(sys_greatbelt_stats_init((ctc_stats_global_cfg_t*)stats_global_cfg));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_set_mac_stats_cfg(uint8 lchip, uint32 gport, ctc_mac_stats_prop_type_t mac_stats_prop_type, ctc_mac_stats_property_t prop_data)
{
    switch (mac_stats_prop_type)
    {
    case CTC_STATS_PACKET_LENGTH_MTU1:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_mac_packet_length_mtu1(gport, prop_data.data.length));
        break;

    case CTC_STATS_PACKET_LENGTH_MTU2:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_mac_packet_length_mtu2(gport, prop_data.data.length));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_mac_stats_cfg(uint8 lchip, uint32 gport, ctc_mac_stats_prop_type_t mac_stats_prop_type, ctc_mac_stats_property_t* p_prop_data)
{
    switch (mac_stats_prop_type)
    {
    case CTC_STATS_PACKET_LENGTH_MTU1:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_mac_packet_length_mtu1(gport, &(p_prop_data->data.length)));
        break;

    case CTC_STATS_PACKET_LENGTH_MTU2:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_mac_packet_length_mtu2(gport, &(p_prop_data->data.length)));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_mac_stats(uint8 lchip, uint32 gport, ctc_mac_stats_dir_t dir, ctc_mac_stats_t* p_stats)
{

    switch (dir)
    {
    case CTC_STATS_MAC_STATS_RX:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_mac_rx_stats(gport, p_stats));
        break;

    case CTC_STATS_MAC_STATS_TX:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_mac_tx_stats(gport, p_stats));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_clear_mac_stats(uint8 lchip, uint32 gport, ctc_mac_stats_dir_t dir)
{
    switch (dir)
    {
    case CTC_STATS_MAC_STATS_RX:
        CTC_ERROR_RETURN(sys_greatbelt_stats_clear_mac_rx_stats(gport));
        break;

    case CTC_STATS_MAC_STATS_TX:
        CTC_ERROR_RETURN(sys_greatbelt_stats_clear_mac_tx_stats(gport));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_cpu_mac_stats(uint8 lchip, uint32 gport, ctc_cpu_mac_stats_t* p_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_get_cpu_mac_stats(gport, p_stats));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_clear_cpu_mac_stats(uint8 lchip, uint32 gport)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_clear_cpu_mac_stats(gport));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_set_drop_packet_stats_en(uint8 lchip, ctc_stats_discard_t bitmap, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_set_drop_packet_stats_en(bitmap, enable));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_drop_packet_stats_en(uint8 lchip, ctc_stats_discard_t bitmap, bool* enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_get_port_log_discard_stats_enable(bitmap, enable));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_port_log_stats(uint8 lchip, uint32 gport, ctc_direction_t dir, ctc_stats_basic_t* p_stats)
{
    switch (dir)
    {
    case CTC_INGRESS:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_igs_port_log_stats(gport, p_stats));
        break;

    case CTC_EGRESS:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_egs_port_log_stats(gport, p_stats));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_clear_port_log_stats(uint8 lchip, uint32 gport, ctc_direction_t dir)
{
    CTC_MAX_VALUE_CHECK(dir, CTC_BOTH_DIRECTION);

    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(sys_greatbelt_stats_clear_igs_port_log_stats(gport));
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(sys_greatbelt_stats_clear_egs_port_log_stats(gport));
    }


    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_set_global_cfg(uint8 lchip, ctc_stats_property_param_t stats_param, ctc_stats_property_t stats_prop)
{
    switch (stats_param.prop_type)
    {
    case CTC_STATS_PROPERTY_SATURATE:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_saturate_en(stats_param.stats_type, stats_prop.data.enable));
        break;

    case CTC_STATS_PROPERTY_HOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_hold_en(stats_param.stats_type, stats_prop.data.enable));
        break;

    case CTC_STATS_PROPERTY_CLEAR_AFTER_READ:
        return CTC_E_FEATURE_NOT_SUPPORT;

    case CTC_STATS_PROPERTY_PKT_CNT_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_pkt_cnt_threshold(stats_prop.data.threshold_16byte));
        break;

    case CTC_STATS_PROPERTY_BYTE_CNT_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_byte_cnt_threshold(stats_prop.data.threshold_16byte));
        break;

    case CTC_STATS_PROPERTY_FIFO_DEPTH_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_set_fifo_depth_threshold(stats_prop.data.threshold_8byte));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_global_cfg(uint8 lchip, ctc_stats_property_param_t stats_param, ctc_stats_property_t* p_stats_prop)
{
    switch (stats_param.prop_type)
    {
    case CTC_STATS_PROPERTY_SATURATE:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_saturate_en(stats_param.stats_type, &(p_stats_prop->data.enable)));
        break;

    case CTC_STATS_PROPERTY_HOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_hold_en(stats_param.stats_type, &(p_stats_prop->data.enable)));
        break;

    case CTC_STATS_PROPERTY_CLEAR_AFTER_READ:
        return CTC_E_FEATURE_NOT_SUPPORT;

    case CTC_STATS_PROPERTY_PKT_CNT_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_pkt_cnt_threshold(&(p_stats_prop->data.threshold_16byte)));
        break;

    case CTC_STATS_PROPERTY_BYTE_CNT_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_byte_cnt_threshold(&(p_stats_prop->data.threshold_16byte)));
        break;

    case CTC_STATS_PROPERTY_FIFO_DEPTH_THREASHOLD:
        CTC_ERROR_RETURN(sys_greatbelt_stats_get_fifo_depth_threshold(&(p_stats_prop->data.threshold_8byte)));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_create_statsid(uint8 lchip, ctc_stats_statsid_t* statsid)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_create_statsid(statsid));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_destroy_statsid(uint8 lchip, uint32 stats_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_destroy_statsid(stats_id));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_get_stats(uint8 lchip, uint32 stats_id, ctc_stats_basic_t* p_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_get_stats(stats_id, p_stats));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_clear_stats(uint8 lchip, uint32 stats_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_clear_stats(stats_id));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_intr_callback_func(uint8 lchip, uint8* p_gchip)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_intr_callback_func(p_gchip));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_register_cb(uint8 lchip, ctc_stats_sync_fn_t cb, void* userdata)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_register_cb(cb, userdata));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_stats_set_syncup_cb_internal(uint8 lchip, uint32 stats_interval)
{
    CTC_ERROR_RETURN(sys_greatbelt_stats_set_stats_interval(stats_interval));

    return CTC_E_NONE;
}

