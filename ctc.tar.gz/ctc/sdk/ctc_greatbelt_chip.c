/**
 @file ctc_greatbelt_chip.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-10-19

 @version v2.0

 The file contains all chip APIs of ctc layer
*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_greatbelt_chip.h"
#include "sys_greatbelt_chip.h"
/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/

/**
 @brief Initialize the chip module and set the local chip number of the linecard
*/
int32
ctc_greatbelt_chip_init(uint8 lchip, uint8 lchip_num)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_init(lchip_num));

    return CTC_E_NONE;
}

/**
 @brief The function is to parse datapath configure file
*/
int32
ctc_greatbelt_parse_datapath(uint8 lchip, char* datapath_config_file)
{
    CTC_ERROR_RETURN(sys_greatbelt_parse_datapath_file(datapath_config_file));

    return CTC_E_NONE;
}

/**
 @brief The function is to init pll and hss
*/
int32
ctc_greatbelt_init_pll_hss(uint8 lchip)
{
    CTC_ERROR_RETURN(sys_greatbelt_init_pll_hss());

    return CTC_E_NONE;
}

/**
 @brief The function is to init datapath
*/
int32
ctc_greatbelt_datapath_init(uint8 lchip, void* p_global_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_datapath_init());

    return CTC_E_NONE;
}

/**
 @brief The function is to init datapath
*/
int32
ctc_greatbelt_datapath_sim_init(uint8 lchip)
{
    CTC_ERROR_RETURN(sys_greatbelt_datapath_sim_init());

    return CTC_E_NONE;
}

/**
 @brief The function is to get the local chip number of the linecard
*/
int32
ctc_greatbelt_get_local_chip_num(uint8 lchip, uint8* lchip_num)
{
    *lchip_num = sys_greatbelt_get_local_chip_num();

    return CTC_E_NONE;
}

/**
 @brief The function is to set chip's global chip id
*/
int32
ctc_greatbelt_set_gchip_id(uint8 lchip, uint8 gchip_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_set_gchip_id(lchip, gchip_id));

    return CTC_E_NONE;
}

/**
 @brief The function is to get chip's global chip id
*/
int32
ctc_greatbelt_get_gchip_id(uint8 lchip, uint8* gchip_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_get_gchip_id(lchip, gchip_id));

    return CTC_E_NONE;
}

/**
 @brief The function is to set chip's global cnfig
*/
int32
ctc_greatbelt_set_chip_global_cfg(uint8 lchip, ctc_chip_global_cfg_t* chip_cfg)
{
    uint8 local_chip_num = 1;
    uint8 lchip_tmp = 0;
    uint8 index = 0;
    ctc_chip_global_cfg_t   chip_global_cfg;

    sal_memset(&chip_global_cfg,0,sizeof(ctc_chip_global_cfg_t));
    ctc_greatbelt_get_local_chip_num(lchip_tmp, &local_chip_num);

    for (lchip_tmp = 0; lchip_tmp < local_chip_num; lchip_tmp++)
    {
        if ( NULL == chip_cfg )
        {
            sal_memset(&chip_global_cfg, 0, sizeof(ctc_chip_global_cfg_t));
            chip_global_cfg.lchip = lchip_tmp;
            chip_global_cfg.cpu_mac_sa[0] = 0xFE;
            chip_global_cfg.cpu_mac_sa[1] = 0xFD;
            chip_global_cfg.cpu_mac_sa[2] = 0x0;
            chip_global_cfg.cpu_mac_sa[3] = 0x0;
            chip_global_cfg.cpu_mac_sa[4] = 0x0;
            chip_global_cfg.cpu_mac_sa[5] = 0x1;

            /*init CPU MAC DA*/
            for (index = 0; index < MAX_CTC_CPU_MACDA_NUM; index++)
            {
                chip_global_cfg.cpu_mac_da[index][0] = 0xFE;
                chip_global_cfg.cpu_mac_da[index][1] = 0xFD;
                chip_global_cfg.cpu_mac_da[index][2] = 0x0;
                chip_global_cfg.cpu_mac_da[index][3] = 0x0;
                chip_global_cfg.cpu_mac_da[index][4] = 0x0;
                chip_global_cfg.cpu_mac_da[index][5] = 0x0;
            }
            chip_global_cfg.tpid                = 0x8100;
            chip_global_cfg.vlanid              = 0x23;
            chip_global_cfg.cut_through_en      = 0;
            chip_global_cfg.cut_through_speed   = 0;
            chip_global_cfg.ecc_recover_en      = 0;
            chip_global_cfg.cpu_port_en = 0;
            chip_cfg = &chip_global_cfg;
        }
        else
        {
            chip_cfg->lchip = lchip_tmp;
        }

        CTC_ERROR_RETURN(sys_greatbelt_set_chip_global_cfg(chip_cfg));

        if (chip_cfg->ecc_recover_en)
        {
            CTC_ERROR_RETURN(sys_greatbelt_chip_ecc_recover_init());
        }
    }

    return CTC_E_NONE;
}

/**
 @brief The function is to get chip's frequency
*/
int32
ctc_greatbelt_get_chip_clock(uint8 lchip, uint16* freq)
{
    CTC_ERROR_RETURN(sys_greatbelt_get_chip_clock(freq));

    return CTC_E_NONE;
}

/**
 @brief Set port to mdio and port to phy mapping
*/
int32
ctc_greatbelt_chip_set_phy_mapping(uint8 lchip, ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_phy_mapping(phy_mapping_para));

    return CTC_E_NONE;
}

/**
 @brief Get port to mdio and port to phy mapping
*/
int32
ctc_greatbelt_chip_get_phy_mapping(uint8 lchip, ctc_chip_phy_mapping_para_t* phy_mapping_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_get_phy_mapping(phy_mapping_para));

    return CTC_E_NONE;
}

/**
 @brief Write Gephy register value
*/
int32
ctc_greatbelt_chip_write_gephy_reg(uint8 lchip, uint32 gport, ctc_chip_gephy_para_t* gephy_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_write_gephy_reg(gport, gephy_para));
    return CTC_E_NONE;
}

/**
 @brief Read Gephy register value
*/
int32
ctc_greatbelt_chip_read_gephy_reg(uint8 lchip, uint32 gport, ctc_chip_gephy_para_t* gephy_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_read_gephy_reg(gport, gephy_para));
    return CTC_E_NONE;
}

/**
 @brief Write XGphy register value
*/
int32
ctc_greatbelt_chip_write_xgphy_reg(uint8 lchip, uint32 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_write_xgphy_reg(gport, xgphy_para));
    return CTC_E_NONE;
}

/**
 @brief Read XGphy register value
*/
int32
ctc_greatbelt_chip_read_xgphy_reg(uint8 lchip, uint32 gport, ctc_chip_xgphy_para_t* xgphy_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_read_xgphy_reg(gport, xgphy_para));
    return CTC_E_NONE;
}

/**
 @brief set gephy scan optional reg
*/
int32
ctc_greatbelt_chip_set_gephy_scan_special_reg(uint8 lchip, ctc_chip_ge_opt_reg_t* p_scan_opt, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_gephy_scan_special_reg(p_scan_opt, enable));
    return CTC_E_NONE;
}

/**
 @brief set xgphy scan optional reg
*/
int32
ctc_greatbelt_chip_set_xgphy_scan_special_reg(uint8 lchip, ctc_chip_xg_opt_reg_t* scan_opt, uint8 enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_xgphy_scan_special_reg(scan_opt, enable));
    return CTC_E_NONE;
}

/**
 @brief control gephy scan
*/
int32
ctc_greatbelt_chip_set_phy_scan_para(uint8 lchip, ctc_chip_phy_scan_ctrl_t* p_scan_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_phy_scan_para(p_scan_para));
    return CTC_E_NONE;
}

/**
 @brief read phy scan enablle
*/
int32
ctc_greatbelt_chip_set_phy_scan_en(uint8 lchip, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_phy_scan_en(0, enable));
    return CTC_E_NONE;
}

/**
 @brief read by i2c master interface
*/
int32
ctc_greatbelt_chip_i2c_read(uint8 lchip, ctc_chip_i2c_read_t* p_i2c_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_i2c_read(p_i2c_para));
    return CTC_E_NONE;
}

/**
 @brief write sfp register by i2c master interface
*/
int32
ctc_greatbelt_chip_i2c_write(uint8 lchip, ctc_chip_i2c_write_t* p_i2c_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_i2c_write(p_i2c_para));
    return CTC_E_NONE;
}

/**
 @brief set sfp scan parameter
*/
int32
ctc_greatbelt_chip_set_i2c_scan_para(uint8 lchip, ctc_chip_i2c_scan_t* p_i2c_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_i2c_scan_para(p_i2c_para));
    return CTC_E_NONE;
}

/**
 @brief set sfp scan enable
*/
int32
ctc_greatbelt_chip_set_i2c_scan_en(uint8 lchip, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_i2c_scan_en(0, enable));
    return CTC_E_NONE;
}

/**
 @brief set read i2c buffer interface
*/
int32
ctc_greatbelt_chip_read_i2c_buf(uint8 lchip, ctc_chip_i2c_scan_read_t *p_i2c_scan_read)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_read_i2c_buf(p_i2c_scan_read));
    return CTC_E_NONE;
}

/**
 @brief set mac led mode interface
*/
int32
ctc_greatbelt_chip_set_mac_led_mode(uint8 lchip, ctc_chip_led_para_t* p_led_para, ctc_chip_mac_led_type_t led_type)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_mac_led_mode(p_led_para, led_type));
    return CTC_E_NONE;
}

/**
 @brief set mac led mapping
*/
int32
ctc_greatbelt_chip_set_mac_led_mapping(uint8 lchip, ctc_chip_mac_led_mapping_t* p_led_map)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_mac_led_mapping(p_led_map));
    return CTC_E_NONE;
}

/**
 @brief set mac led enable
*/
int32
ctc_greatbelt_chip_set_mac_led_en(uint8 lchip, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_mac_led_en(0, enable));
    return CTC_E_NONE;
}

/**
 @brief set gpio interface
*/
int32
ctc_greatbelt_chip_set_gpio_mode(uint8 lchip, uint8 gpio_id, ctc_chip_gpio_mode_t mode)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_gpio_mode(gpio_id, mode));
    return CTC_E_NONE;
}

/**
 @brief set gpio output value
*/
int32
ctc_greatbelt_chip_set_gpio_output(uint8 lchip, uint8 gpio, uint8 out_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_gpio_output(gpio, out_para));
    return CTC_E_NONE;
}

/**
 @brief switch chip access type
*/
int32
ctc_greatbelt_chip_set_access_type(uint8 lchip, ctc_chip_access_type_t access_type)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_access_type(access_type));
    return CTC_E_NONE;
}

/**
 @brief get chip access type
*/
int32
ctc_greatbelt_chip_get_access_type(uint8 lchip, ctc_chip_access_type_t* p_access_type)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_get_access_type(p_access_type));
    return CTC_E_NONE;
}

/**
 @brief set chip dynamic switch mode
*/
int32
ctc_greatbelt_chip_set_serdes_mode(uint8 lchip, ctc_chip_serdes_info_t* p_serdes_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_serdes_mode(lchip, p_serdes_info));
    return CTC_E_NONE;
}

/**
 @brief Mdio read interface
*/
int32
ctc_greatbelt_chip_mdio_read(uint8 lchip, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_mdio_read(lchip, type, p_para));

    return CTC_E_NONE;
}

/**
 @brief Mdio read interface
*/
int32
ctc_greatbelt_chip_mdio_write(uint8 lchip, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_mdio_write(lchip, type, p_para));

    return CTC_E_NONE;
}

/**
 @brief reset hss12g macro
*/
int32
ctc_greatbelt_chip_set_hss12g_enable(uint8 lchip, uint8 macro_id, ctc_chip_serdes_mode_t mode, uint8 enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_hss12g_enable(lchip, macro_id,mode, enable));

    return CTC_E_NONE;
}

/**
 @brief set mdio clock frequency
*/
int32
ctc_greatbelt_chip_set_mdio_clock(uint8 lchip, ctc_chip_mdio_type_t type, uint16 freq)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_mdio_clock(type, freq));

    return CTC_E_NONE;
}

/**
 @brief get mdio clock frequency
*/
int32
ctc_greatbelt_chip_get_mdio_clock(uint8 lchip, ctc_chip_mdio_type_t type, uint16* p_freq)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_get_mdio_clock(type, p_freq));

    return CTC_E_NONE;
}

/**
 @brief get sensor value
*/
int32
ctc_greatbelt_get_chip_sensor(uint8 lchip, ctc_chip_sensor_type_t type, uint32* p_value)
{
    CTC_ERROR_RETURN(sys_greatbelt_get_chip_sensor(lchip, type, p_value));

    return CTC_E_NONE;
}

/**
 @brief set chip property
*/
int32
ctc_greatbelt_chip_set_property(uint8 lchip,  ctc_chip_property_t chip_prop,  void* p_value)
{
    CTC_ERROR_RETURN(sys_greatbelt_chip_set_property(lchip, chip_prop, p_value));
    return CTC_E_NONE;
}
