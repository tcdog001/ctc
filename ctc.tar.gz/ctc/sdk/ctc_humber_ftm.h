/**
 @file ctc_humber_alloc.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-11-11

 @version v2.0

   This file define ctc functions of SDK
*/

#ifndef _CTC_HUMBER_FTM_H
#define _CTC_HUMBER_FTM_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************
*
* Defines and Macros
*
****************************************************************/

/**
 @addtogroup allocation FTM
 @{
*/

/**
 @brief Profile information

 @param[in] lchip    local chip id
 @return CTC_E_XXX
*/
extern int32
ctc_humber_ftm_show_alloc_info(uint8 lchip);

/**
 @brief Profile information

 @param[in] lchip    local chip id

 @param[in] ctc_profile_info  allocation profile information

 @return CTC_E_XXX
*/
extern int32
ctc_humber_ftm_mem_alloc(uint8 lchip, ctc_ftm_profile_info_t* ctc_profile_info);

/**
 @brief Profile information

 @param[in] lchip    local chip id

 @param[in] ctc_profile_info  allocation profile information

 @return CTC_E_XXX
*/
extern int32
ctc_humber_ftm_set_default_profile(uint8 lchip, ctc_ftm_profile_info_t* ctc_profile_info);

/**@} end of @addtogroup allocation FTM  */

#ifdef __cplusplus
}
#endif

#endif

