#include "ctc_error.h"
#include "ctc_debug.h"
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_const.h"
#include "ctc_greatbelt_drv_cli.h"

extern int32
drv_io_debug_set_action(uint32 action);
extern int32
drv_io_debug_clear_cache();
extern int32
drv_io_debug_clear_stats();
extern int32
drv_io_debug_show(uint32 last_count);

CTC_CLI(ctc_cli_gb_drvio_action,
        ctc_cli_gb_drvio_action_cmd,
        "driver action (print|cache|print-and-cache|disable)",
        "Driver IO",
        "Action",
        "Print",
        "Cache",
        "Print and Cache",
        "Disable")
{
    uint32 action = 0;

    if (!sal_strcmp(argv[0], "print-and-cache"))
    {
        action = 0x03;
    }
    else if (!sal_strcmp(argv[0], "print"))
    {
        action = 0x01;  /* DRV_IO_DEBUG_ACTION_PRINT */
    }
    else if (!sal_strcmp(argv[0], "cache"))
    {
        action = 0x02;  /* DRV_IO_DEBUG_ACTION_CACHE */
    }
    else
    {
        action = 0;
    }

    drv_io_debug_set_action(action);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_drvio_clear_cache,
        ctc_cli_gb_drvio_clear_cache_cmd,
        "driver clear (cache | stats | all)",
        "Driver IO",
        "Clear",
        "Cache",
        "Statistics",
        "Cache and Statistics")
{
    if (!sal_strcmp(argv[0], "cache"))
    {
        drv_io_debug_clear_cache();
    }
    else if (!sal_strcmp(argv[0], "stats"))
    {
        drv_io_debug_clear_stats();
    }
    else
    {
        drv_io_debug_clear_cache();
        drv_io_debug_clear_stats();
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_drvio_show,
        ctc_cli_gb_drvio_show_cmd,
        "show driver (cache (<1-256>|) |)",
        CTC_CLI_SHOW_STR,
        "Driver IO",
        "Cache",
        "Lastest count number in cache")
{
    uint32 last_count = 0;

    if (argc > 0)
    {
        last_count = 256;
        if (argc > 1)
        {
            CTC_CLI_GET_INTEGER_RANGE("Last Count", last_count, argv[1], 1, 256);
        }
    }

    drv_io_debug_show(last_count);
    return CLI_SUCCESS;
}

int32
ctc_greatbelt_drv_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gb_drvio_action_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_drvio_clear_cache_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_drvio_show_cmd);
    return CLI_SUCCESS;
}

