/**
 @file sys_humber_parser.c

 @date 2009-12-22

 @version v2.0

---file comments----
*/

#include "sal.h"
#include "ctc_error.h"
#include "ctc_vector.h"
#include "sys_humber_parser.h"
#include "sys_humber_chip.h"
#include "sys_humber_parser_io.h"

/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/

#define SYS_PAS_L2_CAM_L2CAM_VALUE_IPV4 0x400800
#define SYS_PAS_L2_CAM_L2CAM_VALUE_IPV6 0x4086DD
#define SYS_PAS_L2_CAM_L2CAM_VALUE_MPLS 0x408847
#define SYS_PAS_L2_CAM_L2CAM_VALUE_MPLS_MCAST 0x408848
#define SYS_PAS_L2_CAM_L2CAM_VALUE_ARP 0x400806
#define SYS_PAS_L2_CAM_L2CAM_VALUE_RARP 0x408035
#define SYS_PAS_L2_CAM_L2CAM_VALUE_EAPOL 0x40888E
#define SYS_PAS_L2_CAM_L2CAM_VALUE_PPP2B 0x240021
#define SYS_PAS_L2_CAM_L2CAM_VALUE_PPP1B 0x258800
#define SYS_PAS_L2_CAM_L2CAM_VALUE_SNAP 0x430800
#define SYS_PAS_L2_CAM_L2CAM_VALUE_SAP 0x520800
#define SYS_PAS_L2_CAM_L2CAM_VALUE_ETHER_OAM 0x408902
#define SYS_PAS_L2_CAM_L2CAM_VALUE_SLOW_PROTO 0x408809
#define SYS_PAS_L2_CAM_L2CAM_VALUE_PBB 0x4088e7
#define SYS_PAS_L2_CAM_L2CAM_VALUE_PTP 0x4088f7

#define SYS_PAS_IPV6_EXT_LEVEL_HOP_BY_HOP 1
#define SYS_PAS_IPV6_EXT_LEVEL_DESTINATION 8
#define SYS_PAS_IPV6_EXT_LEVEL_ROUTING         3
#define SYS_PAS_IPV6_EXT_LEVEL_FRAG                4
#define SYS_PAS_IPV6_EXT_LEVEL_AH                    5
#define SYS_PAS_IPV6_EXT_LEVEL_ESP                  6

#define SYS_PAS_MAX_L4_PTL_CAM_ENTRY_NUM 2

#define SYS_PAS_MAX_IPV6_EXT_LEVEL 8
#define SYS_PAS_MAX_L3FLEX_BYTE_SEL 8

#define SYS_PAS_MAX_LAYER4_LEN_OP_ENTRY 15
#define SYS_PAS_MAX_UDP_APP_OP_ENTRY 4

#define SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_BASE 13
#define SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_0       13
#define SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_1       14
#define SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_2       15

#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_BASE  8
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_8        8
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_9        9
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_10     10
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_11     11
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_12     12
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_13     13
#define SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_14     14

#define SYS_PAS_CAM_INDEX_CHECK(index, min, max) \
    { \
        if (index < min || index >= max) \
        { \
            return CTC_E_INVALID_PARAM; \
        } \
    }

/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/
/**
 @brief set tpid
*/
int32
sys_humber_parser_set_tpid(ctc_parser_l2_tpid_t type, uint16 tpid)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        switch (type)
        {
        case CTC_PARSER_L2_TPID_CVLAN_TPID:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_cvlan_tpid(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_ITAG_TPID:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_i_tag_tpid(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_BLVAN_TPID:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_bvlan_tpid(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_SVLAN_TPID_0:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_svlan_tpid0(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_SVLAN_TPID_1:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_svlan_tpid1(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_SVLAN_TPID_2:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_svlan_tpid2(lchip, tpid));
            break;

        case CTC_PARSER_L2_TPID_SVLAN_TPID_3:
            CTC_ERROR_RETURN(sys_humber_parser_io_set_svlan_tpid3(lchip, tpid));
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }
    }

    return CTC_E_NONE;
}

/**
 @brief get tpid with some type
*/
int32
sys_humber_parser_get_tpid(ctc_parser_l2_tpid_t type, uint16* tpid)
{
    uint8 lchip = 0;
    uint32 value = 0;

    CTC_PTR_VALID_CHECK(tpid);

    switch (type)
    {
    case CTC_PARSER_L2_TPID_CVLAN_TPID:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_cvlan_tpid(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_ITAG_TPID:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_i_tag_tpid(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_BLVAN_TPID:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_bvlan_tpid(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_SVLAN_TPID_0:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_svlan_tpid0(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_SVLAN_TPID_1:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_svlan_tpid1(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_SVLAN_TPID_2:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_svlan_tpid2(lchip, &value));
        break;

    case CTC_PARSER_L2_TPID_SVLAN_TPID_3:
        CTC_ERROR_RETURN(sys_humber_parser_io_get_svlan_tpid3(lchip, &value));
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    *tpid = value;

    return CTC_E_NONE;
}

/**
 @brief set max_length,based on the value differentiate type or length
*/
int32
sys_humber_parser_set_max_length_filed(uint16 max_length)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(sys_humber_parser_io_set_max_length_field(lchip, max_length));
    }

    return CTC_E_NONE;
}

/**
 @brief get max_length value
*/
int32
sys_humber_parser_get_max_length_filed(uint16* max_length)
{
    uint8 lchip = 0;
    uint32 tmp = 0;

    CTC_ERROR_RETURN(sys_humber_parser_io_get_max_length_field(lchip, &tmp));
    *max_length = tmp;
    return CTC_E_NONE;
}

/**
 @brief set vlan parser num
*/
int32
sys_humber_parser_set_vlan_parser_num(uint8 vlan_num)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;

    if (vlan_num > 3)
    {
        return CTC_E_INVALID_PARAM;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(sys_humber_parser_io_set_vlan_parsing_num(lchip, vlan_num));
    }

    return CTC_E_NONE;
}

/**
 @brief get vlan parser num
*/
int32
sys_humber_parser_get_vlan_parser_num(uint8* vlan_num)
{
    uint8 lchip = 0;
    uint32 tmp = 0;

    CTC_ERROR_RETURN(sys_humber_parser_io_get_vlan_parsing_num(lchip, &tmp));
    *vlan_num = tmp;
    return CTC_E_NONE;
}

/**
 @brief set pbb parser ctl info
*/
int32
sys_humber_parser_set_pbb_header(ctc_parser_pbb_header_t* pbb_header)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;
    parser_pbb_ctl_t pbb_ctl;

    CTC_PTR_VALID_CHECK(pbb_header);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&pbb_ctl, 0, sizeof(parser_pbb_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_pbb_ctl_entry(lchip, &pbb_ctl));

        pbb_ctl.nca_value = pbb_header->nca_value_en ? 1 : 0;
        pbb_ctl.c_mac_outer_vlan_is_cvlan = pbb_header->outer_vlan_is_cvlan ? 1 : 0;

        if (pbb_header->vlan_parsing_num > 2)
        {
            return CTC_E_INVALID_PARAM;
        }

        pbb_ctl.pbb_vlan_parsing_num = pbb_header->vlan_parsing_num;

        if (pbb_header->pbb_oam_ether_type_offset > 0x3f)
        {
            return CTC_E_INVALID_PARAM;
        }

        pbb_ctl.pbb_oam_ether_type_offset = pbb_header->pbb_oam_ether_type_offset;

        pbb_ctl.pbb_oam_ether_type = pbb_header->pbb_oam_ether_type;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_pbb_ctl_entry(lchip, &pbb_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get pbb parser ctl info
*/
int32
sys_humber_parser_get_pbb_header(ctc_parser_pbb_header_t* pbb_header)
{
    uint8 lchip = 0;
    parser_pbb_ctl_t pbb_ctl;

    CTC_PTR_VALID_CHECK(pbb_header);

    sal_memset(&pbb_ctl, 0, sizeof(parser_pbb_ctl_t));
    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_pbb_ctl_entry(lchip, &pbb_ctl));

    pbb_header->nca_value_en = pbb_ctl.nca_value;
    pbb_header->outer_vlan_is_cvlan = pbb_ctl.c_mac_outer_vlan_is_cvlan;
    pbb_header->pbb_oam_ether_type = pbb_ctl.pbb_oam_ether_type;
    pbb_header->pbb_oam_ether_type_offset = pbb_ctl.pbb_oam_ether_type_offset;
    pbb_header->vlan_parsing_num = pbb_ctl.pbb_vlan_parsing_num;

    return CTC_E_NONE;
}

/**
 @brief set l2 flex header info
*/
int32
sys_humber_parser_set_l2flex_header(ctc_parser_l2flex_header_t* l2flex_header)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;
    parser_layer2_flex_ctl_t flex;

    CTC_PTR_VALID_CHECK(l2flex_header);

    if (l2flex_header->mac_da_basic_offset > 26)
    {
        return CTC_E_INVALID_PARAM;
    }

    if (l2flex_header->header_protocol_basic_offset > 30)
    {
        return CTC_E_INVALID_PARAM;
    }

    if (l2flex_header->l2_basic_offset > 0x3f)
    {
        return CTC_E_INVALID_PARAM;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&flex, 0, sizeof(parser_layer2_flex_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer2_flex_ctl_entry(lchip, &flex));

        flex.layer2_byte_select0 = l2flex_header->mac_da_basic_offset;
        flex.layer2_byte_select1 = l2flex_header->mac_da_basic_offset + 1;
        flex.layer2_byte_select2 = l2flex_header->mac_da_basic_offset + 2;
        flex.layer2_byte_select3 = l2flex_header->mac_da_basic_offset + 3;
        flex.layer2_byte_select4 = l2flex_header->mac_da_basic_offset + 4;
        flex.layer2_byte_select5 = l2flex_header->mac_da_basic_offset + 5;

        flex.layer2_protocol_byte_select0 = l2flex_header->header_protocol_basic_offset;
        flex.layer2_protocol_byte_select1 = l2flex_header->header_protocol_basic_offset + 1;

        flex.layer2_min_length = l2flex_header->min_length;
        flex.layer2_basic_offset = l2flex_header->l2_basic_offset;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer2_flex_ctl_entry(lchip, &flex));
    }

    return CTC_E_NONE;
}

/**
 @brief get l2 flex ctl info
*/
int32
sys_humber_parser_get_l2flex_header(ctc_parser_l2flex_header_t* l2flex_header)
{
    uint8 lchip = 0;
    parser_layer2_flex_ctl_t flex;

    CTC_PTR_VALID_CHECK(l2flex_header);

    sal_memset(&flex, 0, sizeof(parser_layer2_flex_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer2_flex_ctl_entry(lchip, &flex));

    l2flex_header->mac_da_basic_offset = flex.layer2_byte_select0;
    l2flex_header->header_protocol_basic_offset = flex.layer2_protocol_byte_select0;
    l2flex_header->l2_basic_offset = flex.layer2_basic_offset;
    l2flex_header->min_length = flex.layer2_min_length;

    return CTC_E_NONE;
}

/**
 @brief mapping layer3 type
*/
int32
sys_humber_parser_mapping_l3_type(uint8 index, ctc_parser_l2_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    uint8 isEth = 0;
    uint8 isPPP = 0;
    uint8 isSAP = 0;
    parser_layer2_protocol_cam_t cam;
    parser_layer2_protocol_cam_valid_t cam_valid;

    /*???should use a variable to count already configed entry*/
    CTC_PTR_VALID_CHECK(entry);

    if (entry->l3_type < CTC_PARSER_L3_TYPE_RSV_USER_DEFINE0
        || entry->l3_type > CTC_PARSER_L3_TYPE_RSV_USER_FLEXL3)
    {
        return CTC_E_INVALID_PARAM;
    }

    if ((entry->addition_offset > 0xf)
        || (entry->l2_type > 0xf))
    {
        return CTC_E_INVALID_PARAM;
    }

    local_chip_num = sys_humber_get_local_chip_num();
    /*only write the user defined entry*/
    index = index + SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_BASE;

    if (index > SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_2)
    {
        return CTC_E_INVALID_PARAM;
    }

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&cam, 0, sizeof(parser_layer2_protocol_cam_t));
        sal_memset(&cam_valid, 0, sizeof(parser_layer2_protocol_cam_valid_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer2_protocol_cam_entry(lchip, &cam));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));

        switch (entry->l2_type)
        {
        case CTC_PARSER_L2_TYPE_NONE:
            isEth = 0;
            isPPP = 0;
            isSAP = 0;
            break;

        case CTC_PARSER_L2_TYPE_ETH_V2:
        case CTC_PARSER_L2_TYPE_ETH_SNAP:
            isEth = 1;
            isPPP = 0;
            isSAP = 0;
            break;

        case CTC_PARSER_L2_TYPE_PPP_2B:
        case CTC_PARSER_L2_TYPE_PPP_1B:
            isEth = 0;
            isPPP = 1;
            isSAP = 0;
            break;

        case CTC_PARSER_L2_TYPE_ETH_SAP:
            isEth = 1;
            isPPP = 0;
            isSAP = 1;
            break;

        default:
            return CTC_E_INVALID_PARAM;
        }

        switch (index)
        {
        case SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_0:
            cam.layer2_protocol_cam_additional_offset13 = entry->addition_offset;
            cam.layer2_protocol_cam_layer3_type13 = entry->l3_type;
            cam.layer2_protocol_cam_mask13 = entry->mask & 0x7fffff;
            cam.layer2_protocol_cam_value13 = (isEth << 22) | (isPPP << 21)
                | (isSAP << 20)
                | (entry->l2_type << 16)
                | (entry->l2_header_protocol);
            break;

        case SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_1:
            cam.layer2_protocol_cam_additional_offset14 = entry->addition_offset;
            cam.layer2_protocol_cam_layer3_type14 = entry->l3_type;
            cam.layer2_protocol_cam_mask14 = entry->mask & 0x7fffff;
            cam.layer2_protocol_cam_value14 = (isEth << 22) | (isPPP << 21)
                | (isSAP << 20)
                | (entry->l2_type << 16)
                | (entry->l2_header_protocol);
            break;

        case SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_2:
            cam.layer2_protocol_cam_additional_offset15 = entry->addition_offset;
            cam.layer2_protocol_cam_layer3_type15 = entry->l3_type;
            cam.layer2_protocol_cam_mask15 = entry->mask & 0x7fffff;
            cam.layer2_protocol_cam_value15 = (isEth << 22) | (isPPP << 21)
                | (isSAP << 20)
                | (entry->l2_type << 16)
                | (entry->l2_header_protocol);
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }

        cam_valid.layer2_cam_entry_valid |= (1 << index);

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer2_protocol_cam_entry(lchip, &cam));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));
    }

    return CTC_E_NONE;
}

/**
 @brief set the entry invalid based on the index
*/
int32
sys_humber_parser_unmapping_l3_type(uint8 index)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer2_protocol_cam_valid_t cam_valid;

    /*9: customer can config 10 entry at most, 6 entry have been config in system initialization.
    MAX_CTC_PARSER_L2_TYPE - CTC_PARSER_L2_TYPE_RAW_SNAP*/

    local_chip_num = sys_humber_get_local_chip_num();
    /*6: already configed entry in system initialization*/
    index = index + SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_BASE;
    if (index > SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_2)
    {
        return CTC_E_INVALID_PARAM;
    }

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&cam_valid, 0, sizeof(parser_layer2_protocol_cam_valid_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));

        if (CTC_IS_BIT_SET(cam_valid.layer2_cam_entry_valid, index))
        {
            cam_valid.layer2_cam_entry_valid &= (~(1 << index));
            CTC_ERROR_RETURN(
                sys_humber_parser_io_set_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));
        }
    }

    return CTC_E_NONE;
}

int32
sys_humber_parser_l2_enable_l3_type(ctc_parser_l3_type_t l3_type, bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    parser_layer2_protocol_cam_valid_t cam_valid;

    lchip_num = sys_humber_get_local_chip_num();

    CTC_MAX_VALUE_CHECK(l3_type, CTC_PARSER_L3_TYPE_RSV_USER_FLEXL3);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        sal_memset(&cam_valid, 0, sizeof(parser_layer2_protocol_cam_valid_t));
        CTC_ERROR_RETURN(sys_humber_parser_io_get_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));

        if (FALSE == enable)  /*disable*/
        {
            if (CTC_IS_BIT_SET(cam_valid.layer2_cam_entry_valid, l3_type))
            {
                cam_valid.layer2_cam_entry_valid &= (~(1 << l3_type));
            }
            else
            {
                return CTC_E_NONE;
            }
        }
        else  /*enable*/
        {
            if (CTC_IS_BIT_SET(cam_valid.layer2_cam_entry_valid, l3_type))
            {
                return CTC_E_NONE;
            }
            else
            {
                cam_valid.layer2_cam_entry_valid |= (1 << l3_type);
            }
        }

        CTC_ERROR_RETURN(sys_humber_parser_io_set_parser_layer2_protocol_cam_valid_entry(lchip, &cam_valid));
    }

    return CTC_E_NONE;
}

/**
 @brief set ip ecmp hash info
*/
static int32
_sys_humber_parser_set_ip_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{

    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_ip_hash_ctl_t ip_ctl;

    CTC_PTR_VALID_CHECK(hash_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ip_ctl, 0, sizeof(parser_ip_hash_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_ip_hash_ctl_entry(lchip, &ip_ctl));

        ip_ctl.protocol_ecmp_hash_en = ((hash_ctl->ip_flag) & CTC_PARSER_IP_ECMP_HASH_FLAGS_PROTOCOL) ? 1 : 0;
        ip_ctl.dscp_ecmp_hash_en = ((hash_ctl->ip_flag) & CTC_PARSER_IP_ECMP_HASH_FLAGS_DSCP) ? 1 : 0;
        ip_ctl.flow_label_ecmp_hash_en = ((hash_ctl->ip_flag) & CTC_PARSER_IP_ECMP_HASH_FLAGS_IPV6_FLOW_LABEL) ? 1 : 0;

        if (CTC_FLAG_ISSET(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_IPSA))
        {
            CTC_BIT_UNSET(ip_ctl.ip_hash_disable, 0);
        }
        else
        {
            CTC_BIT_SET(ip_ctl.ip_hash_disable, 0);
        }

        if (CTC_FLAG_ISSET(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_IPDA))
        {
            CTC_BIT_UNSET(ip_ctl.ip_hash_disable, 1);
        }
        else
        {
            CTC_BIT_SET(ip_ctl.ip_hash_disable, 1);
        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_ip_hash_ctl_entry(lchip, &ip_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get ip ecmp hash info
*/
static int32
_sys_humber_parser_get_ip_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{

    uint8 lchip = 0;
    parser_ip_hash_ctl_t ip_ctl;

    CTC_PTR_VALID_CHECK(hash_ctl);

    sal_memset(&ip_ctl, 0, sizeof(parser_ip_hash_ctl_t));
    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_ip_hash_ctl_entry(lchip, &ip_ctl));

    hash_ctl->ip_flag = 0;
    if (ip_ctl.protocol_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_PROTOCOL);
    }

    if (ip_ctl.dscp_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_DSCP);
    }

    if (ip_ctl.flow_label_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_IPV6_FLOW_LABEL);
    }

    if (!CTC_IS_BIT_SET(ip_ctl.ip_hash_disable, 0))
    {
        CTC_SET_FLAG(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_IPSA);
    }

    if (!CTC_IS_BIT_SET(ip_ctl.ip_hash_disable, 1))
    {
        CTC_SET_FLAG(hash_ctl->ip_flag, CTC_PARSER_IP_ECMP_HASH_FLAGS_IPDA);
    }

    return CTC_E_NONE;
}

/**
 @brief set parser ipv6 ctl reg
*/
int32
sys_humber_parser_set_ipv6_ctl(uint8 index, ctc_parser_ipv6_ctl_t* ipv6_ctl)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_ipv6_ctl_t ctl;

    CTC_PTR_VALID_CHECK(ipv6_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_ipv6_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_ipv6_ctl_entry(lchip, &ctl));

        if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_FLEX_EXT_HDR0)
        {
            ctl.ipv6_flex_ext_header0 = ipv6_ctl->flex_ext_hdr0;
        }

        if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_FLEX_EXT_HDR1)
        {
            ctl.ipv6_flex_ext_header1 = ipv6_ctl->flex_ext_hdr1;
        }

        if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_ERR_OP_EN)
        {
            ctl.parser_ipv6_error_option_en = ipv6_ctl->ipv6_err_option_en ? 1 : 0;
        }

        if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_DIS)
        {
            ctl.ipv6_ext_disable = ipv6_ctl->ipv6_ext_dis ? 1 : 0;
        }

        if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_RSV_L3_HDR_PTL)
        {
            ctl.reserved_l3_header_protocol = ipv6_ctl->rsv_l3_hdr_ptl;
        }

        if (ipv6_ctl->ext_hdr_level.ext_level > 0xf)
        {
            return CTC_E_INVALID_PARAM;
        }

        switch (index)
        {
        case 0:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL0)
            {
                ctl.ipv6_ext_level0 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en0 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift0 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options0 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 1:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL1)
            {
                ctl.ipv6_ext_level1 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en1 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift1 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options1 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 2:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL2)
            {
                ctl.ipv6_ext_level2 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en2 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift2 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options2 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 3:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL3)
            {
                ctl.ipv6_ext_level3 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en3 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift3 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options3 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 4:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL4)
            {
                ctl.ipv6_ext_level4 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en4 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift4 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options4 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 5:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL5)
            {
                ctl.ipv6_ext_level5 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en5 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift5 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options5 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 6:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL6)
            {
                ctl.ipv6_ext_level6 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en6 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift6 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options6 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        case 7:
            if (ipv6_ctl->flags & CTC_PARSER_IPV6_CTL_FLAGS_EXT_HDR_LEVEL7)
            {
                ctl.ipv6_ext_level7 = ipv6_ctl->ext_hdr_level.ext_level;
                ctl.ipv6_ext_level_check_en7 = ipv6_ctl->ext_hdr_level.ext_level_chk_en ? 1 : 0;
                ctl.ipv6_ext_shift7 = ipv6_ctl->ext_hdr_level.ext_shift ? 1 : 0;
                ctl.ipv6_set_ip_options7 = ipv6_ctl->ext_hdr_level.set_ip_options ? 1 : 0;
            }

            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_ipv6_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser ipv6 ctl reg
*/
int32
sys_humber_parser_get_ipv6_ctl(uint8 index, ctc_parser_ipv6_ctl_t* ipv6_ctl)
{
    parser_ipv6_ctl_t ctl;

    CTC_PTR_VALID_CHECK(ipv6_ctl);

    sal_memset(&ctl, 0, sizeof(parser_ipv6_ctl_t));
    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_ipv6_ctl_entry(0, &ctl));
    ipv6_ctl->flex_ext_hdr0 = ctl.ipv6_flex_ext_header0;
    ipv6_ctl->flex_ext_hdr1 = ctl.ipv6_flex_ext_header1;
    ipv6_ctl->ipv6_err_option_en = ctl.parser_ipv6_error_option_en;
    ipv6_ctl->ipv6_ext_dis = ctl.ipv6_ext_disable;
    ipv6_ctl->rsv_l3_hdr_ptl = ctl.reserved_l3_header_protocol;

    switch (index)
    {
    case 0:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level0;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en0;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift0;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options0;
        break;

    case 1:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level1;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en1;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift1;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options1;
        break;

    case 2:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level2;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en2;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift2;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options2;
        break;

    case 3:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level3;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en3;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift3;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options3;
        break;

    case 4:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level4;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en4;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift4;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options4;
        break;

    case 5:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level5;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en5;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift5;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options5;
        break;

    case 6:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level6;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en6;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift6;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options6;
        break;

    case 7:
        ipv6_ctl->ext_hdr_level.ext_level = ctl.ipv6_ext_level7;
        ipv6_ctl->ext_hdr_level.ext_level_chk_en = ctl.ipv6_ext_level_check_en7;
        ipv6_ctl->ext_hdr_level.ext_shift = ctl.ipv6_ext_shift7;
        ipv6_ctl->ext_hdr_level.set_ip_options = ctl.ipv6_set_ip_options7;
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief set parser mpls ecmp hash info
*/
static int32
_sys_humber_parser_set_mpls_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_mpls_ctl_t mpls_ctl;

    CTC_PTR_VALID_CHECK(hash_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&mpls_ctl, 0, sizeof(parser_mpls_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_mpls_ctl_entry(lchip, &mpls_ctl));

        mpls_ctl.mpls_protocol_ecmp_hash_en = ((hash_ctl->mpls_flag) & CTC_PARSER_MPLS_ECMP_HASH_FLAGS_PROTOCOL) ? 1 : 0;
        mpls_ctl.mpls_dscp_ecmp_hash_en = ((hash_ctl->mpls_flag) & CTC_PARSER_MPLS_ECMP_HASH_FLAGS_DSCP) ? 1 : 0;
        mpls_ctl.mpls_flow_label_ecmp_hash_en = ((hash_ctl->mpls_flag) & CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPV6_FLOW_LABEL) ? 1 : 0;

        if (CTC_FLAG_ISSET(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPSA))
        {
            CTC_BIT_UNSET(mpls_ctl.mpls_ip_hash_disable, 0);
        }
        else
        {
            CTC_BIT_SET(mpls_ctl.mpls_ip_hash_disable, 0);
        }

        if (CTC_FLAG_ISSET(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPDA))
        {
            CTC_BIT_UNSET(mpls_ctl.mpls_ip_hash_disable, 1);
        }
        else
        {
            CTC_BIT_SET(mpls_ctl.mpls_ip_hash_disable, 1);
        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_mpls_ctl_entry(lchip, &mpls_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser mpls ecmp hash info
*/
static int32
_sys_humber_parser_get_mpls_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    parser_mpls_ctl_t mpls_ctl;

    sal_memset(&mpls_ctl, 0, sizeof(parser_mpls_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_mpls_ctl_entry(0, &mpls_ctl));

    hash_ctl->mpls_flag = 0;

    if (mpls_ctl.mpls_protocol_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_PROTOCOL);
    }

    if (mpls_ctl.mpls_dscp_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_DSCP);
    }

    if (mpls_ctl.mpls_flow_label_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPV6_FLOW_LABEL);
    }

    if (!CTC_IS_BIT_SET(mpls_ctl.mpls_ip_hash_disable, 0))
    {
        CTC_SET_FLAG(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPSA);
    }

    if (!CTC_IS_BIT_SET(mpls_ctl.mpls_ip_hash_disable, 1))
    {
        CTC_SET_FLAG(hash_ctl->mpls_flag, CTC_PARSER_MPLS_ECMP_HASH_FLAGS_IPDA);
    }

    return CTC_E_NONE;
}

/**
 @brief set parser l3flex header info
*/
int32
sys_humber_parser_set_l3flex_header(ctc_parser_l3flex_header_t* l3flex_header)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer3_flex_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l3flex_header);

    CTC_MAX_VALUE_CHECK(l3flex_header->ipda_basic_offset, 24);
    CTC_MAX_VALUE_CHECK(l3flex_header->protocol_byte_sel, 31);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_layer3_flex_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer3_flex_ctl_entry(lchip, &ctl));

        ctl.layer3_min_length = l3flex_header->l3min_length;
        ctl.layer3_basic_offset = l3flex_header->l3_basic_offset;
        ctl.layer3_protocol_byte_select = l3flex_header->protocol_byte_sel;
        ctl.layer3_byte_select0 = l3flex_header->ipda_basic_offset;
        ctl.layer3_byte_select1 = l3flex_header->ipda_basic_offset + 1;
        ctl.layer3_byte_select2 = l3flex_header->ipda_basic_offset + 2;
        ctl.layer3_byte_select3 = l3flex_header->ipda_basic_offset + 3;
        ctl.layer3_byte_select4 = l3flex_header->ipda_basic_offset + 4;
        ctl.layer3_byte_select5 = l3flex_header->ipda_basic_offset + 5;
        ctl.layer3_byte_select6 = l3flex_header->ipda_basic_offset + 6;
        ctl.layer3_byte_select7 = l3flex_header->ipda_basic_offset + 7;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer3_flex_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser l3flex header info
*/
int32
sys_humber_parser_get_l3flex_header(ctc_parser_l3flex_header_t* l3flex_header)
{
    parser_layer3_flex_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l3flex_header);

    sal_memset(&ctl, 0, sizeof(parser_layer3_flex_ctl_t));
    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer3_flex_ctl_entry(0, &ctl));

    l3flex_header->l3min_length = ctl.layer3_min_length;
    l3flex_header->l3_basic_offset = ctl.layer3_basic_offset;
    l3flex_header->protocol_byte_sel = ctl.layer3_protocol_byte_select;
    l3flex_header->ipda_basic_offset = ctl.layer3_byte_select0;

    return CTC_E_NONE;
}

/**
 @brief mapping l4type,can add a new l3type,addition offset for the type,can get the layer4 type
*/
int32
sys_humber_parser_mapping_l4_type(uint8 index, ctc_parser_l3_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer3_protocol_cam_t cam;
    parser_layer3_protocol_cam_valid_t cam_valid;

    CTC_PTR_VALID_CHECK(entry);

    if ((entry->addition_offset > 0xf)
        || (entry->l3_type > 0xf)
        || (entry->l4_type > 0xf))
    {
        return CTC_E_INVALID_PARAM;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    /*only write user defined entry*/
    index = index + SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_BASE;

    if (index > SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_14)
    {
        return CTC_E_INVALID_PARAM;
    }

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&cam, 0, sizeof(parser_layer3_protocol_cam_t));
        sal_memset(&cam_valid, 0, sizeof(parser_layer3_protocol_cam_valid_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer3_protocol_cam_entry(lchip, &cam));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));

        switch (index)
        {
        case SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_8:
            cam.layer3_protocol_cam_additional_offset8 = entry->addition_offset;
            cam.layer3_protocol_cam_layer3_header_protocol8 = entry->l3_header_protocol;
            cam.layer3_protocol_cam_layer3_header_protocol_mask8 = entry->l3_header_protocol_mask & 0xff;
            cam.layer3_protocol_cam_layer3_type8 = entry->l3_type;
            cam.layer3_protocol_cam_layer3_type_mask8 = entry->l3_type_mask & 0xf;
            cam.layer3_protocol_cam_layer4_type8 = entry->l4_type;
            break;

        case SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_9:
            cam.layer3_protocol_cam_additional_offset9 = entry->addition_offset;
            cam.layer3_protocol_cam_layer3_header_protocol9 = entry->l3_header_protocol;
            cam.layer3_protocol_cam_layer3_header_protocol_mask9 = entry->l3_header_protocol_mask & 0xff;
            cam.layer3_protocol_cam_layer3_type9 = entry->l3_type;
            cam.layer3_protocol_cam_layer3_type_mask9 = entry->l3_type_mask & 0xf;
            cam.layer3_protocol_cam_layer4_type9 = entry->l4_type;
            break;

        case SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_10:
            cam.layer3_protocol_cam_additional_offset10 = entry->addition_offset;
            cam.layer3_protocol_cam_layer3_header_protocol10 = entry->l3_header_protocol;
            cam.layer3_protocol_cam_layer3_header_protocol_mask10 = entry->l3_header_protocol_mask & 0xff;
            cam.layer3_protocol_cam_layer3_type10 = entry->l3_type;
            cam.layer3_protocol_cam_layer3_type_mask10 = entry->l3_type_mask & 0xf;
            cam.layer3_protocol_cam_layer4_type10 = entry->l4_type;
            break;

        case SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_11:
            cam.layer3_protocol_cam_additional_offset11 = entry->addition_offset;
            cam.layer3_protocol_cam_layer3_header_protocol11 = entry->l3_header_protocol;
            cam.layer3_protocol_cam_layer3_header_protocol_mask11 = entry->l3_header_protocol_mask & 0xff;
            cam.layer3_protocol_cam_layer3_type11 = entry->l3_type;
            cam.layer3_protocol_cam_layer3_type_mask11 = entry->l3_type_mask & 0xf;
            cam.layer3_protocol_cam_layer4_type11 = entry->l4_type;
            break;

        case SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_14:
            cam.layer3_protocol_cam_additional_offset14 = entry->addition_offset;
            cam.layer3_protocol_cam_layer3_header_protocol14 = entry->l3_header_protocol;
            cam.layer3_protocol_cam_layer3_header_protocol_mask14 = entry->l3_header_protocol_mask & 0xff;
            cam.layer3_protocol_cam_layer3_type14 = entry->l3_type;
            cam.layer3_protocol_cam_layer3_type_mask14 = entry->l3_type_mask & 0xf;
            cam.layer3_protocol_cam_layer4_type14 = entry->l4_type;
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }

        cam_valid.layer3_cam_entry_valid |= (1 << index);

        CTC_ERROR_RETURN(sys_humber_parser_io_set_parser_layer3_protocol_cam_entry(lchip, &cam));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));
    }

    return CTC_E_NONE;
}

/**
 @brief set the entry invalid based on the index
*/
int32
sys_humber_parser_unmapping_l4_type(uint8 index)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer3_protocol_cam_valid_t cam_valid;

    /*8:customer can config 9 entry at most, 7 entry have been config in system initialization.
    MAX_CTC_PARSER_L3_TYPE - CTC_PARSER_L3_TYPE_RARP*/

    /*6: already configed entry in system initialization*/
    index = index + SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_BASE;
    if ((index > SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_14) ||
        (index == SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_12) ||
        (index == SYS_PARSER_L3PRO_CAM_RSV_USER_DEFINE_13))
    {
        return CTC_E_INVALID_PARAM;
    }

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&cam_valid, 0, sizeof(parser_layer3_protocol_cam_valid_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));
        if (CTC_IS_BIT_SET(cam_valid.layer3_cam_entry_valid, index))
        {
            cam_valid.layer3_cam_entry_valid &= ~(1 << index);
            CTC_ERROR_RETURN(
                sys_humber_parser_io_set_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));
        }
    }

    return CTC_E_NONE;
}

int32
sys_humber_parser_l3_enable_l4_type(ctc_parser_l4_type_t l4_type, bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    parser_layer3_protocol_cam_valid_t cam_valid;

    lchip_num = sys_humber_get_local_chip_num();

    CTC_MAX_VALUE_CHECK(l4_type, CTC_PARSER_L4_TYPE_ANY_PROTO);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        sal_memset(&cam_valid, 0, sizeof(parser_layer3_protocol_cam_valid_t));
        CTC_ERROR_RETURN(sys_humber_parser_io_get_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));

        if (FALSE == enable)  /*disable*/
        {
            if (CTC_IS_BIT_SET(cam_valid.layer3_cam_entry_valid, l4_type))
            {
                cam_valid.layer3_cam_entry_valid &= (~(1 << l4_type));
            }
            else
            {
                return CTC_E_NONE;
            }
        }
        else  /*enable*/
        {
            if (CTC_IS_BIT_SET(cam_valid.layer3_cam_entry_valid, l4_type))
            {
                return CTC_E_NONE;
            }
            else
            {
                cam_valid.layer3_cam_entry_valid |= (1 << l4_type);
            }
        }

        CTC_ERROR_RETURN(sys_humber_parser_io_set_parser_layer3_protocol_cam_valid_entry(lchip, &cam_valid));
    }

    return CTC_E_NONE;
}

/**
 @brief set parser layer4 header ecmp hash info
*/
static int32
_sys_humber_parser_set_l4_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_l4_hash_ctl_t l4_ctl;

    CTC_PTR_VALID_CHECK(hash_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&l4_ctl, 0, sizeof(parser_l4_hash_ctl_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_l4_hash_ctl_entry(lchip, &l4_ctl));

        l4_ctl.source_port_ecmp_hash_en = ((hash_ctl->l4_flag) & CTC_PARSER_L4_ECMP_HASH_FLAGS_SRC_PORT) ? 1 : 0;
        l4_ctl.dest_port_ecmp_hash_en = ((hash_ctl->l4_flag) & CTC_PARSER_L4_ECMP_HASH_FLAGS_DST_PORT) ? 1 : 0;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_l4_hash_ctl_entry(lchip, &l4_ctl));
    }

    return CTC_E_NONE;

}

/**
 @brief get parser layer4 header ecmp hash info
*/
static int32
_sys_humber_parser_get_l4_ecmp_hash(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    parser_l4_hash_ctl_t l4_ctl;

    CTC_PTR_VALID_CHECK(hash_ctl);
    sal_memset(&l4_ctl, 0, sizeof(parser_l4_hash_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_l4_hash_ctl_entry(0, &l4_ctl));

    hash_ctl->l4_flag = 0;

    if (l4_ctl.source_port_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->l4_flag, CTC_PARSER_L4_ECMP_HASH_FLAGS_SRC_PORT);
    }

    if (l4_ctl.dest_port_ecmp_hash_en)
    {
        CTC_SET_FLAG(hash_ctl->l4_flag, CTC_PARSER_L4_ECMP_HASH_FLAGS_DST_PORT);
    }

    return CTC_E_NONE;

}

/**
 @brief set ecmp hash field
*/
int32
sys_humber_parser_set_ecmp_hash_field(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    CTC_PTR_VALID_CHECK(hash_ctl);

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_IP)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_set_ip_ecmp_hash(hash_ctl));
    }

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_L4)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_set_l4_ecmp_hash(hash_ctl));
    }

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_MPLS)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_set_mpls_ecmp_hash(hash_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get ecmp hash field
*/
int32
sys_humber_parser_get_ecmp_hash_field(ctc_parser_ecmp_hash_ctl_t* hash_ctl)
{
    uint8 local_chip_num = 0;

    CTC_PTR_VALID_CHECK(hash_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_IP)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_get_ip_ecmp_hash(hash_ctl));
    }

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_L4)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_get_l4_ecmp_hash(hash_ctl));
    }

    if (hash_ctl->hash_type_bitmap & CTC_PARSER_ECMP_HASH_TYPE_FLAGS_MPLS)
    {
        CTC_ERROR_RETURN(_sys_humber_parser_get_mpls_ecmp_hash(hash_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief set parser layer4 flag op ctl reg
*/
int32
sys_humber_parser_set_layer4_flag_op_ctl(uint8 lchip, uint8 index, sys_parser_l4flag_op_ctl_t* l4flag_op_ctl)
{
    parser_layer4_flag_op_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4flag_op_ctl);

    sal_memset(&ctl, 0, sizeof(parser_layer4_flag_op_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer4_flag_op_ctl_entry(lchip, &ctl));

    switch (index)
    {
    case 0:
        ctl.layer4_op_and_or0 = l4flag_op_ctl->op_and_or ? 1 : 0;
        ctl.layer4_op_flags_mask0 = l4flag_op_ctl->flags_mask & 0x3f;
        break;

    case 1:
        ctl.layer4_op_and_or1 = l4flag_op_ctl->op_and_or ? 1 : 0;
        ctl.layer4_op_flags_mask1 = l4flag_op_ctl->flags_mask & 0x3f;
        break;

    case 2:
        ctl.layer4_op_and_or2 = l4flag_op_ctl->op_and_or ? 1 : 0;
        ctl.layer4_op_flags_mask2 = l4flag_op_ctl->flags_mask & 0x3f;
        break;

    case 3:
        ctl.layer4_op_and_or3 = l4flag_op_ctl->op_and_or ? 1 : 0;
        ctl.layer4_op_flags_mask3 = l4flag_op_ctl->flags_mask & 0x3f;
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    CTC_ERROR_RETURN(
        sys_humber_parser_io_set_parser_layer4_flag_op_ctl_entry(lchip, &ctl));

    return CTC_E_NONE;
}

/**
 @brief set parser layer4 port op sel reg
*/
int32
sys_humber_parser_set_layer4_port_op_sel(uint8 lchip, sys_parser_l4_port_op_sel_t* l4port_op_sel)
{
    parser_layer4_port_op_sel_t ctl;

    CTC_PTR_VALID_CHECK(l4port_op_sel);

    sal_memset(&ctl, 0, sizeof(parser_layer4_port_op_sel_t));

    ctl.layer4_op_dest_port = l4port_op_sel->op_dest_port;

    CTC_ERROR_RETURN(
        sys_humber_parser_io_set_parser_layer4_port_op_sel_entry(lchip, &ctl));

    return CTC_E_NONE;

}

/**
 @brief set parser layer4 port op ctl reg
*/
int32
sys_humber_parser_set_layer4_port_op_ctl(uint8 lchip, uint8 index, sys_parser_l4_port_op_ctl_t* l4port_op_ctl)
{
    parser_layer4_port_op_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4port_op_ctl);

    sal_memset(&ctl, 0, sizeof(parser_layer4_port_op_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer4_port_op_ctl_entry(lchip, &ctl));

    switch (index)
    {
    case 0:
        ctl.layer4_op_port_max0 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min0 = l4port_op_ctl->layer4_port_min;
        break;

    case 1:
        ctl.layer4_op_port_max1 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min1 = l4port_op_ctl->layer4_port_min;
        break;

    case 2:
        ctl.layer4_op_port_max2 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min2 = l4port_op_ctl->layer4_port_min;
        break;

    case 3:
        ctl.layer4_op_port_max3 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min3 = l4port_op_ctl->layer4_port_min;
        break;

    case 4:
        ctl.layer4_op_port_max4 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min4 = l4port_op_ctl->layer4_port_min;
        break;

    case 5:
        ctl.layer4_op_port_max5 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min5 = l4port_op_ctl->layer4_port_min;
        break;

    case 6:
        ctl.layer4_op_port_max6 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min6 = l4port_op_ctl->layer4_port_min;
        break;

    case 7:
        ctl.layer4_op_port_max7 = l4port_op_ctl->layer4_port_max;
        ctl.layer4_op_port_min7 = l4port_op_ctl->layer4_port_min;
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    CTC_ERROR_RETURN(
        sys_humber_parser_io_set_parser_layer4_port_op_ctl_entry(lchip, &ctl));

    return CTC_E_NONE;
}

/**
 @brief set parser udp app op ctl reg
*/
int32
sys_humber_parser_set_udp_app_op_ctl(uint8 index, ctc_parser_udp_app_op_ctl_t* udp_app_op_ctl)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_udp_app_op_ctl_t ctl;

    CTC_PTR_VALID_CHECK(udp_app_op_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_udp_app_op_ctl_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_udp_app_op_ctl_entry(lchip, &ctl));

        switch (index)
        {
        case 0:
            ctl.udp_app_mask0 = udp_app_op_ctl->udp_app_mask;
            ctl.udp_app_value0 = udp_app_op_ctl->udp_app_value;
            break;

        case 1:
            ctl.udp_app_mask1 = udp_app_op_ctl->udp_app_mask;
            ctl.udp_app_value1 = udp_app_op_ctl->udp_app_value;
            break;

        case 2:
            ctl.udp_app_mask2 = udp_app_op_ctl->udp_app_mask;
            ctl.udp_app_value2 = udp_app_op_ctl->udp_app_value;
            break;

        case 3:
            ctl.udp_app_mask3 = udp_app_op_ctl->udp_app_mask;
            ctl.udp_app_value3 = udp_app_op_ctl->udp_app_value;
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;

        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_udp_app_op_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser udp app op ctl reg
*/
int32
sys_humber_parser_get_udp_app_op_ctl(uint8 index, ctc_parser_udp_app_op_ctl_t* udp_app_op_ctl)
{
    parser_udp_app_op_ctl_t ctl;

    CTC_PTR_VALID_CHECK(udp_app_op_ctl);

    sal_memset(&ctl, 0, sizeof(parser_udp_app_op_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_udp_app_op_ctl_entry(0, &ctl));

    switch (index)
    {
    case 0:
        udp_app_op_ctl->udp_app_mask = ctl.udp_app_mask0;
        udp_app_op_ctl->udp_app_value = ctl.udp_app_value0;
        break;

    case 1:
        udp_app_op_ctl->udp_app_mask = ctl.udp_app_mask1;
        udp_app_op_ctl->udp_app_value = ctl.udp_app_value1;
        break;

    case 2:
        udp_app_op_ctl->udp_app_mask = ctl.udp_app_mask2;
        udp_app_op_ctl->udp_app_value = ctl.udp_app_value2;
        break;

    case 3:
        udp_app_op_ctl->udp_app_mask = ctl.udp_app_mask3;
        udp_app_op_ctl->udp_app_value = ctl.udp_app_value3;
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief set parser layer4 len op ctl reg
*/
int32
sys_humber_parser_set_l4_len_op_ctl(uint8 index, uint16 length)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer4_length_op_ctl_t ctl;

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_layer4_length_op_ctl_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer4_length_op_ctl_entry(lchip, &ctl));
        if (length > 0x3fff)
        {
            return CTC_E_INVALID_PARAM;
        }

        switch (index)
        {
        case 0:
            ctl.layer4_op_length1 = length;
            break;

        case 1:
            ctl.layer4_op_length2 = length;
            break;

        case 2:
            ctl.layer4_op_length3 = length;
            break;

        case 3:
            ctl.layer4_op_length4 = length;
            break;

        case 4:
            ctl.layer4_op_length5 = length;
            break;

        case 5:
            ctl.layer4_op_length6 = length;
            break;

        case 6:
            ctl.layer4_op_length7 = length;
            break;

        case 7:
            ctl.layer4_op_length8 = length;
            break;

        case 8:
            ctl.layer4_op_length9 = length;
            break;

        case 9:
            ctl.layer4_op_length10 = length;
            break;

        case 10:
            ctl.layer4_op_length11 = length;
            break;

        case 11:
            ctl.layer4_op_length12 = length;
            break;

        case 12:
            ctl.layer4_op_length13 = length;
            break;

        case 13:
            ctl.layer4_op_length14 = length;
            break;

        case 14:
            ctl.layer4_op_length15 = length;
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_length_op_ctl_entry(lchip, &ctl));

    }

    return CTC_E_NONE;
}

/**
 @brief get parser layer4 len op ctl reg
*/
int32
sys_humber_parser_get_l4_len_op_ctl(uint8 index, uint16* length)
{
    uint32 tmp = 0;
    parser_layer4_length_op_ctl_t ctl;

    sal_memset(&ctl, 0, sizeof(parser_layer4_length_op_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer4_length_op_ctl_entry(0, &ctl));

    switch (index)
    {
    case 0:
        tmp = ctl.layer4_op_length1;
        break;

    case 1:
        tmp = ctl.layer4_op_length2;
        break;

    case 2:
        tmp = ctl.layer4_op_length3;
        break;

    case 3:
        tmp = ctl.layer4_op_length4;
        break;

    case 4:
        tmp = ctl.layer4_op_length5;
        break;

    case 5:
        tmp = ctl.layer4_op_length6;
        break;

    case 6:
        tmp = ctl.layer4_op_length7;
        break;

    case 7:
        tmp = ctl.layer4_op_length8;
        break;

    case 8:
        tmp = ctl.layer4_op_length9;
        break;

    case 9:
        tmp = ctl.layer4_op_length10;
        break;

    case 10:
        tmp = ctl.layer4_op_length11;
        break;

    case 11:
        tmp = ctl.layer4_op_length12;
        break;

    case 12:
        tmp = ctl.layer4_op_length13;
        break;

    case 13:
        tmp = ctl.layer4_op_length14;
        break;

    case 14:
        tmp = ctl.layer4_op_length15;
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    *length = tmp;
    return CTC_E_NONE;
}

/**
 @brief set parser l4flex header info
*/
int32
sys_humber_parser_set_l4flex_header(ctc_parser_l4flex_header_t* l4flex_header)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer4_flex_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4flex_header);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_layer4_flex_ctl_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer4_flex_ctl_entry(lchip, &ctl));

        if (l4flex_header->dest_port_basic_offset > 30)
        {
            return CTC_E_INVALID_PARAM;
        }

        ctl.layer4_byte_select0 = l4flex_header->dest_port_basic_offset;
        ctl.layer4_byte_select1 = l4flex_header->dest_port_basic_offset + 1;

        if (l4flex_header->l4_min_len > 0x1f)
        {
            return CTC_E_INVALID_PARAM;
        }

        ctl.layer4_min_length = l4flex_header->l4_min_len;

        if (l4flex_header->l4_app_min_len > 0x1f)
        {
            return CTC_E_INVALID_PARAM;
        }

        ctl.layer4_app_min_length = l4flex_header->l4_app_min_len;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_flex_ctl_entry(lchip, &ctl));

    }

    return CTC_E_NONE;
}

/**
 @brief get parser l4flex header info
*/
int32
sys_humber_parser_get_l4flex_header(ctc_parser_l4flex_header_t* l4flex_header)
{
    parser_layer4_flex_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4flex_header);

    sal_memset(&ctl, 0, sizeof(parser_layer4_flex_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer4_flex_ctl_entry(0, &ctl));

    l4flex_header->dest_port_basic_offset = ctl.layer4_byte_select0;
    l4flex_header->l4_min_len = ctl.layer4_min_length;
    l4flex_header->l4_app_min_len = ctl.layer4_app_min_length;

    return CTC_E_NONE;
}

/**
 @brief set parser layer4 ptp ctl
*/
int32
sys_humber_parser_set_l4_ptp_ctl(ctc_parser_ptp_ctl_t* l4ptp_ctl)
{

    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_layer4_ptp_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4ptp_ctl);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ctl, 0, sizeof(parser_layer4_ptp_ctl_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_layer4_ptp_ctl_entry(lchip, &ctl));

        ctl.ptp_en = l4ptp_ctl->ptp_en ? 1 : 0;
        ctl.ptp_port0 = l4ptp_ctl->ptp_port0;
        ctl.ptp_port1 = l4ptp_ctl->ptp_port1;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_ptp_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser layer4 ptp ctl
*/
int32
sys_humber_parser_get_l4_ptp_ctl(ctc_parser_ptp_ctl_t* l4ptp_ctl)
{
    parser_layer4_ptp_ctl_t ctl;

    CTC_PTR_VALID_CHECK(l4ptp_ctl);

    sal_memset(&ctl, 0, sizeof(parser_layer4_ptp_ctl_t));

    CTC_ERROR_RETURN(
        sys_humber_parser_io_get_parser_layer4_ptp_ctl_entry(0, &ctl));

    l4ptp_ctl->ptp_en = ctl.ptp_en;
    l4ptp_ctl->ptp_port0 = ctl.ptp_port0;
    l4ptp_ctl->ptp_port1 = ctl.ptp_port1;

    return CTC_E_NONE;
}

/**
 @brief add l4type
*/
int32
sys_humber_parser_set_l4_type(uint8 index, ctc_parser_l4_protocol_entry_t* entry)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_application_cam_t cam;

    /*the max entry num is 2*/
    if (index >= SYS_PAS_MAX_L4_PTL_CAM_ENTRY_NUM)
    {
        return CTC_E_INVALID_PARAM;
    }

    CTC_PTR_VALID_CHECK(entry);

    local_chip_num = sys_humber_get_local_chip_num();
    if ((entry->byte0_select > 0x1f)
        || (entry->byte1_select > 0x1f)
        || (entry->tcp_flag_value > 0x3f)
        || (entry->tcp_flag_mask > 0x3F))
    {
        return CTC_E_INVALID_PARAM;
    }

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&cam, 0, sizeof(parser_application_cam_t));

        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_application_cam_entry(lchip, &cam));

        switch (index)
        {

        case 0:
            cam.application_cam_source_port_value0 = entry->src_port_value;
            cam.application_cam_dest_port_value0 = entry->dst_port_value;
            cam.application_cam_application_type0 = entry->application_type ? 1 : 0;
            cam.application_cam_byte0_select0 = entry->byte0_select;
            cam.application_cam_byte_select_dest0 = entry->byte_select_dest ? 1 : 0;
            cam.application_cam_entry_valid0 = entry->entry_vld ? 1 : 0;
            cam.application_cam_byte1_select0 = entry->byte1_select;
            cam.application_cam_source_port_mask0 = entry->source_port_mask ? 1 : 0;
            cam.application_cam_dest_port_mask0 = entry->dest_port_mask ? 1 : 0;
            cam.application_cam_tcp_flag_mask0 = entry->tcp_flag_mask & 0x3f;
            cam.application_cam_is_tcp_mask0 = entry->is_tcp_mask ? 1 : 0;
            cam.application_cam_is_tcp_value0 = entry->is_tcp_value ? 1 : 0;
            cam.application_cam_tcp_flag_value0 = entry->tcp_flag_value;
            break;

        case 1:
            cam.application_cam_source_port_value1 = entry->src_port_value;
            cam.application_cam_dest_port_value1 = entry->dst_port_value;
            cam.application_cam_application_type1 = entry->application_type ? 1 : 0;
            cam.application_cam_byte0_select1 = entry->byte0_select;
            cam.application_cam_byte_select_dest1 = entry->byte_select_dest ? 1 : 0;
            cam.application_cam_entry_valid1 = entry->entry_vld ? 1 : 0;
            cam.application_cam_byte1_select1 = entry->byte1_select;
            cam.application_cam_source_port_mask1 = entry->source_port_mask ? 1 : 0;
            cam.application_cam_dest_port_mask1 = entry->dest_port_mask ? 1 : 0;
            cam.application_cam_tcp_flag_mask1 = entry->tcp_flag_mask & 0x3f;
            cam.application_cam_is_tcp_mask1 = entry->is_tcp_mask ? 1 : 0;
            cam.application_cam_is_tcp_value1 = entry->is_tcp_value ? 1 : 0;
            cam.application_cam_tcp_flag_value1 = entry->tcp_flag_value;
            break;

        default:
            return CTC_E_INVALID_PARAM;
            break;
        }

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_application_cam_entry(lchip, &cam));
    }

    return CTC_E_NONE;
}

/**
 @brief set parser global config info
*/
int32
sys_humber_parser_set_global_cfg(ctc_parser_global_cfg_t* global_cfg)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_ip_hash_ctl_t ip_ctl;

    CTC_PTR_VALID_CHECK(global_cfg);

    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {

        sal_memset(&ip_ctl, 0, sizeof(parser_ip_hash_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_ip_hash_ctl_entry(lchip, &ip_ctl));

        if (global_cfg->small_frag_offset > 3)
        {
            return CTC_E_INVALID_PARAM;
        }

        ip_ctl.small_fragment_offset = global_cfg->small_frag_offset;

        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_ip_hash_ctl_entry(lchip, &ip_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief get parser global config info
*/
int32
sys_humber_parser_get_global_cfg(ctc_parser_global_cfg_t* global_cfg)
{
    uint8 lchip = 0;
    uint8 local_chip_num = 0;
    parser_ip_hash_ctl_t ip_ctl;

    CTC_PTR_VALID_CHECK(global_cfg);
    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        sal_memset(&ip_ctl, 0, sizeof(parser_ip_hash_ctl_t));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_get_parser_ip_hash_ctl_entry(lchip, &ip_ctl));

        global_cfg->small_frag_offset = ip_ctl.small_fragment_offset;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_parser_l2pro_cam_init(uint8 local_chip_num)
{
    uint8 lchip;
    parser_layer2_protocol_cam_t cam;
    parser_layer2_protocol_cam_valid_t valid;

    sal_memset(&cam, 0, sizeof(parser_layer2_protocol_cam_t));
    sal_memset(&valid, 0, sizeof(parser_layer2_protocol_cam_valid_t));

    /*none*/
    /*ip*/

    /*ipv4*/
    cam.layer2_protocol_cam_layer3_type2 = CTC_PARSER_L3_TYPE_IPV4;
    cam.layer2_protocol_cam_additional_offset2 = 0;
    cam.layer2_protocol_cam_value2 = SYS_PAS_L2_CAM_L2CAM_VALUE_IPV4;
    cam.layer2_protocol_cam_mask2 = 0x40FFFF;

    /*ipv6*/
    cam.layer2_protocol_cam_layer3_type3 = CTC_PARSER_L3_TYPE_IPV6;
    cam.layer2_protocol_cam_additional_offset3 = 0;
    cam.layer2_protocol_cam_value3 = SYS_PAS_L2_CAM_L2CAM_VALUE_IPV6;
    cam.layer2_protocol_cam_mask3 = 0x40FFFF;

    /*mpls*/
    cam.layer2_protocol_cam_layer3_type4 = CTC_PARSER_L3_TYPE_MPLS;
    cam.layer2_protocol_cam_additional_offset4 = 0;
    cam.layer2_protocol_cam_value4 = SYS_PAS_L2_CAM_L2CAM_VALUE_MPLS;
    cam.layer2_protocol_cam_mask4 = 0x40FFFF;

    /*mpls mcast*/
    cam.layer2_protocol_cam_layer3_type5 = CTC_PARSER_L3_TYPE_MPLS_MCAST;
    cam.layer2_protocol_cam_additional_offset5 = 0;
    cam.layer2_protocol_cam_value5 = SYS_PAS_L2_CAM_L2CAM_VALUE_MPLS_MCAST;
    cam.layer2_protocol_cam_mask5 = 0x40FFFF;

    /*ipv4arp*/
    cam.layer2_protocol_cam_layer3_type6 = CTC_PARSER_L3_TYPE_ARP;
    cam.layer2_protocol_cam_additional_offset6 = 0;
    cam.layer2_protocol_cam_value6 = SYS_PAS_L2_CAM_L2CAM_VALUE_ARP;
    cam.layer2_protocol_cam_mask6 = 0x40FFFF;

    /*ipv4rarp*/
    cam.layer2_protocol_cam_layer3_type7 = CTC_PARSER_L3_TYPE_RARP;
    cam.layer2_protocol_cam_additional_offset7 = 0;
    cam.layer2_protocol_cam_value7 = SYS_PAS_L2_CAM_L2CAM_VALUE_RARP;
    cam.layer2_protocol_cam_mask7 = 0x40FFFF;

    /*EAPOL*/
    cam.layer2_protocol_cam_layer3_type8 = CTC_PARSER_L3_TYPE_EAPOL;
    cam.layer2_protocol_cam_additional_offset8 = 0;
    cam.layer2_protocol_cam_value8 = SYS_PAS_L2_CAM_L2CAM_VALUE_EAPOL;
    cam.layer2_protocol_cam_mask8 = 0x40FFFF;

    /*OAM*/
    cam.layer2_protocol_cam_layer3_type9 = CTC_PARSER_L3_TYPE_ETHER_OAM;
    cam.layer2_protocol_cam_additional_offset9 = 0;
    cam.layer2_protocol_cam_value9 = SYS_PAS_L2_CAM_L2CAM_VALUE_ETHER_OAM;
    cam.layer2_protocol_cam_mask9 = 0x40FFFF;

    /*slow proto*/
    cam.layer2_protocol_cam_layer3_type10 = CTC_PARSER_L3_TYPE_SLOW_PROTO;
    cam.layer2_protocol_cam_additional_offset10 = 0;
    cam.layer2_protocol_cam_value10 = SYS_PAS_L2_CAM_L2CAM_VALUE_SLOW_PROTO;
    cam.layer2_protocol_cam_mask10 = 0x40FFFF;

    /*CMAC*/
    cam.layer2_protocol_cam_layer3_type11 = CTC_PARSER_L3_TYPE_CMAC;
    cam.layer2_protocol_cam_additional_offset11 = 0;
    cam.layer2_protocol_cam_value11 = SYS_PAS_L2_CAM_L2CAM_VALUE_PBB;
    cam.layer2_protocol_cam_mask11 = 0x40FFFF;

    /*PTP*/
    cam.layer2_protocol_cam_layer3_type12 = CTC_PARSER_L3_TYPE_PTP;
    cam.layer2_protocol_cam_additional_offset12 = 0;
    cam.layer2_protocol_cam_value12 = SYS_PAS_L2_CAM_L2CAM_VALUE_PTP;
    cam.layer2_protocol_cam_mask12 = 0x40FFFF;

    /*
       index : 13~15 reserved for user define
       #define SYS_PARSER_L2PRO_CAM_RSV_USER_DEFINE_BASE   13
    */
    valid.layer2_cam_entry_valid = 0x1FFC;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer2_protocol_cam_valid_entry(lchip, &valid));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer2_protocol_cam_entry(lchip, &cam));
    }

    return CTC_E_NONE;

}

static int32
_sys_humber_parser_pbb_ctl_init(uint8 local_chip_num)
{

    uint8 lchip;
    parser_pbb_ctl_t ctl;

    sal_memset(&ctl, 0, sizeof(parser_pbb_ctl_t));

    ctl.pbb_vlan_parsing_num = SYS_PAS_PBB_VLAN_PAS_NUM;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_pbb_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_parser_packet_type_map_init(uint8 local_chip_num)
{

    uint8 lchip;
    parser_packet_type_table_t packet_type;

    sal_memset(&packet_type, 0, sizeof(parser_packet_type_table_t));

    packet_type.packet_type_layer2_type0 = CTC_PARSER_L2_TYPE_ETH_V2;
    packet_type.packet_type_layer3_type0 = CTC_PARSER_L3_TYPE_NONE;
    packet_type.packet_type_layer2_type1 = CTC_PARSER_L2_TYPE_NONE;
    packet_type.packet_type_layer3_type1 = CTC_PARSER_L3_TYPE_IPV4;
    packet_type.packet_type_layer2_type2 = CTC_PARSER_L2_TYPE_NONE;
    packet_type.packet_type_layer3_type2 = CTC_PARSER_L3_TYPE_MPLS;
    packet_type.packet_type_layer2_type3 = CTC_PARSER_L2_TYPE_NONE;
    packet_type.packet_type_layer3_type3 = CTC_PARSER_L3_TYPE_IPV6;
    packet_type.packet_type_layer2_type4 = CTC_PARSER_L2_TYPE_NONE;
    packet_type.packet_type_layer3_type4 = CTC_PARSER_L3_TYPE_IP;
    packet_type.packet_type_layer2_type5 = CTC_PARSER_L2_TYPE_PPP_1B;
    packet_type.packet_type_layer3_type5 = CTC_PARSER_L3_TYPE_NONE;
    packet_type.packet_type_layer2_type6 = CTC_PARSER_L2_TYPE_NONE; /*CTC_PARSER_L2_TYPE_PPP_2B;*/
    packet_type.packet_type_layer3_type6 = CTC_PARSER_L3_TYPE_NONE;
    packet_type.packet_type_layer2_type7 = CTC_PARSER_L2_TYPE_NONE;
    packet_type.packet_type_layer3_type7 = CTC_PARSER_L3_TYPE_NONE;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_packet_type_table_entry(lchip, &packet_type));

    }

    return CTC_E_NONE;
}

static int32
_sys_humber_parser_ipv6_ctl_init(uint8 local_chip_num)
{
    parser_ipv6_ctl_t ctl;
    uint8 lchip = 0;

    sal_memset(&ctl, 0, sizeof(parser_ipv6_ctl_t));
    /*hop by hop*/
    ctl.ipv6_set_ip_options0 = 1;
    ctl.ipv6_ext_shift0 = 0;
    ctl.ipv6_ext_level0 = SYS_PAS_IPV6_EXT_LEVEL_HOP_BY_HOP;
    ctl.ipv6_ext_level_check_en0 = 1;

    /*destination*/
    ctl.ipv6_set_ip_options1 = 0;
    ctl.ipv6_ext_shift1 = 0;
    ctl.ipv6_ext_level1 = SYS_PAS_IPV6_EXT_LEVEL_DESTINATION;
    ctl.ipv6_ext_level_check_en1 = 1;

    /*routing*/
    ctl.ipv6_set_ip_options2 = 0;
    ctl.ipv6_ext_shift2 = 0;
    ctl.ipv6_ext_level2 = SYS_PAS_IPV6_EXT_LEVEL_ROUTING;
    ctl.ipv6_ext_level_check_en2 = 1;

    /*fragment*/
    ctl.ipv6_set_ip_options3 = 0;
    ctl.ipv6_ext_shift3 = 0;
    ctl.ipv6_ext_level3 = SYS_PAS_IPV6_EXT_LEVEL_FRAG;
    ctl.ipv6_ext_level_check_en3 = 1;

    /*ah*/
    ctl.ipv6_set_ip_options4 = 0;
    ctl.ipv6_ext_shift4 = 1;
    ctl.ipv6_ext_level4 = SYS_PAS_IPV6_EXT_LEVEL_AH;
    ctl.ipv6_ext_level_check_en4 = 1;

    /*esp*/
    ctl.ipv6_set_ip_options5 = 0;
    ctl.ipv6_ext_shift5 = 0;
    ctl.ipv6_ext_level5 = SYS_PAS_IPV6_EXT_LEVEL_ESP;
    ctl.ipv6_ext_level_check_en5 = 1;

    ctl.parser_ipv6_error_option_en = 1;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_ipv6_ctl_entry(lchip, &ctl));
    }

    return CTC_E_NONE;

}

static int32
_sys_humber_parser_l3pro_cam_init(uint8 local_chip_num)
{
    uint8 lchip;
    parser_layer3_protocol_cam_t cam;
    parser_layer3_protocol_cam_valid_t valid;

    sal_memset(&cam, 0, sizeof(parser_layer3_protocol_cam_t));
    sal_memset(&valid, 0, sizeof(parser_layer3_protocol_cam_valid_t));

    /* layer4 type is none*/
    /*l3 IP/IPv4/IPv6, l4 TCP*/
    cam.layer3_protocol_cam_layer4_type0 = CTC_PARSER_L4_TYPE_TCP;
    cam.layer3_protocol_cam_layer3_type_mask0 = 0xC;
    cam.layer3_protocol_cam_layer3_header_protocol_mask0 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol0 = 6;

    /*l3 IP/IPv4/IPv6, l4 UDP*/
    cam.layer3_protocol_cam_layer4_type1 = CTC_PARSER_L4_TYPE_UDP;
    cam.layer3_protocol_cam_layer3_type_mask1 = 0xC;
    cam.layer3_protocol_cam_layer3_header_protocol_mask1 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol1 = 17;

    /* l3 IPv4, GRE*/
    cam.layer3_protocol_cam_layer4_type2 = CTC_PARSER_L4_TYPE_GRE;
    cam.layer3_protocol_cam_layer3_type_mask2 = 0xF;
    cam.layer3_protocol_cam_layer3_type2 = CTC_PARSER_L3_TYPE_IPV4;
    cam.layer3_protocol_cam_layer3_header_protocol_mask2 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol2 = 47;

    /*l3 IPv4, IP-in-Ip*/
    cam.layer3_protocol_cam_layer4_type3 = CTC_PARSER_L4_TYPE_IPINIP;
    cam.layer3_protocol_cam_layer3_type_mask3 = 0xF;
    cam.layer3_protocol_cam_layer3_type3 = CTC_PARSER_L3_TYPE_IPV4;
    cam.layer3_protocol_cam_layer3_header_protocol_mask3 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol3 = 4;

    /*l3 IPv4, IPv6-in-Ip*/
    cam.layer3_protocol_cam_layer4_type4 = CTC_PARSER_L4_TYPE_V6INIP;
    cam.layer3_protocol_cam_layer3_type_mask4 = 0xF;
    cam.layer3_protocol_cam_layer3_type4 = CTC_PARSER_L3_TYPE_IPV4;
    cam.layer3_protocol_cam_layer3_header_protocol_mask4 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol4 = 41;

    /*l3 IP/IPv4/IPv6, l4 ICMP*/
    cam.layer3_protocol_cam_layer4_type5 = CTC_PARSER_L4_TYPE_ICMP;
    cam.layer3_protocol_cam_layer3_type_mask5 = 0xC;
    cam.layer3_protocol_cam_layer3_type5 = CTC_PARSER_L3_TYPE_NONE;
    cam.layer3_protocol_cam_layer3_header_protocol_mask5 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol5 = 1;

    /*l3 IPv4, l4 IGMP*/
    cam.layer3_protocol_cam_layer4_type6 = CTC_PARSER_L4_TYPE_IGMP;
    cam.layer3_protocol_cam_layer3_type_mask6 = 0xF;
    cam.layer3_protocol_cam_layer3_type6 = CTC_PARSER_L3_TYPE_IPV4;
    cam.layer3_protocol_cam_layer3_header_protocol_mask6 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol6 = 2;

    /* l3 IPv6, ICMPv6(include IGMP for IPv6)*/
    cam.layer3_protocol_cam_layer4_type7 = CTC_PARSER_L4_TYPE_ICMP;
    cam.layer3_protocol_cam_layer3_type_mask7 = 0xF;
    cam.layer3_protocol_cam_layer3_type7 = CTC_PARSER_L3_TYPE_IPV6;
    cam.layer3_protocol_cam_layer3_header_protocol_mask7 = 0xFF;
    cam.layer3_protocol_cam_layer3_header_protocol7 = 58;

    /* layer4 type is any proto*/
    cam.layer3_protocol_cam_layer4_type15 = CTC_PARSER_L4_TYPE_ANY_PROTO;
    cam.layer3_protocol_cam_layer3_header_protocol15 = 0;
    cam.layer3_protocol_cam_layer3_type15 = CTC_PARSER_L3_TYPE_NONE;
    cam.layer3_protocol_cam_layer3_type_mask15 = 0xC;
    cam.layer3_protocol_cam_layer3_header_protocol_mask15 = 0;

    valid.layer3_cam_entry_valid = 0x80FF;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer3_protocol_cam_valid_entry(lchip, &valid));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer3_protocol_cam_entry(lchip, &cam));
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_parser_app_cam_init(uint8 local_chip_num)
{
    uint8 lchip;
    parser_application_cam_t cam;

    sal_memset(&cam, 0, sizeof(parser_application_cam_t));

    cam.application_cam_application_type0 = 0;
    cam.application_cam_application_type1 = 0;
    cam.application_cam_source_port_value0 = 0;
    cam.application_cam_source_port_value1 = 0;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_application_cam_entry(lchip, &cam));
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_parser_l4_reg_ctl_init(uint8 local_chip_num)
{
    uint8 lchip;
    parser_layer4_length_op_ctl_t l4len_opctl;
    parser_layer4_port_op_sel_t port_opsel;
    parser_layer4_port_op_ctl_t port_opctl;
    parser_udp_app_op_ctl_t udp_app_opctl;
    parser_layer4_flag_op_ctl_t l4flag_opctl;
    parser_layer4_flex_ctl_t l4flex_ctl;
    parser_layer4_ptp_ctl_t l4ptp_ctl;
    parser_l4_hash_ctl_t l4hash_ctl;

    sal_memset(&l4hash_ctl, 0, sizeof(parser_l4_hash_ctl_t));
    sal_memset(&l4len_opctl, 0, sizeof(parser_application_cam_t));
    sal_memset(&port_opsel, 0, sizeof(parser_layer4_port_op_sel_t));
    sal_memset(&port_opctl, 0, sizeof(parser_layer4_port_op_ctl_t));
    sal_memset(&udp_app_opctl, 0, sizeof(parser_udp_app_op_ctl_t));
    sal_memset(&l4flag_opctl, 0, sizeof(parser_layer4_flag_op_ctl_t));
    sal_memset(&l4flex_ctl, 0, sizeof(parser_layer4_flex_ctl_t));
    sal_memset(&l4ptp_ctl, 0, sizeof(parser_layer4_ptp_ctl_t));

    l4len_opctl.layer4_op_length1 = 0x1;
    l4len_opctl.layer4_op_length2 = 0x2;
    l4len_opctl.layer4_op_length3 = 0x4;
    l4len_opctl.layer4_op_length4 = 0x8;
    l4len_opctl.layer4_op_length5 = 0x10;
    l4len_opctl.layer4_op_length6 = 0x20;
    l4len_opctl.layer4_op_length7 = 0x40;
    l4len_opctl.layer4_op_length8 = 0x80;
    l4len_opctl.layer4_op_length9 = 0x100;
    l4len_opctl.layer4_op_length10 = 0x200;
    l4len_opctl.layer4_op_length11 = 0x400;
    l4len_opctl.layer4_op_length12 = 0x800;
    l4len_opctl.layer4_op_length13 = 0x1000;
    l4len_opctl.layer4_op_length14 = 0x2000;

    port_opsel.layer4_op_dest_port = 0xf;

    port_opctl.layer4_op_port_max0 = 0x4;
    port_opctl.layer4_op_port_min0 = 0x1;
    port_opctl.layer4_op_port_max1 = 0x8;
    port_opctl.layer4_op_port_min1 = 0x2;
    port_opctl.layer4_op_port_max2 = 0x10;
    port_opctl.layer4_op_port_min2 = 0x4;
    port_opctl.layer4_op_port_max3 = 0x20;
    port_opctl.layer4_op_port_min3 = 0x8;
    port_opctl.layer4_op_port_max4 = 0x40;
    port_opctl.layer4_op_port_min4 = 0x10;
    port_opctl.layer4_op_port_max5 = 0x80;
    port_opctl.layer4_op_port_min5 = 0x20;
    port_opctl.layer4_op_port_max6 = 0x100;
    port_opctl.layer4_op_port_min6 = 0x40;
    port_opctl.layer4_op_port_max7 = 0x200;
    port_opctl.layer4_op_port_min7 = 0x80;

    udp_app_opctl.udp_app_mask0 = 0xffff;
    udp_app_opctl.udp_app_value0 = 0;
    udp_app_opctl.udp_app_mask1 = 0xffff;
    udp_app_opctl.udp_app_value1 = 0;
    udp_app_opctl.udp_app_mask2 = 0xffff;
    udp_app_opctl.udp_app_value2 = 0;
    udp_app_opctl.udp_app_mask3 = 0xffff;
    udp_app_opctl.udp_app_value3 = 0;

    l4flag_opctl.layer4_op_and_or0 = 0;
    l4flag_opctl.layer4_op_flags_mask0 = 0;
    l4flag_opctl.layer4_op_and_or1 = 0;
    l4flag_opctl.layer4_op_flags_mask1 = 0x3f;
    l4flag_opctl.layer4_op_and_or2 = 1;
    l4flag_opctl.layer4_op_flags_mask2 = 0;
    l4flag_opctl.layer4_op_and_or3 = 1;
    l4flag_opctl.layer4_op_flags_mask3 = 0x3f;

    l4flex_ctl.layer4_byte_select0 = 2;
    l4flex_ctl.layer4_byte_select1 = 3;

    l4ptp_ctl.ptp_en = 1;
    l4ptp_ctl.ptp_port0 = 319;
    l4ptp_ctl.ptp_port1 = 320;

    l4hash_ctl.source_port_hash_en = 0;

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_length_op_ctl_entry(lchip, &l4len_opctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_port_op_sel_entry(lchip, &port_opsel));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_port_op_ctl_entry(lchip, &port_opctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_udp_app_op_ctl_entry(lchip, &udp_app_opctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_flag_op_ctl_entry(lchip, &l4flag_opctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_flex_ctl_entry(lchip, &l4flex_ctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_layer4_ptp_ctl_entry(lchip, &l4ptp_ctl));
        CTC_ERROR_RETURN(
            sys_humber_parser_io_set_parser_l4_hash_ctl_entry(lchip, &l4hash_ctl));
    }

    return CTC_E_NONE;

}

/**
 @brief init parser module
*/
extern int32
sys_humber_parser_init(void)
{

    uint8 local_chip_num = 0;

    local_chip_num = sys_humber_get_local_chip_num();

    CTC_ERROR_RETURN(
        _sys_humber_parser_l2pro_cam_init(local_chip_num));

    CTC_ERROR_RETURN(
        _sys_humber_parser_pbb_ctl_init(local_chip_num));

    CTC_ERROR_RETURN(
        _sys_humber_parser_packet_type_map_init(local_chip_num));

    /*l3 parser init*/
    CTC_ERROR_RETURN(
        _sys_humber_parser_ipv6_ctl_init(local_chip_num));
    CTC_ERROR_RETURN(
        _sys_humber_parser_l3pro_cam_init(local_chip_num));

    /*l4 parser init*/
    CTC_ERROR_RETURN(
        _sys_humber_parser_app_cam_init(local_chip_num));
    CTC_ERROR_RETURN(
        _sys_humber_parser_l4_reg_ctl_init(local_chip_num));

    return CTC_E_NONE;

}

