/**
 @file ctc_humber_security.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-2-4

 @version v2.0

   This file define ctc functions of SDK.
*/

#ifndef _CTC_HUMBER_SECURITY_H
#define _CTC_HUMBER_SECURITY_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_security.h"
#include "ctc_l2.h"

/**********************************************************************************
                      Define API function interfaces
***********************************************************************************/
/**
 @addtogroup security SECURITY
 @{
*/

/**
 @brief  Init security module

 @param[in] lchip    local chip id

 @param[in] security_global_cfg security module global config

 @return CTC_E_XXX

*/
extern int32
ctc_humber_security_init(uint8 lchip, void* security_global_cfg);

/**
 @brief  Configure port based  security

 @param[in] lchip    local chip id

 @param[in] gport  global port

 @param[in] enable  if set,packet will be discard when srcport is mismatch with FDB

 @return CTC_E_XXX

*/
extern int32
ctc_humber_mac_security_set_port_security(uint8 lchip, uint32 gport, bool enable);

/**
 @brief  get configure of port based security

 @param[in] lchip    local chip id

 @param[in] gport  global port

 @param[out] p_enable  if set,packet will be discard when srcport is mismatch with FDB

 @return CTC_E_XXX

*/
extern int32
ctc_humber_mac_security_get_port_security(uint8 lchip, uint32 gport, bool* p_enable);

/**
 @brief Configure port based  mac limit

 @param[in] lchip    local chip id

 @param[in] gport       global port

 @param[in] action      refer to ctc_maclimit_action_t

 @return CTC_E_XXX
*/
extern int32
ctc_humber_mac_security_set_port_mac_limit(uint8 lchip, uint32 gport, ctc_maclimit_action_t action);
/**
 @brief Get the configure of port based  mac limit

 @param[in] lchip    local chip id

 @param[in] gport       global port

 @param[out] action      refer to ctc_maclimit_action_t

 @return CTC_E_XXX
*/
extern int32
ctc_humber_mac_security_get_port_mac_limit(uint8 lchip, uint32 gport, ctc_maclimit_action_t* action);

/**
 @brief Configure vlan based  mac limit

 @param[in] lchip    local chip id

 @param[in] vlan_id     vlan id

 @param[in] action      refer to ctc_maclimit_action_t

 @return CTC_E_XXX
*/
extern int32
ctc_humber_mac_security_set_vlan_mac_limit(uint8 lchip, uint16 vlan_id, ctc_maclimit_action_t action);

/**
 @brief Get the configure of vlan based  mac limit

 @param[in] lchip    local chip id

 @param[in] vlan_id     vlan id

 @param[out] action     refer to ctc_maclimit_action_t

 @return CTC_E_XXX
*/
extern int32
ctc_humber_mac_security_get_vlan_mac_limit(uint8 lchip, uint16 vlan_id, ctc_maclimit_action_t* action);

/**
 @brief  Add ip source guard entry

 @param[in] lchip    local chip id

 @param[in] p_elem  ip source guard property

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ip_source_guard_add_entry(uint8 lchip, ctc_security_ip_source_guard_elem_t* p_elem);

/**
 @brief  Remove ip source guard entry

 @param[in] lchip    local chip id

 @param[in] p_elem  ip source guard property

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ip_source_guard_remove_entry(uint8 lchip, ctc_security_ip_source_guard_elem_t* p_elem);

/**
 @brief  Set configure of storm ctl

 @param[in] lchip    local chip id

 @param[in] stmctl_cfg   configure of storm ctl

 @return CTC_E_XXX

*/
extern int32
ctc_humber_storm_ctl_set_cfg(uint8 lchip, ctc_security_stmctl_cfg_t* stmctl_cfg);

/**
 @brief  Get configure of storm ctl

 @param[in] lchip    local chip id

 @param[out] stmctl_cfg  configure of storm ctl

 @return CTC_E_XXX

*/
extern int32
ctc_humber_storm_ctl_get_cfg(uint8 lchip, ctc_security_stmctl_cfg_t* stmctl_cfg);

/**
 @brief  Set global configure of storm ctl

 @param[in] lchip    local chip id

 @param[out] p_glb_cfg  global configure of storm ctl

 @return CTC_E_XXX

*/
extern int32
ctc_humber_storm_ctl_set_global_cfg(uint8 lchip, ctc_security_stmctl_glb_cfg_t* p_glb_cfg);

/**
 @brief  Get global configure of storm ctl

 @param[in] lchip    local chip id

 @param[out] p_glb_cfg  global configure of storm ctl

 @return CTC_E_XXX

*/
extern int32
ctc_humber_storm_ctl_get_global_cfg(uint8 lchip, ctc_security_stmctl_glb_cfg_t* p_glb_cfg);

/**
 @brief  Set route is obey isolated enable

 @param[in] lchip    local chip id

 @param[in] enable  a boolean value denote route-obey-iso is enable

 @return CTC_E_XXX

*/
extern int32
ctc_humber_port_isolation_set_route_obey_isolated_en(uint8 lchip, bool enable);

/**
 @brief  Get route is obey isolated enable

 @param[in] lchip    local chip id

 @param[out] p_enable  a boolean value denote route-obey-iso is enable

 @return CTC_E_XXX

*/
extern int32
ctc_humber_port_isolation_get_route_obey_isolated_en(uint8 lchip, bool* p_enable);

/**@} end of @addtogroup  security SECURITY */

#ifdef __cplusplus
}
#endif

#endif

