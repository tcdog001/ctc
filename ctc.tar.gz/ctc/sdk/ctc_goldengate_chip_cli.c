/**
 @file ctc_goldengate_chip_cli.c

 @date 2012-3-20

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_api.h"
#include "ctc_chip.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_goldengate_chip_cli.h"
#include "dal.h"

extern int32
sys_goldengate_datapath_show_status(uint8 lchip);
extern int32
sys_goldengate_datapath_show_info(uint8 lchip, uint8 type, uint32 start, uint32 end, uint8 is_all);
extern int32
sys_goldengate_chip_show_ecc_recover_status(uint8 lchip, uint8 is_all);

CTC_CLI(ctc_cli_gg_datapath_show_status,
        ctc_cli_gg_datapath_show_status_cmd,
        "show datapath status ",
        CTC_CLI_SHOW_STR,
        "Datapath module",
        "Status")
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;

    ret = sys_goldengate_datapath_show_status(lchip);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_datapath_show_info,
        ctc_cli_gg_datapath_show_info_cmd,
        "show datapath info (hss|serdes|clktree|calendar) (((start-idx SIDX) (end-idx EIDX))|)",
        CTC_CLI_SHOW_STR,
        "Datapath module",
        "Information",
        "Hss",
        "SerDes",
        "Clock Tree",
        "Calendar",
        "Start index",
        "Index",
        "End index",
        "Index")
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint32 index = 0;
    uint32 start_idx = 0;
    uint32 end_idx = 0;
    uint8 is_all = 1;
    uint8 type = 0;

    index = CTC_CLI_GET_ARGC_INDEX("hss");
    if(index != 0xFF)
    {
         type = 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX("serdes");
    if(index != 0xFF)
    {
         type = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("clktree");
    if(index != 0xFF)
    {
         type = 2;
    }
    index = CTC_CLI_GET_ARGC_INDEX("calendar");
    if(index != 0xFF)
    {
         type = 3;
    }
    index = CTC_CLI_GET_ARGC_INDEX("start-idx");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT32("start-idx", start_idx, argv[index+1]);
       is_all = 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX("end-idx");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT32("end-idx", end_idx, argv[index+1]);
       is_all = 0;
    }

    ret = sys_goldengate_datapath_show_info(lchip, type, start_idx, end_idx, is_all);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


extern dal_op_t g_dal_op;

uint8 g_debug = 0;

CTC_CLI(ctc_cli_gg_debug,
        ctc_cli_gg_debug_cmd,
        "debug driver (on|off)",
        "debug",
        "driver",
        "on",
        "off")
{
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("on");
    if(0xFF != index)
    {
        g_debug = 1;
    }
    else
    {
        g_debug = 0;
    }

    return CLI_SUCCESS;
}

extern uint8  g_burst_en;

CTC_CLI(ctc_cli_gg_chip_set_burst_en,
        ctc_cli_gg_chip_set_burst_en_cmd,
        "chip set burst (enable|disable)",
        "chip module",
        "Set",
        "Burst Io",
        "Enable",
        "Disable")
{
    if (0 == sal_memcmp("enable", argv[0], 3))
    {
        g_burst_en = 1;
    }
    else
    {
        g_burst_en = 0;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_chip_show_ecc_status,
        ctc_cli_gg_chip_show_ecc_status_cmd,
        "show chip ecc status ((lchip CHIP_ID) |)",
        CTC_CLI_SHOW_STR,
        "Chip module",
        "Ecc error recover",
        "Status",
        "Local chip id",
        "<0-1>")
{
    int32  ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8  index = 0, all = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("all");
    if (index != 0xFF)
    {
        all = 1;
    }

    ret = sys_goldengate_chip_show_ecc_recover_status(lchip, all);
    if (ret)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

int32
ctc_goldengate_chip_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gg_datapath_show_status_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_datapath_show_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_chip_show_ecc_status_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_debug_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_chip_set_burst_en_cmd);

    return 0;
}

