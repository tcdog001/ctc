/**
 @file dal_user.c

 @date 2012-10-23

 @version v2.0

*/
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <pci.h>
#include <intLib.h>
#include <cacheLib.h>
//-#include <ivPpc.h>
#include "sal.h"
#include "dal.h"
#include "dal_user.h"
#include "dal_mpool.h"

struct dma_info_s
{
    unsigned int phy_base;
    unsigned int size;
    unsigned int* virt_base;
};
typedef struct dma_info_s dma_info_t;


/*****************************************************************************
 * defines
 *****************************************************************************/
#define CTC_VENDOR_VID 0xc001
#define CTC_GREATBELT_DEVICE_ID 0x03e8

#define PCI_BUS_NO_START        0
#define PCI_MAX_BUS         0x100
#define PCI_MAX_DEVICES     0x20
#define PCI_CONF_VENDOR_ID              0x00     /* Word @ Offset 0x00 */
#define PCI_CONF_DEVICE_ID              0x02     /* Word @ Offset 0x02 */
#define PCI_CONF_REVISION_ID            0x08     /* Byte @ Offset 0x08 */
#define PCI_CONF_COMMAND                0x04     /* Word @ Offset 0x04 */
#define PCI_CONF_BAR0                   0x10     /* DWORD @ Offset 0x10 */
#define PCI_CONF_BAR1                   0x14     /* DWORD @ Offset 0x14 */
#define PCI_CONF_BAR2                   0x18     /* DWORD @ Offset 0x18 */
#define PCI_CONF_BAR3                   0x1C     /* DWORD @ Offset 0x1C */
#define PCI_CONF_BAR4                   0x20     /* DWORD @ Offset 0x20 */
#define PCI_CONF_BAR5                   0x24     /* DWORD @ Offset 0x24 */

#define PCI_CONF_BAR_TYPE_MASK          (3 << 1)
#define PCI_CONF_BAR_TYPE_64B           (2 << 1)

#define DAL_INTERRUPT_NUM 2
/*****************************************************************************
 * typedef
 *****************************************************************************/

/*****************************************************************************
 * global variables
 *****************************************************************************/
uint8 g_dal_debug_on = 0;
static dal_access_type_t g_dal_access = DAL_PCIE_MM;
dal_pci_dev_t  g_dal_pci_dev[DAL_MAX_CHIP_NUM];    /* PCI device type */
uint8 g_dal_init = 0;

uint32 g_mem_base[DAL_MAX_CHIP_NUM] = {0x80000000, 0};
dal_intr_para_t g_intr_para[DAL_INTERRUPT_NUM];

typedef void (* DAL_ISR_CALLBACK_FUN_P)  (void*);

DAL_ISR_CALLBACK_FUN_P g_dal_isr_cb = NULL;

extern uintptr dal_logic_to_phy(uint8 lchip, void* laddr);
extern void*
dal_phy_to_logic(uint8 lchip, uintptr paddr);
extern uint32*
dal_dma_alloc(uint8 lchip, int32 size, int32 type);
extern void
dal_dma_free(uint8 lchip, void* ptr);


dal_op_t g_dal_op =
{
    pci_read: dal_pci_read,
    pci_write: dal_pci_write,
    pci_conf_read: dal_pci_conf_read,
    pci_conf_write: dal_pci_conf_write,
    i2c_read: dal_i2c_read,
    i2c_write: dal_i2c_write,
    interrupt_register: dal_interrupt_register,
    interrupt_unregister: NULL,
    interrupt_set_en: dal_interrupt_set_en,
    interrupt_set_msi_cap:NULL,
    logic_to_phy: dal_logic_to_phy,
    phy_to_logic: dal_phy_to_logic,
    dma_alloc: dal_dma_alloc,
    dma_free: dal_dma_free,
};

/*****************************************************************************
 * macros
 *****************************************************************************/

/*****************************************************************************
 * functions
 *****************************************************************************/

int32
dal_init_pcie_resource(uintptr* pcie_base)
{
    uint32 venID = 0;
    uint32 devID = 0;
    uint32 revID = 0;
    uint16 bus_no = 0;
    uint8 dev_no = 0;
    uint32 baroff = PCI_CONF_BAR0;
    uint32 rval = 0;
    int32 ret = 0;
    uint8 lchip_num = 0;

    for (bus_no = PCI_BUS_NO_START; bus_no < PCI_MAX_BUS; bus_no++)
    {
        for (dev_no = 0; dev_no < PCI_MAX_DEVICES; dev_no++)
        {
            ret = pciConfigInLong(bus_no, dev_no, 0, PCI_CONF_VENDOR_ID, &venID);
            if (venID == 0xffff)
            {
                /*continue;*/
                break;
            }

            ret += pciConfigInLong(bus_no, dev_no, 0, PCI_CONF_REVISION_ID, &revID);

            devID = venID >> 16;
            venID = (venID & 0xffff);

            if ((venID == CTC_VENDOR_VID) && (devID == CTC_GREATBELT_DEVICE_ID))
            {

                ret += pciConfigOutLong(bus_no, dev_no, 0, baroff, 0xffffffff);
                ret += pciConfigInLong(bus_no, dev_no, 0, baroff, &rval);
                ret += pciConfigOutLong(bus_no, dev_no, 0, baroff, pcie_base[lchip_num]);
                if ((rval & PCI_CONF_BAR_TYPE_MASK) == PCI_CONF_BAR_TYPE_64B)
                {
                    ret += pciConfigOutLong(bus_no, dev_no, 0, PCI_CONF_BAR1, 0);
                }

                /*enable cmd register */
                ret += pciConfigOutLong(bus_no, dev_no, 0, PCI_CONF_COMMAND, 0x06);
                lchip_num++;
                if (lchip_num > DAL_MAX_CHIP_NUM)
                {
                    return -1;
                }
            }
        }


        /* for vxworks */
        sal_task_sleep(1);

    }

    /* can not find centec device */
    if (lchip_num == 0)
    {
        return DAL_E_DEV_NOT_FOUND;
    }
    return ret;
}

int32
dal_op_init(dal_op_t* p_dal_op)
{
    uint8 op_cnt = 0;
    uint8 index = 0;

    op_cnt = sizeof(dal_op_t)/4;

    /* if dal op is provided by user , using user defined */
    if (p_dal_op)
    {
        for (index = 0; index < op_cnt; index++)
        {
            if (*((uint32*)p_dal_op + index))
            {
                *((uint32*)&g_dal_op + index) = *((uint32*)p_dal_op + index);
            }
        }

        /*if pcie_base_addr is not NULL means need sdk init pcie resource, otherwise user init */
        if (p_dal_op->pcie_base_addr[0])
        {
            dal_init_pcie_resource(p_dal_op->pcie_base_addr);
        }
    }

    /* get pcie base address */
    dal_get_pci_membase();

    /* software init */
    sal_memset(&g_intr_para, 0, sizeof(dal_intr_para_t)*DAL_INTERRUPT_NUM);

    g_dal_init = 1;

    return DAL_E_NONE;
}

int32
dal_get_device_info(uint8 lchip, dal_pci_dev_t* pci_info)
{
    if (g_dal_init == 0)
    {
        return DAL_E_NOT_INIT;
    }

    if (pci_info == NULL)
    {
        return DAL_E_INVALID_PTR;
    }

    sal_memcpy(pci_info, &g_dal_pci_dev[lchip], sizeof(dal_pci_dev_t));

    return DAL_E_NONE;
}

int32
dal_get_pci_membase(void)
{
    uint32 venID = 0;
    uint32 devID = 0;
    uint32 revID = 0;
    dal_pci_dev_t dev;
    uint32 baroff = PCI_CONF_BAR0;
    uint8 lchip_num = 0;

    sal_memset(&dev, 0, sizeof(dal_pci_dev_t));

    for (dev.busNo = PCI_BUS_NO_START; dev.busNo < PCI_MAX_BUS; dev.busNo++)
    {

        for (dev.devNo = 0; dev.devNo < PCI_MAX_DEVICES; dev.devNo++)
        {
            pciConfigInLong(dev.busNo, dev.devNo, 0, PCI_CONF_VENDOR_ID, &venID);

            if (venID == 0xffff)
            {
                /*continue;*/
                break;
            }

             pciConfigInLong(dev.busNo, dev.devNo, 0, PCI_CONF_REVISION_ID, &revID);

            devID = venID >> 16;
            venID = (venID & 0xffff);

            if ((venID == CTC_VENDOR_VID) && (devID == CTC_GREATBELT_DEVICE_ID))
            {
                pciConfigInLong(dev.busNo, dev.devNo, 0, baroff, &g_mem_base[lchip_num]);
                sal_printf("@@@@@Find centec device : devno:%d, devno:%d, membase:0x%x \n", dev.busNo, dev.devNo, g_mem_base[lchip_num]);
                sal_memcpy(&g_dal_pci_dev[lchip_num], &dev, sizeof(dal_pci_dev_t));
                lchip_num++;
                if (lchip_num > DAL_MAX_CHIP_NUM)
                {
                    return -1;
                }
            }
        }

        /* for vxworks */
        sal_task_sleep(1);
    }

    if (lchip_num == 0)
    {
        /* Not find centec device */
        sal_printf("@@@@@Can not Find centec device \n");

        return DAL_E_DEV_NOT_FOUND;
    }

    return DAL_E_NONE;
}

/* set device access type, must be configured before dal_op_init */
int32
dal_set_device_access_type(dal_access_type_t device_type)
{
    if (device_type >= DAL_MAX_ACCESS_TYPE)
    {
        return DAL_E_INVALID_ACCESS;
    }

    g_dal_access = device_type;
    return 0;
}

/* get device access type */
int32
dal_get_device_access_type(dal_access_type_t* p_device_type)
{
    *p_device_type = g_dal_access;
    return 0;
}

/* convert logic address to physical, only using for DMA */
uintptr
dal_logic_to_phy(uint8 lchip, void* laddr)
{
    return (uintptr)laddr;
}

/* convert physical address to logical, only using for DMA */
void*
dal_phy_to_logic(uint8 lchip, uintptr paddr)
{
    return (void*)paddr;
}

/* alloc dma memory from memory pool*/
uint32*
dal_dma_alloc(uint8 lchip, int32 size, int32 type)
{
    lchip = lchip;
    type = type;

    return cacheDmaMalloc(size);
}

/*free memory to memory pool*/
void
dal_dma_free(uint8 lchip, void* ptr)
{
    lchip = lchip;
    cacheDmaFree(ptr);
    return;
}

/* this interface is compatible for humber access */
int32
dal_usrctrl_write_chip(uint8 lchip, uint32 offset, uint32 value)
{
    int32 ret = 0;

    if (g_dal_op.pci_write)
    {
        ret = g_dal_op.pci_write(lchip, offset, value);
        if (ret < 0)
        {
            sal_printf("dal_usrctrl_write_chip   write failed ,%d\n", ret);

            return ret;
        }
    }

    return 0;
}

/* this interface is compatible for humber access */
int32
dal_usrctrl_read_chip(uint8 lchip, uint32 offset, uint32 p_value)
{
    int32 ret = 0;

    if (g_dal_op.pci_read)
    {
        ret = g_dal_op.pci_read(lchip, offset, (uint32*)p_value);
        if (ret < 0)
        {
            sal_printf("dal_usrctrl_write_chip   write failed ,%d\n", ret);
            return ret;
        }
    }

    return 0;
}

/* pci read function */
int32
dal_pci_read(uint8 lchip, uint32 offset, uint32* value)
{

    DAL_DEBUG_OUT("reg_read 0x%x \n", offset);

    switch(g_dal_access)
    {
    case DAL_PCIE_MM:
        /* this mode is usual mode, for support mmap device access */
        *value = *(volatile uint32*)(g_mem_base[lchip] + offset);

        return 0;

    case DAL_PCI_IO:

        /* this mode is used for ioctrl, Humber will use */
        break;

    case DAL_SPECIAL_EMU:

        /* this mode is used for ioctrl,  Emulation will use */
        break;

    case DAL_SUPER_IF:

        /* this mode is special for some customer */
        return 0;

    default:
        return DAL_E_INVALID_ACCESS;
    }

    return 0;
}


/*pci write function */
int32
dal_pci_write(uint8 lchip, uint32 offset, uint32 value)
{

    DAL_DEBUG_OUT("reg_write 0x%x 0x%x \n", offset, value);
    switch (g_dal_access)
    {
    case DAL_PCIE_MM:
        /* this mode is usual mode, for support mmap device access */
        *(volatile uint32*)(g_mem_base[lchip] + offset) = value;
        return 0;

    case DAL_PCI_IO:
        /* this mode is used for ioctrl, Humber and Emulation will use */

        return 0;

    case DAL_SPECIAL_EMU:
        /* this mode is used for ioctrl, Humber and Emulation will use */
        return 0;

    case DAL_SUPER_IF:

        /* this mode is special for some customer */
        return 0;

    default:
        return DAL_E_INVALID_ACCESS;
    }

    return 0;
}


/* interface for read pci configuration space, usual using for debug */
int32
dal_pci_conf_read(uint8 lchip, uint32 offset, uint32* value)
{
    int32 ret = 0;

     ret = pciConfigInLong(g_dal_pci_dev[lchip].busNo, g_dal_pci_dev[lchip].devNo, g_dal_pci_dev[lchip].funNo, offset, value);

    return ret;
}

/* interface for write pci configuration space, usual using for debug */
int32
dal_pci_conf_write(uint8 lchip, uint32 offset, uint32 value)
{
    int32 ret = 0;

    ret = pciConfigOutLong(g_dal_pci_dev[lchip].busNo, g_dal_pci_dev[lchip].devNo, g_dal_pci_dev[lchip].funNo, offset, value);

    return ret;
}


/* create isr thread for sync, para is register interrupt index */
static void
_dal_isr_thread(void* param)
{
    int32 ret = 0;
    uint32 grp_index = (uint32)param;

    while (1)
    {
        ret = sal_sem_take(g_intr_para[grp_index].p_isr_sem, SAL_SEM_FOREVER);
        if (0 != ret)
        {
            continue;
        }

        /* interrupt dispatch */
        if (g_dal_isr_cb)
        {
           g_dal_isr_cb((void*)&grp_index);
        }
    }

    return;
}

/* control interrupt by fpga */
void
_dal_interrupt_disable(uint32 irq)
{
    intDisable(irq);

    return;
}

/* interrupt isr function, para is group id which passed by sdk code */
void
_dal_isr_function(void *data)
{
    uint32 para = (uint32)data;
    uint32 irq = 0;

    if (para >= DAL_INTERRUPT_NUM)
    {
        return;
    }

    irq = g_intr_para[para].irq;

    /* disable interrupt, intDisable have no effect why???? */
    _dal_interrupt_disable(irq);

    /* according interrupt line release sem */
    sal_sem_give(g_intr_para[para].p_isr_sem);

    return;
}

/* register interrupt dispatch function  */
void
_dal_register_isr_callback(DAL_ISR_CALLBACK_FUN_P isr)
{
    g_dal_isr_cb = isr;

    return;
}

/* control interrupt by fpga */
void
_dal_interrupt_enable(uint32 irq)
{

    intEnable(irq);

    return;
}

/* register interrupt */
int32
dal_interrupt_register(uint32 irq, int32 prio, void (* isr)(void*), void* data)
{
    int32 ret = 0;
    uint32 grp_idx = (uint32)data;

    if (grp_idx >= DAL_INTERRUPT_NUM)
    {
        sal_printf("register interrupt group id exceed!!%d \n", grp_idx);
        return DAL_E_EXCEED_MAX;
    }
  //-  logMsg(" dal_interrupt_register!!irq:%d,  data:%d\n", irq, grp_idx, 0,0,0,0);

    /* create sync sem for interrupt routing */
    ret = sal_sem_create(&g_intr_para[grp_idx].p_isr_sem, 0);
    if (ret < 0)
    {
        return ret;
    }

    /* create thread to sync sem */
    ret = sal_task_create(&g_intr_para[grp_idx].p_isr_thread, "ctcisrthread",
                          SAL_DEF_TASK_STACK_SIZE, prio, _dal_isr_thread, (void*)data);
    if (ret < 0)
    {
        return ret;
    }

    /* need modify according user hardware connect */
    g_intr_para[grp_idx].intr_line = irq;
    g_intr_para[grp_idx].irq = irq;

    /* register callback function for interrupt dispatch */
    _dal_register_isr_callback(isr);

    /* connect interrupt */
    if (intConnect((VOIDFUNCPTR *)(irq), (VOIDFUNCPTR)_dal_isr_function, (uint32) (data)))
    {
       //- logMsg("connect interrupt failed!! \n", 0, 0, 0,0,0,0);
        return -1;
    }

    /* enable interrupt */
    if (intEnable(irq ) != 0)
    {
       //- logMsg(" set interrupt enable failed!! \n", 0, 0, 0,0,0,0);
        return -1;
    }

    return ret;
}

int32
dal_interrupt_set_en(uint32 irq, uint32 enable)
{
    enable?_dal_interrupt_enable(irq):_dal_interrupt_disable(irq);

    return 0;
}

int32
dal_i2c_read(uint8 lchip, uint16 offset, uint8 len, uint8* buf)
{

    return DAL_E_NONE;
}

int32
dal_i2c_write(uint8 lchip, uint16 offset, uint8 len, uint8* buf)
{

    return DAL_E_NONE;
}

/* get dma information */
int32
dal_get_dma_info(void* p_info)
{
    return 0;
}

int32 dal_dma_debug_info(void)
{
    return 0;
}

