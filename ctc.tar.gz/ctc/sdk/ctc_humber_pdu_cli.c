/**
 @file ctc_humber_pdu_cli.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-1-11

 @version v2.0

This file contains pdu module cli command
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/

#include "sal.h"
#include "ctc_cli.h"

#include "ctc_api.h"
#include "ctc_pdu.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_humber_pdu_cli.h"
#include "ctc_port_mapping_cli.h"
#include "sys_humber_pdu.h"

CTC_CLI(ctc_cli_hb_pdu_show_port_action,
        ctc_cli_hb_pdu_show_port_action_cmd,
        "show pdu l2pdu port-action port GPORT-ID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PDU_STR,
        CTC_CLI_L2_PDU_STR,
        "L2pdu Port-ction type"
        "Port",
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = 0;
    uint16 gport = 0;

    CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = sys_humber_l2pdu_show_port_action(gport);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_hb_pdu_show_l3if_action,
        ctc_cli_hb_pdu_show_l3if_action_cmd,
        "show pdu l3pdu l3if-action l3if L3IFID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PDU_STR,
        CTC_CLI_L3_PDU_STR,
        "L3pdu l3if-action type",
        "Layer3 interface",
        "<0-1022>")
{
    uint16 l3ifid = 0;
    int32 ret = 0;

    CTC_CLI_GET_UINT16_RANGE("l3ifid", l3ifid, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = sys_humber_l3pdu_show_l3if_action(l3ifid);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_pdu_show_global_config,
        ctc_cli_hb_pdu_show_global_config_cmd,
        "show pdu (l2pdu|l3pdu) global-config",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PDU_STR,
        CTC_CLI_L2_PDU_STR,
        CTC_CLI_L3_PDU_STR,
        "Global configuration info")
{
    int32 ret = 0;

    if (0 == sal_memcmp("l2", argv[0], 2))
    {
        ret = sys_humber_pdu_show_l2pdu_cfg();
    }

    if (0 == sal_memcmp("l3", argv[0], 2))
    {
        ret = sys_humber_pdu_show_l3pdu_cfg();
    }

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_hb_pdu_show_excp_all,
        ctc_cli_hb_pdu_show_excp_all_cmd,
        "show pdu exception all",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PDU_STR,
        "Exception",
        "All")
{
    ctc_cli_out("Exception  0: Ingress Port Mirror Session 0\n");
    ctc_cli_out("Exception  1: Ingress Port Port Mirror Session 1\n");
    ctc_cli_out("Exception  2: Ingress Port Port Mirror Session 2\n");
    ctc_cli_out("Exception  3: Ingress Port Port Mirror Session 3\n");
    ctc_cli_out("Exception  4: Ingress Vlan Mirror Session 0\n");
    ctc_cli_out("Exception  5: Ingress Vlan Mirror Session 1\n");
    ctc_cli_out("Exception  6: Ingress Vlan Mirror Session 2\n");
    ctc_cli_out("Exception  7: Ingress Vlan Mirror Session 3\n");
    ctc_cli_out("Exception  8: Ingress ACL Mirror Session 0\n");
    ctc_cli_out("Exception  9: Ingress ACL Mirror Session 1\n");
    ctc_cli_out("Exception 10: Ingress ACL Mirror Session 2\n");
    ctc_cli_out("Exception 11: Ingress ACL Mirror Session 3\n");
    ctc_cli_out("Exception 12: Ingress QOS Mirror Session 0\n");
    ctc_cli_out("Exception 13: Ingress QOS Mirror Session 1\n");
    ctc_cli_out("Exception 14: Ingress QOS Mirror Session 2\n");
    ctc_cli_out("Exception 15: Ingress QOS Mirror Session 3\n");
    ctc_cli_out("Exception 16: Engress Port Mirror Session 0\n");
    ctc_cli_out("Exception 17: Engress Port Mirror Session 1\n");
    ctc_cli_out("Exception 18: Engress Port Mirror Session 2\n");
    ctc_cli_out("Exception 19: Engress Port Mirror Session 3\n");
    ctc_cli_out("Exception 20: Engress Vlan Mirror Session 0\n");
    ctc_cli_out("Exception 21: Engress Vlan Mirror Session 1\n");
    ctc_cli_out("Exception 22: Engress Vlan Mirror Session 2\n");
    ctc_cli_out("Exception 23: Engress Vlan Mirror Session 3\n");
    ctc_cli_out("Exception 24: Engress ACL Mirror Session 0\n");
    ctc_cli_out("Exception 25: Engress ACL Mirror Session 1\n");
    ctc_cli_out("Exception 26: Engress ACL Mirror Session 2\n");
    ctc_cli_out("Exception 27: Engress ACL Mirror Session 3\n");
    ctc_cli_out("Exception 28: Engress QOS Mirror Session 0\n");
    ctc_cli_out("Exception 29: Engress QOS Mirror Session 1\n");
    ctc_cli_out("Exception 30: Engress QOS Mirror Session 2\n");
    ctc_cli_out("Exception 31: Engress QOS Mirror Session 3\n");
    ctc_cli_out("Exception 32: UserId Exception\n");
    ctc_cli_out("Exception 33: Protocol Vlan Exception. May not be used\n");


    ctc_cli_out("Exception 36: ICMP Redirect Exception\n");
    ctc_cli_out("Exception 37: Mac Learning Exception in case of learning cache full\n");
    ctc_cli_out("Exception 38: IP Multicast RPF Check Fail Exception\n");
    ctc_cli_out("Exception 39: Port Security Violation Exception.\n");
    ctc_cli_out("    Sub Exception 00: Mac Blacklist Violation\n");
    ctc_cli_out("    Sub Exception 01: Mac/Port Binding Violation\n");
    ctc_cli_out("    Sub Exception 02: Port Max Mac Limit Violation\n");
    ctc_cli_out("    Sub Exception 03: Vlan Max Mac Limit Violation\n");
    ctc_cli_out("    Sub Exception 04: Storm Control Violation\n");

    ctc_cli_out("Exception 40: IP routing MTU Check Fail Exception and IP DF bit is set\n");
    ctc_cli_out("Exception 41: IP routing MTU Check Fail Exception and IP DF bit isn't set\n");
    ctc_cli_out("Exception 42: Output TTL becomes 0\n");
    ctc_cli_out("Exception 43: IP Multicast Output TTL isn't bigger than configured TTL threshold\n");
    ctc_cli_out("Exception 44: Reserved\n");
    ctc_cli_out("Exception 45: IP/MPLS Tunnel MTU Check Fail Exception and  IP DF bit is set if it's IP packet\n");
    ctc_cli_out("Exception 46: IP/MPLS Tunnel MTU Check Fail Exception and IP DF bit isn't set or it's MPLS packet\n");
    ctc_cli_out("Exception 47: BFD packet's UDP dest port matches the configured port\n");

    ctc_cli_out("Exception 48: Ingress Port Based Random Log\n");
    ctc_cli_out("Exception 49: Ingress GRE Sequence Number Check Fail\n");
    ctc_cli_out("Exception 50: Ingress MISC Exception\n");
    ctc_cli_out("    Sub Exception 00: PTP Packet Exception\n");
    ctc_cli_out("    Sub Exception 01: Reseved\n");
    ctc_cli_out("    Sub Exception 02: PBB NCA Check Fail\n");
    ctc_cli_out("    Sub Exception 03: Length Parse Error\n");
    ctc_cli_out("    Sub Exception 04: Reserved\n");
    ctc_cli_out("    Sub Exception 05: Internal Payload Offset Error\n");
    ctc_cli_out("    Sub Exception 06: Reserved\n");

    ctc_cli_out("Exception 51: Ingress OAM Exception\n");
    ctc_cli_out("Exception 52: Egress Port Based Random Log\n");
    ctc_cli_out("Exception 53: Egress GRE Sequence Number Check Fail\n");
    ctc_cli_out("Exception 54: Egress MISC Exception\n");
    ctc_cli_out("    Sub Exception 00: Reserved\n");
    ctc_cli_out("    Sub Exception 01: Reserved\n");
    ctc_cli_out("    Sub Exception 02: Reserved\n");
    ctc_cli_out("    Sub Exception 03: Length Parse Error\n");
    ctc_cli_out("Exception 55: Egress OAM Exception\n");

    ctc_cli_out("Exception 56: Fatal Interrupt 00 - Unicast IP Header Error or IP Martian Address Check Fail\n");
    ctc_cli_out("Exception 57: Fatal Interrupt 01 - Unicast IP Option Present\n");
    ctc_cli_out("Exception 58: Fatal Interrupt 02 - Unicast GRE Unknown Option Present\n");
    ctc_cli_out("Exception 59: Fatal Interrupt 03 - Unicast ISATAP Source Address Check Fail\n");
    ctc_cli_out("Exception 60: Fatal Interrupt 04 - Unicast IP TTL Check Fail\n");
    ctc_cli_out("Exception 61: Fatal Interrupt 05 - Unicast RPF Check Fail\n");
    ctc_cli_out("Exception 62: Fatal Interrupt 06 - Unicast Or Multicast More RPF Check Required\n");
    ctc_cli_out("Exception 63: Fatal Interrupt 07 - Unicast Link Id Check Fail\n");
    ctc_cli_out("Exception 64: Fatal Interrupt 08 - MPLS Label Out Of Range\n");
    ctc_cli_out("Exception 65: Fatal Interrupt 09 - MPLS Sbit Error\n");
    ctc_cli_out("Exception 66: Fatal Interrupt 10 - MPLS TTL Check Fail\n");
    ctc_cli_out("Exception 67: Fatal Interrupt 11 - Reserved\n");
    ctc_cli_out("Exception 68: Fatal Interrupt 12 - IGMP Packet\n");
    ctc_cli_out("Exception 69: Fatal Interrupt 13 - Reserved\n");
    ctc_cli_out("Exception 70: Fatal Interrupt 14 - Reserved\n");
    ctc_cli_out("Exception 71: Fatal Interrupt 15 - Reserved\n");

    return CLI_SUCCESS;
}


int32
ctc_humber_pdu_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_hb_pdu_show_port_action_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_pdu_show_l3if_action_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_pdu_show_global_config_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_hb_pdu_show_excp_all_cmd);

    return CLI_SUCCESS;

}

