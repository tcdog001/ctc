/**
 @file ctc_ipfix_cli.c

 @author  Copyright (C) 2013 Centec Networks Inc.  All rights reserved.

 @date 2013-10-24

 @version v3.0

 The file apply clis of ipfix module
*/

#include "ctc_api.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_ipfix_cli.h"

/********************** Field Select *******************/
#define CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "(gport |logic-port |metadata)"

#define CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC \
"gport",\
"logic-port",\
"metadata"


#define CTC_CLI_IPFIX_HASH_FIELD_MAC_KEY_STR  \
    "{"CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "| mac-da | mac-sa | eth-type | vlan | cos | cfi }"

#define CTC_CLI_IPFIX_HASH_FIELD_MAC_KEY_DESC  \
  CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC,\
  CTC_CLI_MACDA_DESC,\
  CTC_CLI_MACSA_DESC,\
  CTC_CLI_ETHTYPE_DESC,\
  CTC_CLI_VLAN_DESC,\
  "Cos",\
  "CFI"

int32 _ctc_cli_ipfix_parser_mac_hash_field_sel(unsigned char argc,char** argv, ctc_ipfix_hash_mac_field_sel_t *mac_field)
{
    uint8 index = 0;
    uint8 start_index = 0;
    start_index = CTC_CLI_GET_ARGC_INDEX("mac-key");

    index = CTC_CLI_GET_SPECIFIC_INDEX("gport",start_index);
    if(index != 0xFF)
    {
        mac_field->gport= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("logic-port",start_index);
    if(index != 0xFF)
    {
        mac_field->logic_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("metadata",start_index);
    if(index != 0xFF)
    {
        mac_field->metadata= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mac-da",start_index);
    if(index != 0xFF)
    {
        mac_field->mac_da = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mac-sa",start_index);
    if(index != 0xFF)
    {
        mac_field->mac_sa = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("eth-type",start_index);
    if(index != 0xFF)
    {
        mac_field->eth_type= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("vlan",start_index);
    if(index != 0xFF)
    {
        mac_field->vlan_id= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("cfi",start_index);
    if(index != 0xFF)
    {
        mac_field->cfi= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("cos",start_index);
    if(index != 0xFF)
    {
        mac_field->cos= 1;
    }
//    index = CTC_CLI_GET_SPECIFIC_INDEX("vni",start_index);
//    if(index != 0xFF)
//    {
//       mac_field->vni= 1;
//    }

//    index = CTC_CLI_GET_SPECIFIC_INDEX("vlan-valid",start_index);
//    if(index != 0xFF)
//    {
//       mac_field->vlan_valid = 1;
//    }

    return CLI_SUCCESS;
}

#define CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR \
    "label-num | \
     mpls0-label | mpls0-s | mpls0-exp | mpls0-ttl | \
     mpls1-label | mpls1-s | mpls1-exp | mpls1-ttl | \
     mpls2-label | mpls2-s | mpls2-exp | mpls2-ttl"

#define CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR_DESC \
 "label-num",\
 "mpls0-label",\
 "mpls0-s",\
 "mpls0-exp",\
 "mpls0-ttl",\
 "mpls1-label",\
 "mpls1-s",\
 "mpls1-exp",\
 "mpls1-ttl",\
 "mpls2-label",\
 "mpls2-s",\
 "mpls2-exp",\
 "mpls2-ttl"

#define CTC_CLI_IPFIX_HASH_FIELD_MPLS_KEY_STR \
    "{"CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "|"CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR"}"

#define CTC_CLI_IPFIX_HASH_FIELD_MPLS_KEY_STR_DESC \
    CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC,\
    CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR_DESC


int32 _ctc_cli_ipfix_parser_mpls_hash_field_sel(unsigned char argc,char** argv, ctc_ipfix_hash_mpls_field_sel_t *mpls_field)
{
    uint8 index = 0;
    uint8 start_index = 0;
    start_index = CTC_CLI_GET_ARGC_INDEX("mpls-key");

    index = CTC_CLI_GET_SPECIFIC_INDEX("gport",start_index);
    if(index != 0xFF)
       {
          mpls_field->gport= 1;
       }
    index = CTC_CLI_GET_SPECIFIC_INDEX("logic-port",start_index);
    if(index != 0xFF)
       {
          mpls_field->logic_port= 1;
       }
    index = CTC_CLI_GET_SPECIFIC_INDEX("metadata",start_index);
    if(index != 0xFF)
       {
          mpls_field->metadata= 1;
       }

    index = CTC_CLI_GET_SPECIFIC_INDEX("label-num",start_index);
    if(index != 0xFF)
       {
          mpls_field->label_num= 1;
       }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-label",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label0_label = 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-s",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label0_s= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-exp",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label0_exp= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-ttl",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label0_ttl = 1;
       }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-label",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label1_label = 1;
       }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-s",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label1_s= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-exp",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label1_exp= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-ttl",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label1_ttl = 1;
       }
        index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-label",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label2_label = 1;
       }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-s",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label2_s= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-exp",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label2_exp= 1;
       }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-ttl",start_index);
    if(index != 0xFF)
       {
          mpls_field->mpls_label2_ttl = 1;
       }

    return CLI_SUCCESS;
}
#define CTC_CLI_IPFIX_HASH_FIELD_L4_STR \
"l4-src-port | l4-dst-port |icmp-type | icmp-code"

#define CTC_CLI_IPFIX_HASH_FIELD_L4_STR_DESC \
"l4-src-port",\
"l4-dst-port",\
"icmp-type ",\
"icmp-code"

#define CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR \
"ip-sa mask-len LEN| ip-da mask-len LEN| dscp |" CTC_CLI_IPFIX_HASH_FIELD_L4_STR

#define CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR_DESC \
"ip-sa",\
"mask-len",\
"mask len value<1-32>",\
"ip-da",\
"mask-len",\
"mask len value<1-32>",\
"dscp",\
CTC_CLI_IPFIX_HASH_FIELD_L4_STR_DESC

#define CTC_CLI_IPFIX_HASH_FIELD_IPV4_KEY_STR \
    "{" CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "|"CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR"|gre-key|ip-protocol|vni|l4-sub-type }"

#define CTC_CLI_IPFIX_HASH_FIELD_IPV4_KEY_STR_DESC \
   CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC, \
   CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR_DESC,\
   "gre-key",\
   "ip-protocol",\
   "vni",\
   "l4-sub-type"

int32 _ctc_cli_ipfix_parser_ipv4_hash_field_sel(unsigned char argc,char** argv, ctc_ipfix_hash_ipv4_field_sel_t *ipv4_field)
{
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint8 start_index = 0;
    start_index = CTC_CLI_GET_ARGC_INDEX("ipv4-key");

    index = CTC_CLI_GET_SPECIFIC_INDEX("gport",start_index);
    if(index != 0xFF)
    {
        ipv4_field->gport= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("logic-port",start_index);
    if(index != 0xFF)
    {
        ipv4_field->logic_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("metadata",start_index);
    if(index != 0xFF)
    {
        ipv4_field->metadata= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-da",start_index);
    if(index != 0xFF)
    {
        ipv4_field->ip_da= 1;
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        ipv4_field->ip_da_mask = mask_len;

    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-sa",start_index);
    if(index != 0xFF)
    {
        ipv4_field->ip_sa = 1;
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        ipv4_field->ip_sa_mask = mask_len;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("dscp",start_index);
    if(index != 0xFF)
    {
        ipv4_field->dscp = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-src-port",start_index);
    if(index != 0xFF)
    {
        ipv4_field->l4_src_port= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-dst-port",start_index);
    if(index != 0xFF)
    {
        ipv4_field->l4_dst_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-type",start_index);
    if(index != 0xFF)
    {
        ipv4_field->icmp_type= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-code",start_index);
    if(index != 0xFF)
    {
        ipv4_field->icmp_code= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("gre-key",start_index);
    if(index != 0xFF)
    {
        ipv4_field->gre_key= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-protocol",start_index);
    if(index != 0xFF)
    {
        ipv4_field->ip_protocol= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-sub-type",start_index);
    if(index != 0xFF)
    {
        ipv4_field->l4_sub_type = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("vni",start_index);
    if(index != 0xFF)
    {
        ipv4_field->vxlan_vni= 1;
    }

    return CLI_SUCCESS;
}

#define CTC_CLI_IPFIX_HASH_FIELD_IPV6_KEY_STR \
"{" CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "|ip-sa mask-len LEN|ip-da mask-len LEN |l4-type|l4-sub-type|flow-label|dscp|gre-key |vxlan-vni|" CTC_CLI_IPFIX_HASH_FIELD_L4_STR " }"

#define CTC_CLI_IPFIX_HASH_FIELD_IPV6_KEY_STR_DESC \
    CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC,\
    "ip-sa",\
    "mask-len",\
    "mask len value<4,8,12,...,128>",\
    "ip-da",\
    "mask-len",\
    "mask len value<4,8,12,...,128>",\
    "l4-type",\
    "l4-sub-type",\
    "flow-label",\
    "dscp",\
    "gre-key",\
    "vxlan-vni",\
    ""CTC_CLI_IPFIX_HASH_FIELD_L4_STR_DESC

int32 _ctc_cli_ipfix_parser_ipv6_hash_field_sel(unsigned char argc,char** argv, ctc_ipfix_hash_ipv6_field_sel_t *ipv6_field)
{
    uint8 index = 0;
    uint8 start_index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;

    start_index = CTC_CLI_GET_ARGC_INDEX("ipv6-key");

    index = CTC_CLI_GET_SPECIFIC_INDEX("gport",start_index);
    if(index != 0xFF)
    {
        ipv6_field->gport= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("logic-port",start_index);
    if(index != 0xFF)
    {
        ipv6_field->logic_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("metadata",start_index);
    if(index != 0xFF)
    {
        ipv6_field->metadata= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-da",start_index);
    if(index != 0xFF)
    {
        ipv6_field->ip_da= 1;
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);

        ipv6_field->ip_da_mask = mask_len;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-sa",start_index);
    if(index != 0xFF)
    {
        ipv6_field->ip_sa = 1;
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);

        ipv6_field->ip_sa_mask = mask_len;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("dscp",start_index);
    if(index != 0xFF)
    {
        ipv6_field->dscp = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("gre-key",start_index);
    if(index != 0xFF)
    {
        ipv6_field->gre_key = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("vxlan-vni",start_index);
    if(index != 0xFF)
    {
        ipv6_field->vxlan_vni= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-type",start_index);
    if(index != 0xFF)
    {
        ipv6_field->l4_type= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-sub-type",start_index);
    if(index != 0xFF)
    {
        ipv6_field->l4_sub_type = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("flow-label",start_index);
    if(index != 0xFF)
    {
        ipv6_field->flow_label= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-dst-port",start_index);
    if(index != 0xFF)
    {
        ipv6_field->l4_dst_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-src-port",start_index);
    if(index != 0xFF)
    {
        ipv6_field->l4_src_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-type",start_index);
    if(index != 0xFF)
    {
        ipv6_field->icmp_type= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-code",start_index);
    if(index != 0xFF)
    {
        ipv6_field->icmp_code= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("gre-key",start_index);
    if(index != 0xFF)
    {
        ipv6_field->gre_key= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("vni",start_index);
    if(index != 0xFF)
    {
        ipv6_field->vxlan_vni= 1;
    }

    return CLI_SUCCESS;
}
#define CTC_CLI_IPFIX_HASH_FIELD_L2_L3_KEY_STR \
    "{"CTC_CLI_IPFIX_HASH_FIELD_PORT_STR "|mac-da | mac-sa |eth-type | cvlan | ctag-cos | ctag-cfi |" \
    "svlan | stag-cos | stag-cfi | l4-type|l4-sub-type |" \
    CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR "|ecn | gre-key|vni|ttl|vrfid| " \
    CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR "}"


#define CTC_CLI_IPFIX_HASH_FIELD_L2_L3_KEY_STR_DESC \
    CTC_CLI_IPFIX_HASH_FIELD_PORT_STR_DESC,\
    CTC_CLI_MACDA_DESC,\
    CTC_CLI_MACSA_DESC,\
    "eth-type",\
    "cvlan",\
    "ctag-cos",\
    "ctag-cfi",\
    "svlan",\
    "stag-cos",\
    "stag-cfi",\
    "l4-type",\
    "l4-sub-type",\
    CTC_CLI_IPFIX_HASH_FIELD_IPV4_STR_DESC,\
    "ecn",\
    "gre-key",\
    "vni",\
    "ttl",\
    "vrfid",\
     CTC_CLI_IPFIX_HASH_FIELD_MPLS_STR_DESC

int32 _ctc_cli_ipfix_parser_l2l3_hash_field_sel(uint8 argc,char** argv, ctc_ipfix_hash_l2_l3_field_sel_t *merge_field)
{
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint8 start_index = 0;
    start_index = CTC_CLI_GET_ARGC_INDEX("l2l3-key");

    index = CTC_CLI_GET_SPECIFIC_INDEX("gport",start_index);
    if(index != 0xFF)
    {
        merge_field->gport= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("logic-port",start_index);
    if(index != 0xFF)
    {
        merge_field->logic_port= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("metadata",start_index);
    if(index != 0xFF)
    {
        merge_field->metadata= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mac-da",start_index);
    if(index != 0xFF)
    {
        merge_field->mac_da = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mac-sa",start_index);
    if(index != 0xFF)
    {
        merge_field->mac_sa = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("eth-type",start_index);
    if(index != 0xFF)
    {
        merge_field->eth_type= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("cvlan",start_index);
    if(index != 0xFF)
    {
        merge_field->ctag_vlan= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ctag-cfi",start_index);
    if(index != 0xFF)
    {
        merge_field->ctag_cfi= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ctag-cos",start_index);
    if(index != 0xFF)
    {
        merge_field->ctag_cos= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("svlan",start_index);
    if(index != 0xFF)
    {
        merge_field->stag_vlan= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("stag-cfi",start_index);
    if(index != 0xFF)
    {
        merge_field->stag_cfi= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("stag-cos",start_index);
    if(index != 0xFF)
    {
        merge_field->stag_cos= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-type",start_index);
    if(index != 0xFF)
    {
        merge_field->l4_type= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-sub-type",start_index);
    if(index != 0xFF)
    {
        merge_field->l4_sub_type = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-da",start_index);
    if(index != 0xFF)
    {
        merge_field->ip_da= 1;

        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        merge_field->ip_da_mask = mask_len;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("ip-sa",start_index);
    if(index != 0xFF)
    {
        merge_field->ip_sa = 1;
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        merge_field->ip_sa_mask = mask_len;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("dscp",start_index);
    if(index != 0xFF)
    {
        merge_field->dscp = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-src-port",start_index);
    if(index != 0xFF)
    {
        merge_field->l4_src_port= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("l4-dst-port",start_index);
    if(index != 0xFF)
    {
        merge_field->l4_dst_port= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-type",start_index);
    if(index != 0xFF)
    {
        merge_field->icmp_type= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("icmp-code",start_index);
    if(index != 0xFF)
    {
        merge_field->icmp_code= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("ecn",start_index);
    if(index != 0xFF)
    {
        merge_field->ecn= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("gre-key",start_index);
    if(index != 0xFF)
    {
        merge_field->gre_key= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("vni",start_index);
    if(index != 0xFF)
    {
        merge_field->vxlan_vni= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("ttl",start_index);
    if(index != 0xFF)
    {
        merge_field->ttl= 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("vrfid",start_index);
    if(index != 0xFF)
    {
        merge_field->vrfid = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("label-num",start_index);
    if(index != 0xFF)
    {
        merge_field->label_num= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-label",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label0_label = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-s",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label0_s= 1;
    }


    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-exp",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label0_exp= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls0-ttl",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label0_ttl = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-label",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label1_label = 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-s",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label1_s= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-exp",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label1_exp= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls1-ttl",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label1_ttl = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-label",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label2_label = 1;
    }
    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-s",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label2_s= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-exp",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label2_exp= 1;
    }

    index = CTC_CLI_GET_SPECIFIC_INDEX("mpls2-ttl",start_index);
    if(index != 0xFF)
    {
        merge_field->mpls_label2_ttl = 1;
    }

    return CLI_SUCCESS;
}


#define CTC_CLI_IPFIX_HASH_FIELD_KEY_STR  \
    "(mac-key" CTC_CLI_IPFIX_HASH_FIELD_MAC_KEY_STR \
    "|ipv4-key" CTC_CLI_IPFIX_HASH_FIELD_IPV4_KEY_STR \
    "|ipv6-key" CTC_CLI_IPFIX_HASH_FIELD_IPV6_KEY_STR \
    "|mpls-key" CTC_CLI_IPFIX_HASH_FIELD_MPLS_KEY_STR \
    "|l2l3-key" CTC_CLI_IPFIX_HASH_FIELD_L2_L3_KEY_STR")"

#define CTC_CLI_IPFIX_HASH_FIELD_KEY_STR_DESC  \
    "mac-key", CTC_CLI_IPFIX_HASH_FIELD_MAC_KEY_DESC,\
    "ipv4-key", CTC_CLI_IPFIX_HASH_FIELD_IPV4_KEY_STR_DESC,\
    "ipv6-key", CTC_CLI_IPFIX_HASH_FIELD_IPV6_KEY_STR_DESC,\
    "mpls-key", CTC_CLI_IPFIX_HASH_FIELD_MPLS_KEY_STR_DESC,\
    "l2l3-key", CTC_CLI_IPFIX_HASH_FIELD_L2_L3_KEY_STR_DESC


int32 _ctc_cli_ipfix_parser_mpls_key(unsigned char argc,char** argv, ctc_ipfix_data_t *data)
{
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("label-num");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("label-num", data->l3_info.mpls.label_num, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls0-label");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("label", data->l3_info.mpls.label[0].label, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls0-s");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("label", data->l3_info.mpls.label[0].sbit, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls0-exp");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("label", data->l3_info.mpls.label[0].exp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls0-ttl");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("label", data->l3_info.mpls.label[0].ttl, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls1-label");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("label", data->l3_info.mpls.label[1].label, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls1-s");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("sbit", data->l3_info.mpls.label[1].sbit, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls1-exp");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("exp", data->l3_info.mpls.label[1].exp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls1-ttl");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ttl", data->l3_info.mpls.label[1].ttl, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls2-label");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("label", data->l3_info.mpls.label[2].label, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls2-s");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("sbit", data->l3_info.mpls.label[2].sbit, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls2-exp");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("exp", data->l3_info.mpls.label[2].exp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mpls2-ttl");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ttl", data->l3_info.mpls.label[2].ttl, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }
    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_ipfix_set_hash_field_sel,
         ctc_cli_ipfix_set_hash_field_sel_cmd,
         "ipfix hash-field-sel FIELD_ID" CTC_CLI_IPFIX_HASH_FIELD_KEY_STR,
         CTC_CLI_IPFIX_M_STR,
         CTC_CLI_FIELD_SEL_ID_DESC,
         CTC_CLI_FIELD_SEL_ID_VALUE,
         CTC_CLI_IPFIX_HASH_FIELD_KEY_STR_DESC
         )
{
    ctc_ipfix_hash_field_sel_t field;
    uint8 start_index = 0;
    int32 ret = 0;

    sal_memset(&field, 0, sizeof(ctc_ipfix_hash_field_sel_t));

    CTC_CLI_GET_UINT8("hash-field-sel",field.field_sel_id, argv[0]);

    start_index = CTC_CLI_GET_ARGC_INDEX("mac-key");
    if (start_index != 0xFF)
    {
        _ctc_cli_ipfix_parser_mac_hash_field_sel(argc, &argv[0],&field.u.mac);
        field.key_type = CTC_IPFIX_KEY_HASH_MAC;
    }
    start_index = CTC_CLI_GET_ARGC_INDEX("ipv4-key");
    if (start_index != 0xFF)
    {
        _ctc_cli_ipfix_parser_ipv4_hash_field_sel(argc, &argv[0], &field.u.ipv4);
        field.key_type = CTC_IPFIX_KEY_HASH_IPV4;
    }
    start_index = CTC_CLI_GET_ARGC_INDEX("ipv6-key");
    if (start_index != 0xFF)
    {
        _ctc_cli_ipfix_parser_ipv6_hash_field_sel(argc, &argv[0], &field.u.ipv6);
        field.key_type = CTC_IPFIX_KEY_HASH_IPV6;
    }
    start_index = CTC_CLI_GET_ARGC_INDEX("mpls-key");
    if (start_index != 0xFF)
    {
        _ctc_cli_ipfix_parser_mpls_hash_field_sel(argc, &argv[0], &field.u.mpls);
        field.key_type = CTC_IPFIX_KEY_HASH_MPLS;
    }
    start_index = CTC_CLI_GET_ARGC_INDEX("l2l3-key");
    if (start_index != 0xFF)
    {
        _ctc_cli_ipfix_parser_l2l3_hash_field_sel(argc, &argv[0], &field.u.l2_l3);
        field.key_type = CTC_IPFIX_KEY_HASH_L2_L3;
    }
    ret = ctc_ipfix_set_hash_field_sel(&field);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return 0;
}

CTC_CLI(ctc_cli_ipfix_set_port_cfg,
        ctc_cli_ipfix_set_port_cfg_cmd,
        "ipfix port GPHYPORT_ID (ingress|egress) {lkup-type TYPE|field-sel-id ID|sampling-interval INTERVAL|tcpend-detect-dis VALUE | flow-type TYPE|learn-disable VALUE}",
         CTC_CLI_IPFIX_M_STR,
         CTC_CLI_PORT_M_STR,
         CTC_CLI_GPHYPORT_ID_DESC,
          "Ingress",
          "Egress",
          "Lookup packet type",
          "0-Disable;1-Only L2 Field;2-Only L3 Field; 3 - L2+ L3 Field",
          CTC_CLI_FIELD_SEL_ID_DESC,
          CTC_CLI_FIELD_SEL_ID_VALUE,
          "Sampling interval(packet cnt)",
          CTC_CLI_UINT32_VAR_STR,
          "TCP End Detect",
          CTC_CLI_BOOL_VAR_STR,
          "IPFix aim to flow packet Type",
          "0-all packet;1-non-discard packet;2-discard packet",
          "Learn disable",
          "Disable learn new flow based port")
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 index = 0;
    ctc_ipfix_port_cfg_t port_cfg;

    sal_memset(&port_cfg, 0, sizeof(port_cfg));

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if(index != 0xFF)
    {
        port_cfg.dir = CTC_INGRESS;
    }
    else
    {
        port_cfg.dir = CTC_EGRESS;
    }

    ret = ctc_ipfix_get_port_cfg(gport,&port_cfg);

    index = CTC_CLI_GET_ARGC_INDEX("lkup-type");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("lkup-type", port_cfg.lkup_type, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("field-sel-id");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("field-sel-id", port_cfg.field_sel_id, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("tcpend-detect-dis");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("tcpend-detect", port_cfg.tcp_end_detect_disable, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("learn-disable");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("learn-disable", port_cfg.learn_disable, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("sampling-interval");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT16("sampling-interval", port_cfg.sample_interval, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("flow-type");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("flow-type", port_cfg.flow_type, argv[index+1]);
    }

    ret = ctc_ipfix_set_port_cfg(gport,&port_cfg);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}


CTC_CLI(ctc_cli_ipfix_set_global_cfg,
         ctc_cli_ipfix_set_global_cfg_cmd,
         "ipfix global {aging-interval INTERVAL|conflict-export VALUE"\
         "|packet-cnt VALUE|bytes-cnt VALUE|time-interval VALUE|sample-mode VALUE|tcp-detect-en VALUE"\
         "|rpf-check-en VALUE| vxlan-extern VALUE|nvgre-extern VALUE|sw-learning VALUE|new-flow-export-en VALUE|unkown-pkt-dest-type VALUE}",
         CTC_CLI_IPFIX_M_STR,
         "Global config",
         "Aging Interval",
         "Interval time(s)",
         "conflict-export",
         CTC_CLI_BOOL_VAR_STR,
         "Number of packets to be export",
         "<1-0xFFFFFFFF>",
         "Size of bytes to be export",
         "Bytes VALUE",
         "Number of time interval to be export",
         "Time interval VALUE",
         "Sample mode",
         "0-all packets;1-unkown packet",
         "Tcp end detect enable",
         "0-disable, 1-enable",
         "RPF check",
         "0-disable, 1-enable",
         "vxlan extern",
         "0-disable, 1-enable",
         "nvgre extern",
         "0-disable, 1-enable",
         "Sw learning",
         "0-disable, 1-enable",
         "new flow export",
         "0-do not export to CPU, 1-export to CPU using DMA",
         "unkown pkt dest type",
         "0:using group id, 1:using vlan id")
{


    ctc_ipfix_global_cfg_t ipfix_cfg;
    int32 ret = 0;
    uint8 index = 0;
    uint64 byte_cnt = 0;

    sal_memset(&ipfix_cfg, 0, sizeof(ctc_ipfix_global_cfg_t));
    ret = ctc_ipfix_get_global_cfg(&ipfix_cfg);

    index = CTC_CLI_GET_ARGC_INDEX("aging-interval");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT32("aging-interval", ipfix_cfg.aging_interval, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("conflict-export");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("conflict-export", ipfix_cfg.conflict_export, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("packet-cnt");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT32("packet-cnt", ipfix_cfg.pkt_cnt, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("bytes-cnt");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT64("bytes-cnt", byte_cnt, argv[index+1]);
       ipfix_cfg.bytes_cnt = byte_cnt;
    }

    index = CTC_CLI_GET_ARGC_INDEX("time-interval");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT32("time-interval", ipfix_cfg.times_interval, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("sample-mode");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("sample-mode", ipfix_cfg.sample_mode, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tcp-detect-en");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("tcp-detect-en", ipfix_cfg.tcp_end_detect_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("rpf-check-en");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8("rpf-check-en", ipfix_cfg.rpf_check_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vxlan-extern");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("vxlan-extern", ipfix_cfg.vxlan_extern_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("nvgre-extern");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("nvgre-extern", ipfix_cfg.nvgre_extern_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("sw-learning");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("sw-learning", ipfix_cfg.sw_learning_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("new-flow-export-en");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("new-flow-export-en", ipfix_cfg.new_flow_export_en, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("unkown-pkt-dest-type");
    if(index != 0xFF)
    {
       CTC_CLI_GET_UINT8("unkown-pkt-dest-type", ipfix_cfg.unkown_pkt_dest_type, argv[index+1]);
    }

    ret = ctc_ipfix_set_global_cfg(&ipfix_cfg);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return 0;
}

CTC_CLI(ctc_cli_ipfix_debug_on,
        ctc_cli_ipfix_debug_on_cmd,
        "debug ipfix (ctc|sys) (debug-level {func|param|info|error|export} |) (log LOG_FILE |)",
        CTC_CLI_DEBUG_STR,
        "Ipfix module",
        "CTC layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR,
        CTC_CLI_DEBUG_LEVEL_EXPORT,
        CTC_CLI_DEBUG_MODE_LOG,
        CTC_CLI_LOG_FILE)
{

    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR|CTC_DEBUG_LEVEL_EXPORT;
    uint8 index = 0;
    char file[MAX_FILE_NAME_SIZE];

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }

        index = CTC_CLI_GET_ARGC_INDEX("export");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_EXPORT;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("log");
    if (index != 0xFF)
    {
        sal_strcpy((char*)&file, argv[index + 1]);
        level |= CTC_DEBUG_LEVEL_LOGFILE;
        ctc_debug_set_log_file("ipfix", "ipfix", (void*)&file, 1);
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPFIX_CTC;
    }
    else
    {
        typeenum = IPFIX_SYS;

    }

    ctc_debug_set_flag("ipfix", "ipfix", typeenum, level, TRUE);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_debug_off,
        ctc_cli_ipfix_debug_off_cmd,
        "no debug ipfix (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        "Ipfix Module",
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPFIX_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = IPFIX_SYS;
    }

    ctc_debug_set_flag("ipfix", "ipfix", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_show_debug,
        ctc_cli_ipfix_show_debug_cmd,
        "show debug ipfix (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        "Ipfix Module",
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPFIX_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = IPFIX_SYS;
    }

    ctc_cli_out("Ipfix:%s debug %s level:%s\n", argv[0],
                (ctc_debug_get_flag("ipfix", "ipfix", typeenum, &level) == TRUE) ? "on" : "off", ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_show_port_cfg,
        ctc_cli_ipfix_show_port_cfg_cmd,
        "show ipfix port-cfg GPHYPORT_ID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPFIX_M_STR,
        "port config for ipfix",
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = 0;
    uint16 gport = 0;
    uint8 cnt = 0;
    ctc_ipfix_port_cfg_t ipfix_cfg;

    sal_memset(&ipfix_cfg, 0, sizeof(ctc_ipfix_port_cfg_t));

    CTC_CLI_GET_UINT16("gport", gport, argv[0]);

    ctc_cli_out("\n");
    for(cnt = 0; cnt < 2; cnt++)
    {
        ipfix_cfg.dir = cnt;

        ret = ctc_ipfix_get_port_cfg(gport, &ipfix_cfg);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return ret;
        }

        ctc_cli_out("%s\n", (ipfix_cfg.dir)?"Egress Direction Config":"Ingress Direction Config" );
        ctc_cli_out("%-25s: %d\n", "Field Select Id", ipfix_cfg.field_sel_id);
        ctc_cli_out("%-25s: %s\n", "Lookup Type", (ipfix_cfg.lkup_type==0)?"Disable":
            ((ipfix_cfg.lkup_type==1)?"L2":((ipfix_cfg.lkup_type==2)?"L3":"L2L3")));
        ctc_cli_out("%-25s: %d\n", "Sample Pkt Interval", ipfix_cfg.sample_interval);
        ctc_cli_out("%-25s: %s\n", "Tcp End Detect", ipfix_cfg.tcp_end_detect_disable?"Disable":"Enable");
        ctc_cli_out("%-25s: %s\n", "Learn Enable", ipfix_cfg.learn_disable?"Disable":"Enable");
        ctc_cli_out("%-25s: %s\n\n", "Flow Type", (ipfix_cfg.flow_type==0)?"All packet":((ipfix_cfg.flow_type==1)?"No Discard packet":"Discard packet"));
    }

    return CLI_SUCCESS;
}

#define __IPFIX_CPU_ADD_ENTRY__

CTC_CLI(ctc_cli_ipfix_add_l2_hashkey,
        ctc_cli_ipfix_add_l2_hashkey_cmd,
        "ipfix add mac-key by key src-gport SRCPORT" "{" CTC_CLI_IPFIX_KEY_PORT_STR " |mac-da MACDA| mac-sa MACSA|eth-type ETHER| cvlan CVLAN | cvlan-prio PRIO | cvlan-cfi CFI |svlan SVLAN |svlan-prio PRIO | svlan-cfi CFI  } (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key",
        "L2 key",
        "By",
        "By Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L2_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_MAC;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-da", use_data.dst_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", use_data.src_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("eth-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ether type", use_data.ether_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan", use_data.cvlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_CVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan", use_data.svlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_SVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan prio", use_data.svlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan prio", use_data.cvlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan cfi", use_data.svlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan cfi", use_data.cvlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_add_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_del_l2_hashkey,
        ctc_cli_ipfix_del_l2_hashkey_cmd,
        "ipfix delete mac-key by key src-gport SRCPORT" "{" CTC_CLI_IPFIX_KEY_PORT_STR " |mac-da MACDA| mac-sa MACSA|eth-type ETHER| cvlan CVLAN |svlan SVLAN |svlan-prio PRIO | cvlan-prio PRIO | svlan-cfi CFI | cvlan-cfi CFI} (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Delete key",
        "L2 key",
        "By",
        "By Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L2_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_MAC;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-da", use_data.dst_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", use_data.src_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("eth-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ether type", use_data.ether_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan", use_data.cvlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_CVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan", use_data.svlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_SVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan prio", use_data.svlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan prio", use_data.cvlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan cfi", use_data.svlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan cfi", use_data.cvlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_delete_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}
CTC_CLI(ctc_cli_ipfix_add_l2l3_hashkey,
        ctc_cli_ipfix_add_l2l3_hashkey_cmd,
        "ipfix add l2l3-key by key src-gport SRCPORT" CTC_CLI_IPFIX_L2_L3_KEY_STR " (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key by cpu",
        "L2L3 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L2_STR_DESC,
        CTC_CLI_IPFIX_KEY_L3_STR_DESC,
        "Ttl",
        "TTl value",
        "Ecn",
        "Ecn value",
        "Vrfid",
        "Vrfid value",
        CTC_CLI_IPFIX_KEY_L4_STR_DESC,
        CTC_CLI_IPFIX_KEY_MPLS_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint32 temp = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_L2_L3;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-da", use_data.dst_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", use_data.src_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("eth-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ether type", use_data.ether_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan", use_data.svlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_SVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan piro", use_data.svlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan cfi", use_data.svlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan", use_data.cvlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_CVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan prio", use_data.cvlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan cfi", use_data.cvlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipsa", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipsa = temp;
        use_data.l3_info.ipv4.ipsa_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipda", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipda = temp;
        use_data.l3_info.ipv4.ipda_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ttl");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ttl", use_data.l3_info.ipv4.ttl, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ecn");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ecn", use_data.l3_info.ipv4.ecn, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vrfid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vrfid", use_data.l3_info.vrfid, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv4.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("l4-type", use_data.l4_info.type.l4_type, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    _ctc_cli_ipfix_parser_mpls_key(argc, &argv[0], &use_data);

    ret = ctc_ipfix_add_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_del_l2l3_hashkey,
        ctc_cli_ipfix_del_l2l3_hashkey_cmd,
        "ipfix delete l2l3-key by key src-gport SRCPORT" CTC_CLI_IPFIX_L2_L3_KEY_STR " (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Delete key by cpu",
        "L2L3 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L2_STR_DESC,
        CTC_CLI_IPFIX_KEY_L3_STR_DESC,
        "Ttl",
        "TTl value",
        "Ecn",
        "Ecn value",
        "Vrfid",
        "Vrfid value",
        CTC_CLI_IPFIX_KEY_L4_STR_DESC,
        CTC_CLI_IPFIX_KEY_MPLS_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint32 temp = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_L2_L3;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-da", use_data.dst_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", use_data.src_mac, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("eth-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ether type", use_data.ether_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan", use_data.svlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_SVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan piro", use_data.svlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan cfi", use_data.svlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan", use_data.cvlan, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.flags |= CTC_IPFIX_DATA_CVLAN_TAGGED;
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-prio");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan prio", use_data.cvlan_prio, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-cfi");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan cfi", use_data.cvlan_cfi, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipsa", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipsa = temp;
        use_data.l3_info.ipv4.ipsa_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipda", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipda = temp;
        use_data.l3_info.ipv4.ipda_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ttl");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ttl", use_data.l3_info.ipv4.ttl, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vifid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vrfid", use_data.l3_info.vrfid, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ecn");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ecn", use_data.l3_info.ipv4.ecn, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv4.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("l4-type", use_data.l4_info.type.l4_type, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    _ctc_cli_ipfix_parser_mpls_key(argc, &argv[0], &use_data);

    ret = ctc_ipfix_delete_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_add_ipv4_hashkey,
        ctc_cli_ipfix_add_ipv4_hashkey_cmd,
        "ipfix add ipv4-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR"|"CTC_CLI_IPFIX_KEY_L3_STR"|"CTC_CLI_IPFIX_KEY_IPV4_L4_STR"} (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key by cpu",
        "Ipv4 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L3_STR_DESC,
        CTC_CLI_IPFIX_KEY_IPV4_L4_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint32 temp = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_IPV4;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-protocol");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ip-protocol", use_data.l4_info.type.ip_protocol, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv4.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipsa", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipsa = temp;
        use_data.l3_info.ipv4.ipsa_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipda", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipda = temp;
        use_data.l3_info.ipv4.ipda_masklen = mask_len;

    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_add_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_del_ipv4_hashkey,
        ctc_cli_ipfix_del_ipv4_hashkey_cmd,
        "ipfix delete ipv4-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR"|"CTC_CLI_IPFIX_KEY_L3_STR"|"CTC_CLI_IPFIX_KEY_IPV4_L4_STR"} (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key by cpu",
        "Ipv4 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_L3_STR_DESC,
        CTC_CLI_IPFIX_KEY_IPV4_L4_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    uint32 temp = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_IPV4;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipsa", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipsa = temp;
        use_data.l3_info.ipv4.ipsa_masklen = mask_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("ipda", temp, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv4.ipda = temp;
        use_data.l3_info.ipv4.ipda_masklen = mask_len;

    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv4.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-protocol");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("ip-protocol", use_data.l4_info.type.ip_protocol, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_delete_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_add_mpls_hashkey,
        ctc_cli_ipfix_add_mpls_hashkey_cmd,
        "ipfix add mpls-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR "|" CTC_CLI_IPFIX_KEY_MPLS_STR "}" " (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key by cpu",
        "Mpls key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_MPLS_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_MPLS;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    _ctc_cli_ipfix_parser_mpls_key(argc, &argv[0], &use_data);

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_add_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_del_mpls_hashkey,
        ctc_cli_ipfix_del_mpls_hashkey_cmd,
        "ipfix delete mpls-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR "|" CTC_CLI_IPFIX_KEY_MPLS_STR "}" " (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Delete key by cpu",
        "Mpls key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        CTC_CLI_IPFIX_KEY_MPLS_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_MPLS;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    _ctc_cli_ipfix_parser_mpls_key(argc, &argv[0], &use_data);

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_delete_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_add_ipv6_hashkey,
        ctc_cli_ipfix_add_ipv6_hashkey_cmd,
        "ipfix add ipv6-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR "| ip-sa X:X::X:X mask-len LEN| ip-da X:X::X:X mask-len LEN|dscp DSCP|flow-label FLOW_LABEL|" CTC_CLI_IPFIX_KEY_L4_STR "} (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Add key by cpu",
        "Ipv6 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        "ip-sa",
        CTC_CLI_IPV6_FORMAT,
        "mask-len",
        "mask len value<8,12,16,...,128>",
        "ip-da",
        CTC_CLI_IPV6_FORMAT,
        "mask-len",
        "mask len value<8,12,16,...,128>",
        "dscp",
        "Dscp value",
        "flow label",
        "Flow label value, it will cover l4_port",
        CTC_CLI_IPFIX_KEY_L4_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    ipv6_addr_t ipv6_address;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_IPV6;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv6.ipsa_masklen = mask_len;
        use_data.l3_info.ipv6.ipsa[0] = sal_htonl(ipv6_address[0]);
        use_data.l3_info.ipv6.ipsa[1] = sal_htonl(ipv6_address[1]);
        use_data.l3_info.ipv6.ipsa[2] = sal_htonl(ipv6_address[2]);
        use_data.l3_info.ipv6.ipsa[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv6.ipda_masklen = mask_len;
        use_data.l3_info.ipv6.ipda[0] = sal_htonl(ipv6_address[0]);
        use_data.l3_info.ipv6.ipda[1] = sal_htonl(ipv6_address[1]);
        use_data.l3_info.ipv6.ipda[2] = sal_htonl(ipv6_address[2]);
        use_data.l3_info.ipv6.ipda[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("l4-type", use_data.l4_info.type.l4_type, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv6.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("flow-label");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("flow label", use_data.l3_info.ipv6.flow_label, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_add_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipfix_del_ipv6_hashkey,
        ctc_cli_ipfix_del_ipv6_hashkey_cmd,
        "ipfix delete ipv6-key by key src-gport SRCPORT" "{"CTC_CLI_IPFIX_KEY_PORT_STR "| ip-sa X:X::X:X mask-len LEN| ip-da X:X::X:X mask-len LEN|dscp DSCP|flow-label FLOW_LABEL|"CTC_CLI_IPFIX_KEY_L4_STR"} (dir DIR)",
        CTC_CLI_IPFIX_M_STR,
        "Delete key by cpu",
        "Ipv6 key",
        "By",
        "Key",
        "Source phyPort",
        CTC_CLI_GPORT_ID_DESC,
        CTC_CLI_KEY_PORT_STR_DESC,
        "ip-sa",
        CTC_CLI_IPV6_FORMAT,
        "mask-len",
        "mask len value<8,12,16,...,128>",
        "ip-da",
        CTC_CLI_IPV6_FORMAT,
        "mask-len",
        "mask len value<8,12,16,...,128>",
        "dscp",
        "Dscp value",
        "flow label",
        "Flow label value, it will cover l4_port",
        CTC_CLI_IPFIX_KEY_L4_STR_DESC,
        "Direction",
        "<0:Ingress,1:Egress>"
        )
{
    ctc_ipfix_data_t use_data;
    uint8 index = 0;
    uint8 sub_idx = 0;
    uint8 mask_len = 0;
    ipv6_addr_t ipv6_address;
    int32 ret = CLI_SUCCESS;

    sal_memset(&use_data, 0, sizeof(ctc_ipfix_data_t));

    use_data.key_type = CTC_IPFIX_KEY_HASH_IPV6;

    CTC_CLI_GET_UINT16_RANGE("src-gport", use_data.gport, argv[0], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("gport");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", use_data.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("logic-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("lport", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_LOGIC_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("metadata");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("metadata", use_data.logic_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        use_data.port_type = CTC_IPFIX_PORT_TYPE_METADATA;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv6.ipsa_masklen = mask_len;
        use_data.l3_info.ipv6.ipsa[0] = sal_htonl(ipv6_address[0]);
        use_data.l3_info.ipv6.ipsa[1] = sal_htonl(ipv6_address[1]);
        use_data.l3_info.ipv6.ipsa[2] = sal_htonl(ipv6_address[2]);
        use_data.l3_info.ipv6.ipsa[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index+1]);
        sub_idx = CTC_CLI_GET_ARGC_INDEX("mask-len");
        CTC_CLI_GET_UINT8_RANGE("mask", mask_len, argv[sub_idx+1],0, CTC_MAX_UINT8_VALUE);
        use_data.l3_info.ipv6.ipda_masklen = mask_len;
        use_data.l3_info.ipv6.ipda[0] = sal_htonl(ipv6_address[0]);
        use_data.l3_info.ipv6.ipda[1] = sal_htonl(ipv6_address[1]);
        use_data.l3_info.ipv6.ipda[2] = sal_htonl(ipv6_address[2]);
        use_data.l3_info.ipv6.ipda[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("l4-type", use_data.l4_info.type.l4_type, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-sub-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-sub-type", use_data.l4_info.l4_sub_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("is-extern");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("is-extern", use_data.l4_info.is_extern, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src", use_data.l4_info.l4_port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst", use_data.l4_info.l4_port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-type", use_data.l4_info.icmp.icmp_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("icmp-code");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("icmp-code", use_data.l4_info.icmp.icmpcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("gre-key");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("gre-key", use_data.l4_info.gre_key, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("dscp", use_data.l3_info.ipv6.dscp, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("flow-label");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("flow label", use_data.l3_info.ipv6.flow_label, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("vni");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("vni", use_data.l4_info.vni, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dir");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("dir", use_data.dir, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = ctc_ipfix_delete_entry(&use_data);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



int32
ctc_ipfix_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_set_hash_field_sel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_set_port_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_set_global_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_show_debug_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_show_port_cfg_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_add_l2_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_add_l2l3_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_add_ipv4_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_add_mpls_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_add_ipv6_hashkey_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_del_l2_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_del_l2l3_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_del_ipv4_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_del_mpls_hashkey_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipfix_del_ipv6_hashkey_cmd);
    return CLI_SUCCESS;

}

