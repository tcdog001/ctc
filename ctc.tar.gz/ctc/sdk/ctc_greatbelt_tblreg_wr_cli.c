#include "ctc_error.h"
#include "ctc_debug.h"
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_const.h"
#include "ctc_greatbelt_tblreg_wr_cli.h"

#include "../../../../driver/greatbelt/include/drv_tbl_reg.h"
#include "../../../../driver/greatbelt/include/drv_io.h"
#include "../../../../driver/greatbelt/include/drv_enum.h"

extern int8 ctc_greatbelt_table_str[MaxTblId_t][CTC_GREATBELT_TR_BUF_SIZE];

#define _GLB_ENABLE_DBGSHOW_

#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG        0
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG        1
#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL        2
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL        3
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG        4
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL        5
#define CTC_DIAG_TBLREG_CHIP_LIST_REG            6
#define CTC_DIAG_TBLREG_CHIP_LIST_TBL            7

typedef struct
{
    uint32  param[5];
    uint8    buf[CTC_GREATBELT_TR_BUF_SIZE];
    uint32  step;
} ctc_dbg_tblreg_show_req_t;

char*
_tbl_type_to_str(ext_content_type_t type)
{
    switch (type)
    {
    case EXT_INFO_TYPE_NORMAL:
        return "RAM";

    case EXT_INFO_TYPE_TCAM:
        return "TCAM";

    case EXT_INFO_TYPE_DYNAMIC:
        return "DYNAMIC";

    default:
        return "Invalid";
    }
}

char*
ctc_dbg_tblreg_dump_list_one(uint32 tbl_id, uint32* first_flag)
{
    tables_info_t* tbl_ptr = NULL;
    ext_content_type_t ext_type = 0;
    char tmp[8];

    tbl_ptr = TABLE_INFO_PTR(tbl_id);
    if (tbl_ptr->ptr_ext_info)
    {
        ext_type = tbl_ptr->ptr_ext_info->ext_content_type;
    }

    if (*first_flag)
    {
        ctc_cli_out("%-5s %-10s %-6s %-7s %-7s %-6s %-7s %-20s\n",
                    "TblID", "Address",  "Number", "EntrySZ", "KeySZ", "Fields", "Type", "Name");
        ctc_cli_out("----------------------------------------------------------------------------------\n");
        *first_flag = FALSE;
    }

    sal_memset(tmp, 0, sizeof(tmp));

    if (drv_table_is_tcam_key(tbl_id))
    {
        if (TABLE_ENTRY_SIZE(tbl_id) == TCAM_KEY_SIZE(tbl_id))
        {
            sal_snprintf(tmp, 7, "%d", TCAM_KEY_SIZE(tbl_id));
        }
        else
        {
            sal_snprintf(tmp, 7, "*%d", TCAM_KEY_SIZE(tbl_id));
        }
    }

    ctc_cli_out("%-5d 0x%08x %-6d %-7d %-7s %-6d %-7s %-20s\n",
                tbl_id, tbl_ptr->hw_data_base,  tbl_ptr->max_index_num,
                TABLE_ENTRY_SIZE(tbl_id), tmp, tbl_ptr->num_fields, _tbl_type_to_str(ext_type),
                ctc_greatbelt_table_str[tbl_id]);

    return CTC_E_NONE;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(char* tbl_name, uint32 id, uint32 detail)
{
    tables_info_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 fld_idx = 0;
    uint32 first_flag = TRUE;

    tbl_ptr = TABLE_INFO_PTR(id);
    ctc_dbg_tblreg_dump_list_one(id, &first_flag);
    ctc_cli_out("----------------------------------------------------------------------------------\n");
    if (detail)
    {
        ctc_cli_out("%-5s %-5s %-4s %-4s %-6s %-30s\n", "TblID", "FldID", "Word", "Bit", "BitLen", "Name");

        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
            ctc_cli_out("%-5d %-5d %-4d %-4d %-6d %-30s\n", id, fld_idx,
                        fld_ptr->word_offset, fld_ptr->bit_offset, fld_ptr->len, fld_ptr->ptr_field_name);
        }

        ctc_cli_out("\n");
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl_db(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 tbl_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    char* tbl_name = NULL;

    all = req->param[1];
    detail = req->param[2];

    tbl_name = (char*)req->buf;
    if ((ret = ctc_greatbelt_tr_str2id(TABLE_ID, tbl_name, &tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CTC_E_NONE;
    }

    ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(tbl_name, tbl_id, detail);
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CTC_E_NONE;
}

extern uint32
ctc_get_local_chip_num(uint8* chip_num);

int32
ctc_dbg_tblreg_dump_chip_read_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_

    char* tbl_name = NULL;
    uint8 chip = 0;
    uint8 chip_num = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 tbl_id = 0;
    uint32 value = 0;
    uint32 mask = 0;
    uint32 num = 0;
    uint32 step = 0;
    int32 ret = 0;
    tables_info_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 cmd = 0;
    uint32 addr = 0;
    uint32 first_flag = TRUE;
    uint8 is_tcam = 0;
    tbl_entry_t entry;
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};

    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    step = req->step;
    tbl_name = (char*)req->buf;

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        ctc_cli_out("%% Chip %d out-of-range\n", chip);
        return CTC_E_NONE;
    }

    if ((ret = ctc_greatbelt_tr_str2id(TABLE_ID, tbl_name, &tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CTC_E_NONE;
    }

    ctc_dbg_tblreg_dump_list_one(tbl_id, &first_flag);

    tbl_ptr = TABLE_INFO_PTR(tbl_id);
    ctc_cli_out("\n");

    for (i = 0; i < num; i++)
    {
        index = (start_index + (i * step));
        if (index >= tbl_ptr->max_index_num)
        {
            ctc_cli_out("%% Index %d out-of-range %d\n", index, tbl_ptr->max_index_num);
            break;
        }

        if (drv_table_is_tcam_key(tbl_id))
        {
            /* TCAM */
            ctc_cli_out("%-6s %-10s %-10s %-6s %-10s Index(%d)\n", "FldID", "Value", "Mask", "BitLen", "Name", index);
        }
        else
        {
            /* non-TCAM */
            ret = drv_table_get_hw_addr(tbl_id, index, &addr);
            if (ret < 0)
            {
                ctc_cli_out("%% get table_id %d index %d address fail\n", tbl_id, index);
                return CLI_ERROR;
            }

            ctc_cli_out("%-6s %-10s %-10s %-6s %-10s Index(%d) Address(0x%08x)\n", "FldID", "Value", "Mask", "BitLen", "Name", index, addr);
        }

        ctc_cli_out("----------------------------------------------------------------------------------\n");

        if (drv_table_is_tcam_key(tbl_id))
        {
            entry.data_entry = data_entry;
            entry.mask_entry = mask_entry;
            cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
            drv_ioctl(chip, index, cmd, &entry);
            is_tcam = 1;
        }
        else
        {
            cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
            drv_ioctl(chip, index, cmd, &data_entry);
            is_tcam = 0;
        }

        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx]);
            if (is_tcam)
            {
                drv_get_field(tbl_id, fld_idx, data_entry, &value);
                drv_get_field(tbl_id, fld_idx, mask_entry, &mask);
                ctc_cli_out("%-6d 0x%08x 0x%08x %-6d %-10s\n", fld_idx, value, mask, fld_ptr->len, fld_ptr->ptr_field_name);
            }
            else
            {
                drv_get_field(tbl_id, fld_idx, data_entry, &value);
                ctc_cli_out("%-6d 0x%08x %-10s %-6d %-10s\n", fld_idx, value, "", fld_ptr->len, fld_ptr->ptr_field_name);
            }

        }

        ctc_cli_out("\n");
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    char* reg_name = NULL;
    uint8 chip = 0;
    int32 index = 0;
    uint32 reg_tbl_id = 0;
    uint32 value = 0;
    uint32 mask = 0;
    uint32 cmd = 0;
    int32 ret = 0;
    tables_info_t* tbl_ptr = NULL;
    int32 fld_id = 0;
    int32 fld_ok = FALSE;
    uint32 max_index_num = 0;
    uint32 reg_or_tbl = (CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG == req->param[0]) ? REGISTER_ID : TABLE_ID;
    uint8 chip_num = 0;
    tbl_entry_t field_entry;

    chip = req->param[1];
    index = req->param[2];
    fld_id = req->param[3];
    value = req->param[4];
    reg_name = (char*)req->buf;

    ctc_cli_out("Write %s field %d chip %d index %d value 0x%0x \n",
                reg_name, fld_id, chip, index, value);

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        ctc_cli_out("%% Chip %d out-of-range\n", chip);
        return CTC_E_NONE;
    }

    if ((ret = ctc_greatbelt_tr_str2id(reg_or_tbl, reg_name, &reg_tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", reg_name);
        return CTC_E_NONE;
    }

    tbl_ptr = TABLE_INFO_PTR(reg_tbl_id);
    if (fld_id < tbl_ptr->num_fields)
    {
        fld_ok = TRUE;
    }

    max_index_num = tbl_ptr->max_index_num;

    if (!fld_ok)
    {
        ctc_cli_out("%% %s has no field %d\n", reg_name, fld_id);
        return CTC_E_NONE;
    }

    if (index >= max_index_num)
    {
        ctc_cli_out("%% Index %d out-of-range %d\n", index, max_index_num);
        return CTC_E_NONE;
    }

    cmd = DRV_IOW(reg_tbl_id, fld_id);

    if (drv_table_is_tcam_key(reg_tbl_id))
    {
        field_entry.data_entry = &value;
        field_entry.mask_entry = &mask;
        ret = drv_ioctl(chip, index, cmd, &field_entry);
    }
    else
    {
        ret = drv_ioctl(chip, index, cmd, &value);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% Write %s index %d failed %d\n", (REGISTER_ID == reg_or_tbl) ? "tbl" : "reg", index, ret);
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CLI_SUCCESS;
}

int32
_str_to_upper(char* str)
{
    uint32  i = 0;

    /* convert the alphabets to upper case before comparison */
    for (i = 0; i < sal_strlen((char*)str); i++)
    {
        if (sal_isalpha((int)str[i]) && sal_islower((int)str[i]))
        {
            str[i] = sal_toupper(str[i]);
        }
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(ctc_dbg_tblreg_show_req_t* req)
{
#define CTC_GREATBELT_LIST_MAX_NUM   256
    uint32  ids[CTC_GREATBELT_LIST_MAX_NUM];
    char    upper_name[CTC_GREATBELT_TR_BUF_SIZE];
    char    upper_name1[CTC_GREATBELT_TR_BUF_SIZE];
    uint32  i = 0;
    uint32  id_index = 0;
    uint32  first_flag = TRUE;
    char* p_char = NULL;

    sal_memset(ids, 0, sizeof(ids));
    sal_memset(upper_name, 0, sizeof(upper_name));

    if (0 == sal_strlen((char*)req->buf))
    {
        /* list all */
        ctc_cli_out("List all %d entries\n", MaxTblId_t);

        for (i = 0; i < MaxTblId_t; i++)
        {
            ctc_dbg_tblreg_dump_list_one(i, &first_flag);
        }

        return CTC_E_NONE;
    }

    sal_strncpy((char*)upper_name, (char*)req->buf, CTC_GREATBELT_TR_BUF_SIZE);
    _str_to_upper(upper_name);

    for (i = 0; i < MaxTblId_t; i++)
    {
        sal_strcpy((char*)upper_name1, (char*)ctc_greatbelt_table_str[i]);
        _str_to_upper(upper_name1);

        p_char = (char*)sal_strstr((char*)upper_name1, (char*)upper_name);
        if (p_char)
        {
            if (sal_strlen((char*)ctc_greatbelt_table_str[i]) == sal_strlen((char*)upper_name))
            {
                /* list full matched */
                ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id((char*)ctc_greatbelt_table_str[i], i, TRUE);
                return CTC_E_NONE;
            }

            ids[id_index] = i;
            id_index++;
            if (id_index >= CTC_GREATBELT_LIST_MAX_NUM)
            {
                ctc_cli_out("Too much matched, only display first %d entries. \n", id_index);
                break;
            }
        }
    }

    if (id_index == 0)
    {
        ctc_cli_out("%% Not found %s \n", req->buf);
        return CTC_E_NONE;
    }

    ctc_cli_out("Found %d matched entries \n", id_index);

    for (i = 0; i < id_index; i++)
    {
        /* list matched */
        ctc_dbg_tblreg_dump_list_one(ids[i], &first_flag);
    }

    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;

    switch (req->param[0])
    {
    case CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl_db(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl_db(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG:
    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL:
        ret = ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_LIST_REG:
    case CTC_DIAG_TBLREG_CHIP_LIST_TBL:
        ret = ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(req);
        break;

    default:
        break;
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CTC_E_NONE;
}

CTC_CLI(show_cli_tbl_reg,
        show_cli_tbl_reg_cmd,
        "show tbl-id TBL_ID",
        CTC_CLI_SHOW_STR,
        "Table or register id",
        "Table id value <0-MaxTblId_t>")
{
    uint32 id = 0;
    int32 ret = 0;
    char    buf[CTC_GREATBELT_TR_BUF_SIZE];

    CTC_CLI_GET_UINT32_RANGE("Table/Reg Index", id, argv[0], 0, MaxTblId_t);

    ret = ctc_greatbelt_tr_id2str(0, id, buf);

    if (CTC_E_NONE == ret)
    {
        ctc_cli_out("----------------------------------\n");
        ctc_cli_out("ID:%d ------> %s\n", id, buf);
        ctc_cli_out("----------------------------------\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(show_cli_drv_list_tbl,
        show_cli_drv_list_tbl_cmd,
        "listtbl STRING:TBL_NAME",
        "List tables",
        "Substring of table name")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 opcode = CTC_DIAG_TBLREG_CHIP_LIST_TBL;

    sal_memset(&req, 0, sizeof(req));
    req.param[0] = opcode;

    if (argc > 0)
    {
        sal_strncpy((char*)req.buf, argv[0], CTC_GREATBELT_TR_BUF_SIZE);
    }

    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

CTC_CLI(show_cli_drv_list_tbl_all,
        show_cli_drv_list_tbl_all_cmd,
        "listtbl",
        "List tables")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 opcode = CTC_DIAG_TBLREG_CHIP_LIST_TBL;

    sal_memset(&req, 0, sizeof(req));
    req.param[0] = opcode;
    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

CTC_CLI(show_cli_drv_read_reg_or_tbl_field,
        show_cli_drv_read_reg_or_tbl_field_cmd,
        "read tbl-name STRING:TBL_NAME tbl-index INDEX (count COUNT (step STEP_COUNT |)|) (lchip CHIP_ID|)",
        "Read table or register",
        "Table name",
        "Table name value example [DsMac]",
        "Table index",
        "Table index value <0-0xFFFFFFFF>",
        "The counts of sequential registers you need to read ",
        "Value <1-8192>",
        "Step how many count. Default:0",
        "Step count. 2 means 0 2 4...",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC)
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 count = 1;
    uint32 opcode = 0;
    uint32 step = 1;
    int32 idx1 = 0;

    opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL;

    /*get tbl name*/
    sal_strncpy((char*)req.buf, argv[0], CTC_GREATBELT_TR_BUF_SIZE);

    /*get tbl index*/
    CTC_CLI_GET_UINT32_RANGE("Tbl-index", index, argv[1], 0, 0xFFFFFFFF);

    /*get chip id*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("Chip", chip, argv[idx1 + 1], 0, 1);
    }

    /*get show count*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("count");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("Count", count, argv[idx1 + 1], 1, 8192);
    }

    /*get show step*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("step");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("step", step, argv[idx1 + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    req.param[0] = opcode;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = count;
    req.step = step;

    ctc_dbg_tblreg_dump_chip(&req);

    return CLI_SUCCESS;
}

CTC_CLI(show_cli_drv_write_reg_or_tbl_field,
        show_cli_drv_write_reg_or_tbl_field_cmd,
        "write tbl-name STRING:TBL_NAME tbl-index INDEX (fld-id) FLD_ID (value) VALUE (lchip CHIP_ID|)",
        "Write table or register",
        "Table name",
        "Table name value example DsMac",
        "Table index",
        "Table index value <0-0xFFFFFFFF>",
        "Field id",
        "Field id range <0-0xFF>",
        "Field value",
        "Value <0-0xFFFFFFFF>",
        CTC_CLI_CHIP_DESC,
        CTC_CLI_CHIP_ID_DESC)
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 chip = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    uint32 value = 0;
    uint32 opcode = 0;
    int32 idx1 = 0;

    opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL;

    /*get tbl name*/
    sal_strncpy((char*)req.buf, argv[0], CTC_GREATBELT_TR_BUF_SIZE);

    /*get tbl index*/
    CTC_CLI_GET_UINT32_RANGE("Tbl-index", index, argv[1], 0, 0xFFFFFFFF);

    /*get chip id*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("Chip", chip, argv[idx1 + 1], 0, 1);
    }

    /*get field id*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("fld-id");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("Fld-id", field_id, argv[idx1 + 1], 0, 0xFFFFFFFF);
    }

    /*get field value*/
    idx1 = CTC_CLI_GET_ARGC_INDEX("value");
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32_RANGE("fld-value", value, argv[idx1 + 1], 0, 0xFFFFFFFF);
    }

    req.param[0] = opcode;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = field_id;
    req.param[4] = value;

    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

int32
ctc_greatbelt_tblreg_wr_cli_init(void)
{
    install_element(CTC_SDK_MODE, &show_cli_drv_read_reg_or_tbl_field_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_write_reg_or_tbl_field_cmd);
    install_element(CTC_SDK_MODE, &show_cli_tbl_reg_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_list_tbl_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_list_tbl_all_cmd);

    return CLI_SUCCESS;
}

