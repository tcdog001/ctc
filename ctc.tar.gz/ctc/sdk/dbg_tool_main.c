
#include "sal.h"
#include "dal.h"
#include "drv_lib.h"
#include "drv_ftm.h"
#include "dbg_tool_cli.h"
#include "ctc_cli.h"

extern int32 dal_set_device_access_type(dal_access_type_t device_type);
extern int32 dal_op_init(dal_op_t* p_dal_op);

void
ctc_cli_mode_exit(void)
{
    switch (g_ctc_vti->node)
    {
    case EXEC_MODE:
        restore_terminal_mode(CTC_VTI_SHELL_MODE_DEFAULT);
        exit(0);
        break;

    case CTC_CMODEL_MODE:
    case CTC_DBG_TOOL_MODE:
        /*vty->node = EXEC_MODE;*/
        restore_terminal_mode(CTC_VTI_SHELL_MODE_DEFAULT);
        exit(0);
        break;

    default:
        g_ctc_vti->node = EXEC_MODE;
        break;
    }
}

CTC_CLI(exit_config,
        exit_cmd,
        "exit",
        "End current mode and down to previous mode")
{
    ctc_cli_mode_exit();
    return CLI_SUCCESS;
}

CTC_CLI(quit_config,
        quit_cmd,
        "quit",
        "Exit current mode and down to previous mode")
{
    ctc_cli_mode_exit();
    return CLI_SUCCESS;
}

CTC_CLI(cli_enter_mode,
        enter_mode_cmd,
        "enter (debug-tool | cmodel) mode",
        "Enter",
        "Ctc debug tool mode",
        "Ctc cmodel mode",
        "Mode")
{
    char* mode = NULL;

    mode = argv[0];

    if (0 == sal_strcmp(mode, "debug-tool"))
    {
        g_ctc_vti->node  = CTC_DBG_TOOL_MODE;
    }
    else
    {
        g_ctc_vti->node  = CTC_CMODEL_MODE;
    }

    return CLI_SUCCESS;
}

ctc_cmd_node_t exec_node =
{
    EXEC_MODE,
    "\rCTC_CLI# ",
};

ctc_cmd_node_t debug_tool_node =
{
    CTC_DBG_TOOL_MODE,
    "\rCTC_CLI(ctc-dt)# ",
};

ctc_cmd_node_t cmodel_node =
{
    CTC_CMODEL_MODE,
    "\rCTC_CLI(ctc-cmodel)# ",
};

int
dbg_tool_cli_master(void)
{
    ctc_cmd_init(0);

    ctc_install_node(&exec_node, NULL);
    ctc_install_node(&debug_tool_node, NULL);
    ctc_vti_init(CTC_DBG_TOOL_MODE);

    install_element(EXEC_MODE, &exit_cmd);
    install_element(EXEC_MODE, &quit_cmd);

    install_element(EXEC_MODE, &enter_mode_cmd);

    install_element(CTC_DBG_TOOL_MODE, &exit_cmd);
    install_element(CTC_DBG_TOOL_MODE, &quit_cmd);

    ctc_com_cli_init(CTC_DBG_TOOL_MODE);

    ctc_dbg_tool_cli_init(CTC_DBG_TOOL_MODE);

    ctc_sort_node();

    set_terminal_raw_mode(CTC_VTI_SHELL_MODE_DEFAULT);

    while (1)
    {
        ctc_vti_read();
    }

    restore_terminal_mode(CTC_VTI_SHELL_MODE_DEFAULT);

    return 0;
}

int
main()
{
    int ret = 0;
    drv_ftm_profile_info_t profile;

    mem_mgr_init();

    if (0 == SDK_WORK_PLATFORM)
    {
        /* dal module init */
        ret = dal_set_device_access_type(DAL_PCIE_MM);
        if (ret < 0)
        {
            sal_printf("Failed to register dal callback\r\n");
            return ret;
        }

        ret = dal_op_init(NULL);
        if (ret != 0)
        {
            sal_printf("Failed to register dal callback\r\n");
            return ret;
        }
    }

    /* drv module init */
    drv_init(1, 0);

    /* drv profile init */
    sal_memset(&profile, 0, sizeof(profile));
    drv_ftm_mem_alloc(&profile);

    /* install dbg tools cli */
    dbg_tool_cli_master();

    return 0;
}

