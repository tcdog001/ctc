/**
 @file sys_humber_security.c

 @date 2010-2-26

 @version v2.0

---file comments----
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_vector.h"
#include "sys_humber_security.h"
#include "sys_humber_port.h"
#include "sys_humber_vlan.h"
#include "sys_humber_usrid.h"
#include "sys_humber_chip.h"

#include "drv_io.h"
#include "drv_humber.h"
#include "drv_humber_data_path.h"
/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/
#define SYS_SECURITY_STMCTL_DEF_UPDATE_EN     1
#define SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM      (1000 - 1)
#define SYS_SECURITY_STMCTL_DEF_MAX_UPDT_PORT_NUM       319
#define SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD (core_frequency - 1)
#define SYS_SECURITY_STMCTL_MAX_PORT_NUM     0x3FFF

#define SYS_SECURITY_PORT_ISOLATION_MAX_GROUP_ID      63

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
sys_security_master_t* security_master = NULL;

#define SYS_SECURITY_INIT_CHECK() \
    { \
        if (security_master == NULL){ \
            return CTC_E_NOT_INIT; } \
    }

/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/

/*mac security*/
int32
sys_humber_mac_security_set_port_security(uint16 gport, bool enable)
{
    SYS_SECURITY_INIT_CHECK();

    CTC_ERROR_RETURN(sys_humber_port_set_security_en(gport, enable));

    return CTC_E_NONE;
}

int32
sys_humber_mac_security_get_port_security(uint16 gport, bool* p_enable)
{
    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_enable);

    CTC_ERROR_RETURN(sys_humber_port_get_security_en(gport, p_enable));

    return CTC_E_NONE;
}

int32
sys_humber_mac_security_set_port_mac_limit(uint16 gport, ctc_maclimit_action_t action)
{
    int32 ret = 0;

    switch (action)
    {
    case CTC_MACLIMIT_ACTION_NONE:          /*learning enable, forwarding, not discard, learnt*/
        ret = sys_humber_port_set_learning_en(gport, TRUE);
        ret = ret ? ret : sys_humber_port_set_mac_security_discard(gport, FALSE);
        ret = ret ? ret : sys_humber_port_set_security_excp_en(gport, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_FWD:           /*learning disable, forwarding*/
        ret = sys_humber_port_set_learning_en(gport, FALSE);
        ret = ret ? ret : sys_humber_port_set_mac_security_discard(gport, FALSE);
        ret = ret ? ret : sys_humber_port_set_security_excp_en(gport, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_DISCARD:       /*learning enable, discard, not learnt*/
        ret = sys_humber_port_set_learning_en(gport, TRUE);
        ret = ret ? ret : sys_humber_port_set_mac_security_discard(gport, TRUE);
        ret = ret ? ret : sys_humber_port_set_security_excp_en(gport, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_TOCPU:         /*learning enable, discard and to cpu, not learnt*/
        ret = sys_humber_port_set_learning_en(gport, TRUE);
        ret = ret ? ret : sys_humber_port_set_mac_security_discard(gport, TRUE);
        ret = ret ? ret : sys_humber_port_set_security_excp_en(gport, TRUE);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

int32
sys_humber_mac_security_get_port_mac_limit(uint16 gport, ctc_maclimit_action_t* action)
{
    bool port_learn_en;
    bool mac_security_discard_en;
    bool security_excp_en;
    int32 ret = CTC_E_NONE;

    ret = sys_humber_port_get_learning_en(gport, &port_learn_en);
    ret |= sys_humber_port_get_mac_security_discard(gport, &mac_security_discard_en);
    ret |= sys_humber_port_get_security_excp_en(gport, &security_excp_en);

    if (port_learn_en)
    {
        if (mac_security_discard_en == FALSE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_NONE;
        }
        else if (mac_security_discard_en == TRUE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_DISCARD;
        }
        else if (mac_security_discard_en == TRUE && security_excp_en == TRUE)
        {
            *action = CTC_MACLIMIT_ACTION_TOCPU;
        }
        else
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (mac_security_discard_en == FALSE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_FWD;
        }
        else
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    return ret;
}

int32
sys_humber_mac_security_set_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t action)
{
    int32 ret = 0;
    sys_vlan_info_t vlan_info;

    sal_memset(&vlan_info, 0, sizeof(sys_vlan_info_t));

    vlan_info.vlan_ptr_type = SYS_VLAN_PTR_TYPE_VID;
    vlan_info.vid = vlan_id;

    switch (action)
    {
    case CTC_MACLIMIT_ACTION_NONE:          /*learning eanble, forwarding, not discard, learnt*/
        ret = sys_humber_vlan_set_learning_en(&vlan_info, TRUE);
        ret = ret ? ret : sys_humber_vlan_set_mac_security_vlan_discard(&vlan_info, FALSE);
        ret = ret ? ret : sys_humber_vlan_set_vlan_security_excp_en(&vlan_info, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_FWD:           /*learning disable, forwarding*/
        ret = sys_humber_vlan_set_learning_en(&vlan_info, FALSE);
        ret = ret ? ret : sys_humber_vlan_set_mac_security_vlan_discard(&vlan_info, FALSE);
        ret = ret ? ret : sys_humber_vlan_set_vlan_security_excp_en(&vlan_info, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_DISCARD:       /*learning enable, discard, not learnt*/
        ret = sys_humber_vlan_set_learning_en(&vlan_info, TRUE);
        ret = ret ? ret : sys_humber_vlan_set_mac_security_vlan_discard(&vlan_info, TRUE);
        ret = ret ? ret : sys_humber_vlan_set_vlan_security_excp_en(&vlan_info, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_TOCPU:         /*learning enable, discard and to cpu, not learnt*/
        ret = sys_humber_vlan_set_learning_en(&vlan_info, TRUE);
        ret = ret ? ret : sys_humber_vlan_set_mac_security_vlan_discard(&vlan_info, TRUE);
        ret = ret ? ret : sys_humber_vlan_set_vlan_security_excp_en(&vlan_info, TRUE);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

int32
sys_humber_mac_security_get_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t* action)
{
    bool learn_en;
    bool mac_security_discard_en;
    bool security_excp_en;
    int32 ret = CTC_E_NONE;
    sys_vlan_info_t vlan_info;

    vlan_info.vid = vlan_id;
    vlan_info.vlan_ptr_type = SYS_VLAN_PTR_TYPE_VID;

    ret = sys_humber_vlan_get_learning_en(&vlan_info, &learn_en);
    ret |= sys_humber_vlan_get_mac_security_vlan_discard(&vlan_info, &mac_security_discard_en);
    ret |= sys_humber_vlan_get_vlan_security_excp_en(&vlan_info, &security_excp_en);

    if (learn_en)
    {
        if (mac_security_discard_en == FALSE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_NONE;
        }
        else if (mac_security_discard_en == TRUE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_FWD;
        }
        else
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (mac_security_discard_en == FALSE && security_excp_en == FALSE)
        {
            *action = CTC_MACLIMIT_ACTION_FWD;
        }
        else if (mac_security_discard_en == TRUE && security_excp_en == TRUE)
        {
            *action = CTC_MACLIMIT_ACTION_TOCPU;
        }
        else
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    return ret;
}

/*ip source guard*/
int32
sys_humber_ip_source_guard_add_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    uint16 gport;
    uint8 lport = 0;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint8 is_linkagg = 0;
    sys_usrid_ipv4_entry_t ipv4_entry;
    sys_usrid_ipv6_entry_t ipv6_entry;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_elem);

    sal_memset(&ipv4_entry, 0, sizeof(sys_usrid_ipv4_entry_t));
    sal_memset(&ipv6_entry, 0, sizeof(sys_usrid_ipv6_entry_t));

    gport = p_elem->gport;

    is_linkagg = CTC_IS_LINKAGG_PORT(gport);
    if (!is_linkagg)   /*not linkagg*/
    {
        SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    }

    lchip_num = sys_humber_get_local_chip_num();

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("gport:%d\n", gport);
    SYS_SECURITY_DBG_INFO("ip source guard type:%d\n", p_elem->ip_src_guard_type);
    SYS_SECURITY_DBG_INFO("ipv4 or ipv6:%s\n", (CTC_IP_VER_4 == p_elem->ipv4_or_ipv6) ? "ipv4" : "ipv6");
    if (CTC_IP_VER_6 == p_elem->ipv4_or_ipv6)
    {
        SYS_SECURITY_DBG_INFO("ipv6sa:%x:%x:%x:%x:%x:%x:%x:%x\n", (p_elem->ipv6_sa[3] >> 16) & 0xFFFF, (p_elem->ipv6_sa[3]) & 0xFFFF, \
                              (p_elem->ipv6_sa[2] >> 16) & 0xFFFF, (p_elem->ipv6_sa[2]) & 0xFFFF, (p_elem->ipv6_sa[1] >> 16) & 0xFFFF,
                              (p_elem->ipv6_sa[1]) & 0xFFFF, (p_elem->ipv6_sa[0] >> 16) & 0xFFFF, (p_elem->ipv6_sa[0]) & 0xFFFF);
    }
    else
    {
        SYS_SECURITY_DBG_INFO("ipv4sa:%d.%d.%d.%d\n", (p_elem->ipv4_sa >> 24) & 0xFF, (p_elem->ipv4_sa >> 16) & 0xFF, \
                              (p_elem->ipv4_sa >> 8) & 0xFF, p_elem->ipv4_sa & 0xFF);
    }

    SYS_SECURITY_DBG_INFO("mac:%x:%x:%x:%x:%x:%x\n", p_elem->mac_sa[0], p_elem->mac_sa[1], p_elem->mac_sa[2], \
                          p_elem->mac_sa[3], p_elem->mac_sa[4], p_elem->mac_sa[5]);
    SYS_SECURITY_DBG_INFO("vlan:%d\n", p_elem->vid);

    if (p_elem->ipv4_or_ipv6 == CTC_IP_VER_4)
    {
        switch (p_elem->ip_src_guard_type)
        {
        case CTC_SECURITY_BINDING_TYPE_IP:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;
            break;

        case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv4_entry.valid.igs_svid_valid = 1;
                ipv4_entry.usrid_key_entry.svid = p_elem->vid;
                ipv4_entry.usrid_key_entry.igs_svid_mask = 0xfff;
            }
            else
            {
                ipv4_entry.valid.igs_cvid_valid = 1;
                ipv4_entry.usrid_key_entry.cvid = p_elem->vid;
                ipv4_entry.usrid_key_entry.igs_cvid_mask = 0xfff;
            }

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            ipv4_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv4_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            ipv4_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv4_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv4_entry.valid.igs_svid_valid = 1;
                ipv4_entry.usrid_key_entry.svid = p_elem->vid;
                ipv4_entry.usrid_key_entry.igs_svid_mask = 0xfff;
            }
            else
            {
                ipv4_entry.valid.igs_cvid_valid = 1;
                ipv4_entry.usrid_key_entry.cvid = p_elem->vid;
                ipv4_entry.usrid_key_entry.igs_cvid_mask = 0xfff;
            }

            break;

        default:
            return CTC_E_INVALID_PARAM;
        }

        ipv4_entry.usrid_key_entry.usrid_label = SYS_USRID_RESERVE_LABEL_FOR_IPSG;

        if (is_linkagg)  /*linkagg*/
        {
            ipv4_entry.ds_entry_usrid.binding_data_h.binding_data = gport;
        }
        else            /*not linkagg*/
        {
            ipv4_entry.ds_entry_usrid.binding_data_h.binding_data = gport;
        }

        ipv4_entry.ds_entry_usrid.usr_vlan_ptr = 0x1FFF;
        ipv4_entry.ds_entry_usrid.usrid_exception_en = 0;
        ipv4_entry.ds_entry_usrid.binding_en = 1;

        if (is_linkagg)   /*linkagg*/
        {
            for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
            {
                ipv4_entry.usrid_key_entry.chip_id = lchip;
                CTC_ERROR_RETURN(sys_humber_usrid_add_ipv4_entry(&ipv4_entry));
            }
        }
        else            /*not linkagg*/
        {
            ipv4_entry.usrid_key_entry.chip_id = lchip;
            CTC_ERROR_RETURN(sys_humber_usrid_add_ipv4_entry(&ipv4_entry));
        }
    }
    else if (p_elem->ipv4_or_ipv6 == CTC_IP_VER_6)         /*not use now,modify latter*/
    {
        switch (p_elem->ip_src_guard_type)
        {
        case CTC_SECURITY_BINDING_TYPE_IP:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));
            break;

        case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv6_entry.valid.igs_svid_valid = 1;
                ipv6_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv6_entry.valid.igs_cvid_valid = 1;
                ipv6_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            ipv6_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv6_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            ipv6_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv6_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv6_entry.valid.igs_svid_valid = 1;
                ipv6_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv6_entry.valid.igs_cvid_valid = 1;
                ipv6_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        default:
            return CTC_E_INVALID_PARAM;
        }

        ipv6_entry.usrid_key_entry.usrid_label = SYS_USRID_RESERVE_LABEL_FOR_IPSG;
        ipv6_entry.ds_entry_usrid.usr_vlan_ptr = 0x1FFF;
        ipv6_entry.ds_entry_usrid.usrid_exception_en = 0;
        ipv6_entry.ds_entry_usrid.binding_en = 1;

        if (is_linkagg)  /*linkagg*/
        {
            ipv6_entry.ds_entry_usrid.binding_data_h.binding_data = gport;
        }
        else            /*not linkagg*/
        {
            ipv6_entry.ds_entry_usrid.binding_data_h.binding_data = gport;
        }

        if (is_linkagg)   /*linkagg*/
        {
            for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
            {
                ipv6_entry.usrid_key_entry.chip_id = lchip;
                CTC_ERROR_RETURN(sys_humber_usrid_add_ipv6_entry(&ipv6_entry));
            }
        }
        else            /*not linkagg*/
        {
            ipv6_entry.usrid_key_entry.chip_id = lchip;
            CTC_ERROR_RETURN(sys_humber_usrid_add_ipv6_entry(&ipv6_entry));
        }
    }

    return CTC_E_NONE;
}

int32
sys_humber_ip_source_guard_remove_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    uint8 lport = 0;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint8 is_linkagg = 0;
    uint16 gport;
    sys_usrid_ipv4_entry_t ipv4_entry;
    sys_usrid_ipv6_entry_t ipv6_entry;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_elem);

    gport = p_elem->gport;

    sal_memset(&ipv4_entry, 0, sizeof(sys_usrid_ipv4_entry_t));
    sal_memset(&ipv6_entry, 0, sizeof(sys_usrid_ipv6_entry_t));

    is_linkagg = CTC_IS_LINKAGG_PORT(gport);
    if (!is_linkagg)   /*not linkagg*/
    {
        SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    }

    lchip_num = sys_humber_get_local_chip_num();

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("gport:%d\n", gport);
    SYS_SECURITY_DBG_INFO("ip source guard type:%d\n", p_elem->ip_src_guard_type);
    SYS_SECURITY_DBG_INFO("ipv4 or ipv6:%d\n", p_elem->ipv4_or_ipv6);
    if (CTC_IP_VER_6 == p_elem->ipv4_or_ipv6)
    {
        SYS_SECURITY_DBG_INFO("ipv6sa:%x:%x:%x:%x:%x:%x:%x:%x\n", (p_elem->ipv6_sa[3] >> 16) & 0xFFFF, (p_elem->ipv6_sa[3]) & 0xFFFF, \
                              (p_elem->ipv6_sa[2] >> 16) & 0xFFFF, (p_elem->ipv6_sa[2]) & 0xFFFF, (p_elem->ipv6_sa[1] >> 16) & 0xFFFF,
                              (p_elem->ipv6_sa[1]) & 0xFFFF, (p_elem->ipv6_sa[0] >> 16) & 0xFFFF, (p_elem->ipv6_sa[0]) & 0xFFFF);
    }
    else
    {
        SYS_SECURITY_DBG_INFO("ipv4sa:%d.%d.%d.%d\n", (p_elem->ipv4_sa >> 24) & 0xFF, (p_elem->ipv4_sa >> 16) & 0xFF, \
                              (p_elem->ipv4_sa >> 8) & 0xFF, p_elem->ipv4_sa & 0xFF);
    }

    SYS_SECURITY_DBG_INFO("mac:%x %x %x %x %x %x\n", p_elem->mac_sa[0], p_elem->mac_sa[1], p_elem->mac_sa[2], \
                          p_elem->mac_sa[3], p_elem->mac_sa[4], p_elem->mac_sa[5]);
    SYS_SECURITY_DBG_INFO("vlan:%d\n", p_elem->vid);

    if (p_elem->ipv4_or_ipv6 == CTC_IP_VER_4)
    {
        switch (p_elem->ip_src_guard_type)
        {
        case CTC_SECURITY_BINDING_TYPE_IP:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;
            break;

        case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv4_entry.valid.igs_svid_valid = 1;
                ipv4_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv4_entry.valid.igs_cvid_valid = 1;
                ipv4_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            ipv4_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv4_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
            ipv4_entry.usrid_key_entry.ipv4_sa = p_elem->ipv4_sa;
            ipv4_entry.usrid_key_entry.ipv4_sa_mask = 0xffffffff;

            ipv4_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv4_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv4_entry.valid.igs_svid_valid = 1;
                ipv4_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv4_entry.valid.igs_cvid_valid = 1;
                ipv4_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        default:
            return CTC_E_INVALID_PARAM;
        }

        ipv4_entry.usrid_key_entry.usrid_label = SYS_USRID_RESERVE_LABEL_FOR_IPSG;

        if (is_linkagg)   /*linkagg*/
        {
            for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
            {
                ipv4_entry.usrid_key_entry.chip_id = lchip;
                CTC_ERROR_RETURN(sys_humber_usrid_delete_ipv4_entry(&ipv4_entry));
            }
        }
        else            /*not linkagg*/
        {
            ipv4_entry.usrid_key_entry.chip_id = lchip;
            CTC_ERROR_RETURN(sys_humber_usrid_delete_ipv4_entry(&ipv4_entry));
        }
    }
    else if (p_elem->ipv4_or_ipv6 == CTC_IP_VER_6)      /*not use now,modify latter*/
    {
        switch (p_elem->ip_src_guard_type)
        {
        case CTC_SECURITY_BINDING_TYPE_IP:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));
            break;

        case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv6_entry.valid.igs_svid_valid = 1;
                ipv6_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv6_entry.valid.igs_cvid_valid = 1;
                ipv6_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            ipv6_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv6_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            break;

        case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
            sal_memcpy(ipv6_entry.usrid_key_entry.ipv6_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
            sal_memset(ipv6_entry.usrid_key_entry.ipv6_smask, 0xFF, sizeof(ipv6_addr_t));

            ipv6_entry.usrid_key_entry.macsa_h = (p_elem->mac_sa[0] << 8) | p_elem->mac_sa[1];
            ipv6_entry.usrid_key_entry.macsa_l = (p_elem->mac_sa[2] << 24) | p_elem->mac_sa[3] << 16 \
                | p_elem->mac_sa[4] << 8 | p_elem->mac_sa[5];

            CTC_VLAN_RANGE_CHECK(p_elem->vid);
            if (p_elem->is_svlan)
            {
                ipv6_entry.valid.igs_svid_valid = 1;
                ipv6_entry.usrid_key_entry.svid = p_elem->vid;
            }
            else
            {
                ipv6_entry.valid.igs_cvid_valid = 1;
                ipv6_entry.usrid_key_entry.cvid = p_elem->vid;
            }

            break;

        default:
            return CTC_E_INVALID_PARAM;
        }

        ipv6_entry.usrid_key_entry.usrid_label = SYS_USRID_RESERVE_LABEL_FOR_IPSG;

        if (is_linkagg)   /*linkagg*/
        {
            for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
            {
                ipv6_entry.usrid_key_entry.chip_id = lchip;
                CTC_ERROR_RETURN(sys_humber_usrid_delete_ipv6_entry(&ipv6_entry));
            }
        }
        else            /*not linkagg*/
        {
            ipv6_entry.usrid_key_entry.chip_id = lchip;
            CTC_ERROR_RETURN(sys_humber_usrid_delete_ipv6_entry(&ipv6_entry));
        }
    }

    return CTC_E_NONE;
}

static int32
sys_humber_ip_source_guard_add_default_entry(uint8 ip_ver, ctc_security_action_type_t action_type)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    sys_usrid_ds_entry_t def_entry;

    SYS_SECURITY_INIT_CHECK();
    sal_memset(&def_entry, 0, sizeof(sys_usrid_ds_entry_t));

    lchip_num = sys_humber_get_local_chip_num();

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("ip version:%d, action type:%d\n", ip_ver, action_type);

    switch (action_type)
    {
    case CTC_SECURITY_ACTION_TYPE_FWD:
        def_entry.usr_vlan_ptr = 0x1FFF;
        def_entry.usrid_exception_en = 0;
        break;

    case CTC_SECURITY_ACTION_TYPE_COPY_TO_CPU:
        def_entry.usr_vlan_ptr = 0x1FFF;
        def_entry.usrid_exception_en = 1;
        break;

    case CTC_SECURITY_ACTION_TYPE_REDIRECT_TO_CPU:
        def_entry.usr_vlan_ptr = 0x1FFF;
        def_entry.by_pass_all = 1;
        def_entry.fwd_ptr_valid = 1;
        def_entry.binding_data_l.fwd_ptr = 0xFFFF;
        def_entry.usrid_exception_en = 1;
        break;

    case CTC_SECURITY_ACTION_TYPE_DISCARD:     /*discard in usrid*/
        def_entry.usr_vlan_ptr = 0x1FFF;
        def_entry.by_pass_all = 0;
        def_entry.fwd_ptr_valid = 1;
        def_entry.binding_data_l.fwd_ptr = 0xFFFE;
        def_entry.usrid_exception_en = 0;
        break;

    default:
        break;
    }

    if (CTC_IP_VER_4 == ip_ver)
    {
        for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
        {
            sys_humber_usrid_add_ipv4_default_entry_per_label(lchip, SYS_USRID_RESERVE_LABEL_FOR_IPSG, &def_entry);
        }
    }
    else if (CTC_IP_VER_6 == ip_ver)
    {
        for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
        {
            sys_humber_usrid_add_ipv6_default_entry_per_label(lchip, SYS_USRID_RESERVE_LABEL_FOR_IPSG, &def_entry);
        }
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

int32
sys_humber_ip_source_guard_remove_default_entry(uint8 ip_ver)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;

    SYS_SECURITY_INIT_CHECK();

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("ip version:%d\n", ip_ver);

    lchip_num = sys_humber_get_local_chip_num();

    if (CTC_IP_VER_4 == ip_ver)
    {
        for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
        {
            sys_humber_usrid_delete_ipv4_default_entry_per_label(lchip, SYS_USRID_RESERVE_LABEL_FOR_IPSG);
        }
    }
    else if (CTC_IP_VER_6 == ip_ver)
    {
        for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
        {
            sys_humber_usrid_delete_ipv6_default_entry_per_label(lchip, SYS_USRID_RESERVE_LABEL_FOR_IPSG);
        }
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

/*storm control*/
int32
sys_humber_storm_ctl_set_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    uint8 lchip;
    uint8 lport;
    uint16 storm_ctl_ptr = 0;
    ds_storm_ctl_table_t storm_ctl;
    uint32 core_frequency;
    uint32 unit = 0;
    uint32 cmd = 0;

    SYS_SECURITY_INIT_CHECK();
    SYS_MAP_GPORT_TO_LPORT(stmctl_cfg->gport, lchip, lport);

    /*ucast mode judge*/
    if (security_master->stmctl_cfg.ustorm_ctl_mode)
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_ALL_UCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_KNOWN_UCAST
            || stmctl_cfg->type == CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    /*Mcast mode judge*/
    if (security_master->stmctl_cfg.mstorm_ctl_mode)
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_ALL_MCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_KNOWN_MCAST
            || stmctl_cfg->type == CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    switch (stmctl_cfg->type)
    {
    case CTC_SECURITY_STORM_CTL_KNOWN_MCAST:
        storm_ctl_ptr = (1 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST:
    case CTC_SECURITY_STORM_CTL_ALL_MCAST:
        storm_ctl_ptr = (2 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_KNOWN_UCAST:
        storm_ctl_ptr = (3 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST:
    case CTC_SECURITY_STORM_CTL_ALL_UCAST:
        storm_ctl_ptr = (4 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_BCAST:
        storm_ctl_ptr = (0 << 6) | (lport & 0x3F);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_STORM_CTL_TABLE, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, storm_ctl_ptr, cmd, &storm_ctl));

    storm_ctl.storm_en = stmctl_cfg->storm_en ? 1 : 0;
    storm_ctl.exception_en = stmctl_cfg->discarded_to_cpu ? 1 : 0;
    storm_ctl.use_packet_count = stmctl_cfg->mode == CTC_SECURITY_STORM_CTL_MODE_PPS ? 1 : 0;

    core_frequency = drv_humber_get_core_freq(lchip);
    unit = core_frequency * 1000000 / ((SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM + 1) * (SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD + 1));
    storm_ctl.threshold = stmctl_cfg->threshold / unit;

    cmd = DRV_IOW(IOC_TABLE, DS_STORM_CTL_TABLE, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, storm_ctl_ptr, cmd, &storm_ctl));
    return CTC_E_NONE;
}

int32
sys_humber_storm_ctl_get_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    ds_storm_ctl_table_t storm_ctl;
    uint8 lchip;
    uint8 lport;
    uint16 storm_ctl_ptr = 0;
    uint32 core_frequency;
    uint32 unit = 0;
    uint32 cmd = 0;

    SYS_SECURITY_INIT_CHECK();
    SYS_MAP_GPORT_TO_LPORT(stmctl_cfg->gport, lchip, lport);

    /*ucast mode judge*/
    if (security_master->stmctl_cfg.ustorm_ctl_mode)
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_ALL_UCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_KNOWN_UCAST
            || stmctl_cfg->type == CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    /*Mcast mode judge*/
    if (security_master->stmctl_cfg.mstorm_ctl_mode)
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_ALL_MCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }
    else
    {
        if (stmctl_cfg->type == CTC_SECURITY_STORM_CTL_KNOWN_MCAST
            || stmctl_cfg->type == CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST)
        {
            return CTC_E_INVALID_PARAM;
        }
    }

    switch (stmctl_cfg->type)
    {
    case CTC_SECURITY_STORM_CTL_KNOWN_MCAST:
        storm_ctl_ptr = (1 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST:
    case CTC_SECURITY_STORM_CTL_ALL_MCAST:
        storm_ctl_ptr = (2 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_KNOWN_UCAST:
        storm_ctl_ptr = (3 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST:
    case CTC_SECURITY_STORM_CTL_ALL_UCAST:
        storm_ctl_ptr = (4 << 6) | (lport & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_BCAST:
        storm_ctl_ptr = (0 << 6) | (lport & 0x3F);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    cmd = DRV_IOR(IOC_TABLE, DS_STORM_CTL_TABLE, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, storm_ctl_ptr, cmd, &storm_ctl));

    core_frequency = drv_humber_get_core_freq(lchip);
    unit = core_frequency * 1000000 / ((SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM + 1) * (SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD + 1));

    stmctl_cfg->storm_en = storm_ctl.storm_en;
    stmctl_cfg->discarded_to_cpu = storm_ctl.exception_en;
    stmctl_cfg->mode = storm_ctl.use_packet_count ? CTC_SECURITY_STORM_CTL_MODE_PPS : CTC_SECURITY_STORM_CTL_MODE_BPS;
    stmctl_cfg->threshold = unit * storm_ctl.threshold;
    return CTC_E_NONE;

}

int32
sys_humber_storm_ctl_set_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 value = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_glb_cfg);

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("ipg_en%d ustorm_ctl_mode:%d,mstorm_ctl_mode:%d\n", p_glb_cfg->ipg_en, p_glb_cfg->ustorm_ctl_mode, p_glb_cfg->mstorm_ctl_mode);

    lchip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        value = p_glb_cfg->ipg_en ? 1 : 0;
        cmd = DRV_IOW(IOC_REG, IPE_BRIDGE_STORM_CTL, IPE_BRIDGE_STORM_CTL_IPG_EN);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &value));

        value = p_glb_cfg->ustorm_ctl_mode ? 1 : 0;
        cmd = DRV_IOW(IOC_REG, IPE_BRIDGE_CTL, IPE_BRIDGE_CTL_UCAST_STORM_CTRL_MODE);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &value));

        value = p_glb_cfg->mstorm_ctl_mode ? 1 : 0;
        cmd = DRV_IOW(IOC_REG, IPE_BRIDGE_CTL, IPE_BRIDGE_CTL_MCAST_STORM_CTRL_MODE);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &value));

    }

    security_master->stmctl_cfg.ustorm_ctl_mode = p_glb_cfg->ustorm_ctl_mode;
    security_master->stmctl_cfg.mstorm_ctl_mode = p_glb_cfg->mstorm_ctl_mode;
    return CTC_E_NONE;

}

int32
sys_humber_storm_ctl_get_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{

    uint32 cmd = 0;
    uint32 value = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_glb_cfg);

    SYS_SECURITY_DBG_FUNC();

    cmd = DRV_IOR(IOC_REG, IPE_BRIDGE_STORM_CTL, IPE_BRIDGE_STORM_CTL_IPG_EN);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &value));
    p_glb_cfg->ipg_en = value;

    cmd = DRV_IOR(IOC_REG, IPE_BRIDGE_CTL, IPE_BRIDGE_CTL_UCAST_STORM_CTRL_MODE);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &value));
    p_glb_cfg->ustorm_ctl_mode = value;

    cmd = DRV_IOR(IOC_REG, IPE_BRIDGE_CTL, IPE_BRIDGE_CTL_MCAST_STORM_CTRL_MODE);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &value));
    p_glb_cfg->mstorm_ctl_mode = value;

    SYS_SECURITY_DBG_INFO("ipg_en%d ustorm_ctl_mode:%d,mstorm_ctl_mode:%d\n", p_glb_cfg->ipg_en, p_glb_cfg->ustorm_ctl_mode, p_glb_cfg->mstorm_ctl_mode);
    return CTC_E_NONE;
}

int32
sys_humber_port_isolation_set_route_obey_isolated_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_INIT_CHECK();

    tmp = enable ? 1 : 0;

    if (tmp != security_master->port_iso_rut_obey)
    {
        lchip_num = sys_humber_get_local_chip_num();
        cmd = DRV_IOW(IOC_REG, EPE_NEXT_HOP_CTL, EPE_NEXT_HOP_CTL_ROUTE_OBEY_ISOLATE);

        for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
        {
            CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));
        }

        security_master->port_iso_rut_obey = tmp;
    }

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_humber_port_isolation_get_route_obey_isolated_en(bool* p_enable)
{
    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_enable);

    *p_enable = security_master->port_iso_rut_obey;

    return CTC_E_NONE;
}

/*arp snooping*/
int32
sys_humber_arp_snooping_set_address_check_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_INIT_CHECK();

    tmp = enable ? 1 : 0;

    lchip_num = sys_humber_get_local_chip_num();
    cmd = DRV_IOW(IOC_REG, IPE_INTF_MAPPER_CTL, IPE_INTF_MAPPER_CTL_ARP_ADDRESS_CHECK_EN);

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));
    }

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_humber_arp_snooping_set_address_check_exception_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_INIT_CHECK();

    tmp = enable ? 1 : 0;

    lchip_num = sys_humber_get_local_chip_num();
    cmd = DRV_IOW(IOC_REG, IPE_INTF_MAPPER_CTL, IPE_INTF_MAPPER_CTL_ARP_CHECK_EXCEPTION_EN);

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));
    }

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_humber_security_init(void)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;
    uint32 core_frequency = 0;

    ipe_bridge_storm_ctl_t storm_brg_ctl;

    if (NULL != security_master)
    {
        return CTC_E_NONE;
    }

    MALLOC_POINTER(sys_security_master_t, security_master);
    if (NULL == security_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(security_master, 0, sizeof(sys_security_master_t));

    /*init default storm cfg*/
    core_frequency = drv_humber_get_core_freq(lchip);

    lchip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        cmd = DRV_IOR(IOC_REG, IPE_BRIDGE_STORM_CTL, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &storm_brg_ctl));
        storm_brg_ctl.ipg_en = 1;
        storm_brg_ctl.max_port_num = SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM;
        storm_brg_ctl.max_update_port_num = SYS_SECURITY_STMCTL_DEF_MAX_UPDT_PORT_NUM;
        storm_brg_ctl.storm_ctl_upd_en = 1;
        storm_brg_ctl.oam_obey_storm_ctl = 0;
        storm_brg_ctl.update_threshold = SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD;

        cmd = DRV_IOW(IOC_REG, IPE_BRIDGE_STORM_CTL, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &storm_brg_ctl));
    }

    cmd = DRV_IOR(IOC_REG, EPE_NEXT_HOP_CTL, EPE_NEXT_HOP_CTL_ROUTE_OBEY_ISOLATE);
    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &tmp));
    security_master->port_iso_rut_obey = tmp;

    /*add default entry for ip-src-guard(label 63)*/
    CTC_ERROR_RETURN(sys_humber_ip_source_guard_add_default_entry(CTC_IP_VER_4, CTC_SECURITY_ACTION_TYPE_DISCARD));
    CTC_ERROR_RETURN(sys_humber_ip_source_guard_add_default_entry(CTC_IP_VER_6, CTC_SECURITY_ACTION_TYPE_DISCARD));

    return CTC_E_NONE;
}

