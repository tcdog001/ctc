/**
 @file ctc_humber_ptp.c

 @date 2010-6-7

 @version v2.0

  This file contains PTP sys layer function implementation
*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "ctc_ptp.h"         /* ctc layer PTP ds */
#include "ctc_error.h"
#include "sys_humber_ptp.h"  /* sys ds for all PTP sub modules */
#include "sys_humber_port.h"
#include "drv_humber.h"
#include "drv_io.h"
#include "drv_tbl_reg.h"
#include "sys_humber_chip.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
#define MAX_DRIFT_VALUE 0.5
#define MAX_DRIFT_RATE_VALUE 0x40000000
#define MAX_NS_OR_NNS_VALUE 1000000000
#define MAX_BIT_VALUE (5 * 100000000)
#define MAX_HEART_BEAT_THRESHOLD (0x1FFFFFF)
#define MAX_SYNC_CLOCK_FREQUENCY_HZ (25000000)

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
#define PTP_LOCK \
    if (p_sys_ptp_master->ptp_mutex) sal_mutex_lock(p_sys_ptp_master->ptp_mutex)
#define PTP_UNLOCK \
    if (p_sys_ptp_master->ptp_mutex) sal_mutex_unlock(p_sys_ptp_master->ptp_mutex)

#define SYS_PTP_DBG_INFO(FMT, ...)                          \
    {                                                      \
        CTC_DEBUG_OUT_INFO(ptp, ptp, PTP_PTP_SYS, FMT, ##__VA_ARGS__); \
    }

#define SYS_PTP_DBG_DUMP(FMT, ...)                          \
    {                                                      \
        CTC_DEBUG_OUT(ptp, ptp, PTP_PTP_SYS, CTC_DEBUG_LEVEL_DUMP, FMT, ##__VA_ARGS__); \
    }

#define SYS_PTP_DBG_FUNC()                          \
    { \
        CTC_DEBUG_OUT_FUNC(ptp, ptp, PTP_PTP_SYS); \
    }

#define SYS_PTP_INIT_CHECK() \
    do { \
        if (!p_sys_ptp_master) \
        { \
            return CTC_E_PTP_NOT_INIT; \
        } \
    } while (0)
#define SYS_PTP_LCHIP_CHECK(val) \
    do { \
        if (val >= sys_humber_get_local_chip_num()){ \
            return CTC_E_INVALID_LOCAL_CHIPID; } \
    } while (0)

#define CTC_ERROR_RETURN_PTP_UNLOCK(op) \
    { \
        int32 rv = (op); \
        if (rv < 0) \
        { \
            if (p_sys_ptp_master->ptp_mutex){sal_mutex_unlock(p_sys_ptp_master->ptp_mutex); } \
            return (rv); \
        } \
    }

/****************************************************************************
*
* Data structures
*
****************************************************************************/

/**
 @brief  Define sys layer ethernet PTP global configure data structure
*/
struct sys_ptp_master_s
{
    sal_mutex_t* ptp_mutex;
    ctc_ptp_time_t frc_offset;
    uint8 ptp_quanta[CTC_MAX_LOCAL_CHIP_NUM];
};
typedef struct sys_ptp_master_s sys_ptp_master_t;

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
static sys_ptp_master_t* p_sys_ptp_master;

extern uint8 drv_humber_get_ptp_quanta(uint8 lchip);
extern uint8 drv_humber_get_ptp_quanta_ratio(uint8 lchip);
/****************************************************************************
 *
* Function
*
*****************************************************************************/

static int32
_sys_humber_ptp_translate_frc_rate(uint32 nns, uint32* drift_rate)
{
    uint32 rate = 0;
    int8 bit_index = 0;
    uint32 bit_value = MAX_BIT_VALUE;

    for (bit_index = 29; bit_index >= 0; bit_index--)
    {
        if (nns >= bit_value)
        {
            rate |= (1 << bit_index);
            nns -= bit_value;
        }

        bit_value = bit_value / 2;
    }

    *drift_rate = rate;

    return 0;
}

static int32
_sys_humber_ptp_inverse_translate_frc_rate(uint32 drift_rate, uint32* nns)
{
    int8 bit_index = 0;
    uint32 bit_value = MAX_BIT_VALUE;

    *nns = 0;

    for (bit_index = 29; bit_index >= 0; bit_index--)
    {
        if (drift_rate & (1 << bit_index))
        {
            *nns += bit_value;
        }

        bit_value = bit_value / 2;
    }

    return 0;
}

/**
 @brief  PTP init
*/
int32
sys_humber_ptp_init(ctc_ptp_global_config_t* ptp_global_cfg)
{
    uint8 local_chip_num = 0;
    uint8 lchip = 0;
    uint32 cmd = 0;
    int32 ret  = 0;
    uint32 field_value = 0;
    uint8 ptp_quanta_ratio = 1;
    ptp_frc_ctl_t frc_ctl;
    ptp_sync_intf_capture_ctl_t capture_ctl;
    ptp_sync_intf_cfg_t sync_intf_cfg;
    ptp_sync_intf_heart_beat_cfg_t intf_heart_beat_cfg;

    if (!ptp_global_cfg)
    {
        return CTC_E_INVALID_PTR;
    }

    /* create ptp master */
    p_sys_ptp_master = (sys_ptp_master_t*)mem_malloc(MEM_PTP_MODULE, sizeof(sys_ptp_master_t));
    if (NULL == p_sys_ptp_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_sys_ptp_master, 0, sizeof(sys_ptp_master_t));

    ret = sal_mutex_create(&(p_sys_ptp_master->ptp_mutex));
    if (ret || !(p_sys_ptp_master->ptp_mutex))
    {
        mem_free(p_sys_ptp_master);

        return CTC_E_FAIL_CREATE_MUTEX;
    }

    /* init ptp registers */
    local_chip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < local_chip_num; lchip++)
    {
        p_sys_ptp_master->ptp_quanta[lchip] = drv_humber_get_ptp_quanta(lchip);
        if (0 == p_sys_ptp_master->ptp_quanta[lchip])
        {
            p_sys_ptp_master->ptp_quanta[lchip] = 8;
        }

        ptp_quanta_ratio = drv_humber_get_ptp_quanta_ratio(lchip);

        /* PTP_MAC_TX_CAPTURE_TS_CTL */
        field_value = 1; /* always capture ts, ignore ptpMsgTxRdy*/
        cmd = DRV_IOW(IOC_REG, PTP_MAC_TX_CAPTURE_TS_CTL, PTP_MAC_TX_CAPTURE_TS_CTL_IGNORE_TX_RDY);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

        /* PTP Quanta */
        field_value = ptp_quanta_ratio * p_sys_ptp_master->ptp_quanta[lchip];
        cmd = DRV_IOW(IOC_REG, PTP_QUANTA, PTP_QUANTA_QUANTA);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

        /* PTP_FRC_CTL */
        sal_memset(&frc_ctl, 0, sizeof(frc_ctl));
        frc_ctl.frc_en = 1;
        if (ptp_global_cfg->ntpv4_en)
        {
            frc_ctl.ptp_ntp_v4_en = 1;
        }
        else
        {
            frc_ctl.ptp_ntp_v4_en = 0;
        }

        cmd = DRV_IOW(IOC_REG, PTP_FRC_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc_ctl));

        /*init sync interface*/
        sal_memset(&sync_intf_cfg, 0, sizeof(sync_intf_cfg));
        sync_intf_cfg.sync_intf_clk_en = 1;
        sync_intf_cfg.time_code_enable = 1;
        cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &sync_intf_cfg));

        sal_memset(&intf_heart_beat_cfg, 0, sizeof(intf_heart_beat_cfg));
        intf_heart_beat_cfg.heart_beat_enable = 1;
        cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_HEART_BEAT_CFG, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &intf_heart_beat_cfg));

        field_value = 0;
        cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CAPTURE_CTL, PTP_SYNC_INTF_CAPTURE_CTL_INTR_EN);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

        /* PTP_SYNC_INTF_CAPTURE_CTL */
        sal_memset(&capture_ctl, 0, sizeof(capture_ctl));
        capture_ctl.intr_en = 0; /* enable interrupt when receive a heart beat */
        capture_ctl.ts_capture_mode = 2; /* capture on rising edge of heartBeat */
        cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CAPTURE_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &capture_ctl));
    }

    return CTC_E_NONE;
}

/**
 @brief  Get the captured timestamp for tx ptp message from CPU, supposed to be called in interrupt context
*/
int32
sys_humber_ptp_get_captured_tx_ts(uint8 lchip, ctc_ptp_capured_ts_t* p_ts)
{
    uint32 cmd = 0;
    ptp_mac_tx_capture_ts_t tx_ts;
    ptp_mac_tx_capture_ts_status_t tx_status;
    ptp_frc_t current_frc;
    ctc_ptp_time_t current_frc_adjusted;
    int64 current_time = 0;
    int64 tx_ts_ns = 0;

    SYS_PTP_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_ts);

    PTP_LOCK;
    sal_memset(&tx_status, 0, sizeof(tx_status));
    cmd = DRV_IOR(IOC_REG, PTP_MAC_TX_CAPTURE_TS_STATUS, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &tx_status));

    if (tx_status.ptp_msg_tx_rdy)
    {
        sal_memset(&tx_ts, 0, sizeof(tx_ts));
        cmd = DRV_IOR(IOC_REG, PTP_MAC_TX_CAPTURE_TS, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &tx_ts));

        p_ts->ts.seconds      = tx_ts.tx_ts_second;
        p_ts->ts.nanoseconds  = tx_ts.tx_ts_ns;
        p_ts->u.lport          = tx_ts.tx_mac_num;
    }
    else
    {
        PTP_UNLOCK;
        return CTC_E_PTP_TS_NOT_READY;
    }

    sal_memset(&current_frc, 0, sizeof(current_frc));
    sal_memset(&current_frc_adjusted, 0, sizeof(current_frc_adjusted));
    cmd = DRV_IOR(IOC_REG, PTP_FRC, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &current_frc));

    /*FRC_OFFSET.ns is a value between 0 ~ 1e9*/
    current_frc_adjusted.nanoseconds = current_frc.frc_ns + p_sys_ptp_master->frc_offset.nanoseconds;
    if (current_frc_adjusted.nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        current_frc_adjusted.nanoseconds -= MAX_NS_OR_NNS_VALUE;
        current_frc_adjusted.seconds++;
    }

    /*ASIC use overflow stand for subtraction*/
    current_frc_adjusted.seconds += (current_frc.frc_second + p_sys_ptp_master->frc_offset.seconds);
    PTP_UNLOCK;

    current_time = 1LL * MAX_NS_OR_NNS_VALUE * current_frc_adjusted.seconds + current_frc_adjusted.nanoseconds;
    tx_ts_ns = 1LL * MAX_NS_OR_NNS_VALUE * tx_ts.tx_ts_second + tx_ts.tx_ts_ns;
    if (current_time - tx_ts_ns > MAX_NS_OR_NNS_VALUE)
    {
        p_ts->ts.seconds += 1;
        return CTC_E_PTP_TX_TS_ROLL_OVER_FAILURE;
    }

    return CTC_E_NONE;
}

/**
 @brief  Adjust humber's FRC offset
*/
int32
sys_humber_ptp_adjust_clock_offset(uint8 lchip, ctc_ptp_time_t* p_offset)
{
    uint32 cmd  = 0;
    ptp_offset_adjust_t ptp_offset;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_offset);

    if (p_offset->nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        return CTC_E_PTP_EXCEED_MAX_FRACTIONAL_VALUE;
    }

    PTP_LOCK;
    cmd = DRV_IOR(IOC_REG, PTP_OFFSET_ADJUST, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_offset));

    if (p_offset->is_negative) /* sub */
    {
        if (ptp_offset.offset_ns < p_offset->nanoseconds) /* not enough for minus */
        {
            ptp_offset.offset_ns = ptp_offset.offset_ns + MAX_NS_OR_NNS_VALUE - p_offset->nanoseconds;
            ptp_offset.offset_second -= p_offset->seconds;
            ptp_offset.offset_second--;
        }
        else
        {
            ptp_offset.offset_second -= p_offset->seconds;
            ptp_offset.offset_ns     -= p_offset->nanoseconds;
        }
    }
    else
    {
        if ((ptp_offset.offset_ns + p_offset->nanoseconds) >= MAX_NS_OR_NNS_VALUE)
        {
            ptp_offset.offset_ns = ptp_offset.offset_ns + p_offset->nanoseconds - MAX_NS_OR_NNS_VALUE;
            ptp_offset.offset_second += p_offset->seconds;
            ptp_offset.offset_second++;
        }
        else
        {
            ptp_offset.offset_second += p_offset->seconds;
            ptp_offset.offset_ns     += p_offset->nanoseconds;
        }
    }

    cmd = DRV_IOW(IOC_REG, PTP_OFFSET_ADJUST, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_offset));

    p_sys_ptp_master->frc_offset.seconds = ptp_offset.offset_second;
    p_sys_ptp_master->frc_offset.nanoseconds = ptp_offset.offset_ns;

    PTP_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief  Set humber's FRC offset
*/
int32
sys_humber_ptp_set_frc_offset(uint8 lchip, ctc_ptp_time_t* p_frc_offset)
{
    uint32 cmd  = 0;
    ptp_offset_adjust_t ptp_offset;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_frc_offset);

    if (p_frc_offset->nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        return CTC_E_PTP_EXCEED_MAX_FRACTIONAL_VALUE;
    }

    PTP_LOCK;

    ptp_offset.offset_second = p_frc_offset->seconds;
    ptp_offset.offset_ns     = p_frc_offset->nanoseconds;

    cmd = DRV_IOW(IOC_REG, PTP_OFFSET_ADJUST, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_offset));

    p_sys_ptp_master->frc_offset.seconds = ptp_offset.offset_second;
    p_sys_ptp_master->frc_offset.nanoseconds = ptp_offset.offset_ns;

    PTP_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief  Get humber's FRC offset
*/
int32
sys_humber_ptp_get_frc_offset(uint8 lchip, ctc_ptp_time_t* p_frc_offset)
{
    uint32 cmd  = 0;
    ptp_offset_adjust_t ptp_offset;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_frc_offset);

    PTP_LOCK;

    cmd = DRV_IOR(IOC_REG, PTP_OFFSET_ADJUST, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_offset));

    p_frc_offset->seconds = ptp_offset.offset_second;
    p_frc_offset->nanoseconds = ptp_offset.offset_ns;

    PTP_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief  Set humber's FRC drift
*/
int32
sys_humber_ptp_set_clock_drift(uint8 lchip, ctc_ptp_time_t* p_drift)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint64 drift_rate = 0;
    uint64 drift_ns = 0;
    ptp_drift_adjust_t ptp_drift;

    sal_memset(&ptp_drift, 0, sizeof(ptp_drift));

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_drift);

    if (p_drift->nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        return CTC_E_PTP_EXCEED_MAX_FRACTIONAL_VALUE;
    }

    PTP_LOCK;
    drift_ns = p_drift->nanoseconds;
    drift_rate = drift_ns * p_sys_ptp_master->ptp_quanta[lchip];

    if (drift_rate >= MAX_NS_OR_NNS_VALUE)
    {
        ret = CTC_E_PTP_EXCEED_MAX_DRIFT_VALUE;
    }
    else
    {
        ptp_drift.sign = p_drift->is_negative ? 1 : 0;
        ptp_drift.drift_rate = drift_rate & 0xFFFFFFFF;
        /*adjust frc drift */
        cmd = DRV_IOW(IOC_REG, PTP_DRIFT_ADJUST, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_drift));
    }

    PTP_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief  Get humber's FRC drift
*/
int32
sys_humber_ptp_get_clock_drift(uint8 lchip, ctc_ptp_time_t* p_drift)
{
    uint32 cmd = 0;
    ptp_drift_adjust_t ptp_drift;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_drift);

    sal_memset(&ptp_drift, 0, sizeof(ptp_drift));

    PTP_LOCK;
    cmd = DRV_IOR(IOC_REG, PTP_DRIFT_ADJUST, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &ptp_drift));
    /*calculate drift,drift = drift_rate / quanta */
    p_drift->seconds = 0;
    p_drift->nanoseconds = ptp_drift.drift_rate / p_sys_ptp_master->ptp_quanta[lchip];
    p_drift->nano_nanoseconds = 0;
    p_drift->is_negative = ptp_drift.sign ? 1 : 0;
    PTP_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief  enable ptp port
*/
int32
sys_humber_ptp_port_enable(uint16 gport, bool ptp_enable)
{
    CTC_ERROR_RETURN(sys_humber_port_set_ptp_en(gport, ptp_enable));
    return CTC_E_NONE;
}

/**
 @brief  Configure ptp sync interface properties
*/
int32
sys_humber_ptp_set_sync_intf(uint8 lchip, ctc_ptp_sync_intf_cfg_t* p_config)
{
    uint32 cmd  = 0;
    ptp_sync_intf_cfg_t intf_cfg;
    ptp_sync_intf_heart_beat_cfg_t intf_heart_beat_cfg;
    ptp_sync_intf_half_period_t intf_half_period;

    sal_memset(&intf_cfg, 0, sizeof(intf_cfg));
    sal_memset(&intf_heart_beat_cfg, 0, sizeof(intf_heart_beat_cfg));
    sal_memset(&intf_half_period, 0, sizeof(intf_half_period));

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_config);

    if ((p_config->sync_clock_hz > MAX_SYNC_CLOCK_FREQUENCY_HZ) || (p_config->sync_clock_hz < 1))
    {
        return CTC_E_PTP_SYNC_SIGNAL_FREQUENCY_OUT_OF_RANGE;
    }

    if ((p_config->sync_pulse_duty > 99) || (p_config->sync_pulse_duty < 1))
    {
        return CTC_E_PTP_SYNC_SIGNAL_DUTY_OUT_OF_RANGE;
    }

    if (((p_config->accuracy > 49) || (p_config->accuracy < 32)) && (p_config->accuracy != 0xFE))
    {
        return CTC_E_PTP_INVALID_SYNC_INTF_ACCURACY_VALUE;
    }

    if (p_config->epoch >= 63)
    {
        return CTC_E_PTP_INVALID_SYNC_INTF_EPOCH_VALUE;
    }

    PTP_LOCK;
    /*set sync interface as input mode*/
    cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));
    intf_cfg.sync_intf_mode = 0;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));

    /* set sync interface config */
    sal_memset(&intf_cfg, 0, sizeof(intf_cfg));
    intf_cfg.sync_intf_mode   = p_config->mode ? 1 : 0;
    intf_cfg.lock             = p_config->lock ? 1 : 0;
    intf_cfg.epoch            = p_config->epoch;
    intf_cfg.accuracy         = p_config->accuracy;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));

    /* calculate syncClock half period */
    intf_half_period.sync_ns = MAX_NS_OR_NNS_VALUE / (p_config->sync_clock_hz * 2);
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_HALF_PERIOD, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_half_period));

    /*calculate syncPulse duty*/
    intf_heart_beat_cfg.heart_beat_threshold = (MAX_HEART_BEAT_THRESHOLD * p_config->sync_pulse_duty) / 100;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_HEART_BEAT_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_heart_beat_cfg));

    PTP_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief  Set ptp sync interface's toggle time
*/
int32
sys_humber_ptp_set_sync_intf_toggle_time(uint8 lchip, ctc_ptp_time_t* p_toggle_time)
{
    uint32 cmd  = 0;
    uint32 fractional_value = 0;
    ptp_sync_intf_toggle_time_t intf_toggle_time;
    ptp_sync_intf_cfg_t intf_cfg;

    sal_memset(&intf_cfg, 0, sizeof(intf_cfg));
    sal_memset(&intf_toggle_time, 0, sizeof(intf_toggle_time));

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_toggle_time);

    if (p_toggle_time->nanoseconds >= MAX_NS_OR_NNS_VALUE || p_toggle_time->nano_nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        SYS_PTP_DBG_INFO("toggle_ns=%d, toggle_nns=%d\n", p_toggle_time->nanoseconds, p_toggle_time->nano_nanoseconds);

        return CTC_E_PTP_EXCEED_MAX_FRACTIONAL_VALUE;
    }

    sal_memset(&intf_toggle_time, 0, sizeof(intf_toggle_time));

    PTP_LOCK;
    /*set sync interface as input mode*/
    cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));
    intf_cfg.sync_intf_mode = 0;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));

    /* PTP_SYNC_INTF_TOGGLE_TIME */
    intf_toggle_time.sync_intf_toggle_second  = p_toggle_time->seconds;
    intf_toggle_time.sync_intf_toggle_ns      = p_toggle_time->nanoseconds;
    _sys_humber_ptp_translate_frc_rate(p_toggle_time->nano_nanoseconds, &fractional_value);
    intf_toggle_time.sync_intf_toggle_frac_ns = fractional_value;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_TOGGLE_TIME, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_toggle_time));

    /*set sync interface as output mode*/
    intf_cfg.sync_intf_mode = 1;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CFG, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_cfg));
    PTP_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief  Get ptp sync interface's toggle time
*/
int32
sys_humber_ptp_get_sync_intf_toggle_time(uint8 lchip, ctc_ptp_time_t* p_toggle_time)
{
    /* NOTE: frac ns is not translated, it is read as register value */
    uint32 cmd  = 0;
    ptp_sync_intf_toggle_time_t intf_toggle_time;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_toggle_time);

    sal_memset(&intf_toggle_time, 0, sizeof(intf_toggle_time));

    PTP_LOCK;
    /* PTP_SYNC_INTF_TOGGLE_TIME */
    cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_TOGGLE_TIME, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &intf_toggle_time));

    p_toggle_time->seconds = intf_toggle_time.sync_intf_toggle_second;
    p_toggle_time->nanoseconds = intf_toggle_time.sync_intf_toggle_ns;
    _sys_humber_ptp_inverse_translate_frc_rate(intf_toggle_time.sync_intf_toggle_frac_ns, &p_toggle_time->nano_nanoseconds);

    PTP_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief  Get ptp sync interface's input timestamp if in input mode,
 supposed to be called in interrupt context
*/
int32
sys_humber_ptp_get_sync_intf_code(uint8 lchip, ctc_ptp_sync_intf_code_t* p_time_code)
{
    uint32 cmd  = 0;
    ptp_sync_intf_input_ts_t intf_ts;
    uint32 field_value = 0;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_time_code);

    cmd = DRV_IOR(IOC_REG, PTP_INTERRUPT, PTP_INTERRUPT_VALUE_SET);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

    if (field_value & 0x2)
    {
        sal_memset(&intf_ts, 0, sizeof(intf_ts));
        cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_INPUT_TS, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &intf_ts));

        p_time_code->seconds     = (intf_ts.data88_to64 & 0xffffff) << 24 | (intf_ts.data63_to32 & 0xffffff00) >> 8;
        p_time_code->nanoseconds = (intf_ts.data63_to32 & 0xff) << 24 | (intf_ts.data31_to0 & 0xffffff00) >> 8;
        p_time_code->lock        = intf_ts.data88_to64 >> 24;
        p_time_code->accuracy    = intf_ts.data31_to0 & 0xff;
        p_time_code->crc_error   = intf_ts.crc_err;
        p_time_code->crc         = intf_ts.crc;
        return CTC_E_NONE;
    }
    else
    {
        return CTC_E_UNEXPECT;
    }
}

/**
 @brief  Get humber's captured frc upon the rising edge of heartbeat from Sync interface,
 supposed to be called in interrupt context
*/
int32
sys_humber_ptp_get_captured_frc_ts(uint8 lchip, ctc_ptp_time_t* p_ts)
{
    uint32 cmd  = 0;
    ptp_sync_intf_capture_frc_ts_t frc_ts;
    uint32 field_value = 0;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_ts);

    cmd = DRV_IOR(IOC_REG, PTP_INTERRUPT, PTP_INTERRUPT_VALUE_SET);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

    sal_memset(&frc_ts, 0, sizeof(frc_ts));
    cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_CAPTURE_FRC_TS, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc_ts));

    p_ts->seconds      = frc_ts.capture_frc_second;
    p_ts->nanoseconds  = frc_ts.capture_frc_ns;

    return CTC_E_NONE;
}

/**
 @brief  Get humber's captured adjusted frc upon the rising edge of heartbeat from Sync interface,
 supposed to be called in interrupt context
*/
int32
sys_humber_ptp_get_captured_rx_ts(uint8 lchip, ctc_ptp_time_t* p_ts)
{
    uint32 cmd  = 0;
    ptp_sync_intf_capture_adj_frc_ts_t frc_ts;
    uint32 field_value = 0;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();
    CTC_PTR_VALID_CHECK(p_ts);

    cmd = DRV_IOR(IOC_REG, PTP_INTERRUPT, PTP_INTERRUPT_VALUE_SET);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

    sal_memset(&frc_ts, 0, sizeof(frc_ts));
    cmd = DRV_IOR(IOC_REG, PTP_SYNC_INTF_CAPTURE_ADJ_FRC_TS, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc_ts));

    p_ts->seconds     = frc_ts.capture_adj_frc_second;
    p_ts->nanoseconds = frc_ts.capture_adj_frc_ns;

    return CTC_E_NONE;

}

int32
sys_humber_ptp_show_frc(uint8 gchip)
{
    uint8 lchip = 0;
    uint32 cmd  = 0;
    ptp_frc_t frc;

    SYS_PTP_INIT_CHECK();
    if (!sys_humber_chip_is_local(gchip, &lchip))
    {
        return CTC_E_CHIP_IS_REMOTE;
    }

    sal_memset(&frc, 0, sizeof(frc));
    cmd = DRV_IOR(IOC_REG, PTP_FRC, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc));

    SYS_PTP_DBG_DUMP("frc_second: %u, frc_ns: %u, frc_frac_ns: 0x%x\n", frc.frc_second, frc.frc_ns, frc.frc_frac_ns);

    return CTC_E_NONE;
}

/**
 @brief  Get ptp frc
*/
int32
sys_humber_ptp_get_frc(uint8 lchip, ctc_ptp_time_t* p_frc)
{
    uint32 cmd  = 0;
    ptp_frc_t frc;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    CTC_PTR_VALID_CHECK(p_frc);

    sal_memset(&frc, 0, sizeof(frc));
    sal_memset(p_frc, 0, sizeof(ctc_ptp_time_t));

    cmd = DRV_IOR(IOC_REG, PTP_FRC, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc));

    p_frc->nanoseconds = frc.frc_ns;
    p_frc->seconds = frc.frc_second;

    return CTC_E_NONE;
}

/**
 @brief  Get ptp adjust frc
*/
int32
sys_humber_ptp_get_clock_timestamp(uint8 lchip, ctc_ptp_time_t* p_timestamp)
{
    uint32 cmd  = 0;
    ptp_frc_t frc;

    SYS_PTP_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_timestamp);
    SYS_PTP_LCHIP_CHECK(lchip);

    sal_memset(&frc, 0, sizeof(frc));
    sal_memset(p_timestamp, 0, sizeof(ctc_ptp_time_t));
    cmd = DRV_IOR(IOC_REG, PTP_FRC, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &frc));

    PTP_LOCK;
    /*FRC_OFFSET.ns is a value between 0 ~ 1e9*/
    p_timestamp->seconds = 0;
    p_timestamp->nanoseconds = frc.frc_ns + p_sys_ptp_master->frc_offset.nanoseconds;
    if (p_timestamp->nanoseconds >= MAX_NS_OR_NNS_VALUE)
    {
        p_timestamp->nanoseconds -= MAX_NS_OR_NNS_VALUE;
        p_timestamp->seconds++;
    }

    /*ASIC use overflow stand for subtraction*/
    p_timestamp->seconds += (frc.frc_second + p_sys_ptp_master->frc_offset.seconds);
    PTP_UNLOCK;
    return CTC_E_NONE;
}

/**
 @brief  Get ptp interrupt bitmap
*/
int32
sys_humber_ptp_get_intr_bitmap(uint8 lchip, uint32* ptp_isr_bitmap)
{
    uint32 cmd  = 0;
    uint32 field_value = 0;

    SYS_PTP_LCHIP_CHECK(lchip);

    cmd = DRV_IOR(IOC_REG, PTP_INTERRUPT, PTP_INTERRUPT_VALUE_SET);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_value));

    *ptp_isr_bitmap = field_value;

    return CTC_E_NONE;
}

/**
 @brief  Configure ptp sync interface capture ctl
*/
int32
sys_humber_ptp_sync_intf_set_capture_ctl_mode(uint8 lchip, uint8 capture_mode)
{
    uint32 cmd  = 0;
    uint32 field_value = 0;

    SYS_PTP_INIT_CHECK();
    SYS_PTP_LCHIP_CHECK(lchip);
    SYS_PTP_DBG_FUNC();

    PTP_LOCK;
    field_value = capture_mode;
    cmd = DRV_IOW(IOC_REG, PTP_SYNC_INTF_CAPTURE_CTL, PTP_SYNC_INTF_CAPTURE_CTL_TS_CAPTURE_MODE);
    CTC_ERROR_RETURN_PTP_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &field_value));

    PTP_UNLOCK;
    return CTC_E_NONE;
}

