/**
 @file ctc_greatbelt_mirror.c

 @date 2009-10-21

 @version v2.0

 The file contains all mirror APIs for customers
*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/

#include "ctc_error.h"
#include "ctc_greatbelt_mirror.h"
#include "sys_greatbelt_mirror.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
/****************************************************************************
 *
* Function
*
*****************************************************************************/

/**
 @brief This function is to initialize the mirror module
 */
int32
ctc_greatbelt_mirror_init(uint8 lchip, void* mirror_global_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_init());

    return CTC_E_NONE;
}

/**
 @brief This function is to set mirror enable on port
*/
int32
ctc_greatbelt_mirror_set_port_en(uint8 lchip, uint32 gport, ctc_direction_t dir, bool enable, uint8 session_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_set_port_en(gport, dir, enable, session_id));

    return CTC_E_NONE;
}

/**
 @brief This function is to get the information of port mirror
*/
int32
ctc_greatbelt_mirror_get_port_info(uint8 lchip, uint32 gport, ctc_direction_t dir, bool* enable, uint8* session_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_get_port_info(gport, dir, enable, session_id));

    return CTC_E_NONE;
}

/**
 @brief This function is to set enable mirror on vlan
*/
int32
ctc_greatbelt_mirror_set_vlan_en(uint8 lchip, uint16 vlan_id, ctc_direction_t dir, bool enable, uint8 session_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_set_vlan_en(vlan_id, dir, enable, session_id));

    return CTC_E_NONE;
}

/**
 @brief This function is to get the information of vlan mirror
*/
int32
ctc_greatbelt_mirror_get_vlan_info(uint8 lchip, uint16 vlan_id, ctc_direction_t dir, bool* enable, uint8* session_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_get_vlan_info(vlan_id, dir, enable, session_id));

    return CTC_E_NONE;
}

/**
 @brief This function is to set local mirror destination port
*/
int32
ctc_greatbelt_mirror_add_session(uint8 lchip, ctc_mirror_dest_t* mirror)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_set_dest(mirror));

    return CTC_E_NONE;
}

/**
 @brief Discard some special mirrored packet if enable
*/
int32
ctc_greatbelt_mirror_set_escape_en(uint8 lchip, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_rspan_escape_en(enable));

    return CTC_E_NONE;
}

/**
 @brief Config mac info indicat the mirrored packet is special
*/
int32
ctc_greatbelt_mirror_set_escape_mac(uint8 lchip, ctc_mirror_rspan_escape_t* escape)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_rspan_escape_mac(escape));

    return CTC_E_NONE;
}

/**
 @brief This function is to remove mirror destination port
*/
int32
ctc_greatbelt_mirror_remove_session(uint8 lchip, ctc_mirror_dest_t* mirror)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_unset_dest(mirror));

    return CTC_E_NONE;
}

/**
 @brief This function is to set that whether packet is mirrored when it has been droped
*/
int32
ctc_greatbelt_mirror_set_mirror_discard(uint8 lchip, ctc_direction_t dir, uint16 discard_flag, bool enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_set_mirror_discard(dir, discard_flag, enable));

    return CTC_E_NONE;
}

/**
 @brief This function is to get that whether packet is mirrored when it has been droped
*/
int32
ctc_greatbelt_mirror_get_mirror_discard(uint8 lchip, ctc_direction_t dir, ctc_mirror_discard_t discard_flag, bool* enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_mirror_get_mirror_discard(dir, discard_flag, enable));
    return CTC_E_NONE;
}

