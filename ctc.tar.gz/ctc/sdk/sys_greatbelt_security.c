/**
 @file sys_greatbelt_security.c

 @date 2010-2-26

 @version v2.0

---file comments----
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_port.h"
#include "ctc_vector.h"
#include "sys_greatbelt_opf.h"
#include "ctc_linklist.h"

#include "sys_greatbelt_security.h"
#include "sys_greatbelt_port.h"
#include "sys_greatbelt_vlan.h"
#include "sys_greatbelt_scl.h"
#include "sys_greatbelt_chip.h"
#include "sys_greatbelt_common.h"
#include "sys_greatbelt_ftm.h"

#include "drv_tbl_reg.h"
#include "drv_io.h"
#include "drv_enum.h"

/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/

/**
 @brief define hash lookup type for scl
*/
enum sys_port_scl_hash_type_e
{
    SYS_PORT_HASH_SCL_MAC_SA          = 0x6,    /**< MACSA */
    SYS_PORT_HASH_SCL_PORT_MAC_SA     = 0x7,    /**< Port+MACSA 160bit */
    SYS_PORT_HASH_SCL_IPV4_SA         = 0x8,    /**< Ip4SA */
    SYS_PORT_HASH_SCL_PORT_IPV4_SA    = 0x9,    /**< Port+IPv4SA */
    SYS_PORT_HASH_SCL_MAX
};
typedef enum sys_port_scl_hash_type_e sys_port_scl_hash_type_t;

#define SYS_SECURITY_STMCTL_DEF_UPDATE_EN     1
#define SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM      (core_frequency - 1)
#define SYS_SECURITY_STMCTL_DEF_MAX_UPDT_PORT_NUM       319
#define SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD (1000000 / (security_master->stmctl_granularity))
#define SYS_SECURITY_STMCTL_MAX_PORT_NUM     0x3FFF
#define SYS_SECURITY_STMCTL_UNIT     0  /* shift left 1 bit */

#define SYS_SECURITY_PORT_ISOLATION_MAX_GROUP_ID      31
#define SYS_SECURITY_PORT_ISOLATION_MIN_GROUP_ID      0

#define SYS_SECURITY_STMCTL_MAX_PORT_VLAN_NUM 64

#define SYS_SECURITY_STMCTL_DISABLE_THRD     0xFFFFFF;

#define SYS_STMCTL_CHK_UCAST(mode, type) \
    { \
        if (mode) \
        { \
            if (CTC_SECURITY_STORM_CTL_ALL_UCAST == type) \
            { \
                return CTC_E_INVALID_PARAM; \
            } \
        } \
        else \
        { \
            if (CTC_SECURITY_STORM_CTL_KNOWN_UCAST == type \
                || CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST == type) \
            { \
                return CTC_E_INVALID_PARAM; \
            } \
        } \
    }

#define SYS_STMCTL_CHK_MCAST(mode, type) \
    { \
        if (mode) \
        { \
            if (CTC_SECURITY_STORM_CTL_ALL_MCAST == type) \
            { \
                return CTC_E_INVALID_PARAM; \
            } \
        } \
        else \
        { \
            if (CTC_SECURITY_STORM_CTL_KNOWN_MCAST == type \
                || CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST == type) \
            { \
                return CTC_E_INVALID_PARAM; \
            } \
        } \
    }

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
enum sys_greatbelt_security_ipsg_flag_e
{
    SYS_SECURITY_IPSG_MAC_SUPPORT = 0x01,
    SYS_SECURITY_IPSG_IPV4_SUPPORT = 0x02,
    SYS_SECURITY_IPSG_IPV6_SUPPORT = 0x04,
    SYS_SECURITY_IPSG_MAX
};
typedef enum sys_greatbelt_security_ipsg_flag_e sys_greatbelt_security_ipsg_flag_t;

struct sys_stmctl_node_s
{
    ctc_slistnode_t head;
    uint16 gport;
    uint16 vlan_id;
    uint8  op;
    uint8  stmctl_en;
    uint8  type_bitmap;
    uint8  rsv;
    uint32  stmctl_offset;
};
typedef struct sys_stmctl_node_s sys_stmctl_node_t;

struct sys_security_master_s
{
    ctc_security_stmctl_glb_cfg_t stmctl_cfg;
    ctc_slist_t*  p_stmctl_list;
    uint8 flag;
    uint32 stmctl_granularity; /* (100/1000/10000) from ctc_security_storm_ctl_granularity_t */
};

typedef struct sys_security_master_s sys_security_master_t;

sys_security_master_t* security_master = NULL;

#define SYS_SECURITY_INIT_CHECK() \
    do { \
        if (security_master == NULL){ \
            return CTC_E_NOT_INIT; } \
    } while (0)

/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/


sys_stmctl_node_t*
_sys_greatbelt_stmctl_db_get_node(ctc_security_stmctl_cfg_t* p_stmctl_cfg)
{
    ctc_slistnode_t* ctc_slistnode = NULL;
    sys_stmctl_node_t* p_stmctl_node = NULL;

    CTC_SLIST_LOOP(security_master->p_stmctl_list, ctc_slistnode)
    {
        p_stmctl_node = _ctc_container_of(ctc_slistnode, sys_stmctl_node_t, head);
        if (NULL != p_stmctl_node)
        {
            if((p_stmctl_cfg->op == p_stmctl_node->op)
             &&(((p_stmctl_cfg->gport == p_stmctl_node->gport)&& (CTC_SECURITY_STORM_CTL_OP_PORT == p_stmctl_cfg->op))
                || ((p_stmctl_cfg->vlan_id == p_stmctl_node->vlan_id)&& (CTC_SECURITY_STORM_CTL_OP_VLAN == p_stmctl_cfg->op))))
            {
                return p_stmctl_node;
            }
        }
    }

    return NULL;

}

uint32
_sys_greatbelt_stmctl_db_add_node(uint8 lchip,
                                  ctc_security_stmctl_cfg_t* p_stmctl_cfg,
                                  uint32* p_ofsset)
{
    sys_greatbelt_opf_t opf;
    sys_stmctl_node_t* p_stmctl_node = NULL;
    sys_stmctl_node_t* p_stmctl_node_ex = NULL;
    ctc_security_stmctl_cfg_t stmctl_cfg;
    uint8 lchip_num = 0;
    uint8 need_alloc = 1;
    uint8 lchip1 = 0, gchip1 = 0;
    int32 ret = CTC_E_NONE;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    sal_memset(&stmctl_cfg, 0, sizeof(stmctl_cfg));

    p_stmctl_node = _sys_greatbelt_stmctl_db_get_node(p_stmctl_cfg);

    if (NULL != p_stmctl_node)
    {
        *p_ofsset = p_stmctl_node->stmctl_offset;
        CTC_BIT_SET(p_stmctl_node->type_bitmap, p_stmctl_cfg->type);

        SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "Entry(p_stmctl_node) Already Exist\n");
        return CTC_E_NONE;
    }

    p_stmctl_node = mem_malloc(MEM_STMCTL_MODULE, sizeof(sys_stmctl_node_t));
    if (NULL == p_stmctl_node)
    {
        SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_ERROR, "No memory!!!\n");
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_stmctl_node, 0, sizeof(sys_stmctl_node_t));
    p_stmctl_node->gport = p_stmctl_cfg->gport;
    p_stmctl_node->vlan_id = p_stmctl_cfg->vlan_id;
    p_stmctl_node->op = p_stmctl_cfg->op;
    p_stmctl_node->stmctl_en  = p_stmctl_cfg->storm_en;
    CTC_BIT_SET(p_stmctl_node->type_bitmap, p_stmctl_cfg->type);

    lchip_num = sys_greatbelt_get_local_chip_num();
    if ((p_stmctl_cfg->op == CTC_SECURITY_STORM_CTL_OP_PORT) && (lchip_num > 1))
    {
        sal_memcpy(&stmctl_cfg, p_stmctl_cfg, sizeof(stmctl_cfg));
        lchip1 = !lchip;
        sys_greatbelt_get_gchip_id(lchip1, &gchip1);
        stmctl_cfg.gport &= 0xFF;
        stmctl_cfg.gport |= gchip1 << 8;
        p_stmctl_node_ex = _sys_greatbelt_stmctl_db_get_node(&stmctl_cfg);
        if (NULL != p_stmctl_node_ex)
        {
            p_stmctl_node->stmctl_offset = p_stmctl_node_ex->stmctl_offset;
            need_alloc = 0;
        }
    }

    if (need_alloc)
    {
        sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));
        opf.pool_type = OPF_STORM_CTL;
        opf.pool_index = 0;
        ret = sys_greatbelt_opf_alloc_offset(&opf, 1, p_ofsset);
        if (CTC_E_NONE != ret)
        {
            mem_free(p_stmctl_node);
            return ret;
        }

        p_stmctl_node->stmctl_offset = *p_ofsset;

        SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "alloc stmctl_offset: %d \n", *p_ofsset);
    }

    ctc_slist_add_tail(security_master->p_stmctl_list, &(p_stmctl_node->head));

    return CTC_E_NONE;

}

uint32
_sys_greatbelt_stmctl_db_del_node(uint8 lchip,
                                  ctc_security_stmctl_cfg_t* p_stmctl_cfg,
                                  uint32* p_ofsset)
{
    sys_greatbelt_opf_t opf;
    sys_stmctl_node_t* p_stmctl_node = NULL;
    sys_stmctl_node_t* p_stmctl_node_ex = NULL;
    ctc_security_stmctl_cfg_t stmctl_cfg;
    uint8 lchip_num = 0;
    uint8 need_free = 1;
    uint8 lchip1 = 0, gchip1 = 0;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    sal_memset(&stmctl_cfg, 0, sizeof(stmctl_cfg));

    p_stmctl_node = _sys_greatbelt_stmctl_db_get_node(p_stmctl_cfg);
    if (NULL == p_stmctl_node)
    {
        return CTC_E_ENTRY_NOT_EXIST;
    }

    CTC_BIT_UNSET(p_stmctl_node->type_bitmap, p_stmctl_cfg->type);

    if (p_stmctl_node->type_bitmap > 0)
    {
        *p_ofsset = p_stmctl_node->stmctl_offset;
        return CTC_E_NONE;
    }

    lchip_num = sys_greatbelt_get_local_chip_num();
    if ((p_stmctl_cfg->op == CTC_SECURITY_STORM_CTL_OP_PORT) && (lchip_num > 1))
    {
        sal_memcpy(&stmctl_cfg, p_stmctl_cfg, sizeof(stmctl_cfg));
        lchip1 = !lchip;
        sys_greatbelt_get_gchip_id(lchip1, &gchip1);
        stmctl_cfg.gport &= 0xFF;
        stmctl_cfg.gport |= gchip1 << 8;
        p_stmctl_node_ex = _sys_greatbelt_stmctl_db_get_node(&stmctl_cfg);
        if (NULL != p_stmctl_node_ex)
        {
            need_free = 0;
        }
    }

    if (need_free)
    {
        *p_ofsset = p_stmctl_node->stmctl_offset;

        sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));
        opf.pool_type = OPF_STORM_CTL;
        opf.pool_index = 0;
        sys_greatbelt_opf_free_offset(&opf, 1, *p_ofsset);

        SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "free stmctl_offset: %d \n", *p_ofsset);
    }

    ctc_slist_delete_node(security_master->p_stmctl_list, &(p_stmctl_node->head));

    mem_free(p_stmctl_node);

    return CTC_E_NONE;
}

/*mac security*/
int32
sys_greatbelt_mac_security_set_port_security(uint16 gport, bool enable)
{
    uint32 value = enable;

    SYS_SECURITY_INIT_CHECK();

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_ERROR_RETURN(sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_SECURITY_EN, value));

    return CTC_E_NONE;
}

int32
sys_greatbelt_mac_security_get_port_security(uint16 gport, bool* p_enable)
{
    uint32 value = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_enable);

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    CTC_ERROR_RETURN(sys_greatbelt_port_get_internal_property(gport, SYS_PORT_PROP_SECURITY_EN, &value));
    *p_enable = (value) ? 1 : 0;

    return CTC_E_NONE;
}

int32
sys_greatbelt_mac_security_set_port_mac_limit(uint16 gport, ctc_maclimit_action_t action)
{
    int32 ret = 0;

    SYS_SECURITY_INIT_CHECK();
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    switch (action)
    {
    case CTC_MACLIMIT_ACTION_NONE:          /*learning enable, forwarding, not discard, learnt*/
        ret = sys_greatbelt_port_set_property(gport, CTC_PORT_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_MAC_SECURITY_DISCARD, FALSE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_SECURITY_EXCP_EN, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_FWD:           /*learning disable, forwarding*/
        ret = sys_greatbelt_port_set_property(gport, CTC_PORT_PROP_LEARNING_EN, FALSE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_MAC_SECURITY_DISCARD, FALSE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_SECURITY_EXCP_EN, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_DISCARD:       /*learning enable, discard, not learnt*/
        ret = sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_MAC_SECURITY_DISCARD, TRUE);
        ret = ret ? ret : sys_greatbelt_port_set_property(gport, CTC_PORT_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_SECURITY_EXCP_EN, FALSE);
        break;

    case CTC_MACLIMIT_ACTION_TOCPU:         /*learning enable, discard and to cpu, not learnt*/
        ret = sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_MAC_SECURITY_DISCARD, TRUE);
        ret = ret ? ret : sys_greatbelt_port_set_property(gport, CTC_PORT_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : sys_greatbelt_port_set_internal_property(gport, SYS_PORT_PROP_SECURITY_EXCP_EN, TRUE);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

int32
sys_greatbelt_mac_security_get_port_mac_limit(uint16 gport, ctc_maclimit_action_t* action)
{
    uint32 port_learn_en;
    uint32 mac_security_discard_en;
    uint32 security_excp_en;
    int32 ret = CTC_E_NONE;

    SYS_SECURITY_INIT_CHECK();
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    CTC_PTR_VALID_CHECK(action);

    ret = sys_greatbelt_port_get_property(gport, CTC_PORT_PROP_LEARNING_EN, &port_learn_en);
    ret |= sys_greatbelt_port_get_internal_property(gport, SYS_PORT_PROP_MAC_SECURITY_DISCARD, &mac_security_discard_en);
    ret |= sys_greatbelt_port_get_internal_property(gport, SYS_PORT_PROP_SECURITY_EXCP_EN, &security_excp_en);

    if (port_learn_en == TRUE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_NONE;
    }
    else if (port_learn_en == FALSE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_FWD;
    }
    else if (port_learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_DISCARD;
    }
    else if (port_learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == TRUE)
    {
        *action = CTC_MACLIMIT_ACTION_TOCPU;
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

int32
_sys_greatbelt_set_vlan_security_excep_en(uint32 value)
{
    uint32 cmd = 0;
    uint8 chip = 0;
    uint8 lchip_num = 0;

    lchip_num = sys_greatbelt_get_local_chip_num();

    cmd = DRV_IOW(IpeLearningCtl_t, IpeLearningCtl_VlanSecurityExceptionEn_f);

    for (chip = 0; chip < lchip_num; chip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(chip, 0, cmd, &value));
    }

    return CTC_E_NONE;
}

int32
_sys_greatbelt_get_vlan_security_excep_en(uint32* value)
{
    uint32 cmd = 0;

    cmd = DRV_IOR(IpeLearningCtl_t, IpeLearningCtl_VlanSecurityExceptionEn_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, value));
    return CTC_E_NONE;
}

int32
sys_greatbelt_mac_security_set_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t action)
{
    int32 ret = 0;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    switch (action)
    {
    case CTC_MACLIMIT_ACTION_NONE:      /*learning eanble, forwarding, not discard, learnt*/
        ret = sys_greatbelt_vlan_set_property(vlan_id, CTC_VLAN_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : sys_greatbelt_vlan_set_internal_property(vlan_id, SYS_VLAN_PROP_MAC_SECURITY_VLAN_DISCARD, FALSE);
        ret = ret ? ret : _sys_greatbelt_set_vlan_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_FWD:       /*learning disable, forwarding*/
        ret = sys_greatbelt_vlan_set_property(vlan_id, CTC_VLAN_PROP_LEARNING_EN, FALSE);
        ret = ret ? ret : sys_greatbelt_vlan_set_internal_property(vlan_id, SYS_VLAN_PROP_MAC_SECURITY_VLAN_DISCARD, FALSE);
        ret = ret ? ret : _sys_greatbelt_set_vlan_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_DISCARD:   /*learning enable, discard, not learnt*/
        ret =   sys_greatbelt_vlan_set_internal_property(vlan_id, SYS_VLAN_PROP_MAC_SECURITY_VLAN_DISCARD, TRUE);
        ret = ret ? ret : sys_greatbelt_vlan_set_property(vlan_id, CTC_VLAN_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : _sys_greatbelt_set_vlan_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_TOCPU:     /*learning enable, discard and to cpu, not learnt*/
        ret = sys_greatbelt_vlan_set_internal_property(vlan_id, SYS_VLAN_PROP_MAC_SECURITY_VLAN_DISCARD, TRUE);
        ret = ret ? ret : sys_greatbelt_vlan_set_property(vlan_id, CTC_VLAN_PROP_LEARNING_EN, TRUE);
        ret = ret ? ret : _sys_greatbelt_set_vlan_security_excep_en(TRUE);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

int32
sys_greatbelt_mac_security_get_vlan_mac_limit(uint16 vlan_id, ctc_maclimit_action_t* action)
{
    uint32 learn_en;
    uint32 mac_security_discard_en;
    uint32 security_excp_en;
    int32 ret = CTC_E_NONE;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    CTC_PTR_VALID_CHECK(action);

    ret = sys_greatbelt_vlan_get_property(vlan_id, CTC_VLAN_PROP_LEARNING_EN, &learn_en);
    ret |= sys_greatbelt_vlan_get_internal_property(vlan_id, SYS_VLAN_PROP_MAC_SECURITY_VLAN_DISCARD, &mac_security_discard_en);
    ret |= _sys_greatbelt_get_vlan_security_excep_en(&security_excp_en);

    if (learn_en == TRUE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_NONE;
    }
    else if (learn_en == FALSE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_FWD;
    }
    else if (learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_DISCARD;
    }
    else if (learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == TRUE)
    {
        *action = CTC_MACLIMIT_ACTION_TOCPU;
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

static int32
_sys_greatbelt_set_syetem_security_learn_en(uint32 value)
{
    uint32 cmd = 0;
    uint8 chip = 0;
    uint8 lchip_num = 0;

    lchip_num = sys_greatbelt_get_local_chip_num();
    value = (value) ? 0 : 1;
    cmd = DRV_IOW(IpeLookupCtl_t, IpeLookupCtl_LearningDisable_f);

    for (chip = 0; chip < lchip_num; chip++)
    {

        CTC_ERROR_RETURN(DRV_IOCTL(chip, 0, cmd, &value));
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_get_system_security_learn_en(uint32* value)
{
    uint32 cmd = 0;

    CTC_PTR_VALID_CHECK(value);
    cmd = DRV_IOR(IpeLookupCtl_t, IpeLookupCtl_LearningDisable_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, value));
    *value = (*value) ? 0 : 1;
    return CTC_E_NONE;
}

static int32
_sys_greatbelt_set_syetem_security_excep_en(uint32 value)
{
    uint32 cmd = 0;
    uint8 chip = 0;
    uint8 lchip_num = 0;

    lchip_num = sys_greatbelt_get_local_chip_num();

    cmd = DRV_IOW(IpeLearningCtl_t, IpeLearningCtl_SystemSecurityExceptionEn_f);

    for (chip = 0; chip < lchip_num; chip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(chip, 0, cmd, &value));
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_get_system_security_excep_en(uint32* value)
{
    uint32 cmd = 0;

    CTC_PTR_VALID_CHECK(value);
    cmd = DRV_IOR(IpeLearningCtl_t, IpeLearningCtl_SystemSecurityExceptionEn_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, value));
    return CTC_E_NONE;
}

static int32
_sys_greatbelt_set_system_mac_security_discard_en(uint32 value)
{
    uint32 cmd = 0;
    uint8 chip = 0;
    uint8 lchip_num = 0;

    lchip_num = sys_greatbelt_get_local_chip_num();

    cmd = DRV_IOW(IpeLearningCtl_t, IpeLearningCtl_SystemMacSecurityDiscard_f);

    for (chip = 0; chip < lchip_num; chip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(chip, 0, cmd, &value));
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_get_system_mac_security_discard_en(uint32* value)
{
    uint32 cmd = 0;

    CTC_PTR_VALID_CHECK(value);
    cmd = DRV_IOR(IpeLearningCtl_t, IpeLearningCtl_SystemMacSecurityDiscard_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, value));
    return CTC_E_NONE;
}

int32
sys_greatbelt_mac_security_set_system_mac_limit(ctc_maclimit_action_t action)
{
    int32 ret = CTC_E_NONE;

    SYS_SECURITY_INIT_CHECK();
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    switch (action)
    {
    case CTC_MACLIMIT_ACTION_NONE:      /*learning eanble, forwarding, not discard, learnt*/
        ret = _sys_greatbelt_set_syetem_security_learn_en(TRUE);
        ret = ret ? ret : _sys_greatbelt_set_system_mac_security_discard_en(FALSE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_FWD:       /*learning disable, forwarding*/
        ret = _sys_greatbelt_set_syetem_security_learn_en(FALSE);
        ret = ret ? ret : _sys_greatbelt_set_system_mac_security_discard_en(FALSE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_DISCARD:   /*learning enable, discard, not learnt*/
        ret = _sys_greatbelt_set_system_mac_security_discard_en(TRUE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_learn_en(TRUE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_excep_en(FALSE);
        break;

    case CTC_MACLIMIT_ACTION_TOCPU:     /*learning enable, discard and to cpu, not learnt*/
        ret = _sys_greatbelt_set_system_mac_security_discard_en(TRUE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_learn_en(TRUE);
        ret = ret ? ret : _sys_greatbelt_set_syetem_security_excep_en(TRUE);
        break;

    default:
        return CTC_E_INVALID_PARAM;

    }

    return ret;

}

int32
sys_greatbelt_mac_security_get_system_mac_limit(ctc_maclimit_action_t* action)
{
    uint32 learn_en;
    uint32 mac_security_discard_en;
    uint32 security_excp_en;
    int32 ret = CTC_E_NONE;

    SYS_SECURITY_INIT_CHECK();
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    CTC_PTR_VALID_CHECK(action);
    ret = _sys_greatbelt_get_system_security_learn_en(&learn_en);
    ret |= _sys_greatbelt_get_system_mac_security_discard_en(&mac_security_discard_en);
    ret |= _sys_greatbelt_get_system_security_excep_en(&security_excp_en);

    if (learn_en == TRUE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_NONE;
    }
    else if (learn_en == FALSE && mac_security_discard_en == FALSE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_FWD;
    }
    else if (learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == FALSE)
    {
        *action = CTC_MACLIMIT_ACTION_DISCARD;
    }
    else if (learn_en == TRUE && mac_security_discard_en == TRUE && security_excp_en == TRUE)
    {
        *action = CTC_MACLIMIT_ACTION_TOCPU;
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    return ret;
}

static int32
_sys_greatbelt_ip_source_guard_init_default_entry()
{
    sys_scl_entry_t def_entry;
    uint32 mac_table_size = 0;
    uint32 ipv4_table_size = 0;
    uint32 ipv6_table_size = 0;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    SYS_SECURITY_INIT_CHECK();

    sal_memset(&def_entry, 0, sizeof(def_entry));
    def_entry.action.type = SYS_SCL_ACTION_INGRESS;
    CTC_SET_FLAG(def_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_DISCARD);

    CTC_ERROR_RETURN(sys_greatbelt_ftm_get_table_entry_num(DsUserIdMacKey_t, &mac_table_size));
    if (mac_table_size != 0)
    {
        def_entry.key.type = SYS_SCL_KEY_TCAM_MAC;

        CTC_ERROR_RETURN(sys_greatbelt_scl_add_entry(SYS_SCL_GROUP_ID_INNER_DEFT_IP_SRC_GUARD, &def_entry, 1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_set_entry_priority(def_entry.entry_id,0,1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_install_entry(def_entry.entry_id, 1));
        security_master->flag = security_master->flag | SYS_SECURITY_IPSG_MAC_SUPPORT;

    }

    CTC_ERROR_RETURN(sys_greatbelt_ftm_get_table_entry_num(DsUserIdIpv4Key_t, &ipv4_table_size));
    if (ipv4_table_size != 0)
    {
        def_entry.key.type = SYS_SCL_KEY_TCAM_IPV4;

        CTC_ERROR_RETURN(sys_greatbelt_scl_add_entry(SYS_SCL_GROUP_ID_INNER_DEFT_IP_SRC_GUARD, &def_entry, 1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_set_entry_priority(def_entry.entry_id,0,1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_install_entry(def_entry.entry_id, 1));
        security_master->flag = security_master->flag | SYS_SECURITY_IPSG_IPV4_SUPPORT;
    }

    CTC_ERROR_RETURN(sys_greatbelt_ftm_get_table_entry_num(DsUserIdIpv6Key_t, &ipv6_table_size));
    if (ipv6_table_size != 0)
    {
        def_entry.key.type = SYS_SCL_KEY_TCAM_IPV6;

        CTC_ERROR_RETURN(sys_greatbelt_scl_add_entry(SYS_SCL_GROUP_ID_INNER_DEFT_IP_SRC_GUARD, &def_entry, 1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_set_entry_priority(def_entry.entry_id,0,1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_install_entry(def_entry.entry_id, 1));
        security_master->flag = security_master->flag | SYS_SECURITY_IPSG_IPV6_SUPPORT;
    }

    return CTC_E_NONE;

}

/*ip source guard*/
int32
sys_greatbelt_ip_source_guard_add_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    sys_scl_entry_t ipv4_entry;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_elem);
    CTC_GLOBAL_PORT_CHECK(p_elem->gport);

    sal_memset(&ipv4_entry, 0, sizeof(ipv4_entry));

    if (p_elem->ip_src_guard_type == CTC_SECURITY_BINDING_TYPE_IPV6_MAC)
    {
        if (!(CTC_FLAG_ISSET(security_master->flag, SYS_SECURITY_IPSG_IPV6_SUPPORT)))
        {
            return CTC_E_FEATURE_NOT_SUPPORT;
        }

        ipv4_entry.key.type = SYS_SCL_KEY_HASH_IPV6;
        ipv4_entry.action.type = SYS_SCL_ACTION_INGRESS;
        sal_memcpy(ipv4_entry.key.u.hash_ipv6_key.ip_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));
        CTC_SET_FLAG(ipv4_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_BINDING_EN);
        ipv4_entry.action.u.igs_action.bind.type    = CTC_SCL_BIND_TYPE_MACSA;
        sal_memcpy(ipv4_entry.action.u.igs_action.bind.mac_sa , p_elem->mac_sa, sizeof(mac_addr_t));

        CTC_ERROR_RETURN(sys_greatbelt_scl_add_entry(SYS_SCL_GROUP_ID_INNER_HASH_IP_SRC_GUARD, &ipv4_entry, 1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_install_entry(ipv4_entry.entry_id, 1));
        return CTC_E_NONE;
    }

    if (CTC_IP_VER_4 != p_elem->ipv4_or_ipv6)
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    if (((p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_IP)) \
        ||(p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_IP_MAC)) \
        ||(p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_IP_VLAN))) \
        && (!(CTC_FLAG_ISSET(security_master->flag, SYS_SECURITY_IPSG_IPV4_SUPPORT))))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    if (((p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_MAC)) \
        ||(p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN)) \
        ||(p_elem->ip_src_guard_type == (CTC_SECURITY_BINDING_TYPE_MAC_VLAN))) \
        && (!(CTC_FLAG_ISSET(security_master->flag, SYS_SECURITY_IPSG_MAC_SUPPORT))))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "gport:%d\n", p_elem->gport);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ip source guard type:%d\n", p_elem->ip_src_guard_type);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ipv4 or ipv6:%s\n", (CTC_IP_VER_4 == p_elem->ipv4_or_ipv6) ? "ipv4" : "ipv6");

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ipv4sa:%d.%d.%d.%d\n", (p_elem->ipv4_sa >> 24) & 0xFF, (p_elem->ipv4_sa >> 16) & 0xFF, \
                         (p_elem->ipv4_sa >> 8) & 0xFF, p_elem->ipv4_sa & 0xFF);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "mac:%x:%x:%x:%x:%x:%x\n", p_elem->mac_sa[0], p_elem->mac_sa[1], p_elem->mac_sa[2], \
                         p_elem->mac_sa[3], p_elem->mac_sa[4], p_elem->mac_sa[5]);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "vlan:%d\n", p_elem->vid);




    ipv4_entry.action.type = SYS_SCL_ACTION_INGRESS;
    switch (p_elem->ip_src_guard_type)
    {
    case CTC_SECURITY_BINDING_TYPE_IP:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_IPV4;
        ipv4_entry.key.u.hash_port_ipv4_key.gport   = p_elem->gport;
        ipv4_entry.key.u.hash_port_ipv4_key.ip_sa   = p_elem->ipv4_sa;

        /* do nothing */
        break;

    case CTC_SECURITY_BINDING_TYPE_IP_MAC:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_IPV4;
        ipv4_entry.key.u.hash_port_ipv4_key.ip_sa= p_elem->ipv4_sa;
        ipv4_entry.key.u.hash_port_ipv4_key.gport= p_elem->gport;

        CTC_SET_FLAG(ipv4_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_BINDING_EN);
        ipv4_entry.action.u.igs_action.bind.type    = CTC_SCL_BIND_TYPE_MACSA;
        sal_memcpy(ipv4_entry.action.u.igs_action.bind.mac_sa, p_elem->mac_sa, sizeof(mac_addr_t));

        break;

    case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_IPV4;
        ipv4_entry.key.u.hash_port_ipv4_key.ip_sa= p_elem->ipv4_sa;
        ipv4_entry.key.u.hash_port_ipv4_key.gport= p_elem->gport;

        CTC_VLAN_RANGE_CHECK(p_elem->vid);
        CTC_SET_FLAG(ipv4_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_BINDING_EN);
        ipv4_entry.action.u.igs_action.bind.type    = CTC_SCL_BIND_TYPE_VLAN;
        ipv4_entry.action.u.igs_action.bind.vlan_id =  p_elem->vid;
        break;

    case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_MAC;
        sal_memcpy(ipv4_entry.key.u.hash_port_mac_key.mac, p_elem->mac_sa, sizeof(mac_addr_t));
        ipv4_entry.key.u.hash_port_mac_key.gport    = p_elem->gport;
        ipv4_entry.key.u.hash_port_mac_key.mac_is_da = 0;

        CTC_VLAN_RANGE_CHECK(p_elem->vid);
        CTC_SET_FLAG(ipv4_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_BINDING_EN);
        ipv4_entry.action.u.igs_action.bind.type        = CTC_SCL_BIND_TYPE_IPV4SA_VLAN;
        ipv4_entry.action.u.igs_action.bind.vlan_id =  p_elem->vid;
        ipv4_entry.action.u.igs_action.bind.ipv4_sa =  p_elem->ipv4_sa;
        break;

    case CTC_SECURITY_BINDING_TYPE_MAC:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_MAC;
        sal_memcpy(ipv4_entry.key.u.hash_port_mac_key.mac, p_elem->mac_sa, sizeof(mac_addr_t));
        ipv4_entry.key.u.hash_port_mac_key.gport    = p_elem->gport;
        ipv4_entry.key.u.hash_port_mac_key.mac_is_da = 0;

        /* do nothing */
        break;

    case CTC_SECURITY_BINDING_TYPE_MAC_VLAN:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_MAC;
        sal_memcpy(ipv4_entry.key.u.hash_port_mac_key.mac, p_elem->mac_sa, sizeof(mac_addr_t));
        ipv4_entry.key.u.hash_port_mac_key.gport    = p_elem->gport;
        ipv4_entry.key.u.hash_port_mac_key.mac_is_da = 0;

        CTC_VLAN_RANGE_CHECK(p_elem->vid);
        CTC_SET_FLAG(ipv4_entry.action.u.igs_action.flag, CTC_SCL_IGS_ACTION_FLAG_BINDING_EN);
        ipv4_entry.action.u.igs_action.bind.type    = CTC_SCL_BIND_TYPE_VLAN;
        ipv4_entry.action.u.igs_action.bind.vlan_id =  p_elem->vid;
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }


    CTC_ERROR_RETURN(sys_greatbelt_scl_add_entry(SYS_SCL_GROUP_ID_INNER_HASH_IP_SRC_GUARD, &ipv4_entry, 1));
    CTC_ERROR_RETURN(sys_greatbelt_scl_install_entry(ipv4_entry.entry_id, 1));

    return CTC_E_NONE;
}

int32
sys_greatbelt_ip_source_guard_remove_entry(ctc_security_ip_source_guard_elem_t* p_elem)
{
    uint8 lport = 0;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint8 is_linkagg = 0;
    sys_scl_entry_t ipv4_entry;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_elem);
    CTC_GLOBAL_PORT_CHECK(p_elem->gport);

    sal_memset(&ipv4_entry, 0, sizeof(ipv4_entry));

    lchip_num = sys_greatbelt_get_local_chip_num();

    if (p_elem->ip_src_guard_type == CTC_SECURITY_BINDING_TYPE_IPV6_MAC)
    {
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_IPV6;
        sal_memcpy(ipv4_entry.key.u.hash_ipv6_key.ip_sa, p_elem->ipv6_sa, sizeof(ipv6_addr_t));

        CTC_ERROR_RETURN(sys_greatbelt_scl_get_entry_id(&ipv4_entry, SYS_SCL_GROUP_ID_INNER_HASH_IP_SRC_GUARD));
        CTC_ERROR_RETURN(sys_greatbelt_scl_uninstall_entry(ipv4_entry.entry_id, 1));
        CTC_ERROR_RETURN(sys_greatbelt_scl_remove_entry(ipv4_entry.entry_id, 1));

        return CTC_E_NONE;
    }


    is_linkagg = CTC_IS_LINKAGG_PORT(p_elem->gport);
    if (!is_linkagg)   /*not linkagg*/
    {
        SYS_MAP_GPORT_TO_LPORT(p_elem->gport, lchip, lport);
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "gport:%d\n", p_elem->gport);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ip source guard type:%d\n", p_elem->ip_src_guard_type);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ipv4 or ipv6:%d\n", p_elem->ipv4_or_ipv6);
    if (CTC_IP_VER_4 != p_elem->ipv4_or_ipv6)
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "ipv4sa:%d.%d.%d.%d\n", (p_elem->ipv4_sa >> 24) & 0xFF, (p_elem->ipv4_sa >> 16) & 0xFF, \
                         (p_elem->ipv4_sa >> 8) & 0xFF, p_elem->ipv4_sa & 0xFF);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "mac:%x %x %x %x %x %x\n", p_elem->mac_sa[0], p_elem->mac_sa[1], p_elem->mac_sa[2], \
                         p_elem->mac_sa[3], p_elem->mac_sa[4], p_elem->mac_sa[5]);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "vlan:%d\n", p_elem->vid);

    switch (p_elem->ip_src_guard_type)
    {
    case CTC_SECURITY_BINDING_TYPE_IP:
    case CTC_SECURITY_BINDING_TYPE_IP_MAC:
    case CTC_SECURITY_BINDING_TYPE_IP_VLAN:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_IPV4;
        ipv4_entry.key.u.hash_port_ipv4_key.ip_sa= p_elem->ipv4_sa;
        ipv4_entry.key.u.hash_port_ipv4_key.gport= p_elem->gport;
        break;

    case CTC_SECURITY_BINDING_TYPE_IP_MAC_VLAN:
    case CTC_SECURITY_BINDING_TYPE_MAC:
    case CTC_SECURITY_BINDING_TYPE_MAC_VLAN:
        ipv4_entry.key.type = SYS_SCL_KEY_HASH_PORT_MAC;
        sal_memcpy(ipv4_entry.key.u.hash_port_mac_key.mac, p_elem->mac_sa, sizeof(mac_addr_t));
        ipv4_entry.key.u.hash_port_mac_key.gport= p_elem->gport;
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(sys_greatbelt_scl_get_entry_id(&ipv4_entry, SYS_SCL_GROUP_ID_INNER_HASH_IP_SRC_GUARD));
    CTC_ERROR_RETURN(sys_greatbelt_scl_uninstall_entry(ipv4_entry.entry_id, 1));
    CTC_ERROR_RETURN(sys_greatbelt_scl_remove_entry(ipv4_entry.entry_id, 1));
    return CTC_E_NONE;
}

static int32
_sys_greatbelt_storm_ctl_set_mode(uint8 lchip, ctc_security_stmctl_cfg_t* p_stmctl_cfg, uint16* p_stmctl_offset)
{
    uint32 stmctl_ptr = 0;
    uint32 stmctl_offset = 0;
    ds_storm_ctl_t storm_ctl;
    uint32 core_frequency;
    uint32 unit = 0;
    uint32 cmd = 0;
    uint32 update_count_per_sec = 0;

    CTC_PTR_VALID_CHECK(p_stmctl_cfg);
    CTC_PTR_VALID_CHECK(p_stmctl_offset);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    if (p_stmctl_cfg->storm_en)
    {
        CTC_ERROR_RETURN(_sys_greatbelt_stmctl_db_add_node(lchip, p_stmctl_cfg, &stmctl_offset));
    }
    else
    {
        CTC_ERROR_RETURN(_sys_greatbelt_stmctl_db_del_node(lchip, p_stmctl_cfg, &stmctl_offset));
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "stmctl_offset: %d \n", stmctl_offset);
    *p_stmctl_offset = stmctl_offset;

    switch (p_stmctl_cfg->type)
    {
    case CTC_SECURITY_STORM_CTL_KNOWN_MCAST:
        stmctl_ptr = (1 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST:
    case CTC_SECURITY_STORM_CTL_ALL_MCAST:
        stmctl_ptr = (2 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_KNOWN_UCAST:
        stmctl_ptr = (3 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST:
    case CTC_SECURITY_STORM_CTL_ALL_UCAST:
        stmctl_ptr = (4 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_BCAST:
        stmctl_ptr = (0 << 6) | (stmctl_offset & 0x3F);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    sal_memset(&storm_ctl, 0, sizeof(ds_storm_ctl_t));
    cmd = DRV_IOR(DsStormCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, stmctl_ptr, cmd, &storm_ctl));
    storm_ctl.exception_en = p_stmctl_cfg->discarded_to_cpu ? 1 : 0;
    storm_ctl.use_packet_count = p_stmctl_cfg->mode == CTC_SECURITY_STORM_CTL_MODE_PPS ? 1 : 0;
    storm_ctl.running_count = 0;    /* must clear */

    core_frequency = sys_greatbelt_get_core_freq(0);

    unit = 1 << SYS_SECURITY_STMCTL_UNIT;
    update_count_per_sec = core_frequency * 1000000 / SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD / (SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM+1);
    if (p_stmctl_cfg->storm_en)
    {
        storm_ctl.threshold = p_stmctl_cfg->threshold / update_count_per_sec / unit;
    }
    else
    {
         storm_ctl.threshold = SYS_SECURITY_STMCTL_DISABLE_THRD;
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "StormCtlPtr:%d, unit: %d, DstormCtl.threshold: %d\n", stmctl_ptr,  unit, storm_ctl.threshold);
    cmd = DRV_IOW(DsStormCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, stmctl_ptr, cmd, &storm_ctl));

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_storm_ctl_get_mode(uint8 lchip, ctc_security_stmctl_cfg_t* p_stmctl_cfg)
{
    sys_stmctl_node_t* p_stmctl_node = NULL;
    uint32 stmctl_ptr = 0;
    uint32 stmctl_offset = 0;
    ds_storm_ctl_t storm_ctl;
    uint32 core_frequency;
    uint32 update_count_per_sec = 0;
    uint32 unit = 0;
    uint32 cmd = 0;

    CTC_PTR_VALID_CHECK(p_stmctl_cfg);

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    p_stmctl_node = _sys_greatbelt_stmctl_db_get_node(p_stmctl_cfg);

    if (NULL == p_stmctl_node)
    {
        return CTC_E_ENTRY_NOT_EXIST;
    }

    stmctl_offset = p_stmctl_node->stmctl_offset;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "stmctl_offset: %d \n", stmctl_offset);

    switch (p_stmctl_cfg->type)
    {
    case CTC_SECURITY_STORM_CTL_KNOWN_MCAST:
        stmctl_ptr = (1 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_MCAST:
    case CTC_SECURITY_STORM_CTL_ALL_MCAST:
        stmctl_ptr = (2 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_KNOWN_UCAST:
        stmctl_ptr = (3 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_UNKNOWN_UCAST:
    case CTC_SECURITY_STORM_CTL_ALL_UCAST:
        stmctl_ptr = (4 << 6) | (stmctl_offset & 0x3F);
        break;

    case CTC_SECURITY_STORM_CTL_BCAST:
        stmctl_ptr = (0 << 6) | (stmctl_offset & 0x3F);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    sal_memset(&storm_ctl, 0, sizeof(ds_storm_ctl_t));
    cmd = DRV_IOR(DsStormCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, stmctl_ptr, cmd, &storm_ctl));

    core_frequency = sys_greatbelt_get_core_freq(0);

    unit = 1 << SYS_SECURITY_STMCTL_UNIT;
    update_count_per_sec = core_frequency * 1000000 / SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD / (SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM+1);
    p_stmctl_cfg->storm_en = p_stmctl_node->stmctl_en;

    p_stmctl_cfg->discarded_to_cpu = storm_ctl.exception_en;
    p_stmctl_cfg->mode = storm_ctl.use_packet_count ? CTC_SECURITY_STORM_CTL_MODE_PPS : CTC_SECURITY_STORM_CTL_MODE_BPS;
    p_stmctl_cfg->threshold = unit * storm_ctl.threshold * update_count_per_sec;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "StormCtlPtr:%d, unit: %d, DsStormCtl.threshold: %d\n", stmctl_ptr, unit, storm_ctl.threshold);

    return CTC_E_NONE;
}




/*storm control*/
int32
sys_greatbelt_storm_ctl_set_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    uint8 lchip;
    uint8 lport;
    uint8 lchip_num = 0;
    uint16 stmctl_offset = 0;
    sys_stmctl_node_t* p_stmctl_node = NULL;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(stmctl_cfg);

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_PARAM,
                         "type:%d , mode:%d, gport :0x%x ,vlan:%d, op:%d, storm_en:%d, discarded_to_cpu:%d ,threshold :%d \n",
                         stmctl_cfg->type, stmctl_cfg->mode, stmctl_cfg->gport, stmctl_cfg->vlan_id,
                         stmctl_cfg->op, stmctl_cfg->storm_en, stmctl_cfg->discarded_to_cpu, stmctl_cfg->threshold)

    /*ucast mode judge*/
    SYS_STMCTL_CHK_UCAST(security_master->stmctl_cfg.ustorm_ctl_mode, stmctl_cfg->type);

    /*Mcast mode judge*/
    SYS_STMCTL_CHK_MCAST(security_master->stmctl_cfg.mstorm_ctl_mode, stmctl_cfg->type);

    lchip_num = sys_greatbelt_get_local_chip_num();

    if (CTC_SECURITY_STORM_CTL_OP_PORT == stmctl_cfg->op)
    {
        SYS_MAP_GPORT_TO_LPORT(stmctl_cfg->gport, lchip, lport);
        CTC_ERROR_RETURN(_sys_greatbelt_storm_ctl_set_mode(lchip, stmctl_cfg, &stmctl_offset));

        /*port storm ctl en*/
        if (stmctl_cfg->storm_en)
        {
            sys_greatbelt_port_set_internal_property(stmctl_cfg->gport, SYS_PORT_PROP_STMCTL_OFFSET, stmctl_offset);
            sys_greatbelt_port_set_internal_property(stmctl_cfg->gport, SYS_PORT_PROP_STMCTL_EN, stmctl_cfg->storm_en);
        }
        else
        {
            p_stmctl_node = _sys_greatbelt_stmctl_db_get_node(stmctl_cfg);
            if (!p_stmctl_node)
            {
                sys_greatbelt_port_set_internal_property(stmctl_cfg->gport, SYS_PORT_PROP_STMCTL_EN, stmctl_cfg->storm_en);
            }
        }

    }
    else if (CTC_SECURITY_STORM_CTL_OP_VLAN == stmctl_cfg->op)
    {
        CTC_VLAN_RANGE_CHECK(stmctl_cfg->vlan_id);

        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            CTC_ERROR_RETURN(_sys_greatbelt_storm_ctl_set_mode(lchip, stmctl_cfg, &stmctl_offset));
        }

        if (stmctl_cfg->storm_en)
        {
            CTC_ERROR_RETURN(sys_greatbelt_vlan_set_internal_property
                                 (stmctl_cfg->vlan_id, SYS_VLAN_PROP_VLAN_STORM_CTL_EN, stmctl_cfg->storm_en));
            CTC_ERROR_RETURN(sys_greatbelt_vlan_set_internal_property
                                 (stmctl_cfg->vlan_id, SYS_VLAN_PROP_VLAN_STORM_CTL_PTR, stmctl_offset));
        }
        else
        {
            p_stmctl_node = _sys_greatbelt_stmctl_db_get_node(stmctl_cfg);
            if (!p_stmctl_node)
            {
                sys_greatbelt_vlan_set_internal_property(stmctl_cfg->vlan_id, SYS_VLAN_PROP_VLAN_STORM_CTL_EN, stmctl_cfg->storm_en);
            }
        }
    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_storm_ctl_get_cfg(ctc_security_stmctl_cfg_t* stmctl_cfg)
{
    uint8 lchip;
    uint8 lport;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(stmctl_cfg);

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_PARAM,
                         "type:%d , mode:%d, gport :0x%x ,vlan:%d, op:%d, storm_en:%d, discarded_to_cpu:%d ,threshold :%d \n",
                         stmctl_cfg->type, stmctl_cfg->mode, stmctl_cfg->gport, stmctl_cfg->vlan_id,
                         stmctl_cfg->op, stmctl_cfg->storm_en, stmctl_cfg->discarded_to_cpu, stmctl_cfg->threshold);

    /*ucast mode judge*/
    SYS_STMCTL_CHK_UCAST(security_master->stmctl_cfg.ustorm_ctl_mode, stmctl_cfg->type);

    /*Mcast mode judge*/
    SYS_STMCTL_CHK_MCAST(security_master->stmctl_cfg.mstorm_ctl_mode, stmctl_cfg->type);

    if (CTC_SECURITY_STORM_CTL_OP_PORT == stmctl_cfg->op)
    {
        SYS_MAP_GPORT_TO_LPORT(stmctl_cfg->gport, lchip, lport);
    }
    else if (CTC_SECURITY_STORM_CTL_OP_VLAN == stmctl_cfg->op)
    {
        lchip = 0;
    }

    CTC_ERROR_RETURN(_sys_greatbelt_storm_ctl_get_mode(lchip, stmctl_cfg));

    return CTC_E_NONE;

}

int32
sys_greatbelt_storm_ctl_set_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 value = 0;
    uint32 update_threshold = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_glb_cfg);

    SYS_SECURITY_DBG_FUNC();
    SYS_SECURITY_DBG_INFO("ipg_en%d ustorm_ctl_mode:%d,mstorm_ctl_mode:%d\n", p_glb_cfg->ipg_en, p_glb_cfg->ustorm_ctl_mode, p_glb_cfg->mstorm_ctl_mode);

    /* can not configure global granularity if created storm control node */
    if (!CTC_SLIST_ISEMPTY(security_master->p_stmctl_list) && (p_glb_cfg->granularity!= security_master->stmctl_cfg.granularity))
    {
        return CTC_E_ENTRY_EXIST;
    }

    security_master->stmctl_cfg.granularity = p_glb_cfg->granularity;

    switch (security_master->stmctl_cfg.granularity)
    {
        case CTC_SECURITY_STORM_CTL_GRANU_100:
            security_master->stmctl_granularity = 100;
            break;
        case CTC_SECURITY_STORM_CTL_GRANU_1000:
            security_master->stmctl_granularity = 1000;
            break;
        case CTC_SECURITY_STORM_CTL_GRANU_10000:
            security_master->stmctl_granularity = 10000;
            break;
        default:
            security_master->stmctl_granularity = 100;
            break;
    }


    update_threshold = SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD;

    lchip_num = sys_greatbelt_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        value = p_glb_cfg->ipg_en ? 1 : 0;
        cmd = DRV_IOW(IpeBridgeStormCtl_t, IpeBridgeStormCtl_IpgEn_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

        value = p_glb_cfg->ustorm_ctl_mode ? 1 : 0;
        cmd = DRV_IOW(IpeBridgeCtl_t, IpeBridgeCtl_UnicastStormControlMode_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

        value = p_glb_cfg->mstorm_ctl_mode ? 1 : 0;
        cmd = DRV_IOW(IpeBridgeCtl_t, IpeBridgeCtl_MulticastStormControlMode_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

        cmd = DRV_IOW(IpeBridgeStormCtl_t, IpeBridgeStormCtl_StormCtlUpdateThreshold_f);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &update_threshold));
    }

    security_master->stmctl_cfg.ustorm_ctl_mode = p_glb_cfg->ustorm_ctl_mode;
    security_master->stmctl_cfg.mstorm_ctl_mode = p_glb_cfg->mstorm_ctl_mode;

    return CTC_E_NONE;
}

int32
sys_greatbelt_storm_ctl_get_global_cfg(ctc_security_stmctl_glb_cfg_t* p_glb_cfg)
{
    uint32 cmd = 0;
    uint32 value = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_glb_cfg);

    SYS_SECURITY_DBG_FUNC();

    cmd = DRV_IOR(IpeBridgeStormCtl_t, IpeBridgeStormCtl_IpgEn_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, &value));
    p_glb_cfg->ipg_en = value;

    cmd = DRV_IOR(IpeBridgeCtl_t, IpeBridgeCtl_UnicastStormControlMode_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, &value));
    p_glb_cfg->ustorm_ctl_mode = value;

    cmd = DRV_IOR(IpeBridgeCtl_t, IpeBridgeCtl_MulticastStormControlMode_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, &value));
    p_glb_cfg->mstorm_ctl_mode = value;

    p_glb_cfg->granularity = security_master->stmctl_cfg.granularity;

    SYS_SECURITY_DBG_INFO("ipg_en:%d, ustorm_ctl_mode:%d, mstorm_ctl_mode:%d, granularity:%d\n", \
                           p_glb_cfg->ipg_en, p_glb_cfg->ustorm_ctl_mode, p_glb_cfg->mstorm_ctl_mode, p_glb_cfg->granularity);

    return CTC_E_NONE;
}

int32
sys_greatbelt_port_isolation_set_route_obey_isolated_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    SYS_SECURITY_INIT_CHECK();

    tmp = enable ? 1 : 0;

    lchip_num = sys_greatbelt_get_local_chip_num();
    cmd = DRV_IOW(EpeNextHopCtl_t, EpeNextHopCtl_RouteObeyIsolate_f);

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &tmp));
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_greatbelt_port_isolation_get_route_obey_isolated_en(bool* p_enable)
{
    uint32 cmd = 0;
    uint32 field_val = 0;

    SYS_SECURITY_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_enable);

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    cmd = DRV_IOR(EpeNextHopCtl_t, EpeNextHopCtl_RouteObeyIsolate_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, &field_val));
    *p_enable = (field_val == 1) ? TRUE : FALSE;

    return CTC_E_NONE;
}

/*arp snooping*/
int32
sys_greatbelt_arp_snooping_set_address_check_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_INIT_CHECK();

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    tmp = enable ? 1 : 0;

    lchip_num = sys_greatbelt_get_local_chip_num();
    cmd = DRV_IOW(IpeIntfMapperCtl_t, IpeIntfMapperCtl_ArpSrcMacCheckEn_f);

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &tmp));
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_greatbelt_arp_snooping_set_address_check_exception_en(bool enable)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 tmp = 0;

    SYS_SECURITY_INIT_CHECK();

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    tmp = enable ? 1 : 0;

    lchip_num = sys_greatbelt_get_local_chip_num();
    cmd = DRV_IOW(IpeIntfMapperCtl_t, IpeIntfMapperCtl_ArpCheckExceptionEn_f);

    for (lchip = 0; lchip < lchip_num && lchip < MAX_LOCAL_CHIP_NUM; lchip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &tmp));
    }

    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_INFO, "enable:%d\n", enable);

    return CTC_E_NONE;
}

int32
sys_greatbelt_security_init(void)
{
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    uint32 cmd = 0;
    uint32 core_frequency = 0;
    uint32 field_val = 0;
    ipe_bridge_storm_ctl_t storm_brg_ctl;
    sys_greatbelt_opf_t opf;
    uint32 stmctl_offset = 0;
    ds_storm_ctl_t storm_ctl;


    SYS_SECURITY_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    if (NULL != security_master)
    {
        return CTC_E_NONE;
    }

    security_master = (sys_security_master_t*)mem_malloc(MEM_STMCTL_MODULE, sizeof(sys_security_master_t));
    if (NULL == security_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(security_master, 0, sizeof(sys_security_master_t));

    security_master->p_stmctl_list = ctc_slist_new();
    if (NULL == security_master->p_stmctl_list)
    {
        mem_free(security_master);
        security_master = NULL;
        return CTC_E_NO_MEMORY;
    }

    /*storm ctl support known unicast/mcast mode*/
    security_master->stmctl_cfg.ustorm_ctl_mode = 1;
    security_master->stmctl_cfg.mstorm_ctl_mode = 1;
    security_master->stmctl_cfg.ipg_en = 0;
    security_master->stmctl_cfg.granularity     = CTC_SECURITY_STORM_CTL_GRANU_100;
    security_master->stmctl_granularity = 100;

    lchip_num = sys_greatbelt_get_local_chip_num();

    /*init storm port and vlan base ptr offset*/
    sal_memset(&opf, 0, sizeof(sys_greatbelt_opf_t));
    sys_greatbelt_opf_init(OPF_STORM_CTL, 1);
    opf.pool_type = OPF_STORM_CTL;
    opf.pool_index = 0;
    sys_greatbelt_opf_init_offset(&opf, 0, SYS_SECURITY_STMCTL_MAX_PORT_VLAN_NUM);

    /*init default storm cfg*/
    core_frequency = sys_greatbelt_get_core_freq(0);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        sal_memset(&storm_ctl, 0, sizeof(storm_ctl));
        for (stmctl_offset = 0; stmctl_offset < 320; stmctl_offset++)
        {
            storm_ctl.threshold = SYS_SECURITY_STMCTL_DISABLE_THRD;
            cmd = DRV_IOW(DsStormCtl_t, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, stmctl_offset, cmd, &storm_ctl));
        }


        cmd = DRV_IOR(IpeBridgeStormCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &storm_brg_ctl));
        storm_brg_ctl.ipg_en = 0;
        storm_brg_ctl.storm_ctl_max_port_num = SYS_SECURITY_STMCTL_DEF_MAX_ENTRY_NUM;
        storm_brg_ctl.storm_ctl_max_update_port_num = SYS_SECURITY_STMCTL_DEF_MAX_UPDT_PORT_NUM;
        storm_brg_ctl.storm_ctl_update_en = 1;
        storm_brg_ctl.oam_obey_storm_ctl = 0;
        storm_brg_ctl.storm_ctl_update_threshold = SYS_SECURITY_STMCTL_DEF_UPDATE_THREHOLD;
        storm_brg_ctl.storm_ctl_en31_0   = 0xFFFFFFFF;
        storm_brg_ctl.storm_ctl_en63_32  = 0xFFFFFFFF;
        storm_brg_ctl.packet_shift = SYS_SECURITY_STMCTL_UNIT;
        storm_brg_ctl.byte_shift = SYS_SECURITY_STMCTL_UNIT;
        cmd = DRV_IOW(IpeBridgeStormCtl_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &storm_brg_ctl));

    }

    /*open port isolation & pvlan function*/
    cmd = DRV_IOR(EpeNextHopCtl_t, EpeNextHopCtl_IsolatedType_f);
    CTC_ERROR_RETURN(DRV_IOCTL(0, 0, cmd, &field_val));
    field_val = 1;
    cmd = DRV_IOW(EpeNextHopCtl_t, EpeNextHopCtl_IsolatedType_f);

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
    }

    CTC_ERROR_RETURN(_sys_greatbelt_ip_source_guard_init_default_entry());

    return CTC_E_NONE;
}

