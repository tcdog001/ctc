/**
 @file sys_greatbelt_packet.h

 @date 2012-10-23

 @version v2.0

*/
#ifndef _SYS_GREATBELT_PACKET_H
#define _SYS_GREATBELT_PACKET_H
#ifdef __cplusplus
extern "C" {
#endif

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_debug.h"
#include "ctc_const.h"

/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/

/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/

extern int32
sys_greatbelt_packet_swap32(uint32* data, int32 len, uint32 hton);

/**
 @brief packet RX in DMA mode, called by DMA RX function
*/
extern int32
sys_greatbelt_packet_rx(ctc_pkt_rx_t* p_pkt_rx);

/**
 @brief packet TX in DMA mode, call DMA TX function
*/
extern int32
sys_greatbelt_packet_tx(ctc_pkt_tx_t* p_pkt_tx);

/**
 @brief encapsulate CPUMAC Header (in ETH mode) and Packet Header for TX packet
*/
extern int32
sys_greatbelt_packet_encap(ctc_pkt_tx_t* p_pkt_tx);

/**
 @brief decapsulate CPUMAC Header (in ETH mode) and Packet Header for RX packet
*/
extern int32
sys_greatbelt_packet_decap(ctc_pkt_rx_t* p_pkt_rx);

/**
 @brief register internal RX callback
*/
extern int32
sys_greatbelt_packet_register_internal_rx_cb(CTC_PKT_RX_CALLBACK internal_rx_cb);

/**
 @brief Initialize packet module
*/
extern int32
sys_greatbelt_packet_init(void* p_global_cfg);

#ifdef __cplusplus
}
#endif

#endif

