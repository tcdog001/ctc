/**
 @file sys_humber_acl.c

 @date 2012-09-19

 @version v2.0

*/

/****************************************************************************
  *
  * Header Files
  *
  ****************************************************************************/
#include "ctc_error.h"
#include "ctc_const.h"
#include "ctc_common.h"
#include "ctc_macro.h"
#include "ctc_debug.h"
#include "ctc_hash.h"
#include "ctc_stats.h"
#include "ctc_parser.h"
#include "ctc_acl.h"
#include "ctc_qos.h"
#include "ctc_linklist.h"

#include "sys_humber_opf.h"
#include "sys_humber_chip.h"
#include "sys_humber_parser.h"
#include "sys_humber_stats.h"
#include "sys_humber_acl.h"
#include "sys_humber_queue_enq.h"
#include "sys_humber_qos_policer.h"
#include "sys_humber_nexthop_api.h"
#include "sys_humber_nexthop.h"
#include "sys_humber_internal_port.h"
#include "sys_humber_mirror.h"
#include "sys_humber_learning_aging.h"
#include "sys_humber_ftm.h"

#include "drv_tbl_reg.h"
#include "drv_io.h"

#define SYS_ACL_GROUP_HASH_BLOCK_SIZE 32
#define SYS_ACL_ENTRY_HASH_BLOCK_SIZE 32
#define SYS_ACL_MAX_ENTRY_PRIORITY    0xFFFFFFFF

#define SYS_ACL_TCP_FLAG_NUM                4
#define SYS_ACL_L4_PORT_NUM                 8
#define SYS_ACL_L4_PORT_REF_CNT          0xFFFF
#define SYS_ACL_TCP_FALG_REF_CNT         0xFFFF
#define SYS_ACL_MAX_SESSION_NUM 3   /* one session is reserved for cpu */

#define SYS_ACL_SPECIAL_STATS_PTR        0xFFFF
#define SYS_ACL_SPECIAL_POLICER_PTR      0xFFFF
#define SYS_ACL_REDIRECT_BUCKET_SIZE     64

#define SYS_ACL_ENTRY_OP_FLAG_ADD           1
#define SYS_ACL_ENTRY_OP_FLAG_DELETE        2

#define MAX_CTC_QOS_COLOR       4
#define MAX_CTC_QOS_TRUST       5

#define SYS_ACL_ASIC_KEY_TYPE_NUM  2         /* asic key type */

#define SYS_ACL_BLOCK_NUM_MAX      2         /* max block num */
#define SYS_ACL_ASIC_TYPE_MAX      3

#define SYS_ACL_IPV4_ICMP   1
#define SYS_ACL_IPV4_IGMP   2
#define SYS_ACL_TCP         6
#define SYS_ACL_UDP         17
#define SYS_ACL_IPV6_ICMP   58
#define DO_REORDER(move_num, all)  ((move_num) >= ((all) / 20))

typedef uint32 sys_entry_offset_t;

struct sys_acl_l4port_op_s
{
    uint16 ref;
    uint8  op_dest_port;
    uint8  rsv;

    uint16 port_min;
    uint16 port_max;
};
typedef struct sys_acl_l4port_op_s sys_acl_l4port_op_t;

struct sys_acl_tcp_flag_s
{
    uint16 ref;

    uint8  match_any; /* 0: match all , 1: match any */
    uint8  tcp_flags;     /* bitmap of CTC_ACLQOS_TCP_XXX_FLAG */
};
typedef struct sys_acl_tcp_flag_s sys_acl_tcp_flag_t;

/**
 @brief  acl redirect data structure
*/
struct sys_acl_redirect_s
{
    uint32 nhid;
    uint32 ds_fwd_offset;
    uint32 ref;
};
typedef struct sys_acl_redirect_s sys_acl_redirect_t;

struct sys_acl_master_s
{
    ctc_hash_t*                 group;
    ctc_hash_t*                 entry;
    sys_acl_block_t             block[SYS_ACL_ASIC_TYPE_MAX][SYS_ACL_BLOCK_NUM_MAX];

    uint32    max_entry_priority;

    sys_acl_tcp_flag_t          tcp_flag[SYS_ACL_TCP_FLAG_NUM];
    sys_acl_l4port_op_t         l4_port[SYS_ACL_L4_PORT_NUM];
    uint8                       l4_port_free_cnt;
    uint8                       tcp_flag_free_cnt;
    uint8                       asic_type[CTC_ACL_KEY_NUM];
    uint8                       block_num_max; /* max number of block: 4 */

    uint32                      acl_fwd_base;
    uint8                       lchip_num;
    uint8                       asic_type_num; /* asic key type num */
    uint8                       rsv0[2];
    uint16                      mac_ipv4_entry_num[SYS_ACL_BLOCK_NUM_MAX];
    uint16                      ipv6_entry_num[SYS_ACL_BLOCK_NUM_MAX];

    ctc_hash_t*                 p_sys_acl_redirect_hash;
};
typedef struct sys_acl_master_s sys_acl_master_t;
sys_acl_master_t* acl_master = NULL;

#define SYS_ACL_DBG_OUT(level, FMT, ...)  \
    CTC_DEBUG_OUT(acl, acl, ACL_SYS, level, FMT, ##__VA_ARGS__)

#define SYS_ACL_DBG_FUNC() \
    SYS_ACL_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "  %% FUNC: %s()\n", __FUNCTION__)

#define SYS_ACL_DBG_INFO(FMT, ...) \
    SYS_ACL_DBG_OUT(CTC_DEBUG_LEVEL_INFO, FMT, ##__VA_ARGS__)

#define SYS_ACL_DBG_PARAM(FMT, ...) \
    SYS_ACL_DBG_OUT(CTC_DEBUG_LEVEL_PARAM, FMT, ##__VA_ARGS__)

#define SYS_ACL_DBG_ERROR(FMT, ...) \
    SYS_ACL_DBG_OUT(CTC_DEBUG_LEVEL_PARAM, FMT, ##__VA_ARGS__)

#define SYS_ACL_DBG_DUMP(FMT, ...) \
    SYS_ACL_DBG_OUT(CTC_DEBUG_LEVEL_DUMP, FMT, ##__VA_ARGS__)

#define SYS_ACL_INIT_CHECK() \
    { \
        if (!acl_master){ \
            return CTC_E_NOT_INIT; } \
    }

#define SYS_ACL_CHECK_GROUP_ID(gid) \
    { \
        ; \
    }

#define SYS_ACL_CHECK_GROUP_TYPE(type) \
    { \
        if (type >= CTC_ACL_GROUP_TYPE_MAX){ \
            return CTC_E_ACL_GROUP_TYPE; } \
    }

#define SYS_ACL_CHECK_GROUP_PRIO(priority) \
    { \
        if (priority >= acl_master->block_num_max){ \
            return CTC_E_ACL_GROUP_PRIORITY; } \
    }

#define SYS_ACL_CHECK_ENTRY_ID(eid) \
    { \
        ; \
    }

#define SYS_ACL_CHECK_ENTRY_PRIO(priority) \
    { \
        if (priority > acl_master->max_entry_priority){ \
            return CTC_E_ACL_GROUP_PRIORITY; } \
    }

#define SYS_ACL_SERVICE_ID_CHECK(sid) \
    { \
        if (sid == 0){ \
            return CTC_E_ACL_SERVICE_ID; } \
    }

#define SYS_ACL_CHECK_GROUP_UNEXIST(pg) \
    {                                       \
        if (!pg)                            \
        {                                   \
            return CTC_E_ACL_GROUP_UNEXIST; \
        }                                   \
    }

#define _DEF_ERR

#define SYS_ACL_MALLOC(_ptr_, _size_)      \
    {                                                \
        if (NULL == (_ptr_)){                       \
            (_ptr_) = mem_malloc((MEM_ACL_MODULE), (_size_));  \
        }                                            \
        if ((_ptr_) != NULL){                        \
            sal_memset((_ptr_), 0, (_size_));        \
        }  else {                                    \
            SYS_ACL_DBG_ERROR("Error: No memory!");  \
        }                                            \
    }

#define SYS_ACL_SET_MAC_HIGH(dest_h, src)                            \
    {                                                                    \
        dest_h = ((src[0] << 8) | (src[1]));                                  \
    }

#define SYS_ACL_SET_MAC_LOW(dest_l, src)                             \
    {                                                                    \
        dest_l = ((src[2] << 24) | (src[3] << 16) | (src[4] << 8) | (src[5])); \
    }

#define  DUMP_IPV4(pk)                                                            \
    {                                                                                 \
        uint32 addr;                                                                  \
        char ip_addr[16];                                                             \
        if (pk->flag.ip_sa)                                                           \
        {                                                                             \
            if (0xFFFFFFFF == pk->ip_sa_mask)                                         \
            {                                                                         \
                SYS_ACL_DBG_DUMP("  ip-sa host");                                     \
                addr = sal_ntohl(pk->ip_sa);                                          \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP(" %s", ip_addr);                                     \
            }                                                                         \
            else if (0 == pk->ip_sa_mask)                                             \
            {                                                                         \
                SYS_ACL_DBG_DUMP("  ip-sa any");                                      \
            }                                                                         \
            else                                                                      \
            {                                                                         \
                SYS_ACL_DBG_DUMP("  ip-sa");                                          \
                addr = sal_ntohl(pk->ip_sa);                                          \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP(" %s", ip_addr);                                     \
                addr = sal_ntohl(pk->ip_sa_mask);                                     \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP("  %s", ip_addr);                                    \
            }                                                                         \
        }                                                                             \
        else                                                                          \
        {                                                                             \
            SYS_ACL_DBG_DUMP("  ip-sa any");                                          \
        }                                                                             \
                                                                                  \
        if (pk->flag.ip_da)                                                           \
        {                                                                             \
            if (0xFFFFFFFF == pk->ip_da_mask)                                         \
            {                                                                         \
                SYS_ACL_DBG_DUMP(",  ip-da host");                                    \
                addr = sal_ntohl(pk->ip_da);                                          \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP(" %s", ip_addr);                                     \
            }                                                                         \
            else if (0 == pk->ip_da_mask)                                             \
            {                                                                         \
                SYS_ACL_DBG_DUMP(",  ip-da any");                                     \
            }                                                                         \
            else                                                                      \
            {                                                                         \
                SYS_ACL_DBG_DUMP(",  ip-da");                                         \
                addr = sal_ntohl(pk->ip_da);                                          \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP(" %s", ip_addr);                                     \
                addr = sal_ntohl(pk->ip_da_mask);                                     \
                sal_inet_ntop(AF_INET, &addr, ip_addr, sizeof(ip_addr));              \
                SYS_ACL_DBG_DUMP("  %s", ip_addr);                                    \
            }                                                                         \
        }                                                                             \
        else                                                                          \
        {                                                                             \
            SYS_ACL_DBG_DUMP(",  ip-da any");                                         \
        }                                                                             \
        SYS_ACL_DBG_DUMP("\n");                                                       \
    }

#define    DUMP_IPV6(pk)                                                                \
    {                                                                                       \
        char buf[CTC_IPV6_ADDR_STR_LEN];                                                    \
        ipv6_addr_t ipv6_addr;                                                              \
        sal_memset(buf, 0, CTC_IPV6_ADDR_STR_LEN);                                          \
        sal_memset(ipv6_addr, 0, sizeof(ipv6_addr_t));                                      \
        if (pk->flag.ip_sa)                                                                 \
        {                                                                                   \
            if ((0xFFFFFFFF == pk->ip_sa_mask[0]) && (0xFFFFFFFF == pk->ip_sa_mask[1])        \
                && (0xFFFFFFFF == pk->ip_sa_mask[2]) && (0xFFFFFFFF == pk->ip_sa_mask[3]))     \
            {                                                                               \
                SYS_ACL_DBG_DUMP("  ip-sa host ");                                          \
                                                                                        \
                ipv6_addr[0] = sal_htonl(pk->ip_sa[0]);                                     \
                ipv6_addr[1] = sal_htonl(pk->ip_sa[1]);                                     \
                ipv6_addr[2] = sal_htonl(pk->ip_sa[2]);                                     \
                ipv6_addr[3] = sal_htonl(pk->ip_sa[3]);                                     \
                                                                                        \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s", buf);                                              \
            }                                                                               \
            else if ((0 == pk->ip_sa_mask[0]) && (0 == pk->ip_sa_mask[1])                     \
                     && (0 == pk->ip_sa_mask[2]) && (0 == pk->ip_sa_mask[3]))                       \
            {                                                                               \
                SYS_ACL_DBG_DUMP("  ip-sa any");                                            \
            }                                                                               \
            else                                                                            \
            {                                                                               \
                SYS_ACL_DBG_DUMP("  ip-sa");                                                \
                ipv6_addr[0] = sal_htonl(pk->ip_sa[0]);                                     \
                ipv6_addr[1] = sal_htonl(pk->ip_sa[1]);                                     \
                ipv6_addr[2] = sal_htonl(pk->ip_sa[2]);                                     \
                ipv6_addr[3] = sal_htonl(pk->ip_sa[3]);                                     \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s ", buf);                                             \
                                                                                        \
                ipv6_addr[0] = sal_htonl(pk->ip_sa_mask[0]);                                \
                ipv6_addr[1] = sal_htonl(pk->ip_sa_mask[1]);                                \
                ipv6_addr[2] = sal_htonl(pk->ip_sa_mask[2]);                                \
                ipv6_addr[3] = sal_htonl(pk->ip_sa_mask[3]);                                \
                                                                                        \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s", buf);                                              \
            }                                                                               \
        }                                                                                   \
        else                                                                                \
        {                                                                                   \
            SYS_ACL_DBG_DUMP("  ip-sa any");                                                \
        }                                                                                   \
                                                                                        \
        sal_memset(buf, 0, CTC_IPV6_ADDR_STR_LEN);                                          \
                                                                                        \
        if (pk->flag.ip_da)                                                                 \
        {                                                                                   \
            if ((0xFFFFFFFF == pk->ip_da_mask[0]) && (0xFFFFFFFF == pk->ip_da_mask[1])        \
                && (0xFFFFFFFF == pk->ip_da_mask[2]) && (0xFFFFFFFF == pk->ip_da_mask[3]))     \
            {                                                                               \
                SYS_ACL_DBG_DUMP(",  ip-da host ");                                         \
                                                                                        \
                ipv6_addr[0] = sal_htonl(pk->ip_da[0]);                                     \
                ipv6_addr[1] = sal_htonl(pk->ip_da[1]);                                     \
                ipv6_addr[2] = sal_htonl(pk->ip_da[2]);                                     \
                ipv6_addr[3] = sal_htonl(pk->ip_da[3]);                                     \
                                                                                        \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s", buf);                                              \
            }                                                                               \
            else if ((0 == pk->ip_da_mask[0]) && (0 == pk->ip_da_mask[1])                     \
                     && (0 == pk->ip_da_mask[2]) && (0 == pk->ip_da_mask[3]))                       \
            {                                                                               \
                SYS_ACL_DBG_DUMP(",  ip-da any");                                           \
            }                                                                               \
            else                                                                            \
            {                                                                               \
                SYS_ACL_DBG_DUMP(",  ip-da");                                               \
                ipv6_addr[0] = sal_htonl(pk->ip_da[0]);                                     \
                ipv6_addr[1] = sal_htonl(pk->ip_da[1]);                                     \
                ipv6_addr[2] = sal_htonl(pk->ip_da[2]);                                     \
                ipv6_addr[3] = sal_htonl(pk->ip_da[3]);                                     \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s ", buf);                                             \
                                                                                        \
                ipv6_addr[0] = sal_htonl(pk->ip_da_mask[0]);                                \
                ipv6_addr[1] = sal_htonl(pk->ip_da_mask[1]);                                \
                ipv6_addr[2] = sal_htonl(pk->ip_da_mask[2]);                                \
                ipv6_addr[3] = sal_htonl(pk->ip_da_mask[3]);                                \
                                                                                        \
                sal_inet_ntop(AF_INET6, ipv6_addr, buf, CTC_IPV6_ADDR_STR_LEN);             \
                SYS_ACL_DBG_DUMP("%20s", buf);                                              \
            }                                                                               \
        }                                                                                   \
        else                                                                                \
        {                                                                                   \
            SYS_ACL_DBG_DUMP(",  ip-da any");                                               \
        }                                                                                   \
        SYS_ACL_DBG_DUMP("\n");                                                             \
    }

#define    DUMP_L2_0(pk)                                                                \
    SYS_ACL_DBG_DUMP("  mac-sa");                                                       \
    if (pk->flag.mac_sa)                                                                \
    {                                                                                   \
        if ((0xFFFF == *(uint16*)&pk->mac_sa_mask[0]) &&                               \
            (0xFFFFFFFF == *(uint32*)&pk->mac_sa_mask[2]))                             \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" host %02x%02x.%02x%02x.%02x%02x",                        \
                             pk->mac_sa[0], pk->mac_sa[1], pk->mac_sa[2],                     \
                             pk->mac_sa[3], pk->mac_sa[4], pk->mac_sa[5]);                    \
        }                                                                               \
        else if ((0 == *(uint16*)&pk->mac_sa_mask[0]) &&                               \
                 (0 == *(uint32*)&pk->mac_sa_mask[2]))                                 \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" any");                                                   \
        }                                                                               \
        else                                                                            \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" %02x%02x.%02x%02x.%02x%02x %02x%02x.%02x%02x.%02x%02x",  \
                             pk->mac_sa[0], pk->mac_sa[1], pk->mac_sa[2],                     \
                             pk->mac_sa[3], pk->mac_sa[4], pk->mac_sa[5],                     \
                             pk->mac_sa_mask[0], pk->mac_sa_mask[1], pk->mac_sa_mask[2],      \
                             pk->mac_sa_mask[3], pk->mac_sa_mask[4], pk->mac_sa_mask[5]);     \
        }                                                                               \
    }                                                                                   \
    else                                                                                \
    {                                                                                   \
        SYS_ACL_DBG_DUMP(" any");                                                       \
    }                                                                                   \
                                                                                        \
    SYS_ACL_DBG_DUMP(",  mac-da");                                                      \
    if (pk->flag.mac_da)                                                                \
    {                                                                                   \
        if ((0xFFFF == *(uint16*)&pk->mac_da_mask[0]) &&                               \
            (0xFFFFFFFF == *(uint32*)&pk->mac_da_mask[2]))                             \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" host %02x%02x.%02x%02x.%02x%02x",                        \
                             pk->mac_da[0], pk->mac_da[1], pk->mac_da[2],                     \
                             pk->mac_da[3], pk->mac_da[4], pk->mac_da[5]);                    \
        }                                                                               \
        else if ((0 == *(uint16*)&pk->mac_da_mask[0]) &&                               \
                 (0 == *(uint32*)&pk->mac_da_mask[2]))                                 \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" any");                                                   \
        }                                                                               \
        else                                                                            \
        {                                                                               \
            SYS_ACL_DBG_DUMP(" %02x%02x.%02x%02x.%02x%02x %02x%02x.%02x%02x.%02x%02x",  \
                             pk->mac_da[0], pk->mac_da[1], pk->mac_da[2],                     \
                             pk->mac_da[3], pk->mac_da[4], pk->mac_da[5],                     \
                             pk->mac_da_mask[0], pk->mac_da_mask[1], pk->mac_da_mask[2],      \
                             pk->mac_da_mask[3], pk->mac_da_mask[4], pk->mac_da_mask[5]);     \
        }                                                                               \
    }                                                                                   \
    else                                                                                \
    {                                                                                   \
        SYS_ACL_DBG_DUMP(" any");                                                       \
    }                                                                                   \
    SYS_ACL_DBG_DUMP("\n");                                                        \
                                                                                   \
                                                                                   \
    if (pk->flag.cos)                                                              \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  cos %d  mask %d,", pk->cos, pk->cos_mask);              \
    }                                                                              \
    if (pk->flag.cvlan)                                                            \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  c-vlan 0x%x  mask 0x%0x,", pk->cvlan, pk->cvlan_mask); \
    }                                                                              \
    if (pk->flag.ctag_cos)                                                         \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  c-cos %d  mask %d,", pk->ctag_cos, pk->ctag_cos_mask);  \
    }                                                                              \
    if (pk->flag.ctag_cfi)                                                         \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  c-cfi %d,", pk->ctag_cfi);                             \
    }                                                                              \
    if ((pk->flag.cos) +                                                           \
        (pk->flag.cvlan) +                                                         \
        (pk->flag.ctag_cos) +                                                      \
        (pk->flag.ctag_cfi))                                                       \
    {                                                                              \
        SYS_ACL_DBG_DUMP("\n");                                                    \
    }                                                                              \
                                                                                   \
                                                                                   \
    if (pk->flag.svlan)                                                            \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  s-vlan 0x%x  mask 0x%0x,", pk->svlan, pk->svlan_mask); \
    }                                                                              \
    if (pk->flag.stag_cos)                                                         \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  s-cos %d  mask %d,", pk->stag_cos, pk->stag_cos_mask);  \
    }                                                                              \
    if (pk->flag.stag_cfi)                                                         \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  s-cfi %d,", pk->stag_cfi);                             \
    }                                                                              \
    if ((pk->flag.svlan) +                                                         \
        (pk->flag.stag_cos) +                                                      \
        (pk->flag.stag_cfi))                                                       \
    {                                                                              \
        SYS_ACL_DBG_DUMP("\n");                                                    \
    }                                                                              \


#define    DUMP_L2_TYPE(pk)                                                           \
    if (pk->flag.l2_type)                                                          \
    {                                                                              \
        SYS_ACL_DBG_DUMP("  l2_type %d  mask %d,", pk->l2_type, pk->l2_type_mask); \
    }                                                                              \
    if (pk->flag.l2_type)                                                          \
    {                                                                              \
        SYS_ACL_DBG_DUMP("\n");                                                    \
    }

#define    DUMP_L2_ETH_TYPE(pk)                                                           \
    if (pk->flag.eth_type)                                                                \
    {                                                                                     \
        SYS_ACL_DBG_DUMP("  eth-type 0x%x  mask 0x%x,", pk->eth_type, pk->eth_type_mask); \
    }                                                                                     \
    if (pk->flag.eth_type)                                                                \
    {                                                                                     \
        SYS_ACL_DBG_DUMP("\n");                                                           \
    }

#define   DUMP_L3(pk)                                                          \
    if (pk->flag.dscp)                                                         \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  dscp %d  mask %d,", pk->dscp, pk->dscp_mask);      \
    }                                                                          \
    if (pk->flag.frag_info)                                                    \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  frag-info %d  mask %d,", pk->frag_info,            \
                         pk->frag_info_mask);                                                   \
    }                                                                          \
    if (pk->flag.ip_option)                                                    \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  ip-option %d,", pk->ip_option);                    \
    }                                                                          \
    if ((pk->flag.dscp) +                                                      \
        (pk->flag.frag_info) +                                                 \
        (pk->flag.ip_option))                                                  \
    {                                                                          \
        SYS_ACL_DBG_DUMP("\n");                                                \
    }                                                                          \
                                                                               \
    if (pk->flag.ip_hdr_error)                                                 \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  ip-hdr-error %d,", pk->ip_hdr_error);              \
    }                                                                          \
    if (pk->flag.routed_packet)                                                \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  routed-packet %d,", pk->routed_packet);            \
    }                                                                          \
    if (pk->flag.l4info_mapped)                                                \
    {                                                                          \
        SYS_ACL_DBG_DUMP("  l4info_mapped 0x%x  mask 0x%x,",                   \
                         pk->l4info_mapped, pk->l4info_mapped_mask);                         \
    }                                                                          \
    if ((pk->flag.ip_hdr_error) +                                              \
        (pk->flag.routed_packet) +                                             \
        (pk->flag.l4info_mapped))                                              \
    {                                                                          \
        SYS_ACL_DBG_DUMP("\n");                                                \
    }

#define    DUMP_L3_TYPE(pk)                                                                       \
    if (pk->flag.l3_type)                                                                            \
    {                                                                                                \
        SYS_ACL_DBG_DUMP("  l3_type %d  mask %d,", pk->l3_type, pk->l3_type_mask);                   \
    }                                                                                                \
    if (pk->flag.l3_type)                                                                            \
    {                                                                                                \
        SYS_ACL_DBG_DUMP("\n");                                                                      \
    }                                                                                                \


#define   DUMP_IPV6_UNIQUE(pk)                                   \
    DUMP_IPV6(pk)                                                \
    if (pk->flag.ext_hdr)                                        \
    {                                                            \
        SYS_ACL_DBG_DUMP("  ext_hdr %d  mask %d,",               \
                         pk->ext_hdr, pk->ext_hdr_mask);                  \
    }                                                            \
    if (pk->flag.flow_label)                                     \
    {                                                            \
        SYS_ACL_DBG_DUMP("  flow-label 0x%x flow-label 0x%x,",   \
                         pk->flow_label, pk->flow_label_mask);         \
    }                                                            \
    if ((pk->flag.ext_hdr) + (pk->flag.flow_label))              \
    {                                                            \
        SYS_ACL_DBG_DUMP("\n");                              \
    }                                                            \


#define   DUMP_MPLS_UNIQUE(pk)                                       \
    if (pk->flag.routed_packet)                                      \
    {                                                                \
        SYS_ACL_DBG_DUMP("  routed-packet %d,", pk->routed_packet);  \
        SYS_ACL_DBG_DUMP("\n");                                      \
    }                                                                \
    if (pk->flag.mpls_label0)                                         \
    {                                                                \
        if (0 == pk->mpls_label0_mask)                                \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label0 any,");                  \
        }                                                            \
        else                                                         \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label0 0x%x  mask 0x%x",        \
                             (pk->mpls_label0 >> 12), (pk->mpls_label0_mask >> 12));   \
        }                                                            \
    }                                                                \
    if (pk->flag.mpls_label1)                                         \
    {                                                                \
        if (0 == pk->mpls_label1_mask)                                \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label1 any,");                  \
        }                                                            \
        else                                                         \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label1 0x%x  mask 0x%x",        \
                             (pk->mpls_label1 >> 12), (pk->mpls_label1_mask >> 12));   \
        }                                                            \
    }                                                                \
    if ((pk->flag.mpls_label0) + (pk->flag.mpls_label1))             \
    {                                                                \
        SYS_ACL_DBG_DUMP("\n");                                  \
    }                                                                \
    if (pk->flag.mpls_label2)                                         \
    {                                                                \
        if (0 == pk->mpls_label2_mask)                                \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label2 any,");                  \
        }                                                            \
        else                                                         \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label2 0x%x  mask 0x%x",        \
                             (pk->mpls_label2 >> 12), (pk->mpls_label2_mask >> 12));   \
        }                                                            \
    }                                                                \
    if (pk->flag.mpls_label3)                                         \
    {                                                                \
        if (0 == pk->mpls_label3_mask)                                \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label3 any,");                  \
        }                                                            \
        else                                                         \
        {                                                            \
            SYS_ACL_DBG_DUMP("  mpls-label3 0x%x  mask 0x%x",        \
                             (pk->mpls_label3 >> 12), (pk->mpls_label3_mask >> 12));   \
        }                                                            \
    }                                                                \
    if ((pk->flag.mpls_label2) + (pk->flag.mpls_label3))             \
    {                                                                \
        SYS_ACL_DBG_DUMP("\n");                                  \
    }                                                                \


#define SYS_ACL_ALL_ONE(num)  ((1 << (num)) - 1)

#define SYS_ACL_AND_MASK_NUM(src, right, num)   (((src) >> (right)) & SYS_ACL_ALL_ONE(num))

#define ACL_PRINT_ENTRY_ROW(eid)        SYS_ACL_DBG_DUMP("\n>>entry-id %u : \n", (eid))
#define ACL_PRINT_GROUP_ROW(gid)        SYS_ACL_DBG_DUMP("\n>>group-id %u (first in goes last, installed goes tail) :\n", (gid))
#define ACL_PRINT_PRIO_ROW(prio)        SYS_ACL_DBG_DUMP("\n>>group-prio %u (sort by block_idx ) :\n", (prio))
#define ACL_PRINT_TYPE_ROW(type)        SYS_ACL_DBG_DUMP("\n>>type %u (sort by block_idx ) :\n", (type))
#define ACL_PRINT_ALL_SORT_SEP_BY_ROW(type) SYS_ACL_DBG_DUMP("\n>>Separate by %s. \n", (type) ? "group" : "priority")

#define ACL_PRINT_COUNT(n)    SYS_ACL_DBG_DUMP("NO.%04d  ", n)
#define SYS_ACL_ALL_KEY   CTC_ACL_KEY_NUM

#define ACL_GET_TABLE_ENTYR_NUM(t, n)  CTC_ERROR_RETURN(sys_alloc_get_table_entry_num(t, n));
struct drv_acl_group_info_s
{
    uint8 dir;
    uint8 is_label;
    uint8 block_id;
    uint16 label;
    uint16 mask;
};
typedef struct drv_acl_group_info_s drv_acl_group_info_t;

typedef struct
{
    uint16 count;
    uint8  detail;
    uint8  rsv;
    ctc_acl_key_type_t key_type;
} _acl_cb_para_t;
#define FPA_INVALID_INDEX  (-1)

#define ___________ACL_INNER_FUNCTION________________________

int32 prio_set_with_no_free_entries = FALSE;

#define _0_ACL_SW_GET_

/*
 *get sys entry node by entry id
 */
static int32
_sys_humber_acl_get_sys_entry_by_eid(uint32 eid, sys_acl_entry_t** sys_entry_out)
{
    sys_acl_entry_t* p_sys_entry_lkup = NULL;
    sys_acl_entry_t sys_entry;

    CTC_PTR_VALID_CHECK(sys_entry_out);
    SYS_ACL_DBG_FUNC();

    sal_memset(&sys_entry, 0, sizeof(sys_acl_entry_t));
    sys_entry.entry_id = eid;

    p_sys_entry_lkup = ctc_hash_lookup(acl_master->entry, &sys_entry);

    *sys_entry_out = p_sys_entry_lkup;

    return CTC_E_NONE;
}

/*
 *get sys group node by group id
 */
static int32
_sys_humber_acl_get_sys_group_by_gid(uint32 gid, sys_acl_group_t** sys_group_out)
{
    sys_acl_group_t* p_sys_group_lkup = NULL;
    sys_acl_group_t sys_group;

    CTC_PTR_VALID_CHECK(sys_group_out);
    SYS_ACL_DBG_FUNC();

    sal_memset(&sys_group, 0, sizeof(sys_acl_group_t));
    sys_group.group_id = gid;

    p_sys_group_lkup = ctc_hash_lookup(acl_master->group, &sys_group);

    *sys_group_out = p_sys_group_lkup;

    return CTC_E_NONE;
}

/*
 * below is build hw struct
 */
#define _2_ACL_HW_

static int32
_sys_humber_acl_copy_dsfwd(uint8 lchip, uint32 src_fwd_ptr, uint32 dest_fwd_ptr)
{
    uint32 cmd;
    ds_fwd_t dsfwd;

    sal_memset(&dsfwd, 0, sizeof(ds_fwd_t));

    cmd = DRV_IOR(IOC_TABLE, DS_FWD, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, src_fwd_ptr, cmd, &dsfwd));

    cmd = DRV_IOW(IOC_TABLE, DS_FWD, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, dest_fwd_ptr, cmd, &dsfwd));

    return CTC_E_NONE;
}

/*
 *check group info if it is valid.
 */
static int32
_sys_humber_acl_check_group_info(ctc_acl_group_info_t* pinfo, uint8 type, uint8 is_create)
{

    CTC_PTR_VALID_CHECK(pinfo);
    SYS_ACL_DBG_FUNC();

    if (is_create) /*only create check lchip..*/
    {
        if (CTC_ACL_GROUP_TYPE_PORT_CLASS == type)
        {
            if (pinfo->lchip >= acl_master->lchip_num)
            {
                return CTC_E_INVALID_PARAM;
            }
        }
    }

    CTC_MAX_VALUE_CHECK(pinfo->dir, CTC_BOTH_DIRECTION);

    switch (type)
    {
    case CTC_ACL_GROUP_TYPE_GLOBAL:
        break;

    case CTC_ACL_GROUP_TYPE_VLAN_CLASS:
        CTC_MAX_VALUE_CHECK(pinfo->un.vlan_class_id, CTC_ACL_VLAN_CLASSID_MAX);
        break;

    case CTC_ACL_GROUP_TYPE_PORT_CLASS:
        CTC_MAX_VALUE_CHECK(pinfo->un.port_class_id, CTC_ACL_PORT_CLASSID_MAX);
        break;

    case CTC_ACL_GROUP_TYPE_SERVICE_ACL:
        SYS_ACL_SERVICE_ID_CHECK(pinfo->un.service_id);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_action(uint8 lchip, sys_acl_action_t* p_sys_action, ds_mac_acl_t* p_ds_action)
{
    CTC_PTR_VALID_CHECK(p_sys_action);
    CTC_PTR_VALID_CHECK(p_ds_action);

    SYS_ACL_DBG_FUNC();

    p_ds_action->discard_packet   = p_sys_action->flag.discard;
    p_ds_action->deny_learning    = p_sys_action->flag.deny_learning;
    p_ds_action->deny_bridge      = p_sys_action->flag.deny_bridge;
    p_ds_action->deny_route       = p_sys_action->flag.deny_route;

    if (p_sys_action->flag.stats)
    {
        p_ds_action->stats_ptr = p_sys_action->stats_ptr[lchip];
    }
    else
    {
        p_ds_action->stats_ptr = SYS_ACL_SPECIAL_STATS_PTR;
    }

    if (p_sys_action->flag.micro_flow_policer)
    {
        p_ds_action->flow_policer_ptr = p_sys_action->micro_policer_ptr[lchip];
    }
    else
    {
        p_ds_action->flow_policer_ptr = SYS_ACL_SPECIAL_POLICER_PTR;
    }

    if (p_sys_action->flag.random_log)
    {
        p_ds_action->random_log_en = 1;
        p_ds_action->random_threshold_shift = p_sys_action->random_threshold_shift;
        p_ds_action->acl_log_id = p_sys_action->acl_log_id;
    }

    if (p_sys_action->flag.priority_and_color)
    {
        p_ds_action->priority_valid = 1;
        p_ds_action->priority = p_sys_action->priority;
        p_ds_action->color = p_sys_action->color;
    }

    if (p_sys_action->flag.trust)
    {
        p_ds_action->qos_policy = p_sys_action->trust;
    }
    else
    { /* 7 is invalid */
        p_ds_action->qos_policy = 7;
    }

    if (p_sys_action->flag.redirect)
    {
        p_ds_action->fwd_ptr = p_sys_action->ds_fwd_offset;
    }
    else
    {
        p_ds_action->fwd_ptr = 0xFFF;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_group_info(sys_acl_group_info_t* pg_sys, drv_acl_group_info_t* pg_drv)
{
    CTC_PTR_VALID_CHECK(pg_drv);
    CTC_PTR_VALID_CHECK(pg_sys);

    SYS_ACL_DBG_FUNC();
    pg_drv->dir = pg_sys->dir;
    pg_drv->is_label = 1;
    pg_drv->block_id = pg_sys->block_id;

    switch (pg_sys->type)
    {
    case     CTC_ACL_GROUP_TYPE_GLOBAL:
        if (pg_sys->dir == CTC_INGRESS)
        {
            pg_drv->label = 0;
            pg_drv->mask  = 0x80;
        }
        else if (pg_sys->dir == CTC_EGRESS)
        {
            pg_drv->label = 0x80;
            pg_drv->mask  = 0x80;
        }
        else
        {
            pg_drv->label = 0;
            pg_drv->mask  = 0;
        }

        break;

    case     CTC_ACL_GROUP_TYPE_VLAN_CLASS:
        if (pg_sys->dir == CTC_INGRESS)
        {
            pg_drv->label = pg_sys->un.vlan_class_id & 0xFF;
        }
        else
        {
            pg_drv->label = (pg_sys->un.vlan_class_id + 0x80) & 0xFF;
        }

        pg_drv->mask  = 0xFF;
        break;

    case     CTC_ACL_GROUP_TYPE_PORT_CLASS:
        if (pg_sys->dir == CTC_INGRESS)
        {
            pg_drv->label = pg_sys->un.port_class_id & 0xFF;
        }
        else
        {
            pg_drv->label = (pg_sys->un.port_class_id + 0x80) & 0xFF;
        }

        pg_drv->mask  = 0xFF;
        break;

    case     CTC_ACL_GROUP_TYPE_SERVICE_ACL:
        pg_drv->is_label = 0;
        pg_drv->label = pg_sys->un.service_id;
        pg_drv->mask  = 0xFFFF;
        break;

    default:
        return CTC_E_INVALID_PARAM;

    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_mac_key(drv_acl_group_info_t* p_info,
                                 sys_acl_mac_key_t* p_sys_key,
                                 ds_acl_mac_key_t* p_ds_key,
                                 ds_acl_mac_key_t* p_ds_mask)
{

    CTC_PTR_VALID_CHECK(p_info);
    CTC_PTR_VALID_CHECK(p_sys_key);
    CTC_PTR_VALID_CHECK(p_ds_key);
    CTC_PTR_VALID_CHECK(p_ds_mask);

    SYS_ACL_DBG_FUNC();

    /* mac da */
    if (p_sys_key->flag.mac_da)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_dah, p_sys_key->mac_da);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_dal, p_sys_key->mac_da);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_dah, p_sys_key->mac_da_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_dal, p_sys_key->mac_da_mask);
    }

    /* mac sa */
    if (p_sys_key->flag.mac_sa)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_sah, p_sys_key->mac_sa);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_sal, p_sys_key->mac_sa);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_sah, p_sys_key->mac_sa_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_sal, p_sys_key->mac_sa_mask);
    }

    /* vlan ptr */
    if (p_sys_key->flag.vlan_ptr)
    {
        p_ds_key->vlan_ptr = p_sys_key->vlan_ptr;
        p_ds_mask->vlan_ptr = 0x3FFF;
    }

    /* cos */
    if (p_sys_key->flag.cos)
    {
        p_ds_key->cos = p_sys_key->cos;
        p_ds_mask->cos = p_sys_key->cos_mask;
    }

    /* cvlan id */
    if (p_sys_key->flag.cvlan)
    {
        p_ds_key->cvlan_id11to5 = p_sys_key->cvlan >> 5;
        p_ds_key->cvlan_id4to0 = p_sys_key->cvlan & 0x1F;

        p_ds_mask->cvlan_id11to5 = p_sys_key->cvlan_mask >> 5;
        p_ds_mask->cvlan_id4to0 = p_sys_key->cvlan_mask & 0x1F;
    }

    /* ctag cos */
    if (p_sys_key->flag.ctag_cos)
    {
        p_ds_key->ctag_cos = p_sys_key->ctag_cos;
        p_ds_mask->ctag_cos = p_sys_key->ctag_cos_mask;
    }

    /* ctag cfi */
    if (p_sys_key->flag.ctag_cfi)
    {
        p_ds_key->ctag_cfi = p_sys_key->ctag_cfi;
        p_ds_mask->ctag_cfi = 0x1;
    }

    /* svlan id */
    if (p_sys_key->flag.svlan)
    {
        p_ds_key->svlan_id = p_sys_key->svlan;
        p_ds_mask->svlan_id = p_sys_key->svlan_mask;
    }

    /* stag cos */
    if (p_sys_key->flag.stag_cos)
    {
        p_ds_key->stag_cos = p_sys_key->stag_cos;
        p_ds_mask->stag_cos = p_sys_key->stag_cos_mask;
    }

    /* stag cfi */
    if (p_sys_key->flag.stag_cfi)
    {
        p_ds_key->stag_cfi = p_sys_key->stag_cfi;
        p_ds_mask->stag_cfi = 0x1;
    }

    /* ethernet type */
    if (p_sys_key->flag.eth_type)
    {
        p_ds_key->ether_type = p_sys_key->eth_type;
        p_ds_mask->ether_type = p_sys_key->eth_type_mask;
    }

    /* layer 2 type */
    if (p_sys_key->flag.l2_type)
    {
        p_ds_key->layer2_type = p_sys_key->l2_type;
        p_ds_mask->layer2_type = p_sys_key->l2_type_mask;
    }

    /* layer 3 type */
    if (p_sys_key->flag.l3_type)
    {
        p_ds_key->layer3_type = p_sys_key->l3_type;
        p_ds_mask->layer3_type = p_sys_key->l3_type_mask;
    }

    /* non-property field */
    if (p_info->block_id == 0)
    {
        p_ds_key->acl_labelh = p_info->label >> 4;
        p_ds_key->acl_labell = p_info->label & 0xF;

        p_ds_mask->acl_labelh = p_info->mask >> 4;
        p_ds_mask->acl_labell = p_info->mask & 0xF;
    }
    else
    {
        p_ds_key->qos_label = p_info->label;
        p_ds_mask->qos_label = p_info->mask;
    }

    p_ds_key->is_label = p_info->is_label;
    p_ds_mask->is_label = 1;

    if (!p_info->is_label)  /* service label */
    {
        p_ds_key->acl_labelh = p_info->label >> 12;
        p_ds_key->acl_labell = (p_info->label >> 8) & 0xF;

        p_ds_mask->acl_labelh = p_info->mask >> 12;
        p_ds_mask->acl_labell = (p_info->mask >> 8) & 0xF;

        p_ds_key->qos_label = p_info->label & 0xFF;
        p_ds_mask->qos_label = p_info->mask & 0xFF;
    }

    p_ds_key->is_ip_key = 0;
    p_ds_mask->is_ip_key = 1;

    p_ds_key->tableid0 = ACL_MAC_TABLEID0_C;
    p_ds_key->tableid1 = ACL_MAC_TABLEID0_C;
    p_ds_key->tableid2 = ACL_MAC_TABLEID0_C;
    p_ds_key->tableid3 = ACL_MAC_TABLEID0_C;

    p_ds_mask->tableid0 = 0xF;
    p_ds_mask->tableid1 = 0xF;
    p_ds_mask->tableid2 = 0xF;
    p_ds_mask->tableid3 = 0xF;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_ipv4_key(drv_acl_group_info_t* p_info,
                                  sys_acl_ipv4_key_t* p_sys_key,
                                  ds_acl_ipv4_key_t* p_ds_key,
                                  ds_acl_ipv4_key_t* p_ds_mask)
{

    CTC_PTR_VALID_CHECK(p_info);
    CTC_PTR_VALID_CHECK(p_sys_key);
    CTC_PTR_VALID_CHECK(p_ds_key);
    CTC_PTR_VALID_CHECK(p_ds_mask);

    SYS_ACL_DBG_FUNC();

    /* ip da */
    if (p_sys_key->flag.ip_da)
    {
        p_ds_key->ip_da = p_sys_key->ip_da;
        p_ds_mask->ip_da = p_sys_key->ip_da_mask;
    }

    /* ip sa */
    if (p_sys_key->flag.ip_sa)
    {
        p_ds_key->ip_sa = p_sys_key->ip_sa;
        p_ds_mask->ip_sa = p_sys_key->ip_sa_mask;
    }

    /* l4 info mapped */
    if (p_sys_key->flag.l4info_mapped)
    {
        p_ds_key->l4info_mapped = p_sys_key->l4info_mapped;
        p_ds_mask->l4info_mapped = p_sys_key->l4info_mapped_mask;
    }

    /* is tcp */
    if (p_sys_key->flag.is_tcp)
    {
        p_ds_key->is_tcp = p_sys_key->is_tcp;
        p_ds_mask->is_tcp = 1;
    }

    /* is udp */
    if (p_sys_key->flag.is_udp)
    {
        p_ds_key->is_udp = p_sys_key->is_udp;
        p_ds_mask->is_udp = 1;
    }

    /* l4 source port */
    if (p_sys_key->flag.l4_src_port)
    {
        p_ds_key->l4_source_port = p_sys_key->l4_src_port;
        p_ds_mask->l4_source_port = p_sys_key->l4_src_port_mask;
    }

    /* l4 destination port */
    if (p_sys_key->flag.l4_dst_port)
    {
        p_ds_key->l4_dest_port = p_sys_key->l4_dst_port;
        p_ds_mask->l4_dest_port = p_sys_key->l4_dst_port_mask;
    }

    /* dscp */
    if (p_sys_key->flag.dscp)
    {
        p_ds_key->dscp = p_sys_key->dscp;
        p_ds_mask->dscp = p_sys_key->dscp_mask;
    }

    /* ip fragement */
    if (p_sys_key->flag.frag_info)
    {
        p_ds_key->frag_info = p_sys_key->frag_info;
        p_ds_mask->frag_info = p_sys_key->frag_info_mask;
    }

    /* ip option */
    if (p_sys_key->flag.ip_option)
    {
        p_ds_key->ip_options = p_sys_key->ip_option;
        ;
        p_ds_mask->ip_options = 1;
    }

    /* ip header error */
    if (p_sys_key->flag.ip_hdr_error)
    {
        p_ds_key->ip_header_error = p_sys_key->ip_hdr_error;
        p_ds_mask->ip_header_error = 1;
    }

    /* routed packet */
    if (p_sys_key->flag.routed_packet)
    {
        p_ds_key->routed_packet = p_sys_key->routed_packet;
        p_ds_mask->routed_packet = 1;
    }

    /* mac da */
    if (p_sys_key->flag.mac_da)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->macda_upper, p_sys_key->mac_da);
        SYS_ACL_SET_MAC_LOW(p_ds_key->macda_lower, p_sys_key->mac_da);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->macda_upper, p_sys_key->mac_da_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->macda_lower, p_sys_key->mac_da_mask);
    }

    /* mac sa */
    if (p_sys_key->flag.mac_sa)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_sa_upper, p_sys_key->mac_sa);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_sa_lower, p_sys_key->mac_sa);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_sa_upper, p_sys_key->mac_sa_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_sa_lower, p_sys_key->mac_sa_mask);
    }

    /* cos */
    if (p_sys_key->flag.cos)
    {
        p_ds_key->cos = p_sys_key->cos;
        p_ds_mask->cos = p_sys_key->cos_mask;
    }

    /* cvlan id */
    if (p_sys_key->flag.cvlan)
    {
        p_ds_key->cvlan_id = p_sys_key->cvlan;
        p_ds_mask->cvlan_id = p_sys_key->cvlan_mask;
    }

    /* ctag cos */
    if (p_sys_key->flag.ctag_cos)
    {
        p_ds_key->ctag_cos = p_sys_key->ctag_cos;
        p_ds_mask->ctag_cos = p_sys_key->ctag_cos_mask;
    }

    /* ctag cfi */
    if (p_sys_key->flag.ctag_cfi)
    {
        p_ds_key->ctag_cfi = p_sys_key->ctag_cfi;
        p_ds_mask->ctag_cfi = 1;
    }

    /* svlan id */
    if (p_sys_key->flag.svlan)
    {
        p_ds_key->svlan_id = p_sys_key->svlan;
        p_ds_mask->svlan_id = p_sys_key->svlan_mask;
    }

    /* stag cos */
    if (p_sys_key->flag.stag_cos)
    {
        p_ds_key->stag_cos = p_sys_key->stag_cos;
        p_ds_mask->stag_cos = p_sys_key->stag_cos_mask;
    }

    /* stag cfi */
    if (p_sys_key->flag.stag_cfi)
    {
        p_ds_key->stag_cfi = p_sys_key->stag_cfi;
        p_ds_mask->stag_cfi = 1;
    }

    /* l2 type */
    if (p_sys_key->flag.l2_type)
    {
        p_ds_key->layer2_type = p_sys_key->l2_type;
        p_ds_mask->layer2_type = p_sys_key->l2_type_mask;
    }

    /* l3 type */
    if (p_sys_key->flag.l3_type)
    {
        p_ds_key->layer3_type = p_sys_key->l3_type;
        p_ds_mask->layer3_type = p_sys_key->l3_type_mask;
    }

    /* non-property field */
    if (p_info->block_id == 0)
    {
        p_ds_key->acl_label_upper = p_info->label >> 4;
        p_ds_key->acl_label_lower = p_info->label & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 4;
        p_ds_mask->acl_label_lower = p_info->mask & 0xF;
    }
    else
    {
        p_ds_key->qos_label = p_info->label;
        p_ds_mask->qos_label = p_info->mask;
    }

    p_ds_key->is_label = p_info->is_label;
    p_ds_mask->is_label = 1;

    if (!p_info->is_label)  /* service label */
    {
        p_ds_key->acl_label_upper = p_info->label >> 12;
        p_ds_key->acl_label_lower = (p_info->label >> 8) & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 12;
        p_ds_mask->acl_label_lower = (p_info->mask >> 8) & 0xF;

        p_ds_key->qos_label = p_info->label & 0xFF;
        p_ds_mask->qos_label = p_info->mask & 0xFF;
    }

    p_ds_key->is_ip_key = 1;
    p_ds_mask->is_ip_key = 1;

    p_ds_key->is_mpls_key = 0;
    p_ds_mask->is_mpls_key = 1;

    p_ds_key->tableid0 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid1 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid2 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid3 = ACL_IPV4_TABLEID0_C;

    p_ds_mask->tableid0 = 0xF;
    p_ds_mask->tableid1 = 0xF;
    p_ds_mask->tableid2 = 0xF;
    p_ds_mask->tableid3 = 0xF;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_ipv6_key(drv_acl_group_info_t* p_info,
                                  sys_acl_ipv6_key_t* p_sys_key,
                                  ds_acl_ipv6_key_t* p_ds_key,
                                  ds_acl_ipv6_key_t* p_ds_mask)
{
    CTC_PTR_VALID_CHECK(p_info);
    CTC_PTR_VALID_CHECK(p_sys_key);
    CTC_PTR_VALID_CHECK(p_ds_key);
    CTC_PTR_VALID_CHECK(p_ds_mask);

    SYS_ACL_DBG_FUNC();

    /* ip da */
    if (p_sys_key->flag.ip_da)
    {
        p_ds_key->ip_da127to104   = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da[0], 8, 24);
        p_ds_key->ip_da103to72    = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da[0], 0, 8) << 24
            | SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da[1], 8, 24);
        p_ds_key->ip_da71to64     = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da[1], 0, 8);
        p_ds_key->ip_da63to32     = p_sys_key->ip_da[2];
        p_ds_key->ip_da31to0      = p_sys_key->ip_da[3];

        p_ds_mask->ip_da127to104   = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da_mask[0], 8, 24);
        p_ds_mask->ip_da103to72    = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da_mask[0], 0, 8) << 24
            | SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da_mask[1], 8, 24);
        p_ds_mask->ip_da71to64     = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_da_mask[1], 0, 8);
        p_ds_mask->ip_da63to32     = p_sys_key->ip_da_mask[2];
        p_ds_mask->ip_da31to0      = p_sys_key->ip_da_mask[3];
    }

    /* ip sa */
    if (p_sys_key->flag.ip_sa)
    {
        p_ds_key->ip_sa127to104   = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa[0], 8, 24);
        p_ds_key->ip_sa103to72    = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa[0], 0, 8) << 24
            | SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa[1], 8, 24);
        p_ds_key->ip_sa71to64     = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa[1], 0, 8);
        p_ds_key->ip_sa63to32     = p_sys_key->ip_sa[2];
        p_ds_key->ip_sa31to0      = p_sys_key->ip_sa[3];

        p_ds_mask->ip_sa127to104   = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa_mask[0], 8, 24);
        p_ds_mask->ip_sa103to72    = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa_mask[0], 0, 8) << 24
            | SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa_mask[1], 8, 24);
        p_ds_mask->ip_sa71to64     = SYS_ACL_AND_MASK_NUM(p_sys_key->ip_sa_mask[1], 0, 8);
        p_ds_mask->ip_sa63to32     = p_sys_key->ip_sa_mask[2];
        p_ds_mask->ip_sa31to0      = p_sys_key->ip_sa_mask[3];
    }

    /* l4_info_mapped */
    if (p_sys_key->flag.l4info_mapped)
    {
        p_ds_key->l4info_mapped  = p_sys_key->l4info_mapped;
        p_ds_mask->l4info_mapped = p_sys_key->l4info_mapped_mask;
    }

    /* is tcp */
    if (p_sys_key->flag.is_tcp)
    {
        p_ds_key->is_tcp = p_sys_key->is_tcp;
        p_ds_mask->is_tcp = 1;
    }

    /* is udp */
    if (p_sys_key->flag.is_udp)
    {
        p_ds_key->is_udp = p_sys_key->is_udp;
        p_ds_mask->is_udp = 1;
    }

    /* l4 source port */
    if (p_sys_key->flag.l4_src_port)
    {
        p_ds_key->l4_source_port15to12 = p_sys_key->l4_src_port >> 12;
        p_ds_key->l4_source_port11to4  = (p_sys_key->l4_src_port >> 4) & 0xFF;
        p_ds_key->l4_source_port3to0   = p_sys_key->l4_src_port & 0xF;

        p_ds_mask->l4_source_port15to12 = p_sys_key->l4_src_port_mask >> 12;
        p_ds_mask->l4_source_port11to4  = (p_sys_key->l4_src_port_mask >> 4) & 0xFF;
        p_ds_mask->l4_source_port3to0   = p_sys_key->l4_src_port_mask & 0xF;
    }

    /* l4 destination port */
    if (p_sys_key->flag.l4_dst_port)
    {
        p_ds_key->l4_destport  = p_sys_key->l4_dst_port;
        p_ds_mask->l4_destport = p_sys_key->l4_dst_port_mask;
    }

    /* dscp */
    if (p_sys_key->flag.dscp)
    {
        p_ds_key->dscp = p_sys_key->dscp;
        p_ds_mask->dscp = p_sys_key->dscp_mask;
    }

    /* ip fragement */
    if (p_sys_key->flag.frag_info)
    {
        p_ds_key->frag_info = p_sys_key->frag_info;
        p_ds_mask->frag_info = p_sys_key->frag_info_mask;
    }

    /* ip option */
    if (p_sys_key->flag.ip_option)
    {
        p_ds_key->ip_options = p_sys_key->ip_option;
        p_ds_mask->ip_options = 1;
    }

    /* ip header error */
    if (p_sys_key->flag.ip_hdr_error)
    {
        p_ds_key->ip_head_error = p_sys_key->ip_hdr_error;
        p_ds_mask->ip_head_error = 1;
    }

    /* routed packet */
    if (p_sys_key->flag.routed_packet)
    {
        p_ds_key->routed_packet = p_sys_key->routed_packet;
        p_ds_mask->routed_packet = 1;
    }

    /* extension header */
    if (p_sys_key->flag.ext_hdr)
    {
        p_ds_key->ipv6_extension_headers = p_sys_key->ext_hdr;
        p_ds_mask->ipv6_extension_headers = p_sys_key->ext_hdr_mask;
    }

    /* flow label */
    if (p_sys_key->flag.flow_label)
    {
        p_ds_key->ipv6_flow_label = p_sys_key->flow_label;
        p_ds_mask->ipv6_flow_label = p_sys_key->flow_label_mask;
    }

    /* mac da */
    if (p_sys_key->flag.mac_da)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_da_upper, p_sys_key->mac_da);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_da_lower, p_sys_key->mac_da);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_da_upper, p_sys_key->mac_da_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_da_lower, p_sys_key->mac_da_mask);
    }

    /* mac sa */
    if (p_sys_key->flag.mac_sa)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_sa_upper, p_sys_key->mac_sa);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_sa_lower, p_sys_key->mac_sa);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_sa_upper, p_sys_key->mac_sa_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_sa_lower, p_sys_key->mac_sa_mask);
    }

    /* cos */
    if (p_sys_key->flag.cos)
    {
        p_ds_key->cos = p_sys_key->cos;
        p_ds_mask->cos = p_sys_key->cos_mask;
    }

    /* cvlan id */
    if (p_sys_key->flag.cvlan)
    {
        p_ds_key->cvlan_id = p_sys_key->cvlan;
        p_ds_mask->cvlan_id = p_sys_key->cvlan_mask;
    }

    /* ctag cos */
    if (p_sys_key->flag.ctag_cos)
    {
        p_ds_key->ctag_cos = p_sys_key->ctag_cos;
        p_ds_mask->ctag_cos = p_sys_key->ctag_cos_mask;
    }

    /* ctag cfi */
    if (p_sys_key->flag.ctag_cfi)
    {
        p_ds_key->ctag_cfi = p_sys_key->ctag_cfi;
        p_ds_mask->ctag_cfi = 1;
    }

    /* svlan id */
    if (p_sys_key->flag.svlan)
    {
        p_ds_key->svlan_id = p_sys_key->svlan;
        p_ds_mask->svlan_id = p_sys_key->svlan_mask;
    }

    /* stag cos */
    if (p_sys_key->flag.stag_cos)
    {
        p_ds_key->stag_cos = p_sys_key->stag_cos;
        p_ds_mask->stag_cos = p_sys_key->stag_cos_mask;
    }

    /* stag cfi */
    if (p_sys_key->flag.stag_cfi)
    {
        p_ds_key->stag_cfi = p_sys_key->stag_cfi;
        p_ds_mask->stag_cfi = 1;
    }

    /* l2 type */
    if (p_sys_key->flag.l2_type)
    {
        p_ds_key->layer2_type = p_sys_key->l2_type;
        p_ds_mask->layer2_type = p_sys_key->l2_type_mask;
    }

    /* l3 type */
    if (p_sys_key->flag.l3_type)
    {
        p_ds_key->layer3_type = p_sys_key->l3_type;
        p_ds_mask->layer3_type = p_sys_key->l3_type_mask;
    }

    /*ether type*/
    if (p_sys_key->flag.eth_type)
    {
        p_ds_key->ether_type  = p_sys_key->eth_type;
        p_ds_mask->ether_type = p_sys_key->eth_type_mask;
    }

    /*non-property field*/
    if (p_info->block_id == 0)
    {
        p_ds_key->acl_label_upper = p_info->label >> 6;
        p_ds_key->acl_label_middle = (p_info->label >> 4) & 0x3;
        p_ds_key->acl_label_lower = p_info->label & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 6;
        p_ds_mask->acl_label_middle = (p_info->mask >> 4) & 0x3;
        p_ds_mask->acl_label_lower = p_info->mask & 0xF;
    }
    else
    {
        p_ds_key->qos_label_upper = (p_info->label >> 6) & 0x3;
        p_ds_key->qos_label_lower = p_info->label & 0x3F;

        p_ds_mask->qos_label_upper = (p_info->label >> 6) & 0x3;
        p_ds_mask->qos_label_lower = p_info->mask & 0x3F;
    }

    p_ds_key->is_label = p_info->is_label;
    p_ds_mask->is_label = 1;

    if (!p_info->is_label)  /* service label */
    {
        p_ds_key->acl_label_upper = p_info->label >> 14;
        p_ds_key->acl_label_middle = (p_info->label >> 12) & 0x3;
        p_ds_key->acl_label_lower = (p_info->label >> 8) & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 14;
        p_ds_mask->acl_label_middle = (p_info->mask >> 12) & 0x3;
        p_ds_mask->acl_label_lower = (p_info->mask >> 8) & 0xF;

        p_ds_key->qos_label_upper = (p_info->label >> 6) & 0x3;
        p_ds_key->qos_label_lower = p_info->label & 0x3F;

        p_ds_mask->qos_label_upper = (p_info->mask >> 6) & 0x3;
        p_ds_mask->qos_label_lower = p_info->mask & 0x3F;
    }

    p_ds_key->tableid0 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid1 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid2 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid3 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid4 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid5 = ACL_IPV6_TABLEID0_C;
    p_ds_key->tableid6 = ACL_IPV6_TABLEID0_C;
    p_ds_key->aclqos_ipv6key_tableid7 = ACL_IPV6_TABLEID0_C;

    p_ds_mask->tableid0 = 0xF;
    p_ds_mask->tableid1 = 0xF;
    p_ds_mask->tableid2 = 0xF;
    p_ds_mask->tableid3 = 0xF;
    p_ds_mask->tableid4 = 0xF;
    p_ds_mask->tableid5 = 0xF;
    p_ds_mask->tableid6 = 0xF;
    p_ds_key->aclqos_ipv6key_tableid7 = 0xF;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_build_ds_mpls_key(drv_acl_group_info_t* p_info,
                                  sys_acl_mpls_key_t* p_sys_key,
                                  ds_acl_mpls_key_t* p_ds_key,
                                  ds_acl_mpls_key_t* p_ds_mask)
{
    CTC_PTR_VALID_CHECK(p_info);
    CTC_PTR_VALID_CHECK(p_sys_key);
    CTC_PTR_VALID_CHECK(p_ds_key);
    CTC_PTR_VALID_CHECK(p_ds_mask);

    SYS_ACL_DBG_FUNC();

    /* mac da */
    if (p_sys_key->flag.mac_da)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->macda_upper, p_sys_key->mac_da);
        SYS_ACL_SET_MAC_LOW(p_ds_key->macda_lower, p_sys_key->mac_da);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->macda_upper, p_sys_key->mac_da_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->macda_lower, p_sys_key->mac_da_mask);
    }

    /* mac sa */
    if (p_sys_key->flag.mac_sa)
    {
        SYS_ACL_SET_MAC_HIGH(p_ds_key->mac_sa_upper, p_sys_key->mac_sa);
        SYS_ACL_SET_MAC_LOW(p_ds_key->mac_sa_lower, p_sys_key->mac_sa);

        SYS_ACL_SET_MAC_HIGH(p_ds_mask->mac_sa_upper, p_sys_key->mac_sa_mask);
        SYS_ACL_SET_MAC_LOW(p_ds_mask->mac_sa_lower, p_sys_key->mac_sa_mask);
    }

    /* cos */
    if (p_sys_key->flag.cos)
    {
        p_ds_key->cos = p_sys_key->cos;
        p_ds_mask->cos = p_sys_key->cos_mask;
    }

    /* cvlan id */
    if (p_sys_key->flag.cvlan)
    {
        p_ds_key->cvlan_id = p_sys_key->cvlan;
        p_ds_mask->cvlan_id = p_sys_key->cvlan_mask;
    }

    /* ctag cos */
    if (p_sys_key->flag.ctag_cos)
    {
        p_ds_key->ctag_cos = p_sys_key->ctag_cos;
        p_ds_mask->ctag_cos = p_sys_key->ctag_cos_mask;
    }

    /* ctag cfi */
    if (p_sys_key->flag.ctag_cfi)
    {
        p_ds_key->ctag_cfi = p_sys_key->ctag_cfi;
        p_ds_mask->ctag_cfi = 0x1;
    }

    /* svlan id */
    if (p_sys_key->flag.svlan)
    {
        p_ds_key->svlan_id = p_sys_key->svlan;
        p_ds_mask->svlan_id = p_sys_key->svlan_mask;
    }

    /* stag cos */
    if (p_sys_key->flag.stag_cos)
    {
        p_ds_key->stag_cos = p_sys_key->stag_cos;
        p_ds_mask->stag_cos = p_sys_key->stag_cos_mask;
    }

    /* stag cfi */
    if (p_sys_key->flag.stag_cfi)
    {
        p_ds_key->stag_cfi = p_sys_key->stag_cfi;
        p_ds_mask->stag_cfi = 0x1;
    }

    /* layer 2 type */
    if (p_sys_key->flag.l2_type)
    {
        p_ds_key->layer2_type = p_sys_key->l2_type;
        p_ds_mask->layer2_type = p_sys_key->l2_type_mask;
    }

    /* mpls label 0 */
    if (p_sys_key->flag.mpls_label0)
    {
        p_ds_key->mpls_label0 = p_sys_key->mpls_label0;
        p_ds_mask->mpls_label0 = p_sys_key->mpls_label0_mask;
    }

    /* mpls label 1 */
    if (p_sys_key->flag.mpls_label1)
    {
        p_ds_key->mpls_label1 = p_sys_key->mpls_label1;
        p_ds_mask->mpls_label1 = p_sys_key->mpls_label1_mask;
    }

    /* mpls label 2 */
    if (p_sys_key->flag.mpls_label2)
    {
        p_ds_key->mpls_label2 = p_sys_key->mpls_label2;
        p_ds_mask->mpls_label2 = p_sys_key->mpls_label2_mask;
    }

    /* mpls label 3 */
    if (p_sys_key->flag.mpls_label3)
    {
        p_ds_key->mpls_label331to28 = (p_sys_key->mpls_label3 >> 28) & 0xF;
        p_ds_key->mpls_label327to0 = p_sys_key->mpls_label3 & 0xFFFFFFF;

        p_ds_mask->mpls_label331to28 = (p_sys_key->mpls_label3_mask >> 28) & 0xF;
        p_ds_mask->mpls_label327to0 = p_sys_key->mpls_label3_mask & 0xFFFFFFF;
    }

    /* routed packet */
    if (p_sys_key->flag.routed_packet)
    {
        p_ds_key->route_pkt = p_sys_key->routed_packet;
        p_ds_mask->route_pkt = 1;
    }

    /*non-property field*/
    if (p_info->block_id == 0)
    {
        p_ds_key->acl_label_upper = p_info->label >> 4;
        p_ds_key->acl_label_lower = p_info->label & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 4;
        p_ds_mask->acl_label_lower = p_info->mask & 0xF;
    }
    else
    {
        p_ds_key->qos_label = p_info->label;
        p_ds_mask->qos_label = p_info->mask;
    }

    p_ds_key->is_label = p_info->is_label;
    p_ds_mask->is_label = 1;

    if (!p_info->is_label)  /* service label */
    {
        p_ds_key->acl_label_upper = p_info->label >> 12;
        p_ds_key->acl_label_lower = (p_info->label >> 8) & 0xF;

        p_ds_mask->acl_label_upper = p_info->mask >> 12;
        p_ds_mask->acl_label_lower = (p_info->mask >> 8) & 0xF;

        p_ds_key->qos_label = p_info->label & 0xFF;
        p_ds_mask->qos_label = p_info->mask & 0xFF;
    }

    p_ds_key->is_ip_key = 1;
    p_ds_mask->is_ip_key = 1;

    p_ds_key->is_mpls_key = 1;
    p_ds_mask->is_mpls_key = 1;

    p_ds_key->tableid0 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid1 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid2 = ACL_IPV4_TABLEID0_C;
    p_ds_key->tableid3 = ACL_IPV4_TABLEID0_C;

    p_ds_mask->tableid0 = 0xF;
    p_ds_mask->tableid1 = 0xF;
    p_ds_mask->tableid2 = 0xF;
    p_ds_mask->tableid3 = 0xF;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_remove_hw(uint32 eid)
{
    uint8  lchip = 0;
    uint8  lchip_num = 0;
    uint8  block_id = 0;

    int32  block_index = 0;
    sys_acl_group_t* pg = NULL;
    sys_acl_entry_t* pe = NULL;
    sys_acl_group_info_t* p_info = NULL;

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid: %u \n", eid);

    /* get sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get sys group */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    /* get block_id, block_index */
    block_id = pg->group_info.block_id;
    block_index = pe->block_index;

    /* get group_info */
    p_info = &(pg->group_info);

    if (p_info->lchip == 0xFF)
    {
        lchip = 0;
        lchip_num = acl_master->lchip_num;
    }
    else
    {
        lchip = p_info->lchip; /* 0 or 1 */
        lchip_num = lchip + 1;
    }

    for (; lchip < lchip_num; lchip++)
    {
        switch (pe->key.type)
        {
        case CTC_ACL_KEY_MAC:
            {
                DRV_TCAM_TBL_REMOVE(lchip, DS_ACL_MAC_KEY + block_id, block_index);
            }
            break;

        case CTC_ACL_KEY_IPV4:
            {
                DRV_TCAM_TBL_REMOVE(lchip, DS_ACL_IPV4_KEY + block_id, block_index);
            }
            break;

        case CTC_ACL_KEY_IPV6:
            {
                DRV_TCAM_TBL_REMOVE(lchip, DS_ACL_IPV6_KEY + block_id, block_index);
            }
            break;

        case CTC_ACL_KEY_MPLS:
            {
                DRV_TCAM_TBL_REMOVE(lchip, DS_ACL_MPLS_KEY + block_id, block_index);
            }
            break;

        default:
            return CTC_E_ACL_INVALID_KEY_TYPE;
        }
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_add_hw(uint32 eid)
{
    uint8  lchip = 0;
    uint8  lchip_num = 0;
    uint8  block_id = 0;

    int32  block_index = 0;
    sys_acl_group_t* pg = NULL;
    sys_acl_entry_t* pe = NULL;
    sys_acl_group_info_t* p_info = NULL;

    uint32                  cmd;
    ds_mac_acl_t            ds_acl;
    drv_acl_group_info_t    drv_info;
    tbl_entry_t             tcam_key;

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid: %u \n", eid);

    sal_memset(&ds_acl, 0, sizeof(ds_acl));
    sal_memset(&drv_info, 0, sizeof(drv_info));
    sal_memset(&tcam_key, 0, sizeof(tcam_key));

    /* get sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get sys group */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    /* get block_id, block_index */
    block_id = pg->group_info.block_id;
    block_index = pe->block_index;

    /* get group_info */
    p_info = &(pg->group_info);

    /* build drv group_info */
    CTC_ERROR_RETURN(_sys_humber_acl_build_ds_group_info(p_info, &drv_info));

    if (p_info->lchip == 0xFF)
    {
        lchip = 0;
        lchip_num = sys_humber_get_local_chip_num();
    }
    else
    {
        lchip = p_info->lchip; /* 0 or 1 */
        lchip_num = lchip + 1;
    }

    for (; lchip < lchip_num; lchip++)
    {

        /* get action */
        CTC_ERROR_RETURN(_sys_humber_acl_build_ds_action(lchip, &pe->action, &ds_acl));

        /* build drv_action. write asic */
        switch (pe->key.type)
        {
        case CTC_ACL_KEY_MAC:
            cmd = DRV_IOW(IOC_TABLE, DS_MAC_ACL + block_id * 4, DRV_ENTRY_FLAG);
            break;

        case CTC_ACL_KEY_IPV4:
            cmd = DRV_IOW(IOC_TABLE, DS_IPV4_ACL + block_id * 4, DRV_ENTRY_FLAG);
            break;

        case CTC_ACL_KEY_MPLS:
            cmd = DRV_IOW(IOC_TABLE, DS_MPLS_ACL + block_id * 4, DRV_ENTRY_FLAG);
            break;

        case CTC_ACL_KEY_IPV6:
            cmd = DRV_IOW(IOC_TABLE, DS_IPV6_ACL + block_id * 4, DRV_ENTRY_FLAG);
            break;

        default:
            return CTC_E_ACL_INVALID_KEY_TYPE;

        }

        CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, block_index, cmd, &ds_acl));

        /* get key, build drv_key. write asic */
        SYS_ACL_DBG_INFO("  %% key_type: %d block_id %d\n", pe->key.type, block_id);

        switch (pe->key.type)
        {
        case CTC_ACL_KEY_MAC:
            {
                ds_acl_mac_key_t data;
                ds_acl_mac_key_t mask;
                sal_memset(&data, 0, sizeof(data));
                sal_memset(&mask, 0, sizeof(mask));

                _sys_humber_acl_build_ds_mac_key(&drv_info,
                                                 &pe->key.key_info.mac_key, &data, &mask);
                tcam_key.data_entry = (uint32*)&data;
                tcam_key.mask_entry = (uint32*)&mask;

                cmd = DRV_IOW(IOC_TABLE, DS_ACL_MAC_KEY + block_id, DRV_ENTRY_FLAG);
                CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, block_index, cmd, &tcam_key));
            }
            break;

        case CTC_ACL_KEY_IPV4:
            {
                ds_acl_ipv4_key_t data;
                ds_acl_ipv4_key_t mask;
                sal_memset(&data, 0, sizeof(data));
                sal_memset(&mask, 0, sizeof(mask));

                _sys_humber_acl_build_ds_ipv4_key(&drv_info,
                                                  &pe->key.key_info.ipv4_key, &data, &mask);
                tcam_key.data_entry = (uint32*)&data;
                tcam_key.mask_entry = (uint32*)&mask;

                cmd = DRV_IOW(IOC_TABLE, DS_ACL_IPV4_KEY + block_id, DRV_ENTRY_FLAG);
                CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, block_index, cmd, &tcam_key));
            }
            break;

        case CTC_ACL_KEY_IPV6:
            {
                ds_acl_ipv6_key_t data;
                ds_acl_ipv6_key_t mask;
                sal_memset(&data, 0, sizeof(data));
                sal_memset(&mask, 0, sizeof(mask));

                _sys_humber_acl_build_ds_ipv6_key(&drv_info,
                                                  &pe->key.key_info.ipv6_key, &data, &mask);
                tcam_key.data_entry = (uint32*)&data;
                tcam_key.mask_entry = (uint32*)&mask;

                cmd = DRV_IOW(IOC_TABLE, DS_ACL_IPV6_KEY + block_id, DRV_ENTRY_FLAG);
                CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, block_index, cmd, &tcam_key));
            }
            break;

        case CTC_ACL_KEY_MPLS:
            {
                ds_acl_mpls_key_t data;
                ds_acl_mpls_key_t mask;
                sal_memset(&data, 0, sizeof(data));
                sal_memset(&mask, 0, sizeof(mask));

                _sys_humber_acl_build_ds_mpls_key(&drv_info,
                                                  &pe->key.key_info.mpls_key, &data, &mask);
                tcam_key.data_entry = (uint32*)&data;
                tcam_key.mask_entry = (uint32*)&mask;

                cmd = DRV_IOW(IOC_TABLE, DS_ACL_MPLS_KEY + block_id, DRV_ENTRY_FLAG);
                CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, block_index, cmd, &tcam_key));
            }
            break;

        default:
            return CTC_E_ACL_INVALID_KEY_TYPE;
        }
    }

    return CTC_E_NONE;
}

/*
 *install entry to hardware table
 */
static int32
_sys_humber_acl_install_entry(uint32 eid, uint8 flag, uint8 move_sw)
{
    sys_acl_group_t* pg = NULL;
    sys_acl_entry_t* pe = NULL;

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", eid);

    /* get sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get sys group */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    /* group must be installed. */
    if (SYS_ACL_GROUP_INSTALLED != pg->flag)
    {
        return CTC_E_ACL_GROUP_NOT_INSTALLED;
    }

    if (SYS_ACL_ENTRY_OP_FLAG_ADD == flag)
    {
        CTC_ERROR_RETURN(_sys_humber_acl_add_hw(eid));
        pe->flag = SYS_ACL_ENTRY_FLAG_INSTALLED;

        if (move_sw)
        {
            /* move to tail */
            ctc_slist_delete_node(pg->entry_list, &(pe->head));
            ctc_slist_add_tail(pg->entry_list, &(pe->head));
        }
    }
    else if (SYS_ACL_ENTRY_OP_FLAG_DELETE == flag)
    {
        CTC_ERROR_RETURN(_sys_humber_acl_remove_hw(eid));
        pe->flag = SYS_ACL_ENTRY_FLAG_UNINSTALLED;

        if (move_sw)
        {
            /* move to head */
            ctc_slist_delete_node(pg->entry_list, &(pe->head));
            ctc_slist_add_head(pg->entry_list, &(pe->head));
        }
    }

    return CTC_E_NONE;

}

/*
 *move entry in hardware table to an new index.
 */
static int32
_sys_humber_acl_entry_move_hw(sys_acl_entry_t* pe,
                              int32 tcam_idx_new)
{
    int32 tcam_idx_old = pe->block_index;
    uint32 eid;

    CTC_PTR_VALID_CHECK(pe);
    SYS_ACL_DBG_FUNC();

    eid = pe->entry_id;

    /* add first */
    pe->block_index = tcam_idx_new;
    CTC_ERROR_RETURN(_sys_humber_acl_add_hw(eid));

    /* then delete */
    pe->block_index = tcam_idx_old;
    CTC_ERROR_RETURN(_sys_humber_acl_remove_hw(eid));

    /* set new_index */
    pe->block_index = tcam_idx_new;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_add_default_entry(bool deny)
{
    ds_mac_acl_t ds_action;
    tbl_entry_t  ds_key;
    ds_acl_mac_key_t  ds_mac_key, ds_mac_mask;
    ds_acl_ipv4_key_t ds_ipv4_key, ds_ipv4_mask;
    ds_acl_ipv6_key_t ds_ipv6_key, ds_ipv6_mask;
    uint8  lchip, lchip_num;
    uint32 cmd;
    uint32 index;

    sal_memset(&ds_action, 0, sizeof(ds_mac_acl_t));
    sal_memset(&ds_key, 0, sizeof(tbl_entry_t));

    lchip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        ds_action.discard_packet = deny ? 1 : 0;
        ds_action.fwd_ptr          = 0xFFF;    /*indicates fwd_ptr is not valid*/
        ds_action.qos_policy       = 0x7;      /*indicates qos_policy is not valid */
        ds_action.stats_ptr        = 0xFFFF;   /*indicates stats_ptr is not valid*/
        ds_action.flow_policer_ptr = 0xFFFF;   /*indicates flow_policer_ptr is not valid*/

        /* block 0 */
        if (acl_master->mac_ipv4_entry_num[0] > 0)
        {
            /* MAC */
            index = acl_master->mac_ipv4_entry_num[0] - 1;

            sal_memset(&ds_mac_key, 0, sizeof(ds_acl_mac_key_t));
            sal_memset(&ds_mac_mask, 0, sizeof(ds_acl_mac_key_t));
            ds_mac_key.tableid0 = ACL_MAC_TABLEID0_C;
            ds_mac_key.tableid1 = ACL_MAC_TABLEID1_C;
            ds_mac_key.tableid2 = ACL_MAC_TABLEID2_C;
            ds_mac_key.tableid3 = ACL_MAC_TABLEID3_C;
            ds_mac_mask.tableid0 = 0xF;
            ds_mac_mask.tableid1 = 0xF;
            ds_mac_mask.tableid2 = 0xF;
            ds_mac_mask.tableid3 = 0xF;
            ds_key.data_entry = (uint32*)&ds_mac_key;
            ds_key.mask_entry = (uint32*)&ds_mac_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_ACL_MAC_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_MAC_ACL, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));

            /* IPv4 ACL */
            index = acl_master->mac_ipv4_entry_num[0] - 2;

            sal_memset(&ds_ipv4_key, 0, sizeof(ds_acl_ipv4_key_t));
            sal_memset(&ds_ipv4_mask, 0, sizeof(ds_acl_ipv4_key_t));
            ds_ipv4_key.tableid0 = ACL_IPV4_TABLEID0_C;
            ds_ipv4_key.tableid1 = ACL_IPV4_TABLEID1_C;
            ds_ipv4_key.tableid2 = ACL_IPV4_TABLEID2_C;
            ds_ipv4_key.tableid3 = ACL_IPV4_TABLEID3_C;
            ds_ipv4_mask.tableid0 = 0xF;
            ds_ipv4_mask.tableid1 = 0xF;
            ds_ipv4_mask.tableid2 = 0xF;
            ds_ipv4_mask.tableid3 = 0xF;
            ds_key.data_entry = (uint32*)&ds_ipv4_key;
            ds_key.mask_entry = (uint32*)&ds_ipv4_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_ACL_IPV4_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_IPV4_ACL, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));
        }

        /* IPv6 */
        if (acl_master->ipv6_entry_num[0] > 0)
        {
            index = acl_master->ipv6_entry_num[0] - 1;

            sal_memset(&ds_ipv6_key, 0, sizeof(ds_acl_ipv6_key_t));
            sal_memset(&ds_ipv6_mask, 0, sizeof(ds_acl_ipv6_key_t));
            ds_ipv6_key.tableid0 = ACL_IPV6_TABLEID0_C;
            ds_ipv6_key.tableid1 = ACL_IPV6_TABLEID1_C;
            ds_ipv6_key.tableid2 = ACL_IPV6_TABLEID2_C;
            ds_ipv6_key.tableid3 = ACL_IPV6_TABLEID3_C;
            ds_ipv6_key.tableid4 = ACL_IPV6_TABLEID4_C;
            ds_ipv6_key.tableid5 = ACL_IPV6_TABLEID5_C;
            ds_ipv6_key.tableid6 = ACL_IPV6_TABLEID6_C;
            ds_ipv6_key.aclqos_ipv6key_tableid7 = ACL_IPV6_TABLEID7_C;
            ds_ipv6_mask.tableid0 = 0xF;
            ds_ipv6_mask.tableid1 = 0xF;
            ds_ipv6_mask.tableid2 = 0xF;
            ds_ipv6_mask.tableid3 = 0xF;
            ds_ipv6_mask.tableid4 = 0xF;
            ds_ipv6_mask.tableid5 = 0xF;
            ds_ipv6_mask.tableid6 = 0xF;
            ds_ipv6_mask.aclqos_ipv6key_tableid7 = 0xF;
            ds_key.data_entry = (uint32*)&ds_ipv6_key;
            ds_key.mask_entry = (uint32*)&ds_ipv6_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_ACL_IPV6_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_IPV6_ACL, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));
        }

        /* block 1 */
        if (acl_master->mac_ipv4_entry_num[1])
        {
            /* MAC */
            index = acl_master->mac_ipv4_entry_num[1] - 1;

            sal_memset(&ds_mac_key, 0, sizeof(ds_acl_mac_key_t));
            sal_memset(&ds_mac_mask, 0, sizeof(ds_acl_mac_key_t));
            ds_mac_key.tableid0 = QOS_MAC_TABLEID0_C;
            ds_mac_key.tableid1 = QOS_MAC_TABLEID1_C;
            ds_mac_key.tableid2 = QOS_MAC_TABLEID2_C;
            ds_mac_key.tableid3 = QOS_MAC_TABLEID3_C;
            ds_mac_mask.tableid0 = 0xF;
            ds_mac_mask.tableid1 = 0xF;
            ds_mac_mask.tableid2 = 0xF;
            ds_mac_mask.tableid3 = 0xF;
            ds_key.data_entry = (uint32*)&ds_mac_key;
            ds_key.mask_entry = (uint32*)&ds_mac_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_QOS_MAC_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_MAC_QOS, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));

            /* IPv4 */
            index = acl_master->mac_ipv4_entry_num[1] - 2;

            sal_memset(&ds_ipv4_key, 0, sizeof(ds_acl_ipv4_key_t));
            sal_memset(&ds_ipv4_mask, 0, sizeof(ds_acl_ipv4_key_t));
            ds_ipv4_key.tableid0 = QOS_IPV4_TABLEID0_C;
            ds_ipv4_key.tableid1 = QOS_IPV4_TABLEID1_C;
            ds_ipv4_key.tableid2 = QOS_IPV4_TABLEID2_C;
            ds_ipv4_key.tableid3 = QOS_IPV4_TABLEID3_C;
            ds_ipv4_mask.tableid0 = 0xF;
            ds_ipv4_mask.tableid1 = 0xF;
            ds_ipv4_mask.tableid2 = 0xF;
            ds_ipv4_mask.tableid3 = 0xF;
            ds_key.data_entry = (uint32*)&ds_ipv4_key;
            ds_key.mask_entry = (uint32*)&ds_ipv4_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_QOS_IPV4_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_IPV4_QOS, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));
        }

        /* IPv6 */
        if (acl_master->ipv6_entry_num[1])
        {
            index = acl_master->ipv6_entry_num[1] - 1;

            sal_memset(&ds_ipv6_key, 0, sizeof(ds_acl_ipv6_key_t));
            sal_memset(&ds_ipv6_mask, 0, sizeof(ds_acl_ipv6_key_t));
            ds_ipv6_key.tableid0 = QOS_IPV6_TABLEID0_C;
            ds_ipv6_key.tableid1 = QOS_IPV6_TABLEID1_C;
            ds_ipv6_key.tableid2 = QOS_IPV6_TABLEID2_C;
            ds_ipv6_key.tableid3 = QOS_IPV6_TABLEID3_C;
            ds_ipv6_key.tableid4 = QOS_IPV6_TABLEID4_C;
            ds_ipv6_key.tableid5 = QOS_IPV6_TABLEID5_C;
            ds_ipv6_key.tableid6 = QOS_IPV6_TABLEID6_C;
            ds_ipv6_key.aclqos_ipv6key_tableid7 = QOS_IPV6_TABLEID7_C;
            ds_ipv6_mask.tableid0 = 0xF;
            ds_ipv6_mask.tableid1 = 0xF;
            ds_ipv6_mask.tableid2 = 0xF;
            ds_ipv6_mask.tableid3 = 0xF;
            ds_ipv6_mask.tableid4 = 0xF;
            ds_ipv6_mask.tableid5 = 0xF;
            ds_ipv6_mask.tableid6 = 0xF;
            ds_ipv6_mask.aclqos_ipv6key_tableid7 = 0xF;
            ds_key.data_entry = (uint32*)&ds_ipv6_key;
            ds_key.mask_entry = (uint32*)&ds_ipv6_mask;

            cmd = DRV_IOW(IOC_TABLE, DS_QOS_IPV6_KEY, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_key));

            cmd = DRV_IOW(IOC_TABLE, DS_IPV6_QOS, DRV_ENTRY_FLAG);
            CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, index, cmd, &ds_action));
        }
    }

    return CTC_E_NONE;
}

/*
 * below is acl sort-algorithm related functions.
 */
#define _1_ACL_SORT_ALGOR_

/*
 * Checks if the entry needs to be moved due to prio set
 */
static bool
_sys_humber_acl_set_prior_require_move(sys_acl_entry_t* pe, int32 prio)
{
    sys_acl_group_t* pg;
    sys_acl_block_t* pb;
    uint16 block_sz;
    uint8  asic_type;
    uint8  block_id;

    int32  i;
    int32 flag; /* flag denotes is we are before OR after pe */

    CTC_PTR_VALID_CHECK(pe);
    SYS_ACL_DBG_FUNC();

    pg = pe->group;
    CTC_PTR_VALID_CHECK(pg);

    asic_type = acl_master->asic_type[pe->key.type];
    block_id = pg->group_info.block_id;

    pb = &(acl_master->block[asic_type][pg->group_info.block_id]);
    block_sz = pb->entry_count;

    flag = -1; /* We are before pe */

    for (i = 0; i < block_sz; i++)
    {
        if (pb->entries[i] == pe)
        {
            flag = 1; /* Now, we are after pe */
            continue;
        }

        if (pb->entries[i] == NULL)
        {
            continue;
        }

        if (flag == -1)
        {
            if ((pb->entries[i]->priority) < prio)
            {
                /*
         * An entry before pe has lower priority than prio
         *     Movement is required
         */
                return TRUE;
            }
        }
        else
        {
            if ((pb->entries[i]->priority) > prio)
            {
                /*
         * An entry after pe has higher priority than prio
         *     Movement is required
         */
                return TRUE;
            }
        }
    }

    return FALSE; /* pe with new prio is in proper location */
}

/*
 *move entry to a new place with amount steps.
 */
static int32
_sys_humber_acl_entry_move(sys_acl_entry_t* pe, int32 amount)
{
    int32  tcam_idx_old = 0; /* Original entry tcam index.    */
    int32  tcam_idx_new = 0; /* Next tcam index for the entry.*/
    sys_acl_group_t*         pg;         /* Field entry group.            */
    sys_acl_block_t*         pb;         /* Field slice control.          */

    int32                    ret;          /* Operation return status.      */
    uint8                    asic_type;

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("    %%PARAM: (entry_id=%u, amount=%d)\n", pe->entry_id, amount);

    CTC_PTR_VALID_CHECK(pe);

    if (NULL == pe->group)
    {
        return (CTC_E_INVALID_PARAM);
    }

    asic_type = acl_master->asic_type[pe->key.type];

    pg = pe->group;
    pb = &acl_master->block[asic_type][pg->group_info.block_id];
    if (amount == 0)
    {
        SYS_ACL_DBG_INFO("    %%INFO: amount == 0\n");
        return (CTC_E_NONE);
    }

    tcam_idx_old = pe->block_index;
    tcam_idx_new = tcam_idx_old + amount;

    /* Move the hardware entry.*/
    if (SYS_ACL_ENTRY_FLAG_INSTALLED == pe->flag)
    {
        ret = _sys_humber_acl_entry_move_hw(pe, tcam_idx_new);
        CTC_ERROR_RETURN(ret);
    }

    /* Move the software entry.*/

    pb->entries[tcam_idx_old] = NULL;
    pb->entries[tcam_idx_new] = pe;
    pe->block_index = tcam_idx_new;

    return (CTC_E_NONE);
}

/*
 *shift up entries from target entry to prev null entry
 */
static int32
_sys_humber_acl_entry_shift_up(sys_acl_block_t* pb,
                               int32 target_index,
                               int32 prev_null_index)
{
    int32                   temp;

    /* Input parameter check. */
    CTC_PTR_VALID_CHECK(pb);
    SYS_ACL_DBG_FUNC();

    temp = prev_null_index;

    /* start from prev-1:
     *  prev + 1 -- > prev
     *  prev + 2 -- > prev + 1
     *  ...
     *  target -- > target - 1
     */
    while ((temp < target_index))
    {
        /* Move the entry at the next index to the prev. empty index. */

        /* Perform entry move. */
        CTC_ERROR_RETURN(_sys_humber_acl_entry_move(pb->entries[temp + 1], -1));

        temp++;
    }

    return (CTC_E_NONE);
}

/*
 *shift down entries from target entry to next null entry
 */
static int32
_sys_humber_acl_entry_shift_down(sys_acl_block_t* pb,
                                 int32 target_index,
                                 int32 next_null_index)
{
    int32              temp;

    /* Input parameter check. */
    CTC_PTR_VALID_CHECK(pb);
    SYS_ACL_DBG_FUNC();

    temp = next_null_index;

    /*
     * Move entries one step down
     *     starting from the last entry
     */
    while (temp > target_index)
    {

        /* Perform entry move. */
        CTC_ERROR_RETURN(_sys_humber_acl_entry_move(pb->entries[temp - 1], 1));

        temp--;
    }

    return (CTC_E_NONE);
}

/*
 * get how many step need to shift entries from target entry to null entry.
 * return value:
 *   TRUE  -- shift is ok
 *   FALSE -- shift is not ok
 *   shift_count --  how many entries need shift
 */
static bool
_sys_humber_acl_get_shift_count(
    int32 null_index,
    int32 target_index,
    int32 direction,
    int32* shift_count)
{
    /*
     *     dir = 1 , shift down
     *     dir =-1 , shift up
     *     move 7 to between 3 and 4. target index 5. prev null=1, next_null = 7.
     *     0 -- 7
     *     1 -- NULL(prev)
     *     2 -- 6
     *     3 -- 5
     *     4 -- 4
     *     5 -- 3(target)
     *     6 -- 2
     *     7 -- NULL(next)
     *
     *     shift up: shift 6 5 4 up. prev_null- target_idx = 4. minus 1 to get 3.
     *     shift down: shift 3 2 down. next_null - target_idx = 2.
     *
     *     for shift up, prev_null_index be -1 or smaller than target_index.
     *               case 1: null_idx = block_sz+2, cannot shift up.
     *               case 2: target_idx > prev_null , shift up.
     *               in case 2, target_idx-1 = prev_null_idx. just move, no shift.
     *
     *     for shift down, next_null_index be -1 or bigger than target_index.
     *               case 1: null_idx = -1. cannot shift down.
     *               case 2: null_idx > target_idx, cannot shit down.
     *
     */
    CTC_PTR_VALID_CHECK(shift_count);

    *shift_count = direction * (null_index - target_index) + ((-1 == direction) ? (-1) : 0);
    if (*shift_count < 0)
    {
        /*   shift_cnt =0, that is no move. checked before.
         *   only shift up has shift_cnt = 0.*/
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

/*
 * get shift direction, up or down
 * return value
 *   TRUE  -- shift is ok
 *   FALSE -- shift is not ok
 *   dir   -- shift to which direction
 */
static int32
_sys_humber_acl_get_shift_direction(
    int32 prev_null_index,
    int32 target_index,
    int32 next_null_index,
    int32* dir)
{
    bool  shift_up = FALSE;
    bool  shift_down = FALSE;
    int32 shift_up_amount = 0;
    int32 shift_down_amount = 0;

    /* Input parameter check. */

    CTC_PTR_VALID_CHECK(dir);

    SYS_ACL_DBG_FUNC();

    shift_up = _sys_humber_acl_get_shift_count(prev_null_index, target_index, -1, &shift_up_amount);

    shift_down = _sys_humber_acl_get_shift_count(next_null_index, target_index, 1, &shift_down_amount);

    SYS_ACL_DBG_INFO("  %%INFO: shift up   %s count %d \n", shift_up ? "T" : "F", shift_up_amount);
    SYS_ACL_DBG_INFO("  %%INFO: shift down %s count %d \n", shift_down ? "T" : "F", shift_down_amount);

    if (shift_up == TRUE)
    {
        if (shift_down == TRUE)
        {
            if (shift_up_amount < shift_down_amount)
            {
                *dir = -1;
            }
            else
            {
                *dir = 1;
            }
        }
        else
        {
            *dir = -1;
        }
    }
    else
    {
        if (shift_down == TRUE)
        {
            *dir = 1;
        }
        else
        {
            return FALSE;
        }
    }

    return TRUE;
}

typedef struct
{
    uint16 t_idx; /* target index */
    uint16 o_idx; /* old index */

}_sys_acl_target_t;
static int32
_sys_humber_acl_reorder(sys_acl_block_t* pb, int32 bottom_idx, uint8 extra_num)
{
    int32   idx;
    int32   t_idx;
    int32   o_idx;
    _sys_acl_target_t* target_a = NULL;
    int32   ret = 0;
    uint8   move_ok;
/*    static double time;*/
/*    clock_t begin,end;*/

    uint32  full_num;
    uint32  free_num;
    uint32  real_num;            /* actual entry number */
    uint32  left_num;

/*    begin = clock();*/
    CTC_PTR_VALID_CHECK(pb);
    SYS_ACL_DBG_FUNC();

    extra_num = extra_num ? 1 : 0; /*extra num is 1 for new entry */

    /* malloc a new array based on new exist entry*/
    full_num = pb->entry_count - extra_num; /* if extra_num == 1, reserve last */
    free_num = pb->free_count;

    real_num = pb->entry_count - pb->free_count;
    SYS_ACL_MALLOC(target_a,real_num * sizeof(_sys_acl_target_t));
    /* save target idx to that array */

    for (t_idx = 0; t_idx < real_num; t_idx++)
    {
        target_a[t_idx].t_idx= (full_num * t_idx) / real_num;
    }

    o_idx = 0;
    for (idx = 0; idx < pb->entry_count ; idx++) /* through all entry */
    {
        if (pb->entries[idx])
        {
            target_a[o_idx].o_idx = idx;
            o_idx++;
        }
    }

    left_num   = real_num;
    while (left_num) /* move_num */
    {
        SYS_ACL_DBG_INFO("left_num %d, real_num %d\n", left_num, real_num);

        for(idx = 0; idx < left_num; idx++)
        {
            move_ok  = 0;

            if (target_a[idx].o_idx == target_a[idx].t_idx) /* stay */
            {
                SYS_ACL_DBG_INFO("stay !\n");
                sal_memmove(&target_a[idx],&target_a[idx+1], (left_num - idx -1)*sizeof(_sys_acl_target_t));
                left_num--;
                idx--;
            }
            else
            {
                if (target_a[idx].o_idx < target_a[idx].t_idx)/* move forward */
                {
                    if ((idx == left_num - 1) || (target_a[idx + 1].o_idx > target_a[idx].t_idx))
                    {
                        move_ok = 1;
                    }
                }
                else /* move backward */
                {
                    if ((idx == 0)|| (target_a[idx - 1].o_idx > target_a[idx].t_idx))
                    {
                        move_ok = 1;
                    }
                }

                if (move_ok)
                {
                    SYS_ACL_DBG_INFO(" move from %d to %d!\n", target_a[idx].o_idx, target_a[idx].t_idx);
                    /* move idx to temp */
                    CTC_ERROR_GOTO(_sys_humber_acl_entry_move
                        (pb->entries[target_a[idx].o_idx], (target_a[idx].t_idx- target_a[idx].o_idx)), ret, cleanup);
                    sal_memmove(&target_a[idx],&target_a[idx+1], (left_num - idx -1)*sizeof(_sys_acl_target_t));
                    left_num--;
                    idx--;
                }
            }

        }
    }

    mem_free(target_a);

/*    end = clock();*/
/*    time = time + ((double)(end - begin) / CLOCKS_PER_SEC);*/
/*    SYS_FPA_DBG_INFO(" t:%lf", time);*/

    return CTC_E_NONE;

cleanup:
    mem_free(target_a);
    return ret;
}

/*
 * set priority of entry specific by entry id
 */
static int32
_sys_humber_acl_set_entry_prio(uint32 eid, uint32 prio)
{
    int32               block_idx_target = 0;
    int32               prev_null_index = -1;
    uint16              block_sz;

    int32               next_null_index = -1;

    int32                 dir = 0;

    int32                 temp;
    int32                 temp1;
    int32               ret = 0;
    uint32              move_num = 0;
    uint32              old_prio = 0;
    uint8               asic_type;
    sys_acl_group_t*    pg = NULL;
    sys_acl_entry_t*    pe = NULL;
    sys_acl_block_t*    pb = NULL;

    bool                flag_no_free_entries = FALSE;

    SYS_ACL_DBG_FUNC();

    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* If the priority isn't changing, just return.*/
    old_prio = pe->priority;
    if (old_prio == prio)
    {
        return (CTC_E_NONE);
    }

    asic_type = acl_master->asic_type[pe->key.type];

    pg = pe->group;
    pb = &acl_master->block[asic_type][pg->group_info.block_id];
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    prio_set_with_no_free_entries = FALSE; /* Global variable */
    /*
     * If priority is changing, but still in proper place,
     * just goto end (change the pe->prio to prio)
     */
    if (_sys_humber_acl_set_prior_require_move(pe, prio) == FALSE)
    {
        goto end;
    }

#if 1 /* open later, consider it later.*/
    if (0 == (pb->free_count))
    {
        if (!(pe->flag & SYS_ACL_ENTRY_FLAG_INSTALLED))
        {
            /*
             * As there are no free entries  and this entry is NOT installed,
             *     fake that it does not exist.
             */
            pb->entries[pe->block_index] = NULL;
            flag_no_free_entries = TRUE;
        }
        else
        {
            return CTC_E_ACL_NO_ROOM_TO_MOVE_ENTRY;
        }
    }

#else
    if (0 == (pb->free_count))
    {
        return CTC_E_ACL_NO_ROOM_TO_MOVE_ENTRY;
    }

#endif

    block_sz = pb->entry_count;

#if 1  /*-1 - target < 0, will return false. means not shift.  better.*/
       /* the default value means cannot shift up.
       so make this shift_up_amount bigger than biggest, that is block_sz+block_sz+1.*/
    prev_null_index = block_sz + 2;
#endif

    for (block_idx_target = 0;
         block_idx_target < block_sz;
         block_idx_target++)
    {

        /* Skip the pe itself */
        if (pe == pb->entries[block_idx_target])
        {
            continue;
        }

        if (pb->entries[block_idx_target] == NULL)
        {
            /* only here to assign prev_null_index,
             * so block_idx_target must be bigger than prev_null_index.
             * UNLESS never enter here, in this case, prev_null_index = -1;
             * in that case, block_idx_tagret still bigger than prev_null_index
             * so if prev_null_index = -1, cannot shift up.
             */
            prev_null_index = block_idx_target;

            continue;
        }

        if (prio > (pb->entries[block_idx_target]->priority))
        {
            SYS_ACL_DBG_INFO("  %%INFO: Found target slice_idx=%u\n",
                             block_idx_target);
            break;
        }

        /* target = NULL only when target_idx = block_sz. in this case, next_null_idx = -1.*/

    }

    SYS_ACL_DBG_INFO("  %%INFO: prev null index %d \n", prev_null_index);
    SYS_ACL_DBG_INFO("  %%INFO: target index %d \n", block_idx_target);

    temp = block_idx_target + 1;
    block_sz = pb->entry_count;

    for (; temp < block_sz; temp++)
    {
        if (pb->entries[temp] == NULL)
        {
            /* enter here, means target not null. so next_null must be bigger than target_index.*/
            /* put this way: next_null_index be -1 or bigger than target_index.*/
            next_null_index = temp;
            break;
        }
    }

    SYS_ACL_DBG_INFO("  %%INFO: next null index %d \n", next_null_index);

    /*
     * Check if the movement is feasible
     */
    ret = (_sys_humber_acl_get_shift_direction( prev_null_index,
                                                  block_idx_target,
                                                  next_null_index,
                                                  &dir));
    if (ret == FALSE)
    {
        /* already checked above. remove it.*/
        return (CTC_E_ACL_NO_ROOM_TO_MOVE_ENTRY);
    }

    if (dir == 1)
    {
        /*
         * Move the entry at the target index to target_index+1. This may
         * mean shifting more entries down to make room. In other words,
         * shift the target index and any that follow it down 1 as far as the
         * next empty index.
         */
        SYS_ACL_DBG_INFO("  %%INFO: from %d to %d do shift down \n", block_idx_target, next_null_index - 1);
        if (pb->entries[block_idx_target] != NULL)
        {
            /* block_idx_target be NULL, only when it's the last one.
             * since shift down is feasible, target cannot be the last one.
             * so this check is meaningless.
             */
            ret = _sys_humber_acl_entry_shift_down(pb,
                                                      block_idx_target,
                                                      next_null_index);
            CTC_ERROR_RETURN(ret);
            move_num = (next_null_index - block_idx_target);
        }
    }
    else
    {
        /*
         * for Shifting UP , the target is one up.
         */
        block_idx_target--;

        SYS_ACL_DBG_INFO("  %%INFO: from %d to %d do shift up \n", block_idx_target, prev_null_index + 1);
        if (pb->entries[block_idx_target] != NULL)
        {
            /* block_idx_target-- be NULL, that's the case of only move.
             * checked before. so this check also is meaningless.
             */
            ret = _sys_humber_acl_entry_shift_up(pb,
                                                    block_idx_target,
                                                    prev_null_index);
            CTC_ERROR_RETURN(ret);
            move_num = (block_idx_target - prev_null_index - 1);
        }
    }

    /*
     * Put the entry back,
     *     in case there is a context switch, AND
     *     another thread calls entry_create
     */
    if (flag_no_free_entries == TRUE)
    {
        pb->entries[block_idx_target] = pe;
        pe->block_index               = block_idx_target;
    }
    else /* Move the entry from its old slice index to the target slice index. */
    {
        temp = block_idx_target;
        temp1 = pe->block_index;

        if ((temp - temp1) != 0)
        {
            /* this condition be true only if still in proper place.
             * just goto end. this has been checked.
             * so the check is meaningless.
             */
            if (flag_no_free_entries)
            {
                prio_set_with_no_free_entries = TRUE;
            }

            ret = _sys_humber_acl_entry_move(pe, (temp - temp1));
            if (ret < 0)
            {
                prio_set_with_no_free_entries = FALSE;
                return ret;
            }

            /* in case _field_entry_move is called from some other function */
            prio_set_with_no_free_entries = FALSE;

        }
    }

end:
    /* Assign the requested priority to the entry. */
    pe->priority = prio;

    if (pg->prio_max < prio)
    {
        pg->prio_max = prio;
    }

    if (0 <= prio &&
        (prio < pg->prio_min || pg->prio_min < 0))
    {
        pg->prio_min = prio;
    }

    if (DO_REORDER(move_num, pb->entry_count))
    {
        _sys_humber_acl_reorder(pb, pb->entry_count - 1, 0);
    }

    if(0 == prio)
    {
        pb->zero_count++;
    }
    if (0 == old_prio)
    {
        pb->zero_count--;
    }
    return (CTC_E_NONE);
}



#define _3_ACL_L4_INFO_MAPPED__

int32
sys_humber_acl_show_tcp_flags()
{
    uint8 idx1;
    sys_acl_tcp_flag_t* p_tcp = NULL;

    p_tcp = acl_master->tcp_flag;

    SYS_ACL_DBG_FUNC();

    SYS_ACL_DBG_DUMP("----------------------- Show layer 4 tcp flags -----------------------\n");

    for (idx1 = 0; idx1 < SYS_ACL_TCP_FLAG_NUM; idx1++)
    {
        SYS_ACL_DBG_DUMP("index=%-2u  op=%s  tcp_flags=0x%02x      ref_cnt=%-4u \n",
                         idx1, (p_tcp[idx1].match_any) ? "match_any" : "match_all", p_tcp[idx1].tcp_flags, p_tcp[idx1].ref);

    }

    return CTC_E_NONE;
}

int32
sys_humber_acl_show_port_range()
{
    uint8 idx1;
    sys_acl_l4port_op_t* p_pop = NULL;

    p_pop = acl_master->l4_port;

    SYS_ACL_DBG_FUNC();

    SYS_ACL_DBG_DUMP("----------------------- Show layer 4 port range -----------------------\n");

    for (idx1 = 0; idx1 < SYS_ACL_L4_PORT_NUM; idx1++)
    {
        SYS_ACL_DBG_DUMP("index=%-2u  op=%s  min_port=%-5u   max_port=%-5u  ref_cnt=%-4u \n",
                         idx1, (p_pop[idx1].op_dest_port) ? "dest_port" : "src_port ",
                         p_pop[idx1].port_min, p_pop[idx1].port_max, p_pop[idx1].ref);
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_lkup_tcp_flag(uint8 match_any, uint8 tcp_flags,
                                 uint8* avail_idx, uint8* lkup_idx)
{
    uint8 idx1;
    uint8 hit = 0;
    sys_acl_tcp_flag_t* p_tcp = NULL;
    sys_parser_l4flag_op_ctl_t parser;

    p_tcp = acl_master->tcp_flag;

    CTC_PTR_VALID_CHECK(avail_idx);
    CTC_PTR_VALID_CHECK(lkup_idx);
    SYS_ACL_DBG_FUNC();

    sal_memset(&parser, 0, sizeof(sys_parser_l4flag_op_ctl_t));

    for (idx1 = 0; idx1 < SYS_ACL_TCP_FLAG_NUM; idx1++)
    {
        if ((p_tcp[idx1].ref > 0) &&
            (p_tcp[idx1].match_any == match_any)
            && (p_tcp[idx1].tcp_flags == (tcp_flags & 0x3F)))
        { /* found exactly matched entry */

            CTC_NOT_EQUAL_CHECK(p_tcp[idx1].ref, SYS_ACL_TCP_FALG_REF_CNT);

            SYS_ACL_DBG_INFO("share tcp flag, index = %u, match_any = %u, tcp_flags = 0x%x, ref = %u\n",
                             idx1, match_any, tcp_flags, p_tcp[idx1].ref);
            break;
        }
        else if ((p_tcp[idx1].ref == 0)
                 && (0 == hit))
        { /* first available entry */
            *avail_idx = idx1;
            hit = 1;
        }
    }

    *lkup_idx = idx1;
    return CTC_E_NONE;
}

static int32
_sys_humber_acl_add_tcp_flag(uint8 match_any, uint8 tcp_flags,
                                uint8 target_idx)
{
    uint8 lchip_num;
    uint8 lchip;
    sys_acl_tcp_flag_t* p_tcp = NULL;
    sys_parser_l4flag_op_ctl_t parser;

    p_tcp = acl_master->tcp_flag;

    CTC_MAX_VALUE_CHECK(target_idx, SYS_ACL_TCP_FLAG_NUM - 1);

    SYS_ACL_DBG_FUNC();

    sal_memset(&parser, 0, sizeof(sys_parser_l4flag_op_ctl_t));

    /* write to hardware */

    parser.op_and_or = match_any;
    if (match_any)
    { /* match any.*/
        parser.flags_mask = tcp_flags;
    }
    else
    { /* match all */
        parser.flags_mask = (~tcp_flags & 0x3F); /* make 1 as care, 0 as don't care.*/
    }

    lchip_num = acl_master->lchip_num;

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        CTC_ERROR_RETURN(sys_humber_parser_set_layer4_flag_op_ctl(lchip, target_idx, &parser));
    }

    /* write to software */
    p_tcp[target_idx].ref = 1;
    p_tcp[target_idx].match_any = match_any;
    p_tcp[target_idx].tcp_flags = tcp_flags & 0x3F;

    if (acl_master->tcp_flag_free_cnt > 0)
    {
        acl_master->tcp_flag_free_cnt--;
    }

    SYS_ACL_DBG_INFO("add tcp flag, index = %u, match_any = %u, flags = 0x%x\n",
                     target_idx, match_any, tcp_flags);

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_remove_tcp_flag(uint8 index)
{
    uint8 lchip_num;
    uint8 lchip;
    sys_acl_tcp_flag_t* p_tcp = NULL;

    sys_parser_l4flag_op_ctl_t parser;

    p_tcp = acl_master->tcp_flag;

    CTC_MAX_VALUE_CHECK(index, SYS_ACL_TCP_FLAG_NUM - 1);
    SYS_ACL_DBG_FUNC();

    sal_memset(&parser, 0, sizeof(sys_parser_l4flag_op_ctl_t));

    if (0 == p_tcp[index].ref)
    {
        return CTC_E_NONE;
    }

    p_tcp[index].ref--;

    if (0 == p_tcp[index].ref)
    {
        /* write to hardware */
        parser.op_and_or = 0;
        parser.flags_mask = 0;

        lchip_num = acl_master->lchip_num;

        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            CTC_ERROR_RETURN(sys_humber_parser_set_layer4_flag_op_ctl(lchip, index, &parser));
        }

        /* write to software */
        p_tcp[index].match_any = 0;
        p_tcp[index].tcp_flags = 0;
    }

    if (acl_master->tcp_flag_free_cnt < SYS_ACL_TCP_FLAG_NUM)
    {
        acl_master->tcp_flag_free_cnt++;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_lkup_l4_port_range(uint16 port_min, uint16 port_max,
                                      uint8 op_dest_port,
                                      uint8* avail_idx, uint8* lkup_idx)
{
    uint8 idx1;
    uint8 hit = 0;
    sys_acl_l4port_op_t* p_pop = NULL;

    p_pop = acl_master->l4_port;

#if 0 /* this can avoid using ** */
    p_pop += lchip;
#endif /* _if0_ */
    CTC_PTR_VALID_CHECK(avail_idx);
    CTC_PTR_VALID_CHECK(lkup_idx);
    SYS_ACL_DBG_FUNC();

    for (idx1 = 0; idx1 < SYS_ACL_L4_PORT_NUM; idx1++)
    {
        if ((p_pop[idx1].ref > 0) &&
            (p_pop[idx1].port_min == port_min)
            && (p_pop[idx1].port_max == port_max)
            && (p_pop[idx1].op_dest_port == op_dest_port))
        { /* found exactly matched entry */

            CTC_NOT_EQUAL_CHECK(p_pop[idx1].ref, SYS_ACL_L4_PORT_REF_CNT);

            SYS_ACL_DBG_INFO("share l4 port entry, index = %u, op_dest_port = %u, \
                                      port_min = % d, port_max = % d, ref = % d\n",
                             idx1, op_dest_port, port_min, port_max, p_pop[idx1].ref);
            break;
        }
        else if ((p_pop[idx1].ref == 0)
                 && (0 == hit))
        { /* first available entry */
            *avail_idx = idx1;
            hit = 1;
        }
    }

    *lkup_idx = idx1;

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_add_l4_port_range(uint16 port_min, uint16 port_max,
                                     uint8 op_dest_port, uint8 target_idx)
{
    uint8 idx1;
    uint8 lchip_num;
    uint8 lchip;
    sys_parser_l4_port_op_sel_t sel;
    sys_parser_l4_port_op_ctl_t ctl;
    sys_acl_l4port_op_t* p_pop = NULL;

    p_pop = acl_master->l4_port;

    CTC_MAX_VALUE_CHECK(target_idx, SYS_ACL_L4_PORT_NUM - 1);
    SYS_ACL_DBG_FUNC();

    sal_memset(&sel, 0, sizeof(sys_parser_l4_port_op_sel_t));
    sal_memset(&ctl, 0, sizeof(sys_parser_l4_port_op_ctl_t));

    /* write to hardware */
    /* get sel from sw */
    for (idx1 = 0; idx1 < SYS_ACL_L4_PORT_NUM; idx1++)
    {
        if (p_pop[idx1].op_dest_port)
        {
            SET_BIT(sel.op_dest_port, idx1);
        }
    }

    /* set new sel */
    if (op_dest_port)
    {
        SET_BIT(sel.op_dest_port, target_idx);
    }

    /* set new ctl */
    ctl.layer4_port_min = port_min;
    ctl.layer4_port_max = port_max;

    lchip_num = acl_master->lchip_num;

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        CTC_ERROR_RETURN(sys_humber_parser_set_layer4_port_op_sel(lchip, &sel));
        CTC_ERROR_RETURN(sys_humber_parser_set_layer4_port_op_ctl(lchip, target_idx, &ctl));
    }

    /* write to software */
    /* set sel */
    if (op_dest_port)
    {
        p_pop[target_idx].op_dest_port = 1;
    }

    /* set ctl */
    p_pop[target_idx].ref = 1;
    p_pop[target_idx].port_min = port_min;
    p_pop[target_idx].port_max = port_max;

    if (acl_master->l4_port_free_cnt > 0)
    {
        acl_master->l4_port_free_cnt--;
    }

    SYS_ACL_DBG_INFO("add l4 port entry, index = %u, op_dest_port = %u, \
                     port_min = % d, port_max = % d\n",
                     target_idx, op_dest_port, port_min, port_max);

    return CTC_E_NONE;

}

static int32
_sys_humber_acl_remove_l4_port_range(uint8 index)
{
    uint8 idx1;
    uint8 lchip_num;
    uint8 lchip;
    sys_parser_l4_port_op_sel_t sel;
    sys_parser_l4_port_op_ctl_t ctl;
    sys_acl_l4port_op_t* p_pop = NULL;

    p_pop = acl_master->l4_port;

    CTC_MAX_VALUE_CHECK(index, SYS_ACL_L4_PORT_NUM - 1);

    SYS_ACL_DBG_FUNC();

    sal_memset(&sel, 0, sizeof(sys_parser_l4_port_op_sel_t));
    sal_memset(&ctl, 0, sizeof(sys_parser_l4_port_op_ctl_t));

    if (0 == p_pop[index].ref)
    {
        return CTC_E_NONE;
    }

    p_pop[index].ref--;

    if (0 == p_pop[index].ref)
    {
        /* write to asic */
        /* get sel from sw */
        for (idx1 = 0; idx1 < SYS_ACL_L4_PORT_NUM; idx1++)
        {
            if (p_pop[idx1].op_dest_port)
            {
                SET_BIT(sel.op_dest_port, idx1);
            }
        }

        /* set new sel */
        CLEAR_BIT(sel.op_dest_port, index);

        /* clear ctl is enough */

        lchip_num = acl_master->lchip_num;

        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            /* sys_humber_parser_set_layer4_port_op_sel(lchip, &sel); */
            sys_humber_parser_set_layer4_port_op_ctl(lchip, index, &ctl);
        }

        /* write to db */
        p_pop[index].port_min = 0;
        p_pop[index].port_max = 0;
        p_pop[index].op_dest_port = 0;

    }

    if (acl_master->l4_port_free_cnt < SYS_ACL_L4_PORT_NUM)
    {
        acl_master->l4_port_free_cnt++;
    }

    return CTC_E_NONE;
}

/*
 * below is build sw struct
 */
#define _4_ACL_SW_

static uint32
_sys_humber_acl_hash_make_group(void* data)
{
    sys_acl_group_t* p_group = (sys_acl_group_t*)data;

    return p_group->group_id;
}

static bool
_sys_humber_acl_hash_compare_group(void* data1, void* data2)
{
    sys_acl_group_t* p_group1 = (sys_acl_group_t*)data1;
    sys_acl_group_t* p_group2 = (sys_acl_group_t*)data2;

    return (p_group1->group_id == p_group2->group_id);
}

static uint32
_sys_humber_acl_hash_make_entry(void* data)
{
    sys_acl_entry_t* p_entry = (sys_acl_entry_t*)data;

    return p_entry->entry_id;
}

static bool
_sys_humber_acl_hash_compare_entry(void* data1, void* data2)
{
    sys_acl_entry_t* p_entry1 = (sys_acl_entry_t*)data1;
    sys_acl_entry_t* p_entry2 = (sys_acl_entry_t*)data2;

    return (p_entry1->entry_id == p_entry2->entry_id);
}

static uint32
_sys_humber_acl_redirect_hash_key(void* data)
{
    sys_acl_redirect_t* p_acl_redirect = (sys_acl_redirect_t*)data;

    return p_acl_redirect->nhid;
}

/**
 @brief Acl redirect hash comparison hook.
*/
static bool
_sys_humber_acl_redirect_hash_cmp(void* data1, void* data2)
{
    sys_acl_redirect_t* p_acl_redirect1 = (sys_acl_redirect_t*)data1;
    sys_acl_redirect_t* p_acl_redirect2 = (sys_acl_redirect_t*)data2;

    if (p_acl_redirect1->nhid == p_acl_redirect2->nhid)
    {
        return TRUE;
    }

    return FALSE;
}

static int32
_sys_humber_acl_map_stats_action(ctc_acl_action_t* p_ctc_action,
                                    sys_acl_action_t* p_sys_action,
                                    uint8 is_update,
                                    sys_acl_action_t* p_sys_action_old)
{
    uint8 lchip = 0;

    if ((0 == is_update) || (0 == p_sys_action_old->flag.stats))  /* pure add, OR update but old action has no stats*/
    {
        if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_STATS))
        {

            for (lchip = 0; lchip < acl_master->lchip_num; lchip++)
            {
                CTC_ERROR_RETURN(sys_humber_stats_create_statsptr(lchip, 1, &p_sys_action->stats_ptr[lchip]));
            }

            p_sys_action->flag.stats = 1;

        }
    }
    else /* update, but old action has stats.1 -> 1, 1 -> 0 */
    {
        if (!CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_STATS))
        {
            for (lchip = 0; lchip < acl_master->lchip_num; lchip++)
            {
                CTC_ERROR_RETURN(sys_humber_stats_delete_statsptr(lchip, 1, p_sys_action_old->stats_ptr[lchip]));
            }
        }
        else
        {
            p_sys_action->flag.stats = 1;
            for (lchip = 0; lchip < acl_master->lchip_num; lchip++)
            {
                p_sys_action->stats_ptr[lchip] = p_sys_action_old->stats_ptr[lchip];
            }
        }
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_remove_redirect_action(sys_acl_action_t* p_sys_action)
{
    sys_acl_redirect_t acl_redirect;
    sys_acl_redirect_t* p_acl_redirect = 0;
    sys_humber_opf_t opf;
    uint32 ds_fwd_offset = 0;

    sal_memset(&opf, 0, sizeof(opf));
    sal_memset(&acl_redirect, 0, sizeof(acl_redirect));

    /* free acl_fwd_ptr, It's no need to free sram */
    if (p_sys_action->flag.redirect)
    {
        acl_redirect.nhid = p_sys_action->nh_id;
        p_acl_redirect = ctc_hash_lookup(acl_master->p_sys_acl_redirect_hash, &acl_redirect);
        if(p_acl_redirect)
        {
            p_acl_redirect->ref --;

            if(p_acl_redirect->ref == 0)
            {
                opf.pool_type = OPF_ACL_FWD_SRAM;
                opf.pool_index = 0;
                ds_fwd_offset = p_sys_action->ds_fwd_offset;
                CTC_ERROR_RETURN(sys_humber_opf_free_offset(&opf, 1, ds_fwd_offset));

                ctc_hash_remove(acl_master->p_sys_acl_redirect_hash, p_acl_redirect);
                mem_free(p_acl_redirect);
            }
        }
        else
        {
            return CTC_E_ACLQOS_INVALID_ACTION;
        }
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_map_action(ctc_acl_action_t* p_ctc_action,
                           sys_acl_action_t* p_sys_action)
{
    uint8 lchip = 0, lchip_num = 0;
    uint32 ds_fwd_offset = 0;
    sys_nh_offset_array_t offset_array;
    sys_acl_redirect_t acl_redirect;
    sys_acl_redirect_t* p_acl_redirect = 0;
    sys_humber_opf_t opf;
    int32 ret = 0;

    CTC_PTR_VALID_CHECK(p_ctc_action);
    CTC_PTR_VALID_CHECK(p_sys_action);

    SYS_ACL_DBG_FUNC();

    sal_memset(&acl_redirect, 0, sizeof(acl_redirect));
    sal_memset(&opf, 0, sizeof(opf));

    lchip_num = sys_humber_get_local_chip_num();

    /* discard */
    p_sys_action->flag.discard      =
        CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_DISCARD);

    /* deny bridging */
    p_sys_action->flag.deny_bridge  =
        CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_DENY_BRIDGE);

    /* deny learning */
    p_sys_action->flag.deny_learning =
        CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_DENY_LEARNING);

    /* deny route */
    p_sys_action->flag.deny_route   =
        CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_DENY_ROUTE);

    /*------ above has no value, below has value -----*/

    /* stats do outside */

    /* micro flow policer */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER))
    {
        p_sys_action->flag.micro_flow_policer = 1;

        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            CTC_ERROR_RETURN(sys_humber_qos_policer_index_get(lchip, p_ctc_action->micro_policer_id, &(p_sys_action->micro_policer_ptr[lchip])));
        }

        p_sys_action->micro_policer_id = p_ctc_action->micro_policer_id;
    }

    /* copy to cpu */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_COPY_TO_CPU))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_action->log_percent, 0xF);
        p_ctc_action->log_percent = p_ctc_action->log_percent ? p_ctc_action->log_percent : 0xF;

        p_sys_action->flag.random_log = 1;
        p_sys_action->acl_log_id = SYS_ACL_MAX_SESSION_NUM;
        p_sys_action->random_threshold_shift = p_ctc_action->log_percent;
    }

    /* random log */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_RANDOM_LOG))
    {
        if (p_ctc_action->flag & CTC_ACL_ACTION_FLAG_COPY_TO_CPU)
        {
            return CTC_E_ACL_FLAG_COLLISION;
        }

        CTC_MAX_VALUE_CHECK(p_ctc_action->log_percent, 0xF);
        CTC_MAX_VALUE_CHECK(p_ctc_action->log_session_id, SYS_ACL_MAX_SESSION_NUM - 1);

        p_sys_action->flag.random_log = 1;
        p_sys_action->acl_log_id = p_ctc_action->log_session_id;
        p_sys_action->random_threshold_shift = p_ctc_action->log_percent;

    }

    /* priority + color */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_PRIORITY_AND_COLOR))
    {
        /*valid check*/
        CTC_NOT_ZERO_CHECK(p_ctc_action->color);
        CTC_MAX_VALUE_CHECK(p_ctc_action->color, MAX_CTC_QOS_COLOR - 1);
        CTC_MAX_VALUE_CHECK(p_ctc_action->priority, 63);

        p_sys_action->flag.priority_and_color = 1;
        p_sys_action->priority = p_ctc_action->priority;
        p_sys_action->color = p_ctc_action->color;

    }

    /* qos policy (trust) */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_TRUST))
    {
        /* 7 is invalid, but that's inside the range.*/
        CTC_MAX_VALUE_CHECK(p_ctc_action->trust, MAX_CTC_QOS_TRUST - 1);
        p_sys_action->flag.trust = 1;
        p_sys_action->trust = p_ctc_action->trust;

    }

    /* ds forward */
    if (CTC_FLAG_ISSET(p_ctc_action->flag, CTC_ACL_ACTION_FLAG_REDIRECT))
    {
        acl_redirect.nhid = p_ctc_action->nh_id;
        p_acl_redirect = ctc_hash_lookup(acl_master->p_sys_acl_redirect_hash, &acl_redirect);

        if (!p_acl_redirect)
        {
            /* new acl redirect */
            p_acl_redirect = (sys_acl_redirect_t*)mem_malloc(MEM_ACL_MODULE, sizeof(sys_acl_redirect_t));
            if (!p_acl_redirect)
            {
                return CTC_E_NO_MEMORY;
            }

            sal_memset(p_acl_redirect, 0, sizeof(sys_acl_redirect_t));

            CTC_ERROR_RETURN(sys_humber_nh_get_dsfwd_offset(p_ctc_action->nh_id, offset_array));

            /* alloc ds_fwd_offset of acl, the ds_fwd_offset are same for the two local chip */
            opf.pool_type = OPF_ACL_FWD_SRAM;
            opf.pool_index = 0;
            ret = sys_humber_opf_alloc_offset(&opf, 1, &ds_fwd_offset);
            if (ret)
            {
                mem_free(p_acl_redirect);
                return ret;
            }

            p_sys_action->ds_fwd_offset = ds_fwd_offset;

            /*copy dsfwd for the dsfwdptr of the key only have 12bit*/
            for (lchip = 0; lchip < lchip_num; lchip++)
            {
                _sys_humber_acl_copy_dsfwd(lchip, offset_array[lchip],
                                           acl_master->acl_fwd_base + p_sys_action->ds_fwd_offset);
            }

            /* insert into hash table */
            p_acl_redirect->nhid = p_sys_action->nh_id;
            p_acl_redirect->ds_fwd_offset = ds_fwd_offset;
            p_acl_redirect->ref++;
            ctc_hash_insert(acl_master->p_sys_acl_redirect_hash, p_acl_redirect);
        }
        else
        {
            p_sys_action->ds_fwd_offset = p_acl_redirect->ds_fwd_offset;
            p_acl_redirect->ref++;
        }

        p_sys_action->nh_id = p_ctc_action->nh_id;

        p_sys_action->flag.redirect = 1;
        p_sys_action->flag.deny_bridge = 1;
        p_sys_action->flag.deny_route = 1;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_map_mac_key(ctc_acl_mac_key_t* p_ctc_key,
                            sys_acl_mac_key_t* p_sys_key)
{
    uint32 flag = 0;

    CTC_PTR_VALID_CHECK(p_ctc_key);
    CTC_PTR_VALID_CHECK(p_sys_key);

    SYS_ACL_DBG_FUNC();

    flag = p_ctc_key->flag;

    /* src cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->cos, 0x7);
        p_sys_key->flag.cos = 1;
        p_sys_key->cos = p_ctc_key->cos;
        p_sys_key->cos_mask = p_ctc_key->cos_mask & 0x7;
    }

    /* mac da */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_MAC_DA))
    {
        p_sys_key->flag.mac_da = 1;
        sal_memcpy(p_sys_key->mac_da, p_ctc_key->mac_da, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_da_mask, p_ctc_key->mac_da_mask, CTC_ETH_ADDR_LEN);
    }

    /* mac sa */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_MAC_SA))
    {
        p_sys_key->flag.mac_sa = 1;
        sal_memcpy(p_sys_key->mac_sa, p_ctc_key->mac_sa, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_sa_mask, p_ctc_key->mac_sa_mask, CTC_ETH_ADDR_LEN);
    }

    /* cvlan */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_CVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->cvlan);
        p_sys_key->flag.cvlan = 1;
        p_sys_key->cvlan = p_ctc_key->cvlan;
        p_sys_key->cvlan_mask = p_ctc_key->cvlan_mask & 0xFFF;
    }

    /* ctag cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_CTAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cos, 0x7);
        p_sys_key->flag.ctag_cos = 1;
        p_sys_key->ctag_cos = p_ctc_key->ctag_cos;
        p_sys_key->ctag_cos_mask = (p_ctc_key->ctag_cos_mask) & 0x7;
    }

    /* ctag cfi */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_CTAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cfi, 0x1);
        p_sys_key->flag.ctag_cfi = 1;
        p_sys_key->ctag_cfi  = p_ctc_key->ctag_cfi;
    }

    /* svlan */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_SVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->svlan);
        p_sys_key->flag.svlan = 1;
        p_sys_key->svlan = p_ctc_key->svlan;
        p_sys_key->svlan_mask = p_ctc_key->svlan_mask & 0xFFF;

    }

    /* stag cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_STAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cos, 0x7);
        p_sys_key->flag.stag_cos = 1;
        p_sys_key->stag_cos = p_ctc_key->stag_cos;
        p_sys_key->stag_cos_mask = (p_ctc_key->stag_cos_mask) & 0x7;
    }

    /* stag cfi */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_STAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cfi, 0x1);
        p_sys_key->flag.stag_cfi = 1;
        p_sys_key->stag_cfi  = p_ctc_key->stag_cfi;
    }

    /* eth type */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_ETH_TYPE))
    {
        /* Ether_type no need check */
        p_sys_key->flag.eth_type = 1;
        p_sys_key->eth_type = p_ctc_key->eth_type;
        p_sys_key->eth_type_mask = p_ctc_key->eth_type_mask;
    }

    /* l2 type */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_L2_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l2_type, 0xF);
        p_sys_key->flag.l2_type = 1;
        p_sys_key->l2_type = p_ctc_key->l2_type;
        p_sys_key->l2_type_mask = p_ctc_key->l2_type_mask;
    }

    /* l3 type */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_MAC_KEY_FLAG_L3_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l3_type, 0xF);
        p_sys_key->flag.l3_type = 1;
        p_sys_key->l3_type = p_ctc_key->l3_type;
        p_sys_key->l3_type_mask = p_ctc_key->l3_type_mask;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_map_ipv4_key(ctc_acl_ipv4_key_t* p_ctc_key,
                             sys_acl_ipv4_key_t* p_sys_key)
{
    int32  ret = 0;
    uint32 flag = 0;
    uint32 sub_flag = 0;
    uint8  idx_lkup = 0;
    uint8  idx_valid = 0;
    uint8  idx_target = 0;

    uint16 port0 = 0;
    uint16 port1 = 0;

    uint8 op_dest = 0;           /* loop 2 times, for saving code.*/
    uint8 l4_src_port_use_range = 0;  /* src port use range */
    uint8 l4_dst_port_use_range = 0;  /* dst port use range */

    CTC_PTR_VALID_CHECK(p_ctc_key);
    CTC_PTR_VALID_CHECK(p_sys_key);

    SYS_ACL_DBG_FUNC();

    flag = p_ctc_key->flag;
    sub_flag = p_ctc_key->sub_flag;

    /* src cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->cos, 0x7);
        p_sys_key->flag.cos = 1;
        p_sys_key->cos = p_ctc_key->cos;
        p_sys_key->cos_mask = p_ctc_key->cos_mask & 0x7;
    }

    /* need both DSCP and PRECEDENCE ????*/
    if ((CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_PRECEDENCE)
         + CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_DSCP)) > 1)
    {
        return CTC_E_ACL_FLAG_COLLISION;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_IP_DA))
    {
        p_sys_key->flag.ip_da = 1;
        p_sys_key->ip_da = p_ctc_key->ip_da;
        p_sys_key->ip_da_mask = p_ctc_key->ip_da_mask;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_IP_SA))
    {
        p_sys_key->flag.ip_sa = 1;
        p_sys_key->ip_sa = p_ctc_key->ip_sa;
        p_sys_key->ip_sa_mask = p_ctc_key->ip_sa_mask;
    }

    /* layer 4 information */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_L4_PROTOCOL))
    {
        if ((0xFF == p_ctc_key->l4_protocol_mask)&&
            (SYS_ACL_IPV4_ICMP == p_ctc_key->l4_protocol))        /* ICMP */
        {
            p_sys_key->flag.l4info_mapped = 1;
            /* l4_info_mapped for non-tcp non-udp packet, it's l4_type | l3_header_protocol */
            p_sys_key->l4info_mapped = p_ctc_key->l4_protocol;
            p_sys_key->l4info_mapped_mask = p_ctc_key->l4_protocol_mask;

            p_sys_key->flag.is_tcp = 1;
            p_sys_key->is_tcp = 0;

            p_sys_key->flag.is_udp = 1;
            p_sys_key->is_udp = 0;

            /* l4_src_port for flex-l4 (including icmp), it's type|code */

            /* icmp type */
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_TYPE))
            {
                p_sys_key->flag.l4_src_port = 1;
                p_sys_key->l4_src_port |= (p_ctc_key->icmp_type) << 8;
                p_sys_key->l4_src_port_mask |= (p_ctc_key->icmp_type_mask) << 8;

            }

            /* icmp code */
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_CODE))
            {
                p_sys_key->flag.l4_src_port = 1;
                p_sys_key->l4_src_port |= p_ctc_key->icmp_code & 0x00FF;
                p_sys_key->l4_src_port_mask |= (p_ctc_key->icmp_code_mask) & 0x00FF;

            }
        }
        else if ((0xFF == p_ctc_key->l4_protocol_mask)
            &&(SYS_ACL_IPV4_IGMP == p_ctc_key->l4_protocol))   /* IGMP */
        {
            /* l4_info_mapped for non-tcp non-udp packet, it's l4_type | l3_header_protocol */
            p_sys_key->flag.l4info_mapped = 1;
            p_sys_key->l4info_mapped = p_ctc_key->l4_protocol;
            p_sys_key->l4info_mapped_mask = p_ctc_key->l4_protocol_mask;

            p_sys_key->flag.is_tcp = 1;
            p_sys_key->is_tcp = 0;

            p_sys_key->flag.is_udp = 1;
            p_sys_key->is_udp = 0;

            /* l4_src_port for flex-l4 (including igmp), it's type|..*/
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_IGMP_TYPE))
            {
                p_sys_key->flag.l4_src_port = 1;
                p_sys_key->l4_src_port |= (p_ctc_key->igmp_type << 8) & 0xFF00;
                p_sys_key->l4_src_port_mask |= (p_ctc_key->igmp_type_mask << 8) & 0xFF00;

            }
        }
        else if ((0xFF == p_ctc_key->l4_protocol_mask)
                &&((SYS_ACL_TCP == p_ctc_key->l4_protocol)
                    || (SYS_ACL_UDP == p_ctc_key->l4_protocol)))    /* TCP or UDP */
        {
            if (SYS_ACL_TCP == p_ctc_key->l4_protocol)
            { /* TCP */
                p_sys_key->flag.is_tcp = 1;
                p_sys_key->is_tcp = 1;

            }
            else
            { /* UDP */
                p_sys_key->flag.is_udp = 1;
                p_sys_key->is_udp = 1;

            }

            /* caculate use how many range count */
#if 0
            range_cnt = ((CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT)) &&
                         (!p_ctc_key->l4_src_port_use_mask))
                + ((CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT)) &&
                   (!p_ctc_key->l4_dst_port_use_mask))
#endif /* _if0_ */
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT))
            { /* op_dest_port = 0 */
                if (p_ctc_key->l4_src_port_use_mask)
                {  /*  use mask.
                    *  l4_src_port_0 is data.
                    *  l4_src_port_1 is mask.
                    */
                    p_sys_key->flag.l4_src_port = 1;
                    p_sys_key->l4_src_port = p_ctc_key->l4_src_port_0;
                    p_sys_key->l4_src_port_mask = p_ctc_key->l4_src_port_1;

                }
                else
                {  /*  use range.
                    *  l4_src_port_0 is min.
                    *  l4_src_port_1 is max.
                    */
                    if (p_ctc_key->l4_src_port_0 >= p_ctc_key->l4_src_port_1)
                    {
                        return CTC_E_INVALID_PARAM;
                    }

                    l4_src_port_use_range = 1;
                }
            }

            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT))
            { /* op_dest_port =1 */
                if (p_ctc_key->l4_dst_port_use_mask)
                {  /*  use mask.
                    *  l4_dst_port_0 is data.
                    *  l4_dst_port_1 is mask.
                    */
                    p_sys_key->flag.l4_dst_port = 1;
                    p_sys_key->l4_dst_port = p_ctc_key->l4_dst_port_0;
                    p_sys_key->l4_dst_port_mask = p_ctc_key->l4_dst_port_1;

                }
                else
                {  /*  use range.
                    *  l4_dst_port_0 is min.
                    *  l4_dst_port_1 is max.
                    */

                    if (p_ctc_key->l4_dst_port_0 >= p_ctc_key->l4_dst_port_1)
                    {
                        return CTC_E_INVALID_PARAM;
                    }

                    l4_dst_port_use_range = 1;
                }
            }

            /* op_dest, use loop to save code.
             * op_dest = 0 -->src_port
             * op_dest = 1 -->dst_port
             */
            for (op_dest = 0; op_dest <= 1; op_dest++)
            {
                if (0 == op_dest)
                {
                    if (!l4_src_port_use_range)
                    {
                        continue;
                    }

                    port0 = p_ctc_key->l4_src_port_0;
                    port1 = p_ctc_key->l4_src_port_1;
                }
                else
                {
                    if (!l4_dst_port_use_range)
                    {
                        continue;
                    }

                    port0 = p_ctc_key->l4_dst_port_0;
                    port1 = p_ctc_key->l4_dst_port_1;
                }

                p_sys_key->flag.l4info_mapped = 1;

                CTC_ERROR_RETURN(_sys_humber_acl_lkup_l4_port_range(port0,
                                                                    port1, op_dest, &idx_target, &idx_lkup));

                if (SYS_ACL_L4_PORT_NUM != idx_lkup)
                { /* lkup success */
                    acl_master->l4_port[idx_lkup].ref++;

                    idx_valid = idx_lkup;

                }
                else if ((SYS_ACL_L4_PORT_NUM == idx_lkup)
                         && (acl_master->l4_port_free_cnt > 0))
                {
                    CTC_ERROR_RETURN(_sys_humber_acl_add_l4_port_range
                                         (port0, port1, op_dest, idx_target));

                    idx_valid = idx_target;

                }
                else
                {
                    ret = CTC_E_ACL_L4_PORT_RANGE_EXHAUSTED;
                    goto error;
                }

                p_sys_key->l4info_mapped |= 1 << idx_valid;
                p_sys_key->l4info_mapped_mask |= 1 << idx_valid;

                if (0 == op_dest)
                {
                    p_sys_key->flag.l4_src_port_range = 1;
                    p_sys_key->l4_src_port_range_idx = idx_valid;
                }
                else
                {
                    p_sys_key->flag.l4_dst_port_range = 1;
                    p_sys_key->l4_dst_port_range_idx = idx_valid;
                }
            }
        }
        else    /* other layer 4 protocol type */
        {
            p_sys_key->flag.l4info_mapped = 1;
            p_sys_key->l4info_mapped |= p_ctc_key->l4_protocol;
            p_sys_key->l4info_mapped_mask |= p_ctc_key->l4_protocol_mask;

            p_sys_key->flag.is_tcp = 1;
            p_sys_key->is_tcp = 0;

            p_sys_key->flag.is_udp = 1;
            p_sys_key->is_udp = 0;

        }
    }

    /* ip fragment */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_IP_FRAG))
    {
        p_sys_key->flag.frag_info = 1;

        CTC_MAX_VALUE_CHECK(p_ctc_key->ip_frag, CTC_IP_FRAG_MAX - 1);

        switch (p_ctc_key->ip_frag)
        {
        case CTC_IP_FRAG_NON:
            /* Non fragmented */
            p_sys_key->frag_info = 0;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_FIRST:
            /* Fragmented, and first fragment */
            p_sys_key->frag_info = 1;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_NON_OR_FIRST:
            /* Non fragmented OR Fragmented and first fragment */
            p_sys_key->frag_info = 0;
            p_sys_key->frag_info_mask = 2;     /* mask frag_info as 0x */
            break;

        case CTC_IP_FRAG_SMALL:
            /* Small fragment */
            p_sys_key->frag_info = 2;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_NOT_FIRST:
            /* Not first fragment (Fragmented of cause) */
            p_sys_key->frag_info = 3;
            p_sys_key->frag_info_mask = 3;
            break;

        default:
            return CTC_E_INVALID_PARAM;

        }
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_IP_OPTION))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ip_option, 1);
        p_sys_key->flag.ip_option = 1;
        p_sys_key->ip_option = p_ctc_key->ip_option;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_ROUTED_PACKET))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->routed_packet, 1);
        p_sys_key->flag.routed_packet = 1;
        p_sys_key->routed_packet = p_ctc_key->routed_packet;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_MAC_DA))
    {
        /* no check */
        p_sys_key->flag.mac_da = 1;
        sal_memcpy(p_sys_key->mac_da, p_ctc_key->mac_da, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_da_mask, p_ctc_key->mac_da_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_MAC_SA))
    {
        /* no check */
        p_sys_key->flag.mac_sa = 1;
        sal_memcpy(p_sys_key->mac_sa, p_ctc_key->mac_sa, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_sa_mask, p_ctc_key->mac_sa_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_CVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->cvlan);
        p_sys_key->flag.cvlan = 1;
        p_sys_key->cvlan = p_ctc_key->cvlan;
        p_sys_key->cvlan_mask = p_ctc_key->cvlan_mask & 0xFFF;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cos, 0x7);
        p_sys_key->flag.ctag_cos = 1;
        p_sys_key->ctag_cos = p_ctc_key->ctag_cos;
        p_sys_key->ctag_cos_mask = (p_ctc_key->ctag_cos_mask) & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cfi, 0x1);
        p_sys_key->flag.ctag_cfi = 1;
        p_sys_key->ctag_cfi  = p_ctc_key->ctag_cfi;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_SVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->svlan);
        p_sys_key->flag.svlan = 1;
        p_sys_key->svlan = p_ctc_key->svlan;
        p_sys_key->svlan_mask = p_ctc_key->svlan_mask & 0xFFF;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_STAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cos, 0x7);
        p_sys_key->flag.stag_cos = 1;
        p_sys_key->stag_cos = p_ctc_key->stag_cos;
        p_sys_key->stag_cos_mask = (p_ctc_key->stag_cos_mask) & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_STAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cfi, 0x1);
        p_sys_key->flag.stag_cfi = 1;
        p_sys_key->stag_cfi  = p_ctc_key->stag_cfi;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_L2_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l2_type, 0xF);
        p_sys_key->flag.l2_type = 1;
        p_sys_key->l2_type = p_ctc_key->l2_type;
        p_sys_key->l2_type_mask = (p_ctc_key->l2_type_mask) & 0xF;
    }

    if (p_ctc_key->flag & CTC_ACL_IPV4_KEY_FLAG_L3_TYPE)
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l3_type, 0xF);
        p_sys_key->flag.l3_type = 1;
        p_sys_key->l3_type = p_ctc_key->l3_type;
        p_sys_key->l3_type_mask = (p_ctc_key->l3_type_mask) & 0xF;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_DSCP))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->dscp, 0x3F);
        p_sys_key->flag.dscp = 1;
        p_sys_key->dscp = p_ctc_key->dscp;
        p_sys_key->dscp_mask = (p_ctc_key->dscp_mask) & 0x3F;
    }
    else if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_PRECEDENCE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->dscp, 7);

        p_sys_key->flag.dscp = 1;
        p_sys_key->dscp = (p_ctc_key->dscp) << 3;
        p_sys_key->dscp_mask = (p_ctc_key->dscp_mask & 0x7) << 3;
    }

    /* tcp flag */
    if (p_sys_key->flag.is_tcp
        && p_sys_key->is_tcp
        && CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_TCP_FLAGS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->tcp_flags_match_any, 1);
        CTC_MAX_VALUE_CHECK(p_ctc_key->tcp_flags, 0x3F);

        CTC_ERROR_RETURN(_sys_humber_acl_lkup_tcp_flag(p_ctc_key->tcp_flags_match_any,
                                                       p_ctc_key->tcp_flags, &idx_target, &idx_lkup));

        if (SYS_ACL_TCP_FLAG_NUM != idx_lkup)
        { /* lkup success */
            acl_master->tcp_flag[idx_lkup].ref++;

            idx_valid = idx_lkup;

        }
        else if ((SYS_ACL_TCP_FLAG_NUM == idx_lkup) && (acl_master->tcp_flag_free_cnt > 0))
        {
            _sys_humber_acl_add_tcp_flag(p_ctc_key->tcp_flags_match_any,
                                         p_ctc_key->tcp_flags, idx_target);
            idx_valid = idx_target;

        }
        else
        {
            ret = CTC_E_ACL_TCP_FLAG_EXHAUSTED;
            goto error;
        }

        p_sys_key->flag.l4info_mapped = 1;
        p_sys_key->l4info_mapped |= 1 << (idx_valid + 8);
        p_sys_key->l4info_mapped_mask |= 1 << (idx_valid + 8);

        p_sys_key->flag.tcp_flags = 1;
        p_sys_key->tcp_flags_idx = idx_valid;
    }

    return CTC_E_NONE;


error:
    return ret;
}

static int32
_sys_humber_acl_map_mpls_key(ctc_acl_mpls_key_t* p_ctc_key,
                             sys_acl_mpls_key_t* p_sys_key)
{
    uint32 flag = 0;

    CTC_PTR_VALID_CHECK(p_ctc_key);
    CTC_PTR_VALID_CHECK(p_sys_key);

    SYS_ACL_DBG_FUNC();

    flag = p_ctc_key->flag;

    /* src cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->cos, 0x7);
        p_sys_key->flag.cos = 1;
        p_sys_key->cos = p_ctc_key->cos;
        p_sys_key->cos_mask = p_ctc_key->cos_mask & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MAC_DA))
    {
        p_sys_key->flag.mac_da = 1;
        sal_memcpy(p_sys_key->mac_da, p_ctc_key->mac_da, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_da_mask, p_ctc_key->mac_da_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MAC_SA))
    {
        p_sys_key->flag.mac_sa = 1;
        sal_memcpy(p_sys_key->mac_sa, p_ctc_key->mac_sa, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_sa_mask, p_ctc_key->mac_sa_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_CVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->cvlan);
        p_sys_key->flag.cvlan = 1;
        p_sys_key->cvlan = p_ctc_key->cvlan;
        p_sys_key->cvlan_mask = p_ctc_key->cvlan_mask & 0xFFF;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_CTAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cos, 0x7);
        p_sys_key->flag.ctag_cos = 1;
        p_sys_key->ctag_cos = p_ctc_key->ctag_cos;
        p_sys_key->ctag_cos_mask = (p_ctc_key->ctag_cos_mask) & 0x7;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_CTAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cfi, 0x1);
        p_sys_key->flag.ctag_cfi = 1;
        p_sys_key->ctag_cfi  = p_ctc_key->ctag_cfi;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_SVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->svlan);
        p_sys_key->flag.svlan = 1;
        p_sys_key->svlan = p_ctc_key->svlan;
        p_sys_key->svlan_mask = p_ctc_key->svlan_mask & 0xFFF;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_STAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cos, 0x7);
        p_sys_key->flag.stag_cos = 1;
        p_sys_key->stag_cos = p_ctc_key->stag_cos;
        p_sys_key->stag_cos_mask = (p_ctc_key->stag_cos_mask) & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_STAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cfi, 0x1);
        p_sys_key->flag.stag_cfi = 1;
        p_sys_key->stag_cfi  = p_ctc_key->stag_cfi;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_ROUTED_PACKET))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->routed_packet, 1);
        p_sys_key->flag.routed_packet = 1;
        p_sys_key->routed_packet = p_ctc_key->routed_packet;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_L2_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l2_type, 0xF);
        p_sys_key->flag.l2_type = 1;
        p_sys_key->l2_type = p_ctc_key->l2_type;
        p_sys_key->l2_type_mask = (p_ctc_key->l2_type_mask) & 0xF;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL0))
    {
        /* no check */
        p_sys_key->flag.mpls_label0 = 1;
        p_sys_key->mpls_label0 = p_ctc_key->mpls_label0;
        p_sys_key->mpls_label0_mask = p_ctc_key->mpls_label0_mask;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL1))
    {
        /* no check */
        p_sys_key->flag.mpls_label1 = 1;
        p_sys_key->mpls_label1 = p_ctc_key->mpls_label1;
        p_sys_key->mpls_label1_mask = p_ctc_key->mpls_label1_mask;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL2))
    {
        /* no check */
        p_sys_key->flag.mpls_label2 = 1;
        p_sys_key->mpls_label2 = p_ctc_key->mpls_label2;
        p_sys_key->mpls_label2_mask = p_ctc_key->mpls_label2_mask;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL3))
    {
        /* no check */
        p_sys_key->flag.mpls_label3 = 1;
        p_sys_key->mpls_label3 = p_ctc_key->mpls_label3;
        p_sys_key->mpls_label3_mask = p_ctc_key->mpls_label3_mask;

    }

    return CTC_E_NONE;
}

static int32
_sys_humber_acl_map_ipv6_key(ctc_acl_ipv6_key_t* p_ctc_key,
                             sys_acl_ipv6_key_t* p_sys_key)
{
    uint32 flag = 0;
    uint32 sub_flag = 0;
    int32  ret = 0;
    uint8  idx_lkup = 0;
    uint8  idx_target = 0;
    uint8  idx_valid = 0;

    uint16 port0 = 0;
    uint16 port1 = 0;
    uint8 op_dest = 0;           /* loop 2 times, for saving code.*/
    uint8 l4_src_port_use_range = 0;  /* src port use range */
    uint8 l4_dst_port_use_range = 0;  /* dst port use range */

    CTC_PTR_VALID_CHECK(p_ctc_key);
    CTC_PTR_VALID_CHECK(p_sys_key);

    SYS_ACL_DBG_FUNC();

    flag = p_ctc_key->flag;
    sub_flag = p_ctc_key->sub_flag;

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_DSCP)
        && CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_PRECEDENCE))
    {
        return CTC_E_ACL_FLAG_COLLISION;
    }

    /* src cos */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV4_KEY_FLAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->cos, 0x7);
        p_sys_key->flag.cos = 1;
        p_sys_key->cos = p_ctc_key->cos;
        p_sys_key->cos_mask = p_ctc_key->cos_mask & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_IP_DA))
    {
        p_sys_key->flag.ip_da = 1;
        sal_memcpy(p_sys_key->ip_da, p_ctc_key->ip_da, sizeof(ipv6_addr_t));
        sal_memcpy(p_sys_key->ip_da_mask, p_ctc_key->ip_da_mask, sizeof(ipv6_addr_t));

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_IP_SA))
    {
        p_sys_key->flag.ip_sa = 1;
        sal_memcpy(p_sys_key->ip_sa, p_ctc_key->ip_sa, sizeof(ipv6_addr_t));
        sal_memcpy(p_sys_key->ip_sa_mask, p_ctc_key->ip_sa_mask, sizeof(ipv6_addr_t));

    }

    /* layer 4 information */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_L4_PROTOCOL))
    {

        if ((0xFF == p_ctc_key->l4_protocol_mask)
            &&(SYS_ACL_IPV6_ICMP == p_ctc_key->l4_protocol))        /* ICMP */
        {
            p_sys_key->flag.l4info_mapped = 1;
            p_sys_key->l4info_mapped = p_ctc_key->l4_protocol;
            p_sys_key->l4info_mapped_mask = p_ctc_key->l4_protocol_mask;

            p_sys_key->flag.is_tcp = 1;
            p_sys_key->is_tcp = 0;

            p_sys_key->flag.is_udp = 1;
            p_sys_key->is_udp = 0;

            /* icmp type */
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV6_KEY_SUB_FLAG_ICMP_TYPE))
            {
                p_sys_key->flag.l4_src_port = 1;
                p_sys_key->l4_src_port = (p_ctc_key->icmp_type << 8) & 0xFF00;
                p_sys_key->l4_src_port_mask |= (p_ctc_key->icmp_type_mask << 8) & 0xFF00;

            }

            /* icmp code */
            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV6_KEY_SUB_FLAG_ICMP_CODE))
            {
                p_sys_key->flag.l4_src_port = 1;
                p_sys_key->l4_src_port |= p_ctc_key->icmp_code & 0x00FF;
                p_sys_key->l4_src_port_mask |= p_ctc_key->icmp_code_mask & 0x00FF;

            }
        }
        else if ((0xFF == p_ctc_key->l4_protocol_mask)
                &&((SYS_ACL_TCP == p_ctc_key->l4_protocol)
                 || (SYS_ACL_UDP == p_ctc_key->l4_protocol)))  /* TCP or UDP */
        {
            if (SYS_ACL_TCP == p_ctc_key->l4_protocol)
            { /* TCP */
                p_sys_key->flag.is_tcp = 1;
                p_sys_key->is_tcp = 1;

            }
            else
            { /* UDP */
                p_sys_key->flag.is_udp = 1;
                p_sys_key->is_udp = 1;

            }

            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV6_KEY_SUB_FLAG_L4_SRC_PORT))
            {
                if (p_ctc_key->l4_src_port_use_mask)
                {  /*  use mask.
                    *  l4_src_port_0 is data.
                    *  l4_src_port_1 is mask.
                    */
                    p_sys_key->flag.l4_src_port = 1;
                    p_sys_key->l4_src_port = p_ctc_key->l4_src_port_0;
                    p_sys_key->l4_src_port_mask = p_ctc_key->l4_src_port_1;

                }
                else
                {  /*  use range.
                    *  l4_src_port_0 is min.
                    *  l4_src_port_1 is max.
                    */
                    if (p_ctc_key->l4_src_port_0 >= p_ctc_key->l4_src_port_1)
                    {
                        return CTC_E_INVALID_PARAM;
                    }

                    l4_src_port_use_range = 1;

                }
            }

            if (CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV6_KEY_SUB_FLAG_L4_DST_PORT))
            {
                if (p_ctc_key->l4_dst_port_use_mask)
                {  /*  use mask.
                    *  l4_dst_port_0 is data.
                    *  l4_dst_port_1 is mask.
                    */
                    p_sys_key->flag.l4_dst_port = 1;
                    p_sys_key->l4_dst_port = p_ctc_key->l4_dst_port_0;
                    p_sys_key->l4_dst_port_mask = p_ctc_key->l4_dst_port_1;

                }
                else
                {  /*  use range.
                    *  l4_dst_port_0 is min.
                    *  l4_dst_port_1 is max.
                    */

                    if (p_ctc_key->l4_dst_port_0 >= p_ctc_key->l4_dst_port_1)
                    {
                        return CTC_E_INVALID_PARAM;
                    }

                    l4_dst_port_use_range = 1;
                }
            }

            /* op_dest, use loop to save code.
             * op_dest = 0 -->src_port
             * op_dest = 1 -->dst_port
             */
            for (op_dest = 0; op_dest <= 1; op_dest++)
            {
                if (0 == op_dest)
                {
                    if (!l4_src_port_use_range)
                    {
                        continue;
                    }

                    port0 = p_ctc_key->l4_src_port_0;
                    port1 = p_ctc_key->l4_src_port_1;
                }
                else
                {
                    if (!l4_dst_port_use_range)
                    {
                        continue;
                    }

                    port0 = p_ctc_key->l4_dst_port_0;
                    port1 = p_ctc_key->l4_dst_port_1;
                }

                p_sys_key->flag.l4info_mapped = 1;

                CTC_ERROR_RETURN(_sys_humber_acl_lkup_l4_port_range(port0,
                                                                    port1, op_dest, &idx_target, &idx_lkup));

                if (SYS_ACL_L4_PORT_NUM != idx_lkup)
                { /* lkup success */
                    acl_master->l4_port[idx_lkup].ref++;

                    idx_valid = idx_lkup;

                }
                else if ((SYS_ACL_L4_PORT_NUM == idx_lkup) && (acl_master->l4_port_free_cnt > 0))
                {
                    CTC_ERROR_RETURN(_sys_humber_acl_add_l4_port_range
                                         (port0, port1, op_dest, idx_target));

                    idx_valid = idx_target;
                }
                else
                {
                    ret = CTC_E_ACL_L4_PORT_RANGE_EXHAUSTED;
                    goto error;
                }

                p_sys_key->l4info_mapped |= 1 << idx_valid;
                p_sys_key->l4info_mapped_mask |= 1 << idx_valid;

                if (0 == op_dest)
                {
                    p_sys_key->flag.l4_src_port_range = 1;
                    p_sys_key->l4_src_port_range_idx = idx_valid;
                }
                else
                {
                    p_sys_key->flag.l4_dst_port_range = 1;
                    p_sys_key->l4_dst_port_range_idx = idx_valid;
                }
            }
        }
        else    /* other layer 4 protocol type */
        {
            p_sys_key->flag.l4info_mapped = 1;
            p_sys_key->l4info_mapped = p_ctc_key->l4_protocol;
            p_sys_key->l4info_mapped_mask = p_ctc_key->l4_protocol_mask;

            p_sys_key->flag.is_tcp = 1;
            p_sys_key->is_tcp = 0;

            p_sys_key->flag.is_udp = 1;
            p_sys_key->is_udp = 0;

        }
    }

    /* ip fragment */
    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_IP_FRAG))
    {
        p_sys_key->flag.frag_info = 1;

        CTC_MAX_VALUE_CHECK(p_ctc_key->ip_frag, CTC_IP_FRAG_MAX - 1);

        switch (p_ctc_key->ip_frag)
        {
        case CTC_IP_FRAG_NON:
            /* Non fragmented */
            p_sys_key->frag_info = 0;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_FIRST:
            /* Fragmented, and first fragment */
            p_sys_key->frag_info = 1;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_NON_OR_FIRST:
            /* Non fragmented OR Fragmented and first fragment */
            p_sys_key->frag_info = 0;
            p_sys_key->frag_info_mask = 2;     /* mask frag_info as 0x */
            break;

        case CTC_IP_FRAG_SMALL:
            /* Small fragment */
            p_sys_key->frag_info = 2;
            p_sys_key->frag_info_mask = 3;
            break;

        case CTC_IP_FRAG_NOT_FIRST:
            /* Not first fragment (Fragmented of cause) */
            p_sys_key->frag_info = 3;
            p_sys_key->frag_info_mask = 3;
            break;

        default:
            return CTC_E_INVALID_PARAM;

        }
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_DSCP))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->dscp, 0x3F);
        p_sys_key->flag.dscp = 1;
        p_sys_key->dscp = p_ctc_key->dscp;
        p_sys_key->dscp_mask = p_ctc_key->dscp_mask;
    }
    else if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_PRECEDENCE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->dscp, 7);

        p_sys_key->flag.dscp = 1;
        p_sys_key->dscp = (p_ctc_key->dscp) << 3;
        p_sys_key->dscp_mask = (p_ctc_key->dscp_mask & 0x7) << 3;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_IP_OPTION))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ip_option, 1);
        p_sys_key->flag.ip_option = 1;
        p_sys_key->ip_option = p_ctc_key->ip_option;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_ROUTED_PACKET))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->routed_packet, 1);
        p_sys_key->flag.routed_packet = 1;
        p_sys_key->routed_packet = p_ctc_key->routed_packet;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_FLOW_LABEL))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->flow_label, 0xFFFFF);
        p_sys_key->flag.flow_label = 1;
        p_sys_key->flow_label = p_ctc_key->flow_label;
        p_sys_key->flow_label_mask = p_ctc_key->flow_label_mask & 0xFFFFF;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_MAC_DA))
    {
        p_sys_key->flag.mac_da = 1;
        sal_memcpy(p_sys_key->mac_da, p_ctc_key->mac_da, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_da_mask, p_ctc_key->mac_da_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_MAC_SA))
    {
        p_sys_key->flag.mac_sa = 1;
        sal_memcpy(p_sys_key->mac_sa, p_ctc_key->mac_sa, CTC_ETH_ADDR_LEN);
        sal_memcpy(p_sys_key->mac_sa_mask, p_ctc_key->mac_sa_mask, CTC_ETH_ADDR_LEN);
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_CVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->cvlan);
        p_sys_key->flag.cvlan = 1;
        p_sys_key->cvlan = p_ctc_key->cvlan;
        p_sys_key->cvlan_mask = p_ctc_key->cvlan_mask & 0xFFF;

    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_CTAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cos, 0x7);
        p_sys_key->flag.ctag_cos = 1;
        p_sys_key->ctag_cos = p_ctc_key->ctag_cos;
        p_sys_key->ctag_cos_mask = (p_ctc_key->ctag_cos_mask) & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_CTAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->ctag_cfi, 0x1);
        p_sys_key->flag.ctag_cfi = 1;
        p_sys_key->ctag_cfi   = p_ctc_key->ctag_cfi;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_SVLAN))
    {
        CTC_VLAN_RANGE_CHECK(p_ctc_key->svlan);
        p_sys_key->flag.svlan = 1;
        p_sys_key->svlan = p_ctc_key->svlan;
        p_sys_key->svlan_mask = p_ctc_key->svlan_mask & 0xFFF;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_STAG_COS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cos, 0x7);
        p_sys_key->flag.stag_cos = 1;
        p_sys_key->stag_cos = p_ctc_key->stag_cos;
        p_sys_key->stag_cos_mask = (p_ctc_key->stag_cos_mask) & 0x7;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_STAG_CFI))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->stag_cfi, 0x1);
        p_sys_key->flag.stag_cfi = 1;
        p_sys_key->stag_cfi = p_ctc_key->stag_cfi;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_ETH_TYPE))
    {
        p_sys_key->flag.eth_type = 1;
        p_sys_key->eth_type = p_ctc_key->eth_type;
        p_sys_key->eth_type_mask = p_ctc_key->eth_type_mask;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_L2_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l2_type, 0xF);
        p_sys_key->flag.l2_type = 1;
        p_sys_key->l2_type = p_ctc_key->l2_type;
        p_sys_key->l2_type_mask = p_ctc_key->l2_type_mask;
    }

    if (CTC_FLAG_ISSET(flag, CTC_ACL_IPV6_KEY_FLAG_L3_TYPE))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->l3_type, 0xF);
        p_sys_key->flag.l3_type = 1;
        p_sys_key->l3_type = p_ctc_key->l3_type;
        p_sys_key->l3_type_mask = p_ctc_key->l3_type_mask;
    }

    if (p_sys_key->flag.is_tcp
        && p_sys_key->is_tcp
        && CTC_FLAG_ISSET(sub_flag, CTC_ACL_IPV6_KEY_SUB_FLAG_TCP_FLAGS))
    {
        CTC_MAX_VALUE_CHECK(p_ctc_key->tcp_flags_match_any, 1);
        CTC_MAX_VALUE_CHECK(p_ctc_key->tcp_flags, 0x3F);

        CTC_ERROR_RETURN(_sys_humber_acl_lkup_tcp_flag(p_ctc_key->tcp_flags_match_any,
                                                       p_ctc_key->tcp_flags, &idx_target, &idx_lkup));

        if (SYS_ACL_TCP_FLAG_NUM != idx_lkup)
        { /* lkup success */
            acl_master->tcp_flag[idx_lkup].ref++;

            idx_valid = idx_lkup;
        }
        else if ((SYS_ACL_TCP_FLAG_NUM == idx_lkup) && (acl_master->tcp_flag_free_cnt > 0))
        {
            _sys_humber_acl_add_tcp_flag(p_ctc_key->tcp_flags_match_any,
                                         p_ctc_key->tcp_flags, idx_target);
            idx_valid = idx_target;

        }
        else
        {
            ret = CTC_E_ACL_TCP_FLAG_EXHAUSTED;
            goto error;
        }

        p_sys_key->flag.l4info_mapped = 1;
        p_sys_key->l4info_mapped |= 1 << (idx_valid + 8);
        p_sys_key->l4info_mapped_mask |= 1 << (idx_valid + 8);

        p_sys_key->flag.tcp_flags  = 1;
        p_sys_key->tcp_flags_idx = idx_valid;

    }

    if (p_ctc_key->flag & CTC_ACL_IPV6_KEY_FLAG_EXT_HDR)
    {
        p_sys_key->flag.ext_hdr = 1;
        p_sys_key->ext_hdr = p_ctc_key->ext_hdr;
        p_sys_key->ext_hdr_mask = p_ctc_key->ext_hdr;
    }

    return CTC_E_NONE;

error:
    return ret;
}

/*
 *get sys key based on ctc key
 */
static int32
_sys_humber_acl_map_key(ctc_acl_key_t* p_ctc_key,
                        sys_acl_key_t* p_sys_key)
{
    CTC_PTR_VALID_CHECK(p_ctc_key);
    CTC_PTR_VALID_CHECK(p_sys_key);

    SYS_ACL_DBG_FUNC();

    p_sys_key->type = p_ctc_key->type;

    switch (p_sys_key->type)
    {
    case CTC_ACL_KEY_MAC:
        CTC_ERROR_RETURN(
            _sys_humber_acl_map_mac_key(&p_ctc_key->u.mac_key, &p_sys_key->key_info.mac_key));
        break;

    case CTC_ACL_KEY_IPV4:
        CTC_ERROR_RETURN(
            _sys_humber_acl_map_ipv4_key(&p_ctc_key->u.ipv4_key, &p_sys_key->key_info.ipv4_key));
        break;

    case CTC_ACL_KEY_MPLS:
        CTC_ERROR_RETURN(
            _sys_humber_acl_map_mpls_key(&p_ctc_key->u.mpls_key, &p_sys_key->key_info.mpls_key));
        break;

    case CTC_ACL_KEY_IPV6:
        CTC_ERROR_RETURN(
            _sys_humber_acl_map_ipv6_key(&p_ctc_key->u.ipv6_key, &p_sys_key->key_info.ipv6_key));
        break;

    default:
        return CTC_E_ACL_INVALID_KEY_TYPE;
    }

    return CTC_E_NONE;
}

/*
 *check if group info is new. if new return true
 */
static bool
_sys_humber_acl_is_group_info_new(sys_acl_group_info_t* sys, ctc_acl_group_info_t* ctc)
{
    uint8  equal = 0;
    switch(ctc->type)
    {
    case  CTC_ACL_GROUP_TYPE_GLOBAL:
        equal = 1;
        break;
    case  CTC_ACL_GROUP_TYPE_VLAN_CLASS:
        equal = (ctc->un.vlan_class_id == sys->un.vlan_class_id);
        break;
    case  CTC_ACL_GROUP_TYPE_PORT_CLASS:
        equal = (ctc->un.port_class_id == sys->un.port_class_id);
        break;
    case  CTC_ACL_GROUP_TYPE_SERVICE_ACL:
        equal = (ctc->un.service_id == sys->un.service_id);
        break;
    default:
        return CTC_E_INVALID_PARAM;

    }

    if ((ctc->dir != sys->dir) || !equal)
    {
        return TRUE;
    }

    return FALSE;
}

/*
 *get sys group info based on ctc group info
 */
static int32
_sys_humber_acl_map_group_info(sys_acl_group_info_t* sys, ctc_acl_group_info_t* ctc, uint8 is_create)
{
    if (is_create)
    {
        sys->type = ctc->type;
        if (ctc->type == CTC_ACL_GROUP_TYPE_PORT_CLASS)
        { /* install one chip */
            sys->lchip  =  ctc->lchip;
        }
        else
        { /* install two chips */
            sys->lchip = 0xFF; /* 0xFF means install to 2 chips */
        }
    }

    sys->dir = ctc->dir;
    sal_memcpy(&sys->un, &ctc->un, sizeof(uint8) * CTC_ACL_PORT_BITMAP_IN_BYTE);

    return CTC_E_NONE;
}

/*
 *get ctc group info based on sys group info
 */
static int32
_sys_humber_acl_unmap_group_info(ctc_acl_group_info_t* ctc, sys_acl_group_info_t* sys)
{
    ctc->dir = sys->dir;
    ctc->type = sys->type;
    ctc->lchip = sys->lchip;

    sal_memcpy(&ctc->un, &sys->un, sizeof(uint8) * CTC_ACL_PORT_BITMAP_IN_BYTE);

    return CTC_E_NONE;
}

#define SYS_ACL_INVALID_INDEX -1

/*
 * worst is best
 */
static int32
_sys_humber_acl_get_block_index(sys_acl_block_t* pb,
                                   uint16* block_index)
{
    int32   bottom_idx = 0;
    int32   target_idx = 0;
    int32   last_entry_idx = 0;
    int32   idx;
    int32   prev_null_idx = FPA_INVALID_INDEX;
    int32   next_null_idx = FPA_INVALID_INDEX;
    int32   dir = 0;
    uint32  move_num = 0;

    CTC_PTR_VALID_CHECK(pb);
    CTC_PTR_VALID_CHECK(block_index);
    SYS_ACL_DBG_FUNC();

    if (pb->free_count < 1)
    {
        return CTC_E_NO_RESOURCE;
    }

    if (pb->entry_count == pb->free_count) /* no entry exist, use middle index */
    {
        target_idx = pb->entry_count >> 1;
    }
    else
    {
        uint16 zero_cnt = pb->zero_count;

        bottom_idx = pb->entry_count - 1;

        /*get last not null index*/
        last_entry_idx = FPA_INVALID_INDEX;

        /* get last not null index( the last entry whose prio != 0).
         * get bottom_idx, the first prio==0 entry's previous entry.
         */
        for (idx = bottom_idx; (idx >= 0) ; idx--)
        {
            if(pb->entries[idx])
            {
                if (zero_cnt)
                {
                    zero_cnt --;
                    if(0 == zero_cnt)
                    {
                        bottom_idx = idx - 1;
                    }
                }
                else
                {
                    last_entry_idx = idx;
                    break;
                }
            }

        }

        if (last_entry_idx == bottom_idx)  /* last entry touch bound */
        {

            target_idx = last_entry_idx + 1;

            /* search prev NULL entry  */
            for (idx = target_idx; idx >= 0; idx--)
            {
                if (pb->entries[idx] == NULL)
                {
                    prev_null_idx = idx;
                    break;
                }
            }

            /* search next NULL entry  */
            for (idx = target_idx +1; idx < pb->entry_count ; idx++)
            {
                if (pb->entries[idx] == NULL)
                {
                    next_null_idx = idx;
                    break;
                }
            }

            _sys_humber_acl_get_shift_direction(prev_null_idx, target_idx, next_null_idx, &dir);

            if (dir == 1)
            {
                CTC_ERROR_RETURN(_sys_humber_acl_entry_shift_down(pb, (target_idx),next_null_idx));
                move_num = (next_null_idx - target_idx -1 );
            }
            else
            {
                target_idx--;
                CTC_ERROR_RETURN(_sys_humber_acl_entry_shift_up(pb, target_idx, prev_null_idx));
                move_num = (target_idx - prev_null_idx);
            }

            if (DO_REORDER(move_num, pb->entry_count))
            {
                CTC_ERROR_RETURN(_sys_humber_acl_reorder(pb, pb->entry_count - 1, 0));
            }
        }
        else /*use last index*/
        {
            target_idx = last_entry_idx + 1;
        }
    }

    *block_index = target_idx;

    return CTC_E_NONE;

}

/*
 * remove accessory property
 */
static int32
_sys_humber_acl_remove_accessory_property(sys_acl_entry_t* pe)
{
    uint8 lchip = 0, lchip_num = 0;
    sys_acl_redirect_t acl_redirect;
    sys_acl_redirect_t* p_acl_redirect = 0;
    sys_humber_opf_t opf;

    sal_memset(&acl_redirect, 0, sizeof(acl_redirect));
    sal_memset(&opf, 0, sizeof(opf));

    lchip_num = sys_humber_get_local_chip_num();

    CTC_PTR_VALID_CHECK(pe);

    /* remove tcp flags and port range */
    switch (pe->key.type)
    {
    case CTC_ACL_KEY_MAC:
    case CTC_ACL_KEY_MPLS:
        break;

    case CTC_ACL_KEY_IPV4:
        if (pe->key.key_info.ipv4_key.flag.tcp_flags)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_tcp_flag(pe->key.key_info.ipv4_key.tcp_flags_idx));
        }

        if (pe->key.key_info.ipv4_key.flag.l4_src_port_range)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_l4_port_range(pe->key.key_info.ipv4_key.l4_src_port_range_idx));
        }

        if (pe->key.key_info.ipv4_key.flag.l4_dst_port_range)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_l4_port_range(pe->key.key_info.ipv4_key.l4_dst_port_range_idx));
        }

        break;

    case CTC_ACL_KEY_IPV6:
        if (pe->key.key_info.ipv6_key.flag.tcp_flags)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_tcp_flag(pe->key.key_info.ipv6_key.tcp_flags_idx));
        }

        if (pe->key.key_info.ipv6_key.flag.l4_src_port_range)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_l4_port_range(pe->key.key_info.ipv6_key.l4_src_port_range_idx));
        }

        if (pe->key.key_info.ipv6_key.flag.l4_dst_port_range)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_remove_l4_port_range(pe->key.key_info.ipv6_key.l4_dst_port_range_idx));
        }

        break;

    case CTC_ACL_KEY_HASH_IPV4:
    case CTC_ACL_KEY_HASH_MAC:
        return CTC_E_FEATURE_NOT_SUPPORT;

    default:
        return CTC_E_INVALID_PARAM;

    }

    /* remove statsptr */
    if (pe->action.flag.stats)
    {
        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            sys_humber_stats_delete_statsptr(lchip, 1, pe->action.stats_ptr[lchip]);
            sys_humber_stats_reset_flow_stats(lchip, pe->action.stats_ptr[lchip]);
        }
    }

    /* free acl_fwd_ptr, It's no need to free sram */
    if (pe->action.flag.redirect)
    {
        acl_redirect.nhid = pe->action.nh_id;
        p_acl_redirect = ctc_hash_lookup(acl_master->p_sys_acl_redirect_hash, &acl_redirect);
        if (p_acl_redirect)
        {
            p_acl_redirect->ref--;

            if (p_acl_redirect->ref == 0)
            {
                opf.pool_type = OPF_ACL_FWD_SRAM;
                opf.pool_index = 0;
                CTC_ERROR_RETURN(sys_humber_opf_free_offset(&opf, 1, pe->action.ds_fwd_offset));

                ctc_hash_remove(acl_master->p_sys_acl_redirect_hash, p_acl_redirect);
                mem_free(p_acl_redirect);
            }
        }
        else
        {
            return CTC_E_ACLQOS_INVALID_ACTION;
        }
    }

    return CTC_E_NONE;
}

/*
 *remove acl entry from software table
 */
int32
_sys_humber_acl_remove_entry(uint32 entry_id)
{
    uint32 eid = 0;
    uint32 block_index     = 0;
    uint8               asic_type;
    sys_acl_entry_t* pe = NULL;
    sys_acl_group_t* pg = NULL;
    sys_acl_block_t* pb = NULL;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(entry_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", entry_id);

    /* check raw entry */
    eid = (entry_id);
    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get sys group */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    asic_type = acl_master->asic_type[pe->key.type];

    pb = &acl_master->block[asic_type][pg->group_info.block_id];

/* consider roll back later */
    /* remove software entry must after uninstall */
    /* if installed, remove hw. else need not return error.*/
    if (SYS_ACL_ENTRY_FLAG_INSTALLED == pe->flag)
    {
        return CTC_E_ACL_ENTRY_INSTALLED;
    }

    /* remove from block */
    block_index = pe->block_index;
    pb->entries[block_index] = NULL;

    /* remove from group */
    ctc_slist_delete_node(pg->entry_list, &(pe->head));

    /* remove from hash */
    ctc_hash_remove(acl_master->entry, pe);

    /* remove accessory property */
    CTC_ERROR_RETURN(_sys_humber_acl_remove_accessory_property(pe));

    /* memory free */
    mem_free(pe);

    /* free_count++ */
    (pb->free_count)++;

    (pg->entry_count)--;

    return CTC_E_NONE;
}

/*
 *add acl entry to software table
 */
static int32
_sys_humber_acl_add_entry(uint32 group_id,
                             uint32 eid,
                             ctc_acl_key_t* key,
                             ctc_acl_action_t* action)
{
    uint16 block_index = 0;
    int32  ret = 0;
    uint8               asic_type;
    sys_acl_entry_t* pe_lkup = NULL;
    sys_acl_entry_t* pe_new = NULL;

    sys_acl_group_t* pg = NULL;
    sys_acl_block_t* pb = NULL;

    /* check sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe_lkup);
    if (pe_lkup)
    {
        return CTC_E_ACL_ENTRY_EXIST;
    }

    /* check sys group */
    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);


    asic_type = acl_master->asic_type[key->type];

    pb = &acl_master->block[asic_type][pg->group_info.block_id];
    /* malloc sys entry */
    SYS_ACL_MALLOC(pe_new, sizeof(sys_acl_entry_t));
    if (!pe_new)
    {
        return CTC_E_NO_MEMORY;
    }

    /* build sys entry .1 */
    pe_new->group = pg;
    pe_new->entry_id = eid;
    pe_new->priority = CTC_ACL_ENTRY_PRIORITY_DEFAULT;
    pe_new->head.next = NULL;

    /* build sys entry .2 */
    CTC_ERROR_GOTO(_sys_humber_acl_map_stats_action(action, &pe_new->action, 0, NULL), ret, cleanup);
    CTC_ERROR_GOTO(_sys_humber_acl_map_action(action, &pe_new->action), ret, cleanup);
    CTC_ERROR_GOTO(_sys_humber_acl_map_key(key, &pe_new->key), ret, cleanup);

    /* get block index, based on priority. */
    CTC_ERROR_GOTO(_sys_humber_acl_get_block_index(pb, &block_index), ret, cleanup);
    pe_new->block_index = block_index;

    /* add to hash */
    ctc_hash_insert(acl_master->entry, pe_new);

    /* add to group */
    ctc_slist_add_head(pg->entry_list, &(pe_new->head));

    /* add to block */
    pb->entries[block_index] = pe_new;

    /* mark flag */
    pe_new->flag = SYS_ACL_ENTRY_FLAG_UNINSTALLED;

    /* free_count-- */
    (pb->free_count)--;

    (pg->entry_count)++;

    return CTC_E_NONE;

cleanup:
    _sys_humber_acl_remove_accessory_property(pe_new);
    mem_free(pe_new);
    return ret;

}

static int32
_sys_humber_acl_init_ctl()
{
    uint8 chip_id = 0;
    uint8 local_chip_num = 0;
    uint32 cmd = 0;
    uint32 ds_fwd_ptr_base = 0;

    ds_fwd_ptr_base = acl_master->acl_fwd_base >> 8;
    local_chip_num = sys_humber_get_local_chip_num();

    for (chip_id = 0; chip_id < local_chip_num; chip_id++)
    {
        /* write IPE_ACL_QOS_CTL */
        cmd = DRV_IOW(IOC_REG, IPE_ACL_QOS_CTL, IPE_ACL_QOS_CTL_DS_FWD_PTR_BASE);
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd, &ds_fwd_ptr_base));
    }

    return CTC_E_NONE;

}

#define ___________ACL_OUTER_FUNCTION________________________
#define _0_ACL_DUMP_

/*
 *show acl action
 */
static int32
_sys_humber_acl_show_action(sys_acl_action_t* pa)
{
    CTC_PTR_VALID_CHECK(pa);

    if (pa->flag.discard)
    {
        SYS_ACL_DBG_DUMP("  =================== deny ====================");
    }
    else
    {
        SYS_ACL_DBG_DUMP("  =================== permit ====================");
    }

    /* next line */
    SYS_ACL_DBG_DUMP("\n");

    if (pa->flag.deny_bridge)
    {
        SYS_ACL_DBG_DUMP("  deny-bridge,");
    }

    if (pa->flag.deny_learning)
    {
        SYS_ACL_DBG_DUMP("  deny-learning,");
    }

    if (pa->flag.deny_route)
    {
        SYS_ACL_DBG_DUMP("  deny-route,");
    }

    if ((pa->flag.deny_bridge) +
        (pa->flag.deny_learning) +
        (pa->flag.deny_route))
    {
        SYS_ACL_DBG_DUMP("\n");
    }

    if (pa->flag.stats)
    {
        SYS_ACL_DBG_DUMP("  stats,");
    }

    if (pa->flag.copy_to_cpu)
    {
        SYS_ACL_DBG_DUMP("  copy-to-cpu,");
    }

    if ((pa->flag.stats) +
        (pa->flag.copy_to_cpu))
    {
        SYS_ACL_DBG_DUMP("\n");
    }

    if (pa->flag.trust)
    {
        SYS_ACL_DBG_DUMP("  trust %u,", pa->trust);
    }

    if (pa->flag.priority_and_color)
    {
        SYS_ACL_DBG_DUMP("  priority %u color %u,", pa->priority, pa->color);
    }

    if ((pa->flag.trust) +
        (pa->flag.priority_and_color))
    {
        SYS_ACL_DBG_DUMP("\n");
    }

    if (pa->flag.random_log)
    {
        SYS_ACL_DBG_DUMP("  random-log id %u  log-percent %u,", pa->acl_log_id, pa->random_threshold_shift);
    }

    if (pa->flag.redirect)
    {
        SYS_ACL_DBG_DUMP("  redirect nhid %u,", pa->nh_id);
    }

    if ((pa->flag.random_log) +
        (pa->flag.redirect))
    {
        SYS_ACL_DBG_DUMP("\n");
    }

    if (pa->flag.micro_flow_policer)
    {
        SYS_ACL_DBG_DUMP("  micro policer-id %u,", pa->micro_policer_id);
    }


    SYS_ACL_DBG_DUMP("\n");

    return CTC_E_NONE;
}

/*
 *show mac entry
 */
static int32
_sys_humber_acl_show_mac_entry(sys_acl_entry_t* p_entry)
{
    sys_acl_action_t*   pa;
    sys_acl_mac_key_t*  pk;

    CTC_PTR_VALID_CHECK(p_entry);

    pa = &p_entry->action;
    pk = &p_entry->key.key_info.mac_key;

    DUMP_L2_0(pk)
    DUMP_L2_TYPE(pk)
    DUMP_L2_ETH_TYPE(pk)
    DUMP_L3_TYPE(pk)

    CTC_ERROR_RETURN(_sys_humber_acl_show_action(pa));

    return CTC_E_NONE;
}

/*
 *show ipv4 entry
 */
static int32
_sys_humber_acl_show_ipv4_entry(sys_acl_entry_t* p_entry)
{
    sys_acl_action_t* pa;
    sys_acl_ipv4_key_t* pk;

    CTC_PTR_VALID_CHECK(p_entry);

    pa = &p_entry->action;
    pk = &p_entry->key.key_info.ipv4_key;

    DUMP_L2_0(pk)
    DUMP_L2_TYPE(pk)
    DUMP_L3_TYPE(pk)
    DUMP_L3(pk)
    DUMP_IPV4(pk)

    CTC_ERROR_RETURN(_sys_humber_acl_show_action(pa));

    return CTC_E_NONE;
}

/*
 *show ipv6 entry
 */
static int32
_sys_humber_acl_show_ipv6_entry(sys_acl_entry_t* p_entry)
{
    sys_acl_action_t* pa;
    sys_acl_ipv6_key_t* pk;

    CTC_PTR_VALID_CHECK(p_entry);

    pa = &p_entry->action;
    pk = &p_entry->key.key_info.ipv6_key;

    DUMP_L2_0(pk)
    DUMP_L2_TYPE(pk)
    DUMP_L2_ETH_TYPE(pk)
    DUMP_L3_TYPE(pk)
    DUMP_L3(pk)
    DUMP_IPV6_UNIQUE(pk)

    CTC_ERROR_RETURN(_sys_humber_acl_show_action(pa));

    return CTC_E_NONE;
}

/*
 *show mpls entry
 */
static int32
_sys_humber_acl_show_mpls_entry(sys_acl_entry_t* p_entry)
{
    sys_acl_action_t* pa;
    sys_acl_mpls_key_t* pk;

    CTC_PTR_VALID_CHECK(p_entry);

    pa = &p_entry->action;
    pk = &p_entry->key.key_info.mpls_key;

    DUMP_L2_0(pk)
    DUMP_L2_TYPE(pk)
    DUMP_MPLS_UNIQUE(pk)

    CTC_ERROR_RETURN(_sys_humber_acl_show_action(pa));

    return CTC_E_NONE;
}

/*
 *show acl entry to a specific entry with specific key type
 */
static int32
_sys_humber_acl_show_entry(sys_acl_entry_t* pe, uint16* p_cnt, ctc_acl_key_type_t key_type, uint8 detail)
{
    char* type[4] = {"Mac ", "Ipv4", "MPLS", "Ipv6"};
    char** pp_temp  = NULL;
    sys_acl_group_t* pg;

    CTC_PTR_VALID_CHECK(pe);

    pp_temp = type;

    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    if ((SYS_ACL_ALL_KEY != key_type)
        && (pe->key.type != key_type))
    {
        return CTC_E_NONE;
    }

    ACL_PRINT_COUNT(*p_cnt);
    (*p_cnt)++;

    SYS_ACL_DBG_DUMP("eid=%-4u gid=%-4u index=%-3d HW=%3s e_prio=%-4u g_prio=%-2u (%s)\n",
                     pe->entry_id, pg->group_id, pe->block_index, (pe->flag) ? "yes" : "no ",
                     pe->priority, pg->group_info.block_id, type[pe->key.type]);

    if (detail)
    {
        switch (pe->key.type)
        {
        case CTC_ACL_KEY_MAC:
            _sys_humber_acl_show_mac_entry(pe);
            break;

        case CTC_ACL_KEY_IPV4:
            _sys_humber_acl_show_ipv4_entry(pe);
            break;

        case CTC_ACL_KEY_IPV6:
            _sys_humber_acl_show_ipv6_entry(pe);
            break;

        case CTC_ACL_KEY_MPLS:
            _sys_humber_acl_show_mpls_entry(pe);
            break;

        default: /* won't hit, just shut warning*/
            break;

        }
    }

    return CTC_E_NONE;
}

/*
 *show acl entriy by entry id
 */
static int32
_sys_humber_acl_show_entry_by_entry_id(uint32 eid, ctc_acl_key_type_t key_type, uint8 detail)
{
    sys_acl_entry_t* pe;
    uint16 count      = 1;

    _sys_humber_acl_get_sys_entry_by_eid(eid, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    ACL_PRINT_ENTRY_ROW(eid);

    CTC_ERROR_RETURN(_sys_humber_acl_show_entry(pe, &count, key_type, detail));

    return CTC_E_NONE;
}

/*
 *show acl entries in a group with specific key type
 */
static int32
_sys_humber_acl_show_entry_in_group(sys_acl_group_t* pg, uint16* p_cnt, ctc_acl_key_type_t key_type, uint8 detail)
{
    struct ctc_slistnode_s* pe;

    CTC_PTR_VALID_CHECK(pg);

    CTC_SLIST_LOOP(pg->entry_list, pe)
    {
        _sys_humber_acl_show_entry((sys_acl_entry_t*)pe, p_cnt, key_type, detail);
    }

    return CTC_E_NONE;
}

/*
 *show acl entries by group id with specific key type
 */
static int32
_sys_humber_acl_show_entry_by_group_id(uint32 gid, ctc_acl_key_type_t key_type, uint8 detail)
{
    uint16 count = 1;
    sys_acl_group_t* pg = NULL;

    _sys_humber_acl_get_sys_group_by_gid(gid, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    ACL_PRINT_GROUP_ROW(gid);

    CTC_ERROR_RETURN(_sys_humber_acl_show_entry_in_group(pg, &count, key_type, detail));

    return CTC_E_NONE;

}

/*
 *show acl entries in a block with specific key type
 */
static int32
_sys_humber_acl_show_entry_in_block(sys_acl_block_t* pb, uint16* p_cnt, ctc_acl_key_type_t key_type, uint8 detail)
{
    sys_acl_entry_t* pe;
    uint16 block_idx;

    CTC_PTR_VALID_CHECK(pb);
    CTC_PTR_VALID_CHECK(p_cnt);

    for (block_idx = 0; block_idx < pb->entry_count; block_idx++)
    {
        pe = pb->entries[block_idx];

        if (pe)
        {
            CTC_ERROR_RETURN(_sys_humber_acl_show_entry(pe, p_cnt, key_type, detail));
        }
    }

    return CTC_E_NONE;
}

/*
 *show acl entries by group priority
 */
static int32
_sys_humber_acl_show_entry_by_priority(uint8 prio, ctc_acl_key_type_t key_type, uint8 detail)
{

    uint16              count = 1;
    uint8               asic_type;
    sys_acl_block_t* pb;

    SYS_ACL_CHECK_GROUP_PRIO(prio);

    ACL_PRINT_PRIO_ROW(prio);

    for (asic_type = 0; asic_type < acl_master->asic_type_num; asic_type++)
    {
        pb = &acl_master->block[asic_type][prio];
        if (pb->free_count != pb->entry_count) /*not empty*/
        {

            CTC_ERROR_RETURN(_sys_humber_acl_show_entry_in_block
                                 (pb, &count, key_type, detail));

        }
    }

    return CTC_E_NONE;
}

/*
 *callback for hash traverse. traverse group hash table, show each group's entry.
 *
 */
static int32
_sys_humber_acl_hash_traverse_cb_show_entry(sys_acl_group_t* pg, _acl_cb_para_t* cb_para)
{
    CTC_PTR_VALID_CHECK(cb_para);
    CTC_ERROR_RETURN(_sys_humber_acl_show_entry_in_group(pg, &(cb_para->count), cb_para->key_type, cb_para->detail));
    return CTC_E_NONE;
}

/*
 *callback for hash traverse. traverse group hash table, show each group's group id.
 *
 */
static int32
_sys_humber_acl_hash_traverse_cb_show_gid(sys_acl_group_t* pg, _acl_cb_para_t* cb_para)
{
    CTC_PTR_VALID_CHECK(cb_para);
    cb_para->count++;
    SYS_ACL_DBG_DUMP("No.%03u  :  gid %u \n", cb_para->count, pg->group_id);
    return CTC_E_NONE;
}

/*
 *show all acl entries separate by priority or group
 *sort_type = 0: by priority
 *sort_type = 1: by group
 */
static int32
_sys_humber_acl_show_entry_all(uint8 sort_type, ctc_acl_key_type_t key_type, uint8 detail)
{
    uint8               prio;
    uint8               asic_type;
    uint16              count = 1;
    _acl_cb_para_t      para;
    sys_acl_block_t*    pb;

    sal_memset(&para, 0, sizeof(_acl_cb_para_t));
    para.detail = detail;
    para.key_type = key_type;

    ACL_PRINT_ALL_SORT_SEP_BY_ROW(sort_type);

    if (sort_type == 0) /* separate by priority */
    {

        for (prio = 0; prio < SYS_ACL_BLOCK_NUM_MAX; prio++)
        {
            for (asic_type = 0; asic_type < acl_master->asic_type_num; asic_type++)
            {
                pb = &acl_master->block[asic_type][prio];
                CTC_ERROR_RETURN(_sys_humber_acl_show_entry_in_block
                                     (pb, &count, key_type, detail));

            }
        }
    }
    else /* separate by group */
    {

        ctc_hash_traverse_through(acl_master->group,
                                  (hash_traversal_fn)_sys_humber_acl_hash_traverse_cb_show_entry, &para);
    }

    return CTC_E_NONE;
}

int32
sys_humber_acl_show_status(void)
{
    uint8 idx;
    uint8 mac_type;
    uint8 ipv4_type;
    uint8 ipv6_type;

    uint16              block_idx = 0;
    uint8               prio  = 0;
    uint8               asic_type = 0;
    sys_acl_block_t*    pb = NULL;
    sys_acl_entry_t*    pe = NULL;
    uint16              mac_cnt = 0;
    uint16              ipv4_cnt = 0;
    uint16              ipv6_cnt = 0;
    uint16              mpls_cnt = 0;

    _acl_cb_para_t      para;

    SYS_ACL_INIT_CHECK();

    mac_type  = acl_master->asic_type[CTC_ACL_KEY_MAC];
    ipv4_type = acl_master->asic_type[CTC_ACL_KEY_IPV4];
    ipv6_type = acl_master->asic_type[CTC_ACL_KEY_IPV6];

    SYS_ACL_DBG_DUMP("================= ACL Overall Status ==================\n");

    SYS_ACL_DBG_DUMP("#1 Priority Status\n");
    SYS_ACL_DBG_DUMP("-------------------------------------------------------\n");
    if (mac_type != ipv4_type)
    {
        SYS_ACL_DBG_DUMP("%-12s  %-12s  %-12s  %-12s\n", "Prio\\Type", "Mac", "Ipv4/MPLS", "Ipv6");

        for (idx = 0; idx < 4; idx++)
        {
            SYS_ACL_DBG_DUMP("%-4s %d  %6d of %d  %6d of %d  %6d of %d\n",
                             "Prio", idx,
                             acl_master->block[mac_type][idx].entry_count - acl_master->block[mac_type][idx].free_count,
                             acl_master->block[mac_type][idx].entry_count,
                             acl_master->block[ipv4_type][idx].entry_count - acl_master->block[ipv4_type][idx].free_count,
                             acl_master->block[ipv4_type][idx].entry_count,
                             acl_master->block[ipv6_type][idx].entry_count - acl_master->block[ipv6_type][idx].free_count,
                             acl_master->block[ipv6_type][idx].entry_count);
        }
    }
    else
    {
        SYS_ACL_DBG_DUMP("%-12s  %-12s       %-12s\n", "Prio\\Type", "Mac/Ipv4/MPLS", "Ipv6");

        for (idx = 0; idx < 4; idx++)
        {
            SYS_ACL_DBG_DUMP("%-4s %d      %6d of %d    %6d of %d\n",
                             "Prio", idx,
                             acl_master->block[mac_type][idx].entry_count - acl_master->block[mac_type][idx].free_count,
                             acl_master->block[mac_type][idx].entry_count,
                             acl_master->block[ipv6_type][idx].entry_count - acl_master->block[ipv6_type][idx].free_count,
                             acl_master->block[ipv6_type][idx].entry_count);
        }
    }

    for (prio = 0; prio < SYS_ACL_BLOCK_NUM_MAX; prio++)
    {
        for (asic_type = 0; asic_type < acl_master->asic_type_num; asic_type++)
        {
            pb = &acl_master->block[asic_type][prio];

            for (block_idx = 0; block_idx < pb->entry_count; block_idx++)
            {
                pe = pb->entries[block_idx];
                if (pe)
                {
                    switch (pe->key.type)
                    {
                    case CTC_ACL_KEY_MAC:
                        mac_cnt++;
                        break;

                    case CTC_ACL_KEY_IPV4:
                        ipv4_cnt++;
                        break;

                    case CTC_ACL_KEY_IPV6:
                        ipv6_cnt++;
                        break;

                    case CTC_ACL_KEY_MPLS:
                        mpls_cnt++;
                        break;

                    default: /* won't hit, just shut warning*/
                        break;

                    }
                }
            }
        }
    }

    SYS_ACL_DBG_DUMP("\n");
    SYS_ACL_DBG_DUMP("#2 Entry Status\n");
    SYS_ACL_DBG_DUMP("-------------------------------------------------------\n");
    SYS_ACL_DBG_DUMP("%-6s entries: %u \n", "Mac", mac_cnt);
    SYS_ACL_DBG_DUMP("%-6s entries: %u \n", "MPLS", mpls_cnt);
    SYS_ACL_DBG_DUMP("%-6s entries: %u \n", "Ipv4", ipv4_cnt);
    SYS_ACL_DBG_DUMP("%-6s entries: %u \n", "Ipv6", ipv6_cnt);

    SYS_ACL_DBG_DUMP("\n");
    SYS_ACL_DBG_DUMP("#3 Group Status\n");
    SYS_ACL_DBG_DUMP("-------------------------------------------------------\n");

    sal_memset(&para, 0, sizeof(_acl_cb_para_t));
    para.count = 0;
    ctc_hash_traverse_through(acl_master->group,
                              (hash_traversal_fn)_sys_humber_acl_hash_traverse_cb_show_gid, &para);
    SYS_ACL_DBG_DUMP("Totol group count :%u \n", para.count);

    return CTC_E_NONE;

}

/** show acl entry **
 * type = 0 :by all
 * type = 1 :by entry
 * type = 2 :by group
 * type = 3 :by priority
 */
int32
sys_humber_acl_show_entry(uint8 type, uint32 param, ctc_acl_key_type_t key_type, uint8 detail)
{

    /* CTC_ACL_KEY_NUM represents all type*/
    CTC_MAX_VALUE_CHECK(type, CTC_ACL_KEY_NUM);

    switch (type)
    {
    case 0:
        CTC_ERROR_RETURN(_sys_humber_acl_show_entry_all(param, key_type, detail));
        SYS_ACL_DBG_DUMP("\n");
        break;

    case 1:
        CTC_ERROR_RETURN(_sys_humber_acl_show_entry_by_entry_id(param, key_type, detail));
        SYS_ACL_DBG_DUMP("\n");
        break;

    case 2:
        CTC_ERROR_RETURN(_sys_humber_acl_show_entry_by_group_id(param, key_type, detail));
        SYS_ACL_DBG_DUMP("\n");
        break;

    case 3:
        CTC_ERROR_RETURN(_sys_humber_acl_show_entry_by_priority(param, key_type, detail));
        SYS_ACL_DBG_DUMP("\n");
        break;

    default:
        return CTC_E_INVALID_PARAM;

    }

    return CTC_E_NONE;
}

#define _1_ACL_GROUP_

/*
 *create an empty acl group.
 */
int32
sys_humber_acl_create_group(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    int32  ret = 0;
    sys_acl_group_t* pg_new = NULL;
    sys_acl_group_t* pg = NULL;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);
    /* check if priority bigger than biggest priority */

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: group_id: %u \n", group_id);
    /*
    *  group_id is uint32.
    *  #1 check block_num from p_acl_master. precedence cannot bigger than block_num.
    *  #2 malloc a sys_acl_group_t, add to hash based on group_id.
    */

    /* check if group exist */
    _sys_humber_acl_get_sys_group_by_gid(group_id,  &pg);
    if (pg)
    {
        return CTC_E_ACL_GROUP_EXIST;
    }

    /* malloc an empty group */

    SYS_ACL_MALLOC(pg_new, sizeof(sys_acl_group_t));
    if (!pg_new)
    {
        return CTC_E_NO_MEMORY;
    }

    if(!group_info)
    {
        ret = CTC_E_INVALID_PTR;
        goto cleanup;
    }
    CTC_ERROR_GOTO(_sys_humber_acl_check_group_info(group_info, group_info->type, 1), ret ,cleanup);
    CTC_ERROR_GOTO(_sys_humber_acl_map_group_info(&pg_new->group_info, group_info, 1), ret ,cleanup);
    pg_new->group_id = group_id;
//    pg_new->group_info.block_id = priority;
    pg_new->entry_list = ctc_slist_new();
    pg_new->prio_max = 0;
    pg_new->prio_min = 0;

    /* add to hash */
    ctc_hash_insert(acl_master->group, pg_new);

    return CTC_E_NONE;
cleanup:
    mem_free(pg_new);
    return ret;
}

/*
 *destroy an empty group.
 */
int32
sys_humber_acl_destroy_group(uint32 group_id)
{
    sys_acl_group_t* pg = NULL;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: group_id: %u \n", group_id);

    /*
     * #1 check if entry all removed.
     * #2 remove from hash. free sys_acl_group_t.
     */

    /* check if group exist */
    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    /* check if all entry removed */
    if (0 != pg->entry_list->count)
    {
        return CTC_E_ACL_GROUP_NOT_EMPTY;
    }

    ctc_hash_remove(acl_master->group, pg);

    /* free slist */
    ctc_slist_free(pg->entry_list);

    /* free pg */
    mem_free(pg);

    return CTC_E_NONE;
}

/*
 *install a group (empty or NOT) to hardware table
 */
int32
sys_humber_acl_install_group(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    sys_acl_group_t* pg = NULL;
    uint8               install_all = 0;
    struct ctc_slistnode_s* pe;

    uint32 eid = 0;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);
    CTC_PTR_VALID_CHECK(group_info);
    SYS_ACL_CHECK_GROUP_TYPE(group_info->type);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: gid %u -- type %u \n", group_id, group_info->type);

    /*
     * #1 get the group_node by group_id: ctc_hash_lookup.
     * #2 compare the group_info of group_node to group_info
     * #3 get the single-list belongs to the group_node.
     * #4 traverse the single-list, install all not installed entry to hw. until find a first installed entry.
     * #5 if list empty, install nothing.
     * #6 add those flag=add to hw.
          delete those flag=del from hw.
          skip those flag=installed.
     */

    /* get group node */

    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    /* check if group installed */
    if (CTC_FLAG_ISSET(pg->flag, SYS_ACL_GROUP_INSTALLED))
    {
        /* if group_info is new, rewrite all entries */
        if (_sys_humber_acl_is_group_info_new(&pg->group_info, group_info))
        {
            install_all = 1;
        }
        else
        {
            install_all = 0;
        }
    }
    else
    {

        install_all = 1;
    }

    if (install_all)
    {   /* traverse all install */
        CTC_ERROR_RETURN(_sys_humber_acl_check_group_info(group_info,pg->group_info.type, 0));

        /* set group installed before install entry. after check group */
        CTC_SET_FLAG(pg->flag, SYS_ACL_GROUP_INSTALLED);

        CTC_ERROR_RETURN(_sys_humber_acl_map_group_info(&pg->group_info, group_info, 0));

        CTC_SLIST_LOOP(pg->entry_list, pe)
        {
            eid = ((sys_acl_entry_t*)pe)->entry_id;
            _sys_humber_acl_install_entry(eid, SYS_ACL_ENTRY_OP_FLAG_ADD, 0);
        }
    }
    else
    { /* traverse, stop at first installed entry.*/
        if (pg->entry_list)
        {
            for (pe = pg->entry_list->head;
                 pe && (((sys_acl_entry_t*)pe)->flag != SYS_ACL_ENTRY_FLAG_INSTALLED);
                 pe = pe->next)
            {
                eid = ((sys_acl_entry_t*)pe)->entry_id;
                _sys_humber_acl_install_entry(eid, SYS_ACL_ENTRY_OP_FLAG_ADD, 0);
            }
        }
    }

    return CTC_E_NONE;
}

/*
 *uninstall a group (empty or NOT) from hardware table
 */
int32
sys_humber_acl_uninstall_group(uint32 group_id)
{
    sys_acl_group_t* pg = NULL;
    struct ctc_slistnode_s* pe = NULL;

    uint32 eid = 0;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: gid %u \n", group_id);

    /* get group node */
    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    CTC_SLIST_LOOP(pg->entry_list, pe)
    {
        eid = ((sys_acl_entry_t*)pe)->entry_id;
        CTC_ERROR_RETURN(_sys_humber_acl_install_entry(eid, SYS_ACL_ENTRY_OP_FLAG_DELETE, 0));
    }

#if 0 /* uninstall group not affect the flag = INSTALLED*/
    CTC_UNSET_FLAG(pg->flag, SYS_ACL_GROUP_INSTALLED);
#endif

    return CTC_E_NONE;
}

/*
 *get group info by group id
 */
int32
sys_humber_acl_get_group_info(uint32 group_id, ctc_acl_group_info_t* group_info)
{
    sys_acl_group_info_t* pinfo = NULL;  /* sys group info */
    sys_acl_group_t* pg = NULL;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);
    CTC_PTR_VALID_CHECK(group_info);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: gid: %u \n", group_id);

    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    /* uninstalled group has no group info. */
    if (SYS_ACL_GROUP_INSTALLED != pg->flag)
    {
        return CTC_E_ACL_GROUP_NOT_INSTALLED;
    }

    pinfo = &(pg->group_info);

    /* get ctc group info based on pinfo (sys group info) */
    CTC_ERROR_RETURN(_sys_humber_acl_unmap_group_info(group_info, pinfo));

    return CTC_E_NONE;
}

#define _2_ACL_ENTRY_

/*
 *clear stats of one acl entry
 */
int32
sys_humber_acl_clear_stats(uint32 entry_id)
{
    sys_acl_entry_t* pe = NULL;
    sys_acl_group_t* pg = NULL;
    uint8 lchip;
    uint8 lchip_num;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(entry_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", entry_id);

    /* get sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(entry_id, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get sys group */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    if (pe->action.flag.stats)
    {
        if (pg->group_info.lchip == 0xFF)
        {
            lchip = 0;
            lchip_num = acl_master->lchip_num;
        }
        else
        {
            lchip = pg->group_info.lchip; /* 0 or 1 */
            lchip_num = lchip + 1;
        }

        for (; lchip < lchip_num; lchip++)
        {
            CTC_ERROR_RETURN(sys_humber_stats_reset_flow_stats(lchip, pe->action.stats_ptr[lchip]));
        }
    }

    return CTC_E_NONE;

}

/*
 *get stats from one acl entry
 */
int32
sys_humber_acl_get_stats(uint32 entry_id,  ctc_stats_basic_t* stats)
{

    uint8 lchip;
    uint8 lchip_num;
    sys_acl_entry_t* pe = NULL;
    sys_acl_group_t* pg = NULL;
    ctc_stats_basic_t stats_result;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(entry_id);
    CTC_PTR_VALID_CHECK(stats);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", entry_id);

    sal_memset(stats, 0, sizeof(ctc_stats_basic_t));
    /* get sys entry */
    _sys_humber_acl_get_sys_entry_by_eid(entry_id, &pe);
    if (!pe)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* get lchip */
    pg = pe->group;
    if (!pg)
    {
        return CTC_E_ACL_GROUP_UNEXIST;
    }

    if (pg->group_info.lchip == 0xFF)
    { /* if installed 2 chips, get stats from both chips.*/
        lchip = 0;
        lchip_num = acl_master->lchip_num;
    }
    else
    {
        lchip = pg->group_info.lchip;
        lchip_num = lchip + 1;
    }

    if (pe->action.flag.stats)
    {
        for (; lchip < lchip_num; lchip++)
        {
            CTC_ERROR_RETURN(sys_humber_stats_get_flow_stats(lchip, pe->action.stats_ptr[lchip], &stats_result));
            stats->packet_count += stats_result.packet_count;
            stats->byte_count += stats_result.byte_count;
        }
    }
    else
    {
        return CTC_E_ACL_GET_STATS_FAILED;
    }

    return CTC_E_NONE;

}

/*
 *install entry to hardware table
 */
int32
sys_humber_acl_install_entry(uint32 eid)
{

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(eid);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", eid);

    CTC_ERROR_RETURN(_sys_humber_acl_install_entry(eid, SYS_ACL_ENTRY_OP_FLAG_ADD, 1));
    return CTC_E_NONE;
}

/*
 *uninstall entry from hardware table
 */
int32
sys_humber_acl_uninstall_entry(uint32 eid)
{
    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(eid);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", eid);

    CTC_ERROR_RETURN(_sys_humber_acl_install_entry(eid, SYS_ACL_ENTRY_OP_FLAG_DELETE, 1));
    return CTC_E_NONE;
}

/*
    ctc_acl_key_t key;
    ctc_acl_action_t action;
    uint32 entry_id;
    uint32 priority;
    uint8 op_flag;
*/

/*
    CTC_ACL_ENTRY_OP_SW_HW: add software and hardware. done
    CTC_ACL_ENTRY_OP_SW   : add software.              done.
    CTC_ACL_ENTRY_OP_HW   : revert hardware. (sw must existed)
    CTC_ACL_ENTRY_OP_MARK : just mark
*/
int32
sys_humber_acl_add_entry(uint32 group_id, ctc_acl_entry_t* acl_entry)
{
    /*
    ctc_acl_key_t* p_key_in = NULL;
    ctc_acl_action_t* p_action_in = NULL;
*/

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);
    CTC_PTR_VALID_CHECK(acl_entry);
    SYS_ACL_CHECK_ENTRY_ID(acl_entry->entry_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u -- key_type %u\n",
                      acl_entry->entry_id, acl_entry->key.type);

    CTC_ERROR_RETURN(_sys_humber_acl_add_entry(group_id, acl_entry->entry_id,
                                                  &acl_entry->key, &acl_entry->action));

    return CTC_E_NONE;
}

/*
 *remove entry from software table
 */
int32
sys_humber_acl_remove_entry(uint32 entry_id)
{

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(entry_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u \n", entry_id);

    CTC_ERROR_RETURN(_sys_humber_acl_remove_entry(entry_id));

    return CTC_E_NONE;
}

/*
 *remove all entries from a group
 */
int32
sys_humber_acl_remove_all_entry(uint32 group_id)
{
    sys_acl_group_t* pg = NULL;
    struct ctc_slistnode_s* pe = NULL;
    struct ctc_slistnode_s* pe_next = NULL;
    uint32 eid = 0;

    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_GROUP_ID(group_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: gid %u \n", group_id);

    /* get group node */
    _sys_humber_acl_get_sys_group_by_gid(group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    /* check if all uninstalled */
    CTC_SLIST_LOOP(pg->entry_list, pe)
    {
        if (SYS_ACL_ENTRY_FLAG_INSTALLED ==
            ((sys_acl_entry_t*)pe)->flag)
        {
            return CTC_E_ACL_ENTRY_INSTALLED;
        }
    }

    CTC_SLIST_LOOP_DEL(pg->entry_list, pe, pe_next)
    {
        eid = ((sys_acl_entry_t*)pe)->entry_id;
        /* no stop to keep consitent */
        _sys_humber_acl_remove_entry(eid);
    }

    return CTC_E_NONE;
}

/*
 *set priority of entry
 */
int32
sys_humber_acl_set_entry_priority(uint32 entry_id, uint32 priority)
{
    SYS_ACL_INIT_CHECK();
    SYS_ACL_CHECK_ENTRY_ID(entry_id);
    SYS_ACL_CHECK_ENTRY_PRIO(priority);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: eid %u -- prio %u \n", entry_id, priority);

    CTC_ERROR_RETURN(_sys_humber_acl_set_entry_prio(entry_id, priority));
    return CTC_E_NONE;
}

/*
 *get multiple entries
 */
int32
sys_humber_acl_get_multi_entry(ctc_acl_query_t* query)
{
    uint32  entry_index = 0;
    sys_acl_group_t* pg = NULL;
    struct ctc_slistnode_s* pe = NULL;

    SYS_ACL_INIT_CHECK();
    CTC_PTR_VALID_CHECK(query);
    SYS_ACL_CHECK_GROUP_ID(query->group_id);

    SYS_ACL_DBG_FUNC();
    SYS_ACL_DBG_PARAM("  %% PARAM: gid %u -- entry_sz %u\n", query->group_id, query->entry_size);

    /* get group node */
    _sys_humber_acl_get_sys_group_by_gid(query->group_id, &pg);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg);

    if (query->entry_size == 0)
    {
        query->entry_count = pg->entry_count;
    }
    else
    {
        uint32* p_array = query->entry_array;
        CTC_PTR_VALID_CHECK(p_array);

        if (query->entry_size > pg->entry_count)
        {
            query->entry_size = pg->entry_count;
        }

        CTC_SLIST_LOOP(pg->entry_list, pe)
        {
            *p_array = ((sys_acl_entry_t*)pe)->entry_id;
            p_array++;
            entry_index++;
            if (entry_index == query->entry_size)
            {
                break;
            }
        }

        query->entry_count = query->entry_size;

    }

    return CTC_E_NONE;
}

/* update acl action*/
int32
sys_humber_acl_update_action(uint32 entry_id, ctc_acl_action_t* action)
{
    sys_acl_entry_t*     pe_old = NULL;
    sys_acl_action_t     new_action;

    SYS_ACL_INIT_CHECK();
    CTC_PTR_VALID_CHECK(action);
    SYS_ACL_DBG_FUNC();

    /* lookup */
    _sys_humber_acl_get_sys_entry_by_eid(entry_id, &pe_old);
    if (!pe_old)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    sal_memset(&new_action, 0, sizeof(sys_acl_action_t));

    CTC_ERROR_RETURN(_sys_humber_acl_map_stats_action(action, &new_action, 1, &(pe_old->action)));

    CTC_ERROR_RETURN(_sys_humber_acl_map_action(action, &new_action));

    CTC_ERROR_RETURN(_sys_humber_acl_remove_redirect_action(&(pe_old->action)));

    sal_memcpy(&(pe_old->action), &new_action, sizeof(sys_acl_action_t));

    if (pe_old->flag == SYS_ACL_ENTRY_FLAG_INSTALLED)
    {
        CTC_ERROR_RETURN(_sys_humber_acl_add_hw(entry_id));
    }

    return CTC_E_NONE;
}

int32
sys_humber_acl_copy_entry(ctc_acl_copy_entry_t* copy_entry)
{
    sys_acl_entry_t*   pe_src  = NULL;

    sys_acl_entry_t*   pe_dst  = NULL;
    sys_acl_block_t*   pb_dst   = NULL;
    sys_acl_group_t*   pg_dst   = NULL;
    uint16             block_index = 0;
    uint8              asic_type = 0;
    int32              ret  = 0;
    uint8              index;
    uint8              lchip;

    SYS_ACL_INIT_CHECK();
    CTC_PTR_VALID_CHECK(copy_entry);
    SYS_ACL_CHECK_ENTRY_ID(copy_entry->entry_id);
    SYS_ACL_DBG_FUNC();

    /* check src entry */
    _sys_humber_acl_get_sys_entry_by_eid(copy_entry->src_entry_id, &pe_src);
    if (!pe_src)
    {
        return CTC_E_ACL_ENTRY_UNEXIST;
    }

    /* check dst entry */
    _sys_humber_acl_get_sys_entry_by_eid(copy_entry->dst_entry_id, &pe_dst);
    if (pe_dst)
    {
        return CTC_E_ACL_ENTRY_EXIST;
    }

    _sys_humber_acl_get_sys_group_by_gid(copy_entry->dst_group_id, &pg_dst);
    SYS_ACL_CHECK_GROUP_UNEXIST(pg_dst);

    SYS_ACL_MALLOC(pe_dst, sizeof(sys_acl_entry_t));
    if (!pe_dst)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memcpy(&(pe_dst->key), &(pe_src->key), sizeof(sys_acl_key_t));
    sal_memcpy(&(pe_dst->action), &(pe_src->action), sizeof(sys_acl_action_t));

    /* flag count ++ */
    switch (pe_dst->key.type)
    {
    case CTC_ACL_KEY_MAC:
    case CTC_ACL_KEY_MPLS:
        break;

    case CTC_ACL_KEY_IPV4:
        if (pe_dst->key.key_info.ipv4_key.flag.tcp_flags)
        {
            index = pe_dst->key.key_info.ipv4_key.tcp_flags_idx;
            acl_master->tcp_flag[index].ref++;
        }

        if (pe_dst->key.key_info.ipv4_key.flag.l4_src_port_range)
        {
            index = pe_dst->key.key_info.ipv4_key.l4_src_port_range_idx;
            acl_master->l4_port[index].ref++;
        }

        if (pe_dst->key.key_info.ipv4_key.flag.l4_dst_port_range)
        {
            index = pe_dst->key.key_info.ipv4_key.l4_dst_port_range_idx;
            acl_master->l4_port[index].ref++;
        }

        break;

    case CTC_ACL_KEY_IPV6:
        if (pe_dst->key.key_info.ipv6_key.flag.tcp_flags)
        {
            index = pe_dst->key.key_info.ipv6_key.tcp_flags_idx;
            acl_master->tcp_flag[index].ref++;
        }

        if (pe_dst->key.key_info.ipv6_key.flag.l4_src_port_range)
        {
            index = pe_dst->key.key_info.ipv6_key.l4_src_port_range_idx;
            acl_master->l4_port[index].ref++;
        }

        if (pe_dst->key.key_info.ipv6_key.flag.l4_dst_port_range)
        {
            index = pe_dst->key.key_info.ipv6_key.l4_dst_port_range_idx;
            acl_master->l4_port[index].ref++;
        }

        break;

        case CTC_ACL_KEY_HASH_IPV4:
        case CTC_ACL_KEY_HASH_MAC:
            ret = CTC_E_FEATURE_NOT_SUPPORT;
            goto cleanup;

        default:
            ret = CTC_E_INVALID_PARAM;
            goto cleanup;

    }

    if (pe_dst->action.flag.stats) /* alloc new stats ptr */
    {
        for (lchip = 0; lchip < acl_master->lchip_num; lchip++)
        {
            CTC_ERROR_GOTO(sys_humber_stats_create_statsptr
                               (lchip, 1, &pe_dst->action.stats_ptr[lchip]), ret, cleanup);
        }
    }

    pe_dst->entry_id = copy_entry->dst_entry_id;
    pe_dst->group = pg_dst;
    pe_dst->priority = CTC_ACL_ENTRY_PRIORITY_DEFAULT;
    pe_dst->head.next = NULL;

    asic_type = acl_master->asic_type[pe_dst->key.type];
    pb_dst = &acl_master->block[asic_type][pg_dst->group_info.block_id];
    if (NULL == pb_dst)
    {
        ret = CTC_E_INVALID_PTR;
        goto cleanup;

    }

    /* get block index, based on priority */
    CTC_ERROR_GOTO(_sys_humber_acl_get_block_index(pb_dst, &block_index), ret, cleanup);
    pe_dst->block_index  = block_index;

    /* add to hash */
    ctc_hash_insert(acl_master->entry, pe_dst);

    /* add to group */
    ctc_slist_add_head(pg_dst->entry_list, &(pe_dst->head));

    /* add to block */
    pb_dst->entries[block_index] = pe_dst;

    /* mark flag */
    pe_dst->flag = SYS_ACL_ENTRY_FLAG_UNINSTALLED;

    /* free_count-- */
    (pb_dst->free_count)--;

    (pg_dst->entry_count)++;

    return CTC_E_NONE;

cleanup:
    mem_free(pe_dst);
    return ret;

}

/*
 *init acl module
 */
int32
sys_humber_acl_init(ctc_acl_global_cfg_t* acl_global_cfg)
{

    /*
    *   #1 get key_size. decide use which mode.
    *   #2 160 bit mode, only label can be used. In this mode, only one block is support.
    *      This mode, we support port_group, vlan_group;
    *   #3 320 bit mode, port 0-51 use port_bitmap, port 52-55 use label, one for each.
    *      This mode, we support port_bitmap, vlan_mask. Vlan_group/Vlan_id cannot be support.
    *   above is the old way.

    *   The new way:
    *   #1 160 mode, ristrict to one block? Discuss later. This mode supports
    *      port_bitmap, global, SeviceACL
    *   #2 320 mode, leave the dicission of using port_bitmap or label to users.
    *      This mode supports port_bitmap, global, port_group, vlan_group, service ACL.

    */

    uint8               block_idx;
    uint8               asic_type;
    uint8               mac_type;
    uint8               ipv4_type;
    uint8               ipv6_type;

    uint32              size;
    sys_acl_block_t*    pb[SYS_ACL_ASIC_TYPE_MAX];
    uint32              pb_sz[SYS_ACL_ASIC_TYPE_MAX][SYS_ACL_BLOCK_NUM_MAX] = {{0}};
    uint8               pb_num[SYS_ACL_ASIC_TYPE_MAX] = {0};
    uint32 glb_met_entry_num = 0, local_met_dsfwd_entry_num = 0;
    uint32 fwd_opf_start_offset = 0;
    sys_humber_opf_t opf;

    /* check init */
    if (acl_master)
    { /* already init */
        return CTC_E_NONE;
    }

    CTC_PTR_VALID_CHECK(acl_global_cfg);
    sal_memset(&opf, 0, sizeof(opf));

    /* malloc master */
    acl_master = (sys_acl_master_t*)mem_malloc(MEM_ACL_MODULE, sizeof(sys_acl_master_t));
    if (NULL == acl_master)
    {
        return CTC_E_NO_MEMORY;
    }

    /* zero master */
    sal_memset(acl_master, 0, sizeof(sys_acl_master_t));

    /* init asic_key_type */
    acl_master->asic_type_num = SYS_ACL_ASIC_KEY_TYPE_NUM;
    mac_type  = 0;
    ipv4_type = acl_master->asic_type_num - 2;
    ipv6_type = acl_master->asic_type_num - 1;

    acl_master->asic_type[CTC_ACL_KEY_MAC]    = mac_type;
    acl_master->asic_type[CTC_ACL_KEY_IPV4]   = ipv4_type;
    acl_master->asic_type[CTC_ACL_KEY_MPLS]   = ipv4_type;
    acl_master->asic_type[CTC_ACL_KEY_IPV6]   = ipv6_type;

    /* set pointer to block: 2d array */
    pb[mac_type]    = acl_master->block[mac_type];
    pb[ipv4_type]   = acl_master->block[ipv4_type];
    pb[ipv6_type]   = acl_master->block[ipv6_type];


    /* init max priority */
    acl_master->max_entry_priority = SYS_ACL_MAX_ENTRY_PRIORITY;

    /* init block_sz */
    /* default merge mac ip key */
    pb_sz[mac_type][0] = 0;
    pb_sz[mac_type][1] = 0;

    ACL_GET_TABLE_ENTYR_NUM(DS_ACL_IPV4_KEY, pb_sz[ipv4_type]);
    ACL_GET_TABLE_ENTYR_NUM(DS_QOS_IPV4_KEY, pb_sz[ipv4_type] + 1);

    ACL_GET_TABLE_ENTYR_NUM(DS_ACL_IPV6_KEY, pb_sz[ipv6_type]);
    ACL_GET_TABLE_ENTYR_NUM(DS_QOS_IPV6_KEY, pb_sz[ipv6_type] + 1);

    /* init block_num */
    pb_num[mac_type] =
        (pb_sz[mac_type][0] ? 1 : 0) +
        (pb_sz[mac_type][1] ? 1 : 0);

    pb_num[ipv4_type] =
        (pb_sz[ipv4_type][0] ? 1 : 0) +
        (pb_sz[ipv4_type][1] ? 1 : 0);

    pb_num[ipv6_type] =
        (pb_sz[ipv6_type][0] ? 1 : 0) +
        (pb_sz[ipv6_type][1] ? 1 : 0);

    /* init block_num_max */
    acl_master->block_num_max = (pb_num[mac_type] > pb_num[ipv4_type]) ? pb_num[mac_type] : pb_num[ipv4_type];
    acl_master->block_num_max = (acl_master->block_num_max > pb_num[ipv6_type]) ?
        acl_master->block_num_max : pb_num[ipv6_type];

    /*acl redirect*/
    if (acl_global_cfg->acl_redirect_num > 0)
    {
        CTC_ERROR_RETURN(sys_alloc_get_met_dsfwd_table_info(&glb_met_entry_num, &local_met_dsfwd_entry_num));
        acl_master->acl_fwd_base = glb_met_entry_num + local_met_dsfwd_entry_num - acl_global_cfg->acl_redirect_num;
        fwd_opf_start_offset = acl_master->acl_fwd_base & 0x000000FF;
        acl_master->acl_fwd_base = acl_master->acl_fwd_base & 0xFFFFFF00;
    }

    /* init l4_port_free_cnt */
    acl_master->l4_port_free_cnt = SYS_ACL_L4_PORT_NUM;

    /* init tcp_flag_free_cnt */
    acl_master->tcp_flag_free_cnt = SYS_ACL_TCP_FLAG_NUM;

    /* init lchip num */
    acl_master->lchip_num = sys_humber_get_local_chip_num();

    /* init group hash table :
     *    instead of using one linklist, acl use 32 linklist.
     *    hash caculatition is pretty fast, just label_id % hash_size
     */

    acl_master->group = ctc_hash_create(1,
                                        SYS_ACL_GROUP_HASH_BLOCK_SIZE,
                                        (hash_key_fn)_sys_humber_acl_hash_make_group,
                                        (hash_cmp_fn)_sys_humber_acl_hash_compare_group);

    /* init entry hash table */
    acl_master->entry = ctc_hash_create(1,
                                        SYS_ACL_ENTRY_HASH_BLOCK_SIZE,
                                        (hash_key_fn)_sys_humber_acl_hash_make_entry,
                                        (hash_cmp_fn)_sys_humber_acl_hash_compare_entry);

    if ((!acl_master->group)
        || (!acl_master->entry)
        )
    {
        goto ERROR_FREE_MEM0;
    }

    acl_master->mac_ipv4_entry_num[0] = pb_sz[ipv4_type][0];
    acl_master->mac_ipv4_entry_num[1] = pb_sz[ipv4_type][1];
    acl_master->ipv6_entry_num[0] = pb_sz[ipv6_type][0];
    acl_master->ipv6_entry_num[1] = pb_sz[ipv6_type][1];

    /* consider default entry */
    pb_sz[ipv4_type][0] =
        pb_sz[ipv4_type][0] ? (pb_sz[ipv4_type][0] - 2) : 0;
    pb_sz[ipv4_type][1] =
        pb_sz[ipv4_type][1] ? (pb_sz[ipv4_type][1] - 2) : 0;
    pb_sz[ipv6_type][0] =
        pb_sz[ipv6_type][0] ? (pb_sz[ipv6_type][0] - 1) : 0;
    pb_sz[ipv6_type][1] =
        pb_sz[ipv6_type][1] ? (pb_sz[ipv6_type][1] - 1) : 0;

    /* init each block */
    for (asic_type = 0; asic_type < acl_master->asic_type_num; asic_type++)
    {
        for (block_idx = 0; block_idx < SYS_ACL_BLOCK_NUM_MAX; block_idx++)
        {
            pb[asic_type][block_idx].block_number = block_idx;
            pb[asic_type][block_idx].block_type   = asic_type;
            pb[asic_type][block_idx].entry_count  = (uint16)pb_sz[asic_type][block_idx];
            pb[asic_type][block_idx].free_count   = (uint16)pb_sz[asic_type][block_idx];

            size = sizeof(sys_acl_entry_t*) * pb_sz[asic_type][block_idx];
            pb[asic_type][block_idx].entries      = (sys_acl_entry_t**)mem_malloc
                    (MEM_ACL_MODULE, size);
            if (NULL == pb[asic_type][block_idx].entries && size)
            {
                goto ERROR_FREE_MEM1;
            }

            sal_memset(pb[asic_type][block_idx].entries, 0, size);
        }
    }

    /* ACL redirect */
    CTC_ERROR_RETURN(sys_humber_opf_init(OPF_ACL_FWD_SRAM, 1));
    if (acl_global_cfg->acl_redirect_num > 0)
    {
        opf.pool_type = OPF_ACL_FWD_SRAM;
        opf.pool_index = 0;
        CTC_ERROR_RETURN(sys_humber_opf_init_offset(&opf, fwd_opf_start_offset, acl_global_cfg->acl_redirect_num));
    }

    acl_master->p_sys_acl_redirect_hash = ctc_hash_create(1, SYS_ACL_REDIRECT_BUCKET_SIZE,
                                                          _sys_humber_acl_redirect_hash_key,
                                                          _sys_humber_acl_redirect_hash_cmp);

    CTC_ERROR_RETURN(_sys_humber_acl_init_ctl());
    CTC_ERROR_RETURN(_sys_humber_acl_add_default_entry(FALSE));

    return CTC_E_NONE;

ERROR_FREE_MEM1:

    for (asic_type = 0; asic_type < acl_master->asic_type_num; asic_type++)
    {
        for (block_idx = 0; block_idx < SYS_ACL_BLOCK_NUM_MAX; block_idx++)
        {
            if (pb[asic_type][block_idx].entries)
            {
                mem_free(pb[asic_type][block_idx].entries);
            }
        }
    }

ERROR_FREE_MEM0:

    if (acl_master->entry)
    {
        ctc_hash_free(acl_master->entry);
    }

    if (acl_master->group)
    {
        ctc_hash_free(acl_master->group);
    }

    if (acl_master)
    {
        mem_free(acl_master);
    }

    return CTC_E_ACL_INIT;

}

