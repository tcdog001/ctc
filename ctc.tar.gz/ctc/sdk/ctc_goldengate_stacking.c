/**
 @file ctc_goldengate_stacking.c

 @date 2012-3-14

 @version v2.0
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_error.h"
#include "ctc_goldengate_stacking.h"
#include "sys_goldengate_stacking.h"
/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/
/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/

int32
ctc_goldengate_stacking_create_trunk(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_create_trunk(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_destroy_trunk(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_destroy_trunk(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_add_trunk_port(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_add_trunk_port(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_remove_trunk_port(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_remove_trunk_port(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_add_trunk_rchip(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_add_trunk_rchip(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_remove_trunk_rchip(uint8 lchip, ctc_stacking_trunk_t* p_trunk)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_remove_trunk_rchip(lchip, p_trunk));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_set_property(uint8 lchip, ctc_stacking_property_t* p_prop)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_set_property(lchip, p_prop));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_get_property(uint8 lchip, ctc_stacking_property_t* p_prop)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_get_property(lchip, p_prop));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_keeplive_add_member(uint8 lchip, ctc_stacking_keeplive_t* p_keeplive)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_keeplive_add_member(lchip, p_keeplive));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_keeplive_remove_member(uint8 lchip, ctc_stacking_keeplive_t* p_keeplive)
{
    CTC_ERROR_RETURN(sys_goldengate_stacking_keeplive_remove_member(lchip, p_keeplive));

    return CTC_E_NONE;
}

int32
ctc_goldengate_stacking_init(uint8 lchip, void* p_cfg)
{
    ctc_stacking_glb_cfg_t stacking_glb_cfg;

    /* init stacking*/
    if (NULL == p_cfg)
    {
        sal_memset(&stacking_glb_cfg, 0 , sizeof(stacking_glb_cfg));
        stacking_glb_cfg.hdr_glb.mac_da_chk_en     = 0;
        stacking_glb_cfg.hdr_glb.ether_type_chk_en = 0;
        stacking_glb_cfg.hdr_glb.vlan_tpid         = 0x8100;
        stacking_glb_cfg.hdr_glb.ether_type        = 0x55bb;
        stacking_glb_cfg.hdr_glb.ip_protocol       = 0;
        stacking_glb_cfg.hdr_glb.udp_dest_port     = 0x1234;
        stacking_glb_cfg.hdr_glb.udp_src_port      = 0x5678;
        stacking_glb_cfg.hdr_glb.udp_en            = 0;
        stacking_glb_cfg.hdr_glb.ip_ttl            = 255;
        stacking_glb_cfg.hdr_glb.ip_dscp           = 63;
        stacking_glb_cfg.hdr_glb.cos               = 7;
        stacking_glb_cfg.hdr_glb.is_ipv4           = 1;
        stacking_glb_cfg.hdr_glb.ipsa.ipv4         = 0x11223344;
        p_cfg = &stacking_glb_cfg;
    }

    CTC_ERROR_RETURN(sys_goldengate_stacking_init(lchip, p_cfg));

    return CTC_E_NONE;
}

