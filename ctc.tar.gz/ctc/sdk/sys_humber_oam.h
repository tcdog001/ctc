/**
 @file sys_humber_oam.h

 @date 2010-1-19

 @version v2.0

  The file defines Macro, stored data structure for  Ethernet OAM module
*/
#ifndef _SYS_HUMBER_OAM_H
#define _SYS_HUMBER_OAM_H
#ifdef __cplusplus
extern "C" {
#endif
/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "sal.h"
#include "ctc_debug.h"
#include "ctc_oam.h"
#include "ctc_linklist.h"
#include "ctc_hash.h"
#include "ctc_parser.h"
#include "ctc_vector.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/
#define SYS_HUMBER_OAM_HASH_ENABLE 1

#define SYS_HUMBER_OAM_INVALID_ENTRY_INDEX 0xffffffff
#define SYS_HUMBER_OAM_INVALID_MAID_INDEX 0xffff
#define SYS_HUMBER_OAM_MAX_MD_LEVEL 7
#define SYS_HUMBER_OAM_MIN_CCM_INTERVAL 1
#define SYS_HUMBER_OAM_MAX_CCM_INTERVAL 7
#define SYS_HUMBER_OAM_MIN_MEP_ID 1
#define SYS_HUMBER_OAM_MAX_MEP_ID 8191

#define OAM_LOCK \
    if (p_sys_oam_master->oam_mutex) sal_mutex_lock(p_sys_oam_master->oam_mutex)
#define OAM_UNLOCK \
    if (p_sys_oam_master->oam_mutex) sal_mutex_unlock(p_sys_oam_master->oam_mutex)

#define SYS_OAM_DBG_DUMP(FMT, ...)                          \
    {                                                      \
        CTC_DEBUG_OUT(oam, oam, OAM_SYS, CTC_DEBUG_LEVEL_DUMP, FMT, ##__VA_ARGS__); \
    }

#define SYS_OAM_DBG_INFO(FMT, ...)                          \
    {                                                      \
        CTC_DEBUG_OUT_INFO(oam, oam, OAM_SYS, FMT, ##__VA_ARGS__); \
    }

#define SYS_OAM_DBG_FUNC()                          \
    { \
        CTC_DEBUG_OUT_FUNC(oam, oam, OAM_SYS); \
    }

#define SYS_HUMBER_OAM_MASTER      p_sys_oam_master
#define SYS_HUMBER_ETH_OAM_MASTER  p_sys_oam_master->eth_oam_master
#define SYS_HUMBER_EFM_OAM_MASTER  p_sys_oam_master->efm_oam_master
#define SYS_HUMBER_MPLS_OAM_MASTER p_sys_oam_master->mpls_oam_master
#define SYS_HUMBER_PBX_OAM_MASTER  p_sys_oam_master->pbx_oam_master

#define SYS_HUMBER_ETH_OAM_GLOBAL  p_sys_oam_master->eth_oam_master->eth_oam_global

#define SYS_HUMBER_ETH_OAM_INIT_CHECK \
    if (!SYS_HUMBER_OAM_MASTER || !SYS_HUMBER_ETH_OAM_MASTER) \
    { \
        return CTC_E_OAM_NOT_INIT; \
    }

#define SYS_HUMBER_EFM_OAM_INIT_CHECK \
    if (!SYS_HUMBER_OAM_MASTER || !SYS_HUMBER_EFM_OAM_MASTER) \
    { \
        return CTC_E_OAM_NOT_INIT; \
    }

#define SYS_HUMBER_MPLS_OAM_INIT_CHECK \
    if (!SYS_HUMBER_OAM_MASTER || !SYS_HUMBER_MPLS_OAM_MASTER) \
    { \
        return CTC_E_OAM_NOT_INIT; \
    }

#define SYS_HUMBER_PBX_OAM_INIT_CHECK \
    if (!SYS_HUMBER_OAM_MASTER || !SYS_HUMBER_PBX_OAM_MASTER) \
    { \
        return CTC_E_OAM_NOT_INIT; \
    }

#define SYS_HUMBER_OAM_RETURN_WITH_ROLL_BACK(op, roll_back) \
    { \
        int32 rv; \
        if ((rv = (op)) < 0) \
        { \
            roll_back; \
            return (rv); \
        } \
    }

#define SYS_OAM_DRIVER_ERROR_RETURN(op) \
    { \
        int32 rv; \
        if ((rv = (op)) < 0) \
        { \
            return CTC_E_OAM_DRIVER_FAIL; \
        } \
    }

/****************************************************************************
*
* Data structures
*
****************************************************************************/

/**
 @brief  Define oam lookup type
*/
typedef enum oam_lookup_type_e
{
    PORT_VID = 0,
    ESPID,
    MPLS_LABEL,
    IPV4_TTSI,
    RMEP
} oam_lookup_type_t;

/**
 @brief  Define oam MEP type
*/
typedef enum oam_mep_type_e
{
    ETH_CCM_MEP = 0,
    PBT_CCM_MEP,
    CV0_MEP,
    FFD_MEP,
    CV1_MEP,
} oam_mep_type_t;

/**
 @brief  sys oam hash index type
*/
enum sys_humber_oam_asic_index_type_s
{
    SYS_HUMBER_OAM_ASIC_HASH_LEFT_BUCKET,
    SYS_HUMBER_OAM_ASIC_HASH_RIGHT_BUCKET,
    SYS_HUMBER_OAM_ASIC_TCAM,
    SYS_HUMBER_OAM_ASIC_RMEP_P2P
};
typedef enum sys_humber_oam_asic_index_type_s sys_humber_oam_asic_index_type_t;

/**
 @brief  sys oam hash bucket creator type
*/
enum sys_humber_oam_hash_entry_status_s
{
    SYS_HUMBER_OAM_HASH_ENTRY_NOT_CREATED,
    SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_SDK_PASSIVE,
    SYS_HUMBER_OAM_HASH_ENTRY_CREATED_BY_USER,
    SYS_HUMBER_OAM_HASH_ENTRY_PASSIVE_OVERWRITE_BY_USER
};
typedef enum sys_humber_oam_hash_entry_status_s sys_humber_oam_hash_entry_status_t;

/**
 @brief  Define sys layer ethernet oam maid structure
*/
struct sys_eth_oam_maid_s
{
    ctc_slistnode_t head;
    uint8    maid[CTC_OAM_MAX_MAID_LEN];
    uint8   maid_len;
    uint16  maid_index;
    uint8   rsv;
};
typedef struct sys_eth_oam_maid_s sys_eth_oam_maid_t;

/**
 @brief  Define sys layer ethernet oam key structure
*/
struct sys_eth_oam_key_s
{
    uint16    gport;     /**<Ethernet OAM channel associated global port id,if MEP configured on linkagg,the gport should global linkagg ID */
    uint16    vlan_id;   /**<Ethernet OAM channel associated Vlan ID */
    uint16    ccm_vlan_id;   /**<Ethernet OAM channel associated ccm Vlan ID */
    uint8     direction; /**<Ethernet OAM channel associated MEP direction,UP(1), or Down(0) MEP */
    uint8     link_oam;  /**<If set,indicate that it is link oam MEP */
};
typedef struct sys_eth_oam_key_s sys_eth_oam_key_t;

/**
 @brief  Define sys layer ethernet oam local mep structure
*/
struct sys_eth_oam_lmep_s
{
    ctc_slistnode_t head;
    sys_eth_oam_maid_t* maid;
    ctc_slist_t* rmep_list; /**<sys_eth_oam_rmep_t*/
    sys_eth_oam_key_t     lmep_chan_key; /**<Ethernet OAM channel lookup assocatied local mep key*/
    uint8   mp_addr_mode;
    uint8   aps_en;
    uint8   rsv[2];
    uint16 ma_index;
    uint16 mep_index;
    uint16 mep_id;
    uint16 ccm_gport_id;  /**<when MEP is configured on linkagg, the gport should be one of member port.
                            and the port will be used as the MEP associated port property,such as port-based 8bits mac ,global port id */
    uint8  tx_with_send_id;
    uint8  tx_ccm_with_if_status_tlv;
    uint8  tx_ccm_with_port_status_tlv;
    uint8  md_level;
    uint8  enable_pm;     /**< (enable Y1731 delay measurement)*/
    uint8  active;
    uint8  ccm_interval;
    uint8  ethtype_index;
    uint8  ccm_en;
    uint8  mep_on_cpu;
    uint16 sim_ccm_while;
    uint32 upmep_nhid;
    ctc_slist_t* local_member_list[CTC_MAX_HUMBER_CHIP_NUM];
};
typedef struct sys_eth_oam_lmep_s sys_eth_oam_lmep_t;

/**
 @brief  Define sys layer ethernet oam remote mep structure
*/
struct sys_eth_oam_rmep_s
{
    ctc_slistnode_t head;
    uint16          mep_index;
    uint16          rmep_id;
    uint16          rmep_index;
    uint8           seq_num_en;
    uint8           rmep_mac_check_en;
    uint8           active;
    uint8           reserved;
    uint8           rsv[2];
    uint32          asic_key_index;
    sys_humber_oam_asic_index_type_t asic_index_type;
};
typedef struct sys_eth_oam_rmep_s sys_eth_oam_rmep_t;

/**
 @brief  Define sys layer ethernet oam mep lookup channel structure
*/
struct sys_eth_oam_lmep_lkup_chan_s
{
    sys_eth_oam_key_t lmep_chan_key; /**<mep chan key*/
    ctc_slist_t* lmep_list;     /**<sys_eth_oam_lmep_s*/
    uint8  mep_on_master_chip;  /**<When MEP is config on cross chip linkagg,and the chan is on the slave chip*/
    uint8  master_gchip;        /**<linkagg MEP's configured master gchip ID*/
    uint8  max_active_md_level; /**<max active md level on this chan*/
    uint8  rsv;
    sys_humber_oam_hash_entry_status_t entry_status; /**< bucket entry creator type */
    sys_humber_oam_asic_index_type_t asic_index_type; /**<chan's key index type in asic, for ethernet oam, 0 for DsEthOamHashKey0(left bucket),
                                                     1 for DsEthOamHashKey1(right bucket), 2 for TCAM */
    uint32 asic_key_index;      /**<Entry index in the asic table, for ether oam, it is the table index of DsEthOamHashkey or DsEthOamKey(TCAM),
                                and will used to calculate the related table entry index of DsEthOamChan. */
};
typedef struct sys_eth_oam_lmep_lkup_chan_s sys_eth_oam_lmep_lkup_chan_t;

/**
 @brief  Define sys layer nexthop offset and id structure for down mep
*/
struct sys_eth_nh_offset_s
{
    uint32 nhid;        /**<next hop id for vlan */
    uint32 group_id;
    uint8   upmep_count;
    uint8   downmep_count;
    uint16 rsv0;

};
typedef struct sys_eth_nh_offset_s sys_eth_nh_offset_t;

/**
 @brief  Define sys layer eth_oam master structure
*/
struct sys_eth_oam_master_s
{
    ctc_oam_global_t*       eth_oam_global;  /**<global configurations for CFM */
    ctc_slist_t*            maid_list;       /**<ctc_eth_oam_maid_t*/
    ctc_vector_t*           nh_offset_vector; /**<sys_eth_nh_offset_t*/
    ctc_hash_t* lmep_lkup_chan_hash[CTC_MAX_LOCAL_CHIP_NUM]; /**<sys_eth_oam_lmep_lkup_chan_t*/

};
typedef struct sys_eth_oam_master_s sys_eth_oam_master_t;

/**
 @brief  Define sys layer mpls master structure
*/
struct sys_mpls_oam_master_s
{
    uint8 rsv[4];
};
typedef struct sys_mpls_oam_master_s sys_mpls_oam_master_t;

/**
 @brief  Define sys layer mpls master data structure
*/
struct sys_pbx_oam_master_s
{
    uint8 rsv[4];
};
typedef struct sys_pbx_oam_master_s sys_pbx_oam_master_t;

/**
 @brief  Define sys layer ethernet oam global configure data structure
*/
struct sys_oam_master_s
{
    sys_eth_oam_master_t*  eth_oam_master;
    sys_mpls_oam_master_t* mpls_oam_master;
    sys_pbx_oam_master_t*  pbx_oam_master;
    sal_mutex_t*           oam_mutex;
    ctc_vector_t*          mep_vector[CTC_MAX_LOCAL_CHIP_NUM]; /**<sys_eth_oam_lmep_t/sys_eth_oam_rmep_t*/
    uint32                 oam_tcam_table_base;
    uint32                 oam_hash_table_base;
};
typedef struct sys_oam_master_s sys_oam_master_t;

struct sys_eth_oam_lmep_info_s
{
    uint16 mep_index; /* input paramter */
    uint16 mep_id;    /* output paramter */
    uint16 vlan_id;   /* output paramter */
    uint16 gport;     /* output paramter */
    uint8  md_level;  /* output paramter */
    uint8  mep_info_valid; /* output paramter */
    uint16 resv;
};
typedef struct sys_eth_oam_lmep_info_s sys_eth_oam_lmep_info_t;

extern sys_oam_master_t* p_sys_oam_master;

/****************************************************************************
 *
* Function
*
****************************************************************************/
/**
 @brief   oam resource check
*/
extern int32
sys_humber_oam_resource_check(void);

/**
 @brief  sys layer oam master init
*/
extern int32
sys_humber_oam_master_init(ctc_oam_global_t* com_global);

/**
 @brief   read error cache
*/
extern int32
sys_humber_oam_get_error_cache_list(uint8 lchip, void* defect_info);

/**
 @brief   Read  MEP data structure get from both SDK database and ASIC dataset
*/
extern int32
sys_humber_oam_get_mep_info(uint8 lchip, ctc_oam_mep_info_t* mep_info);

#ifdef __cplusplus
}
#endif

#endif

