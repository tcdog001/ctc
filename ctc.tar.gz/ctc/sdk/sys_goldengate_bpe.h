/**
 @file sys_goldengate_bpe.h

 @date 2013-05-28

 @version v2.0

 The file define APIs and types use in sys layer
*/
#ifndef _SYS_goldengate_BPE_H
#define _SYS_goldengate_BPE_H
#ifdef __cplusplus
extern "C" {
#endif
/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_const.h"
#include "ctc_vector.h"

#include "ctc_bpe.h"

#define SYS_BPE_DBG_OUT(level, FMT, ...) \
    do { \
        CTC_DEBUG_OUT(port, port, PORT_SYS, level, FMT, ##__VA_ARGS__); \
    } while (0);


struct sys_bpe_master_s
{
    uint8  is_port_extender;
    uint8  rsv;
    uint16 port_base;
    uint32 pe_uc_dsfwd_base;
    uint32 pe_mc_dsfwd_base;
};
typedef struct sys_bpe_master_s sys_bpe_master_t;

enum bpe_igs_muxtype_e
{
    BPE_IGS_MUXTYPE_NOMUX = 0,
    BPE_IGS_MUXTYPE_MUXDEMUX = 1,
    BPE_IGS_MUXTYPE_EVB = 2,
    BPE_IGS_MUXTYPE_CB_DOWNLINK = 3,
    BPE_IGS_MUXTYPE_PE_DOWNLINK_WITH_CASCADE_PORT = 4,
    BPE_IGS_MUXTYPE_PE_UPLINK = 5,
    BPE_IGS_MUXTYPE_NUM
};
typedef enum bpe_igs_muxtype_e bpe_igs_muxtype_t;

enum bpe_egs_muxtype_e
{
    BPE_EGS_MUXTYPE_NOMUX,
    BPE_EGS_MUXTYPE_MUXDEMUX = 2,
    BPE_EGS_MUXTYPE_LOOPBACK_ENCODE,
    BPE_EGS_MUXTYPE_EVB,
    BPE_EGS_MUXTYPE_CB_CASCADE,
    BPE_EGS_MUXTYPE_UPSTREAM,
    BPE_EGS_MUXTYPE_NUM
};
typedef enum bpe_egs_muxtype_e bpe_egs_muxtype_t;

extern int32
sys_goldengate_bpe_init(uint8 lchip, void* bpe_global_cfg);
extern int32
sys_goldengate_bpe_set_intlk_en(uint8 lchip, bool enable);
extern int32
sys_goldengate_bpe_get_intlk_en(uint8 lchip, bool* enable);
extern int32
sys_goldengate_bpe_set_port_extender(uint8 lchip, uint16 gport, ctc_bpe_extender_t* p_extender);
extern int32
sys_goldengate_bpe_get_port_extender(uint8 lchip, uint16 gport, bool* enable);
extern int32
sys_goldengate_bpe_get_port_extend_mcast_en(uint8 lchip, uint8 *p_enable);
extern int32
sys_goldengate_bpe_set_port_extend_mcast_en(uint8 lchip, uint8 enable);
#ifdef __cplusplus
}
#endif

#endif

