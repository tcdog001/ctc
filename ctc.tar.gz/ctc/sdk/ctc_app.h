/**
 @file ctc_app.h

 @date 2010-3-2

 @version v2.0

 This file define the isr APIs
*/

#ifndef _CTC_SMP_COMMON_H
#define _CTC_SMP_COMMON_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_const.h"
#include "ctc_debug.h"

#define CTC_APP_DBG_OUT(level, FMT, ...) \
    do { \
        CTC_DEBUG_OUT(app, app, APP_SMP, level, FMT, ##__VA_ARGS__); \
    } while (0)

#ifdef __cplusplus
}
#endif

#endif
