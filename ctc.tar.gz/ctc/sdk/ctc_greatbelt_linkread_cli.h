#ifndef _CTC_GREATBELT_LINKREAD_H
#define _CTC_GREATBELT_LINKREAD_H
#ifdef __cplusplus
extern "C" {
#endif
#include "sal.h"
#include "ctc_cli.h"

extern int32
ctc_greatbelt_linkread_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif  /* _CTC_GREATBELT_LINKREAD_H */

