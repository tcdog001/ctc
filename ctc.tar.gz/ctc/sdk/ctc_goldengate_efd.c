/**
 @file ctc_goldengate_efd.c

 @date 2014-10-28

 @version v3.0

 The file apply APIs to config efd
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_error.h"
#include "ctc_efd.h"
#include "sys_goldengate_efd.h"

/****************************************************************************
 *
 * Function
 *
 *****************************************************************************/

int32
ctc_goldengate_efd_set_global_ctl(uint8 lchip, ctc_efd_global_control_type_t type, void* value)
{

    CTC_ERROR_RETURN(sys_goldengate_efd_set_global_ctl(lchip, type, value));

    return CTC_E_NONE;
}

int32
ctc_goldengate_efd_get_global_ctl(uint8 lchip, ctc_efd_global_control_type_t type, void* value)
{

    CTC_ERROR_RETURN(sys_goldengate_efd_get_global_ctl(lchip, type, value));

    return CTC_E_NONE;
}

int32
ctc_goldengate_efd_register_cb(uint8 lchip, ctc_efd_fn_t callback, void* userdata)
{
    CTC_ERROR_RETURN(sys_goldengate_efd_register_cb(lchip, callback, userdata));
    
    return CTC_E_NONE;
}

int32
ctc_goldengate_efd_init(uint8 lchip, void* p_global_cfg)
{

    CTC_ERROR_RETURN(sys_goldengate_efd_init(lchip));

    return CTC_E_NONE;
}

