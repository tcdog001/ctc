/**
 @file ctc_l2_cli.c

 @date 2009-10-30

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_l2_cli.h"
#include "ctc_api.h"
#include "ctc_l2.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_port_mapping_cli.h"

CTC_CLI(ctc_cli_hb_chip_set_datapath,
        ctc_cli_hb_chip_set_datapath_cmd,
        "chip datapath mode set (48-4 | 36-6) (chip LOCAL_CHIPID |)",
        "chip module",
        "user configuration",
        "mode",
        "set",
        "48G+4TenG mode",
        "36G+6TenG mode",
        "chip",
        "<0~1>")
{
    int32 ret = CLI_SUCCESS;
    ctc_chip_datapath_mode_t datapath_mode;
    uint8 lchip = 0;
    uint8 index = 0;

    sal_memset(&datapath_mode, 0, sizeof(datapath_mode));

    if (0 == sal_memcmp("48", argv[0], 2))
    {
        datapath_mode = CTC_CHIP_48G_PLUS_4TG;
    }
    else
    {
        datapath_mode = CTC_CHIP_36G_PLUS_6TG;
    }

    if (1 < argc)
    {
        index = CTC_CLI_GET_ARGC_INDEX("chip");
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip id", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    ret = ctc_datapath_set_mode(lchip, datapath_mode);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_chip_show_datapath_mode,
        ctc_cli_hb_chip_show_datapath_mode_cmd,
        "show chip datapath mode (chip LOCAL_CHIPID |)",
        "show",
        "chip module",
        "user configuration",
        "mode",
        "chip",
        "<0~1>")
{
    int32 ret = CLI_SUCCESS;
    ctc_chip_datapath_mode_t datapath_mode;
    uint8 lchip = 0;
    uint8 index = 0;

    if (0 < argc)
    {
        index = CTC_CLI_GET_ARGC_INDEX("chip");
        if (argc <= (index + 1))
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip id", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    ret = ctc_datapath_get_mode(lchip, &datapath_mode);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    switch (datapath_mode)
    {
    case CTC_CHIP_48G_PLUS_4TG:
        ctc_cli_out("The current mode is 48G+4TenG \n\r");
        break;

    case CTC_CHIP_36G_PLUS_6TG:
        ctc_cli_out("The current mode is 36G+6TenG \n\r");
        break;

    default:
        ctc_cli_out("%% Insufficient  param \n\r");
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_chip_show_serdes_mode,
        ctc_cli_hb_chip_show_serdes_mode_cmd,
        "show chip serdes SERDES mode",
        "show",
        "chip module",
        "serdes",
        "Serdes id",
        "3.125G/1.25G")
{
    int32 ret = CLI_SUCCESS;
    uint16 serdes = 0;
    ctc_serdes_mode_t serdes_mode;

    CTC_CLI_GET_UINT16_RANGE("serdes id", serdes, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = ctc_get_serdes_mode(serdes, &serdes_mode);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;

    }

    if (CTC_SERDES_MODE_1G25 == serdes_mode)
    {
        ctc_cli_out("The serdes mode is 1.25G\n");
    }
    else
    {
        ctc_cli_out("The serdes mode is 3.125G\n");
    }

    return ret;
}

int32
ctc_humber_chip_cli_init(void)
{
    install_element(CTC_SDK_MODE,  &ctc_cli_hb_chip_show_serdes_mode_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_hb_chip_show_datapath_mode_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_hb_chip_show_serdes_mode_cmd);

    return 0;
}

