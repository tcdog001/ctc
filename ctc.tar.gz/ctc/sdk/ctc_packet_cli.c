/**
 @file ctc_packet_cli.c

 @date 2012-07-09

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_const.h"
#include "ctc_api.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_packet.h"
#include "ctc_port_mapping_cli.h"

#define CTC_CLI_PKT_ALERT_LABEL_13  13
#define CTC_CLI_PKT_PUSH_LABEL(pkt, label, exp, bos, ttl) \
do {                                        \
    uint32 shim = 0;                        \
    shim |= (((label) & 0xFFFFF) << 12);    \
    shim |= ((exp) & 0x7) << 9;             \
    shim |= ((bos) & 0x1) << 8;             \
    shim |= ((ttl) & 0xFF);                 \
    shim = htonl(shim);                     \
    sal_memcpy(pkt, &shim, 4);              \
    pkt += 4;                               \
} while(0)

int32
_ctc_cli_packet_get_from_file(char* file, uint8* buf, uint32* pkt_len)
{
    sal_file_t fp = NULL;
    int8  line[128];
    int32 lidx = 0, cidx = 0, tmp_val = 0;

    /* read packet from file */
    fp = sal_fopen(file, "r");
    if (NULL == fp)
    {
        return CTC_E_UNEXPECT;
    }

    sal_memset(line, 0, 128);
    while (sal_fgets((char*)line, 128, fp))
    {


        for (cidx = 0; cidx < 16; cidx++)
        {
            if (1 == sal_sscanf((char*)line + cidx * 2, "%02x", &tmp_val))
            {
                buf[lidx * 16 + cidx] = tmp_val;
                (*pkt_len) += 1;
            }
            else
            {
                break;
            }
        }

        lidx++;
    }

    sal_fclose(fp);
    fp = NULL;

    return CTC_E_NONE;
}

CTC_CLI(ctc_cli_packet_tx_uc,
        ctc_cli_packet_tx_uc_cmd,
        "packet tx ucast (dest-gport GPHYPORT_ID | linkagg AGG_ID (hash HASH|))(pri PRI |) (bypass|bridge vlan VLAN_ID) (pkt-file FILE_NAME | ((payload macda MAC svid VLAN_ID)|) length LEN) {dma | count COUNT| is-c2c |}",
        CTC_CLI_PACKET_M_STR,
        "Send packet",
        "Unicast",
        "Destination gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_LINKAGG_DESC,
        CTC_CLI_LINKAGG_ID_DESC,
        "Has hash",
        "Hash Value",
        "Pri",
        "Pri value",
        "Bypass nexthop",
        "Bridge nexthop",
        "VLAN of packet",
        "VLAN ID",
        "File store packet",
        "File name",
        "Payload",
        CTC_CLI_MAC_DESC,
        CTC_CLI_MAC_FORMAT,
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC,
        "Packet length",
        "Length value",
        "DMA mode",
        "The counts of packet you need to send ",
        "Value <1-8192>",
        "C2C packet")
{
    static uint8 pkt_buf[CTC_PKT_MTU] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x08, 0x00, 0x45, 0x00, 0x00, 0x3e, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x22, 0xf5, 0xc7, 0xc7,
        0xc7, 0x01, 0xc8, 0x01, 0x01, 0x01, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa
    };
    static char file[256] = {0};
    static ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    uint8* p_data = NULL;
    uint32 pkt_len = 0;
    int32 idx1 = 0;
    int32 ret = 0;
    uint32 dest_gport = 0;
    uint8 tid = 0;
    uint8 hash = 0;
    uint16 count = 1;
    uint16 cnt = 0;
    mac_addr_t mac;
    uint16 vid = 0;

    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_ETH;

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_NORMAL;
    p_tx_info->is_critical = TRUE;

    /* get mac info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "macda", sal_strlen("macda"));
    if (0xFF != idx1)
    {
        sal_memset(&mac, 0, sizeof(mac_addr_t));
        CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[idx1 + 1]);
        sal_memcpy(pkt_buf, &mac[0], sizeof(mac_addr_t));
    }

    /* get svid info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "svid", sal_strlen("svid"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT16("svid", vid, argv[idx1 + 1]);
        pkt_buf[14] = (vid >> 8) & 0xF;
        pkt_buf[15] = vid & 0xFF;
    }

    /* get dest_gport info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dest-gport", sal_strlen("dest-gport"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("dest_gport", dest_gport, argv[idx1 + 1]);
        CTC_PORT_MAPPING(dest_gport,1);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "pri", sal_strlen("pri"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("pri", (p_tx_info->priority), argv[idx1 + 1]);
    }

    /* get linkagg info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "linkagg", sal_strlen("linkagg"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("linkagg", tid, argv[idx1 + 1]);
        dest_gport = CTC_MAP_TID_TO_GPORT(tid);
        idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "hash", sal_strlen("hash"));
        if (0xFF != idx1)
        {
            p_tx_info->flags |= CTC_PKT_FLAG_HASH_VALID;
            CTC_CLI_GET_UINT32("hash", hash, argv[idx1 + 1]);
            p_tx_info->hash = hash;
        }
    }

    p_tx_info->dest_gport = dest_gport;

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "bypass", sal_strlen("bypass"));
    if (0xFF != idx1)
    {
        p_tx_info->flags |= CTC_PKT_FLAG_NH_OFFSET_BYPASS;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "vlan", sal_strlen("vlan"));
    if (0xFF != idx1)
    {
        p_tx_info->flags |= CTC_PKT_FLAG_SRC_SVID_VALID;
        CTC_CLI_GET_UINT32("Vlan ID", p_tx_info->src_svid, argv[idx1 + 1]);
    }

    /* get packet from file */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "pkt-file", sal_strlen("pkt-file"));
    if (0xFF != idx1)
    {
        sal_strcpy((char*)file, argv[idx1 + 1]);
        /* get packet from file */
        ret = _ctc_cli_packet_get_from_file(file, pkt_buf, &pkt_len);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    /* use default packet */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "length", sal_strlen("length"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("length", pkt_len, argv[idx1 + 1]);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dma", sal_strlen("dma"));
    if (0xFF != idx1)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "count", sal_strlen("count"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT16("count", count, argv[idx1 + 1]);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "is-c2c", sal_strlen("is-c2c"));
    if (0xFF != idx1)
    {
        p_tx_info->oper_type = CTC_PKT_OPER_C2C;
    }

    if (pkt_len > (CTC_PKT_MTU - CTC_PKT_HDR_ROOM))
    {
        ctc_cli_out("%% ret = %d, %s\n", CTC_E_EXCEED_MAX_SIZE, ctc_get_error_desc(CTC_E_EXCEED_MAX_SIZE));
        return CLI_ERROR;
    }

    if((0 == count) || (count > 8192))
    {
        ctc_cli_out("%% count = %d, not valid\n", count);
        return CLI_ERROR;
    }

    /* send packet by encap info */
    for(cnt = 0; cnt < count; cnt++)
    {
        ctc_packet_skb_init(p_skb);
        p_data = ctc_packet_skb_put(p_skb, pkt_len);
        sal_memcpy(p_data, pkt_buf, pkt_len);
        ret = ctc_packet_tx(p_pkt_tx);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_packet_tx_mc,
        ctc_cli_packet_tx_mc_cmd,
        "packet tx mcast group GROUP_ID (src-vid VLAN_ID|) (stag-action STAG_ACTION|) (nhid NHID | dsnh-offset OFFSET) \
        (nhp-8w|) (bypass|) (pkt-file FILE_NAME | ((payload {macda MAC | svid VLAN_ID|} |) length LEN)) {dma | is-c2c |}",
        CTC_CLI_PACKET_SAMPLE_M_STR,
        "Send packet",
        "Multicast",
        "Mcast group",
        CTC_CLI_GLOBAL_MCASTGRP_ID_DESC,
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC,
        "stag-action",
        "0:none, 1:replace, 2:add, 3:delete",
        "Set NH ID",
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_DSNH_OFFSET_VALUE_STR,
        CTC_CLI_NH_ID_STR,
        "Nexthop is 8w",
        "Nexthop is bypass",
        "File store packet",
        "File name",
        "Payload",
        CTC_CLI_MAC_DESC,
        CTC_CLI_MAC_FORMAT,
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC,
        "Packet length",
        "length value",
        "DMA mode",
        "C2C packet")
{
    static uint8 pkt_buf[CTC_PKT_MTU] = {
        0x01, 0x00, 0x5E, 0x7F, 0x00, 0x01, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x08, 0x00, 0x45, 0x00, 0x00, 0x3E, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x22, 0xF5, 0xC7, 0xC7,
        0xC7, 0x01, 0xC8, 0x01, 0x01, 0x01, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA,
        0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA,
        0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA, 0xAA, 0xDD, 0xAA, 0xAA
    };
    static char file[256] = {0};
    static ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    uint8* p_data = NULL;
    uint32 pkt_len = 0;
    uint16 group_id = 0;
    uint16 vlan_id = 0;
    uint16 nexthop_ptr = 0;
    uint8 stag_action = 0;
    int32 idx1 = 0;
    int32 ret = 0;
    uint32 nh_id = 0;
    ctc_nh_info_t dsnh;
    mac_addr_t mac;
    uint16 vid = 0;

    sal_memset(&dsnh, 0, sizeof(dsnh));
    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_ETH;

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_NORMAL;
    p_tx_info->is_critical = TRUE;

    /* destmap */
    CTC_CLI_GET_UINT32("group", group_id, argv[0]);
    p_tx_info->dest_group_id = group_id;       /* l2 mcast group id*/
    CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_MCAST);

    /* get mac info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "macda", sal_strlen("macda"));
    if (0xFF != idx1)
    {
        sal_memset(&mac, 0, sizeof(mac_addr_t));
        CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[idx1 + 1]);
        sal_memcpy(pkt_buf, &mac[0], sizeof(mac_addr_t));
    }

    /* get svid info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "svid", sal_strlen("svid"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT16("svid", vid, argv[idx1 + 1]);
        pkt_buf[14] = (vid >> 8) & 0xF;
        pkt_buf[15] = vid & 0xFF;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "src-vid", sal_strlen("src-vid"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[idx1 + 1]);
        p_tx_info->src_svid = vlan_id;
        p_tx_info->vrfid = vlan_id;
        /* vlan filter */
        CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "nhid", sal_strlen("nhid"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("nhid", nh_id, argv[idx1 + 1]);
        ret = ctc_nh_get_nh_info(nh_id, &dsnh);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
        p_tx_info->flags |= CTC_PKT_FLAG_NH_OFFSET_VALID;
        p_tx_info->nh_offset = dsnh.dsnh_offset[0];

        if(CTC_FLAG_ISSET(dsnh.flag, CTC_NH_INFO_FLAG_IS_DSNH8W))
        {
            CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_IS_8W);
        }
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dsnh-offset", sal_strlen("dsnh-offset"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("dsnh-offset", nexthop_ptr, argv[idx1 + 1]);
        p_tx_info->nh_offset = nexthop_ptr;
        /* vlan filter */
        CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_VALID);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "nhp-8w", sal_strlen("nhp-8w"));
    if (0xFF != idx1)
    {
        CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_IS_8W);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "bypass", sal_strlen("bypass"));
    if (0xFF != idx1)
    {
        CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_BYPASS);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "stag-action", sal_strlen("stag-action"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT8("stag action", stag_action, argv[idx1 + 1]);
    }

    /* get packet from file */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "pkt-file", sal_strlen("pkt-file"));
    if (0xFF != idx1)
    {
        sal_strcpy((char*)file, argv[idx1 + 1]);
        /* get packet from file */
        ret = _ctc_cli_packet_get_from_file(file, pkt_buf, &pkt_len);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dma", sal_strlen("dma"));
    if (0xFF != idx1)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "is-c2c", sal_strlen("is-c2c"));
    if (0xFF != idx1)
    {
        p_tx_info->oper_type = CTC_PKT_OPER_C2C;
    }

    /* use default packet */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "length", sal_strlen("length"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("length", pkt_len, argv[idx1 + 1]);
    }

    /* send packet by encap info */
    ctc_packet_skb_init(p_skb);
    p_data = ctc_packet_skb_put(p_skb, pkt_len);
    sal_memcpy(p_data, pkt_buf, pkt_len);
    ret = ctc_packet_tx(p_pkt_tx);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_packet_tx_eth_oam,
        ctc_cli_packet_tx_eth_oam_cmd,
        "packet tx cfm dest-gport GPHYPORT_ID mep (up VLAN_ID|down) ((lbm|lbr|ltm|ltr) | (1dm|dmm|dmr) (dm-ts-offset OFFSET)) (dma|)",
        CTC_CLI_PACKET_M_STR,
        "Send packet",
        "CFM",
        "Destination gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Set MEP type",
        "Up MEP",
        "VLAN of Up MEP",
        "Down MEP",
        "LBM",
        "LBR",
        "LTM",
        "LTR",
        "1DM",
        "DMM",
        "DMR",
        "Set DM timestamp offset",
        "Offset value in bytes",
        "DMA mode")
{
    static uint8 pkt_buf_lbm[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x03, 0x00, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_lbr[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x02, 0x00, 0x04, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_ltm[100] = {
        0x01, 0x80, 0xc2, 0x00, 0x00, 0x3d, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x05, 0x00, 0x11, 0x00, 0x00, 0x00, 0x01, 0x40, 0x00, 0x11, 0x22, 0x33, 0x44,
        0x55, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_ltr[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x04, 0x20, 0x06, 0x00, 0x00, 0x00, 0x01, 0x3f, 0x01, 0x05, 0x00, 0x10, 0x01,
        0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x07, 0x05, 0x65, 0x74, 0x68, 0x2d, 0x30, 0x2d, 0x39, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_1dm[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x2d, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_dmm[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x2f, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_dmr[100] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x89, 0x02, 0xa0, 0x2e, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    uint8* pkt_buf = NULL;

    static ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    uint8* p_data = NULL;
    uint32 pkt_len = 64;
    uint16 dest_gport = 0;
    int32 ret = 0;
    uint32 is_dm = FALSE;
    uint32 is_up = FALSE;
    uint32 dm_ts_offset = 0;
    uint16 vlan_id = 0;
    uint32 pkt_type_base = 2;
    int32 idx1 = 0;

    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_ETH;

    /* destmap */
    CTC_CLI_GET_UINT32("dest_gport", dest_gport, argv[0]);
    CTC_PORT_MAPPING(dest_gport,1);
    p_tx_info->dest_gport = dest_gport;

    /* MEP type */
    if (sal_strncmp(argv[1], "up", 2) == 0)
    {
        is_up = TRUE;
        CTC_CLI_GET_UINT16("vlan id", vlan_id, argv[2]);
        pkt_type_base += 1;
    }
    else
    {
        is_up = FALSE;
    }

    /* packet type */
    if (sal_strncmp(argv[pkt_type_base + 0], "lbm", 3) == 0)
    {
        pkt_buf = pkt_buf_lbm;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "lbr", 3) == 0)
    {
        pkt_buf = pkt_buf_lbr;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "ltm", 3) == 0)
    {
        pkt_buf = pkt_buf_ltm;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "ltr", 3) == 0)
    {
        pkt_buf = pkt_buf_ltr;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "1dm", 3) == 0)
    {
        pkt_buf = pkt_buf_1dm;
        is_dm = TRUE;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "dmm", 3) == 0)
    {
        pkt_buf = pkt_buf_dmm;
        is_dm = TRUE;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "dmr", 3) == 0)
    {
        pkt_buf = pkt_buf_dmr;
        is_dm = TRUE;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dma", sal_strlen("dma"));
    if (0xFF != idx1)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
    }

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_OAM;
    p_tx_info->is_critical = TRUE;

    /* cfm */
    p_tx_info->oam.type = CTC_OAM_TYPE_ETH;
    if (is_up)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP);
        p_tx_info->oam.vid = vlan_id;
    }

    if (is_dm)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM);
        CTC_CLI_GET_UINT32("offset", dm_ts_offset, argv[pkt_type_base + 2]);
        p_tx_info->oam.dm_ts_offset = dm_ts_offset;
    }

    /* send packet by encap info */
    ctc_packet_skb_init(p_skb);
    p_data = ctc_packet_skb_put(p_skb, pkt_len);
    sal_memcpy(p_data, pkt_buf, pkt_len);
    ret = ctc_packet_tx(p_pkt_tx);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_packet_tx_ingress_ipuc,
        ctc_cli_packet_tx_ingress_ipuc_cmd,
        "packet tx ingress-ipuc (dest-gport GPHYPORT_ID) (vrf VRFID) (length LEN) (dma|)",
        CTC_CLI_PACKET_M_STR,
        "Send packet",
        "Ingress IPUC packet",
        "Destination gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        "VRF",
        "VRF ID",
        "Packet length",
        "Length value",
        "DMA mode")
{
    static uint8 pkt_buf[CTC_PKT_MTU] = {
        0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff, 0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x81, 0x00, 0x00, 0x0a,
        0x08, 0x00, 0x45, 0x00, 0x00, 0x3e, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x74, 0xbd, 0x01, 0x01,
        0x01, 0x01, 0x02, 0x02, 0x02, 0x00, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa,
        0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa, 0xaa, 0xdd, 0xaa, 0xaa
    };

    static ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    uint8* p_data = NULL;
    uint32 pkt_len = 0;
    int32 idx1 = 0;
    int32 ret = 0;
    uint16 dest_gport = 0;
    uint16 vid = 0;

    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_ETH;

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_NORMAL;
    p_tx_info->is_critical = TRUE;

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "vrf", sal_strlen("vrf"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("vid", vid, argv[idx1 + 1]);
        pkt_buf[14] = (vid >> 8) & 0xFF;
        pkt_buf[15] = (vid) & 0xFF;
        p_tx_info->flags |= CTC_PKT_FLAG_INGRESS_MODE;
    }

    /* get dest_gport info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dest-gport", sal_strlen("dest-gport"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("dest_gport", dest_gport, argv[idx1 + 1]);
        CTC_PORT_MAPPING(dest_gport,1);
        p_tx_info->dest_gport = dest_gport;
    }

    /* use default packet */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "length", sal_strlen("length"));
    if (0xFF != idx1)
    {
        CTC_CLI_GET_UINT32("length", pkt_len, argv[idx1 + 1]);
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dma", sal_strlen("dma"));
    if (0xFF != idx1)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
    }

    if (pkt_len > (CTC_PKT_MTU - CTC_PKT_HDR_ROOM))
    {
        ctc_cli_out("%% ret = %d, %s\n", CTC_E_EXCEED_MAX_SIZE, ctc_get_error_desc(CTC_E_EXCEED_MAX_SIZE));
        return CLI_ERROR;
    }

    /* send packet by encap info */
    ctc_packet_skb_init(p_skb);
    p_data = ctc_packet_skb_put(p_skb, pkt_len);
    sal_memcpy(p_data, pkt_buf, pkt_len);
    ret = ctc_packet_tx(p_pkt_tx);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_packet_debug_on,
        ctc_cli_packet_debug_on_cmd,
        "debug packet (ctc | sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_PACKET_M_STR,
        "Ctc layer",
        "System layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    int32 ret = CTC_E_NONE;
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = PACKET_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = PACKET_SYS;
    }

    ret = ctc_debug_set_flag("packet", "packet", typeenum, level, TRUE);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_packet_debug_off,
        ctc_cli_packet_debug_off_cmd,
        "no debug packet (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_PACKET_M_STR,
        "Ctc layer",
        "System layer")
{
    int32 ret = CTC_E_NONE;
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = PACKET_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = PACKET_SYS;
    }

    ctc_debug_set_flag("packet", "packet", typeenum, level, FALSE);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_packet_debug_show,
        ctc_cli_packet_debug_show_cmd,
        "show debug packet (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_PACKET_M_STR,
        "Ctc layer",
        "System layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;
    uint32 is_on = FALSE;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = PACKET_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = PACKET_SYS;
    }

    is_on = ctc_debug_get_flag("packet", "packet", typeenum, &level);
    ctc_cli_out("packet: %s debug %s  level: %s\n", argv[0], is_on ? "on" : "off",
                ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_packet_tx_tp_y1731,
        ctc_cli_packet_tx_tp_y1731_cmd,
        "packet tx tp-y1731 dest-gport GPHYPORT_ID (nhid NHID|dsnh-offset OFFSET) ttl TTL (pw (gal|)|lsp|section) ((lbm|lbr) | (1dm|dmm|dmr) (dm-ts-offset OFFSET)) (dma|)",
        CTC_CLI_PACKET_M_STR,
        "Send packet",
        "TP-Y1731 OAM",
        "Destination gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Set NH ID",
        CTC_CLI_NH_ID_STR,
        "Set DSNH offset",
        "DSNH offset value",
        "Ttl",
        "Ttl value",
        "PW Label",
        "PW has GAL",
        "LSP Label",
        "Section",
        "LBM",
        "LBR",
        "1DM",
        "DMM",
        "DMR",
        "Set DM timestamp offset",
        "Offset value in bytes",
        "DMA mode")
{
    static uint8 pkt_buf_lbm[100] = {
        0x10, 0x00, 0x89, 0x02, 0xe0, 0x03, 0x00, 0x04, 0x00, 0x00, 0x00, 0x02, 0x21, 0x00, 0x19, 0x02,
        0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_lbr[100] = {
        0x10, 0x00, 0x89, 0x02, 0xe0, 0x02, 0x00, 0x04, 0x00, 0x00, 0x00, 0x02, 0x22, 0x00, 0x19, 0x02,
        0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_1dm[100] = {
        0x10, 0x00, 0x89, 0x02, 0xe0, 0x2d, 0x00, 0x10, 0x50, 0xf6, 0x1e, 0x74, 0x1a, 0x3b, 0xb6, 0xa8,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_dmm[100] = {
        0x10, 0x00, 0x89, 0x02, 0xe0, 0x2f, 0x00, 0x20, 0x50, 0xf6, 0x1f, 0xcb, 0x29, 0xb8, 0xc5, 0x58,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    static uint8 pkt_buf_dmr[100] = {
        0x10, 0x00, 0x89, 0x02, 0xe0, 0x2e, 0x00, 0x20, 0x50, 0xf6, 0x1f, 0xcb, 0x29, 0xb8, 0xc5, 0x58,
        0x50, 0xf6, 0x1f, 0xcb, 0x2b, 0x7a, 0x53, 0x48, 0x50, 0xf6, 0x1f, 0xcb, 0x2b, 0xe3, 0x5a, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    };

    int32 idx1 = 0;
    static uint8 pkt_buffer[256];
    uint8* pkt_buf = pkt_buffer;
    uint8* p_pkt = pkt_buf;
    static ctc_pkt_tx_t pkt_tx;
    ctc_pkt_tx_t* p_pkt_tx = &pkt_tx;
    ctc_pkt_info_t* p_tx_info = &(p_pkt_tx->tx_info);
    ctc_pkt_skb_t* p_skb = &(p_pkt_tx->skb);
    uint8* p_data = NULL;
    uint32 pkt_len = 64;
    uint16 dest_gport = 0;
    int32 ret = 0;
    uint32 is_dm = FALSE;
    uint32 is_link = FALSE;
    uint32 has_gal = FALSE;
    uint32 has_cw = FALSE;
    uint32 dm_ts_offset = 0;
    uint32 pkt_type_base = 5;
    uint32 nh_id = 0;
    uint32 ttl = 0;
    ctc_nh_info_t nh_info;

    sal_memset(&nh_info, 0, sizeof(ctc_nh_info_t));
    sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
    pkt_tx.mode = CTC_PKT_MODE_ETH;

    /* destmap */
    CTC_CLI_GET_UINT32("dest_gport", dest_gport, argv[0]);
    CTC_PORT_MAPPING(dest_gport,1);
    p_tx_info->dest_gport = dest_gport;

    if (sal_strncmp(argv[1], "nhid", 4) == 0)
    {
        CTC_CLI_GET_UINT32("nhid", nh_id, argv[2]);
        ret = ctc_nh_get_nh_info(nh_id, &nh_info);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
        p_tx_info->flags |= CTC_PKT_FLAG_NH_OFFSET_VALID;
        p_tx_info->nh_offset = nh_info.dsnh_offset[0];

        if (CTC_FLAG_ISSET(nh_info.flag, CTC_NH_INFO_FLAG_IS_DSNH8W))
        {
            CTC_SET_FLAG(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_IS_8W);
        }
    }
    else if (sal_strncmp(argv[1], "dsnh", 4) == 0)
    {
        p_tx_info->flags |= CTC_PKT_FLAG_NH_OFFSET_VALID;
        CTC_CLI_GET_UINT32("nh-offset", p_tx_info->nh_offset, argv[2]);
    }

    CTC_CLI_GET_UINT32("TTL", ttl, argv[3]);
    p_tx_info->ttl = ttl;

    /* get nexthopptr info */
    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "pw", sal_strlen("pw"));
    if (0xFF != idx1)
    {
        has_cw = TRUE;
        idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "gal", sal_strlen("gal"));
        if (0xFF != idx1)
        {
            has_gal = TRUE;
            pkt_type_base += 1;
        }
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "lsp", sal_strlen("lsp"));
    if (0xFF != idx1)
    {
        has_gal = TRUE;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "section", sal_strlen("section"));
    if (0xFF != idx1)
    {
        has_gal = TRUE;
        is_link = TRUE;
    }

    idx1 = ctc_cli_get_prefix_item(&argv[0], argc, "dma", sal_strlen("dma"));
    if (0xFF != idx1)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
    }

    /* must be evaluated field */
    p_tx_info->oper_type = CTC_PKT_OPER_OAM;
    p_tx_info->is_critical = TRUE;

    p_tx_info->oam.type = CTC_OAM_TYPE_ACH;

    if (is_link)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM);
    }
    if (has_gal)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL);
        CTC_CLI_PKT_PUSH_LABEL(p_pkt, CTC_CLI_PKT_ALERT_LABEL_13, 0, TRUE, 1);
    }
    if (has_cw)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_CW);
    }


    /* packet type */
    if (sal_strncmp(argv[pkt_type_base + 0], "lbm", 3) == 0)
    {
        sal_memcpy(p_pkt, pkt_buf_lbm, pkt_len);
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "lbr", 3) == 0)
    {
        sal_memcpy(p_pkt, pkt_buf_lbr, pkt_len);
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "1dm", 3) == 0)
    {
        sal_memcpy(p_pkt, pkt_buf_1dm, pkt_len);
        is_dm = TRUE;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "dmm", 3) == 0)
    {
        sal_memcpy(p_pkt, pkt_buf_dmm, pkt_len);
        is_dm = TRUE;
    }
    else if (sal_strncmp(argv[pkt_type_base + 0], "dmr", 3) == 0)
    {
        sal_memcpy(p_pkt, pkt_buf_dmr, pkt_len);
        is_dm = TRUE;
    }

    if (is_dm)
    {
        CTC_SET_FLAG(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM);
        CTC_CLI_GET_UINT32("offset", dm_ts_offset, argv[pkt_type_base + 2]);
        p_tx_info->oam.dm_ts_offset = dm_ts_offset;
    }

    /* send packet by encap info */
    ctc_packet_skb_init(p_skb);
    p_data = ctc_packet_skb_put(p_skb, pkt_len);
    sal_memcpy(p_data, pkt_buf, pkt_len);
    ret = ctc_packet_tx(p_pkt_tx);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

int32
ctc_packet_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_packet_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_debug_show_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_tx_uc_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_tx_mc_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_tx_eth_oam_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_tx_ingress_ipuc_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_packet_tx_tp_y1731_cmd);

    return 0;
}
