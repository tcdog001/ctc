
#ifndef _CTC_HUMBER_CHIP_DBG_H_
#define _CTC_HUMBER_CHIP_DBG_H_
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************************
 *
* add by jcao start
*
****************************************************************************/

/*show humber <0-1> (gmac|xgmac|qmac|muxnetrxtx|ipe|fwd|epe|cpumac|eloop|fabric|interrupt|internal|oam) (all|INDEX) */
#define SHOW_HUMBER_STATS_CMD          0x05090000
#define SHOW_HUMBER_STATS_CHIP_ID      0x05090001
#define SHOW_HUMBER_STATS_GMAC         0x05090002
#define SHOW_HUMBER_STATS_XGMAC        0x05090003
#define SHOW_HUMBER_STATS_QMAC         0x05090004
#define SHOW_HUMBER_STATS_MUXNETRXTX   0x05090005
#define SHOW_HUMBER_STATS_IPE          0x05090006
#define SHOW_HUMBER_STATS_FWD          0x05090007
#define SHOW_HUMBER_STATS_EPE          0x05090008
#define SHOW_HUMBER_STATS_CPUMAC       0x05090009
#define SHOW_HUMBER_STATS_ELOOP        0x0509000a
#define SHOW_HUMBER_STATS_FABRIC       0x0509000b
#define SHOW_HUMBER_STATS_INTERRUPT    0x0509000c
#define SHOW_HUMBER_STATS_INTERNAL     0x0509000d
#define SHOW_HUMBER_STATS_OAM            0x0509000e
#define SHOW_HUMBER_STATS_PARSER       0x0509000f
#define SHOW_HUMBER_STATS_SHAREDS      0x05090010
#define SHOW_HUMBER_STATS_TBINFOARB    0x05090011
#define SHOW_HUMBER_STATS_TCAM         0x05090012
#define SHOW_HUMBER_STATS_QUEUEIDMON   0x05090013
#define SHOW_HUMBER_STATS_QUEUEDEPTH   0x05090014
#define SHOW_HUMBER_STATS_SGMAC        0x05090015
#define SHOW_HUMBER_STATS_HASHDS       0x05090016
#define SHOW_HUMBER_STATS_DISCARDTYPE  0x05090017
#define SHOW_HUMBER_STATS_ALL          0x05090018
#define SHOW_HUMBER_STATS_INDEX        0x05090019

/*show humber <chip_id> bus {busHa2Im|busIm2LmPI|busIm2LmPR|busLm2PpPI|busLm2PpPR|busMfEnqMsgFifo|
ha2NhPiBus|Nh2HpPiBus|Pr2HpPrBus|aqos2EditPiBus|cla2EditPiBus} START-MSG MSG-NUM */
#define SHOW_HUMBER_STATS_BUS             0x0509001a
#define SHOW_HUMBER_BUS_BUSHA2IM          0x0509001b
#define SHOW_HUMBER_BUS_BUSIM2LMPI        0x0509001c
#define SHOW_HUMBER_BUS_BUSIM2LMPR        0x0509001d
#define SHOW_HUMBER_BUS_BUSLM2PPPI        0x0509001e
#define SHOW_HUMBER_BUS_BUSLM2PPPR        0x0509001f
#define SHOW_HUMBER_BUS_BUSMFENQMSGFIFO   0x05090020
#define SHOW_HUMBER_BUS_HA2NHPIBUS        0x05090021
#define SHOW_HUMBER_BUS_NH2HPPIBUS        0x05090022
#define SHOW_HUMBER_BUS_PR2HPPRBUS        0x05090023
#define SHOW_HUMBER_BUS_AQOS2EDITPIBUS    0x05090024
#define SHOW_HUMBER_BUS_CLA2EDITPIBUS     0x05090025
#define SHOW_HUMBER_BUS_START_MSG         0x05090026
#define SHOW_HUMBER_BUS_MSG_NUM           0x05090027

/*run bist humber <0-1> (ddr|qdr|tcam) (LATENCY|)*/
#define RUN_BIST_HUMBER_CMD         0x05090100
#define RUN_BIST_HUMBER_CHIP_ID     0x05090101
#define RUN_BIST_HUMBER_DDR         0x05090102
#define RUN_BIST_HUMBER_QDR         0x05090103
#define RUN_BIST_HUMBER_TCAM        0x05090104
#define RUN_BIST_HUMBER_LATENCY     0x05090105
#define RUN_BIST_HUMBER_EXT_TCAM    0x05090106

/*check bist humber <0-1> (ddr|qdr|tcam) */
#define CHECK_BIST_HUMBER_CMD         0x05090200
#define CHECK_BIST_HUMBER_CHIP_ID     0x05090201
#define CHECK_BIST_HUMBER_DDR         0x05090202
#define CHECK_BIST_HUMBER_QDR         0x05090203
#define CHECK_BIST_HUMBER_TCAM        0x05090204
#define CHECK_BIST_HUMBER_EXT_TCAM    0x05090205

/* si self-test humber <0-1> (qdr|ddr|tcam)(sso|isi|crosstalk)<0-all,x-case_number><0-once,1-continue><0-normal,1-sweep><0-35/0-79>*/
#define SI_SELFTEST_HUMBER_CMD          0x05090300
#define SI_SELFTEST_HUMBER_CHIP_ID      0x05090301
#define SI_SELFTEST_HUMBER_SELFTEST     0x05090302
#define SI_SELFTEST_HUMBER_QDR          0x05090303
#define SI_SELFTEST_HUMBER_DDR          0x05090304
#define SI_SELFTEST_HUMBER_TCAM         0x05090305
#define SI_SELFTEST_HUMBER_SSO          0x05090306
#define SI_SELFTEST_HUMBER_ISI          0x05090307
#define SI_SELFTEST_HUMBER_CROSSTALK    0x05090308
#define SI_SELFTEST_HUMBER_CASENUMBER   0x05090309
#define SI_SELFTEST_HUMBER_TIMES        0x0509030a
#define SI_SELFTEST_HUMBER_SWEEP        0x0509030b
#define SI_SELFTEST_HUMBER_PINNUMBER    0x0509030c
#define SI_SELFTEST_HUMBER_CONTINUE     0x0509030d
#define SI_SELFTEST_HUMBER_ONCE         0x0509030e
#define SI_SELFTEST_HUMBER_NORMAL       0x0509030f
#define SI_SELFTEST_HUMBER_ALL          0x05090310

/* si probe humber <0-1> (qdr|ddr|tcam)(sso|isi|crosstalk)<x-case_number>(read |write)<0-35/0-79-pin_number>*/
#define SI_PROBE_HUMBER_CMD           0x05090400
#define SI_PROBE_HUMBER_CHIP_ID       0x05090401
#define SI_PROBE_HUMBER_PROBE         0x05090402
#define SI_PROBE_HUMBER_QDR           0x05090403
#define SI_PROBE_HUMBER_DDR           0x05090404
#define SI_PROBE_HUMBER_TCAM          0x05090405
#define SI_PROBE_HUMBER_SSO           0x05090406
#define SI_PROBE_HUMBER_ISI           0x05090407
#define SI_PROBE_HUMBER_CROSSTALK     0x05090408
#define SI_PROBE_HUMBER_CASENUMBER    0x05090409
#define SI_PROBE_HUMBER_READ          0x0509040a
#define SI_PROBE_HUMBER_WRITE         0x0509040b
#define SI_PROBE_HUMBER_PINNUMBER     0x0509040c

/* register walk humber <0-1> internal */
/* register walk humber <0-1> external */
/* register walk humber <0-1> supif */
#define REGISTER_WALK_HUMBER_CMD                    0x05090500
#define REGISTER_WALK_HUMBER_CHIP_ID                0x05090501
#define REGISTER_WALK_HUMBER_INTERNAL               0x05090502
#define REGISTER_WALK_HUMBER_EXTERNAL               0x05090503
#define REGISTER_WALK_HUMBER_SUPIF                  0x05090504

/*test humber <0-1> tcam (mpmiReadLatency |
bistLatency) */
#define TEST_TCAM_READLATENCY_HUMBER_CMD                  0x05090600
#define TEST_TCAM_READLATENCY_HUMBER_CHIP_ID              0x05090601
#define TEST_TCAM_READLATENCY_HUMBER_READLATENCY          0x05090602
#define TEST_TCAM_READLATENCY_HUMBER_BISTLATENCY          0x05090603
#define TEST_TCAM_READLATENCY_HUMBER_TCAM                 0x05090604

/*test sram humber <0-1> (ddr |qdr) (bistLatency |readLatency) */
#define TEST_SRAM_BISTLATENCY_HUMBER_CMD                  0x05090700
#define TEST_SRAM_BISTLATENCY_HUMBER_CHIP_ID              0x05090701
#define TEST_SRAM_BISTLATENCY_HUMBER_DDRLATENCY           0x05090702
#define TEST_SRAM_BISTLATENCY_HUMBER_QDRLATENCY           0x05090703
#define TEST_SRAM_BISTLATENCY_HUMBER_SRAM                 0x05090704
#define TEST_SRAM_BISTLATENCY_HUMBER_BISTLATENCY          0x05090705
#define TEST_SRAM_BISTLATENCY_HUMBER_READLATENCY          0x05090706

/*test humber <0-1> (ddr |qdr) (dataPopLatency|readValidLatency) */

#define TEST_SRAM_LATENCY_HUMBER_CMD                       0x05090800
#define TEST_SRAM_LATENCY_HUMBER_CHIP_ID                   0x05090801
#define TEST_SRAM_LATENCY_HUMBER_DDRLATENCY                0x05090802
#define TEST_SRAM_LATENCY_HUMBER_QDRLATENCY                0x05090803
#define TEST_SRAM_LATENCY_HUMBER_DATAPOPLATENCY            0x05090804
#define TEST_SRAM_LATENCY_HUMBER_READVALIDRLATENCY         0x05090805

/*run/check humber <chip_id> {extcam|intcam|ddr|qdr}*/

/*run capture humber <chip_id> {extcam|intcam|ddr|qdr}*/
#define RUN_CAPTURE_HUMBER_CMD         0x05100000
#define RUN_CAPTURE_HUMBER_RUN         0x05100001
#define RUN_CAPTURE_HUMBER_CAPTURE     0x05100002
#define RUN_CAPTURE_HUMBER_HUMBER      0x05100003
#define RUN_CAPTURE_HUMBER_CHIPID      0x05100004
#define RUN_CAPTURE_HUMBER_EXTCAM      0x05100005
#define RUN_CAPTURE_HUMBER_INTCAM      0x05100006
#define RUN_CAPTURE_HUMBER_DDR         0x05100007
#define RUN_CAPTURE_HUMBER_QDR         0x05100008

/*check capture humber <chip_id> {extcam|intcam|ddr|qdr}*/
#define CHECK_CAPTURE_HUMBER_CMD       0x05110000
#define CHECK_CAPTURE_HUMBER_CHECK     0x05110001
#define CHECK_CAPTURE_HUMBER_CAPTURE   0x05110002
#define CHECK_CAPTURE_HUMBER_HUMBER    0x05110003
#define CHECK_CAPTURE_HUMBER_CHIPID    0x05110004
#define CHECK_CAPTURE_HUMBER_EXTCAM    0x05110005
#define CHECK_CAPTURE_HUMBER_INTCAM    0x05110006
#define CHECK_CAPTURE_HUMBER_DDR       0x05110007
#define CHECK_CAPTURE_HUMBER_QDR       0x05110008

/*tcam write humber <chip_id> entry  <index> DATA  MASK <0-internal,1-external>*/
/*tcam write humber <chip_id> register  <index> VALUE*/
#define TCAM_WRITE_HUMBER_CMD           0x05110100
#define TCAM_WRITE_HUMBER_TCAM          0x05110101
#define TCAM_WRITE_HUMBER_WRITE         0x05110102
#define TCAM_WRITE_HUMBER_ENTRY         0x05110103
#define TCAM_WRITE_HUMBER_REGISTER      0x05110104
#define TCAM_WRITE_HUMBER_HUMBER        0x05110105
#define TCAM_WRITE_HUMBER_CHIPID        0x05110106
#define TCAM_WRITE_HUMBER_INDEX         0x05110107
#define TCAM_WRITE_HUMBER_DATA          0x05110108
#define TCAM_WRITE_HUMBER_MASK          0x05110109
#define TCAM_WRITE_HUMBER_VALUE         0x0511010A
#define TCAM_WRITE_HUMBER_TYPE         0x0511010B

/*tcam read humber <chip_id> entry  <index> <0-internal,1-external>*/
/*tcam read humber <chip_id> register <index>*/
#define TCAM_READ_HUMBER_CMD            0x05110200
#define TCAM_READ_HUMBER_TCAM           0x05110201
#define TCAM_READ_HUMBER_READ           0x05110202
#define TCAM_READ_HUMBER_ENTRY          0x05110203
#define TCAM_READ_HUMBER_REGISTER       0x05110204
#define TCAM_READ_HUMBER_HUMBER         0x05110205
#define TCAM_READ_HUMBER_CHIPID         0x05110206
#define TCAM_READ_HUMBER_INDEX          0x05110207
#define TCAM_READ_HUMBER_TYPE          0x05110208

/*config humber <chip_id> 4G Eq <Eq_vlalue>  Amp <Amp_vlalue> Slew <Slew_vlalue> Coef <Coef_vlalue> (all|Port_num)*/
/*config humber <chip_id> 6G coe0 <coe0_vlalue>  coe1 <coe1_vlalue> coe2 <coe2_vlalue> coe3 <coe3_vlalue> polarity <polarity_vlalue> (all|Port_num)*/
#define CONFIG_HUMBER_HSS_CMD                       0x05110300
#define CONFIG_HUMBER_HSS_CONFIG                    0x05110301
#define CONFIG_HUMBER_HSS_HUMBER                    0x05110302
#define CONFIG_HUMBER_HSS_CHIPID                    0x05110303
#define CONFIG_HUMBER_HSS_4G                        0x05110304
#define CONFIG_HUMBER_HSS_6G                        0x05110305
#define CONFIG_HUMBER_HSS_4G_EQ                     0x05110306
#define CONFIG_HUMBER_HSS_4G_EQ_VALUE               0x05110307
#define CONFIG_HUMBER_HSS_4G_AMP                    0x05110308
#define CONFIG_HUMBER_HSS_4G_AMP_VALUE              0x05110309
#define CONFIG_HUMBER_HSS_4G_SLEW                   0x0511030A
#define CONFIG_HUMBER_HSS_4G_SLEW_VALUE             0x0511030B
#define CONFIG_HUMBER_HSS_4G_COEF                   0x0511030C
#define CONFIG_HUMBER_HSS_4G_COEF_VALUE             0x0511030D
#define CONFIG_HUMBER_HSS_6G_COE0                   0x0511030E
#define CONFIG_HUMBER_HSS_6G_COE0_VALUE             0x0511030F
#define CONFIG_HUMBER_HSS_6G_COE1                   0x05110310
#define CONFIG_HUMBER_HSS_6G_COE1_VALUE             0x05110311
#define CONFIG_HUMBER_HSS_6G_COE2                   0x05110312
#define CONFIG_HUMBER_HSS_6G_COE2_VALUE             0x05110313
#define CONFIG_HUMBER_HSS_6G_COE3                   0x05110314
#define CONFIG_HUMBER_HSS_6G_COE3_VALUE             0x05110315
#define CONFIG_HUMBER_HSS_6G_POLARITY               0x05110316
#define CONFIG_HUMBER_HSS_6G_POLARITY_VALUE         0x05110317
#define CONFIG_HUMBER_HSS_ALL                       0x05110318
#define CONFIG_HUMBER_HSS_PORTNUM                   0x05110319
#define CONFIG_HUMBER_HSS_PORTNUM_VALUE             0x0511031A

/****************************************************************************
 *
* add by jcao end
*
****************************************************************************/

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/
#define DDR_DFT_BISTEXP_LATENCY     6
#define QDR_DFT_BISTEXP_LATENCY     6
#define EXT_TCAM_DFT_BISTEXP_LATENCY    0x25   /*external tcam*/
#define INT_TCAM_DFT_BISTEXP_LATENCY    0   /*internal tcam*/

#define DDR_MAX_ENTRY_NUM       64
#define TEST_SECOND 100

#define DDR_CONTROL_ADDR         0x0cc00000
#define DDR_BISTCTRL_ADDR        0x0cc00008
#define DDR_BISTINIT_ADDR        0x0cc00020
#define DDR_BISTREQRAM_ADDR      0x0cc01800
#define DDR_BISTEXPRAM_ADDR      0x0cc01400
#define DDR_BISTRLTRAM_ADDR      0x0cc01000

#define QDR_CONTROL_ADDR         0x0e000000
#define QDR_BISTCTRL_ADDR        0x0e000008
#define QDR_BISTINIT_ADDR        0x0e000020
#define QDR_BISTREQRAM_ADDR      0x0e001800
#define QDR_BISTEXPRAM_ADDR      0x0e001400
#define QDR_BISTRLTRAM_ADDR      0x0e001000

#define EXT_TCAM_CTRL_SETUP      0x0b800000
#define EXT_TCAM_BISTCTRL_ADDR   0x0b800070
#define EXT_TCAM_BISTINIT_ADDR   0x0b800050
#define EXT_TCAM_BISTREQRAM_ADDR 0x0b801000
#define EXT_TCAM_BISTEXPRAM_ADDR 0x0b801a00
#define EXT_TCAM_BISTRLTRAM_ADDR 0x0b801800

#define EXT_TCAM_ACCESS_ADDR      0x0b800004
#define EXT_TCAM_WRITEDATA_ADDR   0x0b800010
#define EXT_TCAM_READDATA_ADDR    0x0b800030

#define EXT_TCAM_WRITEMASK_ADDR      0x0b800020

#define INT_TCAM_BISTCTRL_ADDR   0x0bc00040
#define INT_TCAM_BISTINIT_ADDR   0x0bc00050
#define INT_TCAM_BISTREQRAM_ADDR 0x0bc01000
#define INT_TCAM_BISTEXPRAM_ADDR 0x0bc01800
#define INT_TCAM_BISTRLTRAM_ADDR 0x0bc01a00

#define INT_TCAM_KEYSIZECFG_ADDR 0x0bc001b0
#define INT_TCAM_KEYTYPECFG_ADDR 0x0bc001C0

#define INT_TCAM_ACCESS_ADDR      0x0bc00004
#define INT_TCAM_WRITEDATA_ADDR   0x0bc00010
#define INT_TCAM_WRITEMASK_ADDR   0x0bc00020

#define DDR_SRAM_BASE 0x05000000
#define QDR_SRAM_BASE 0x0f000000

#define CHSM_HUMBER_MAX_INT_MODULE 135
#define CHSM_HUMBER_MAX_BUS_MESSAGE 11
#define TCAM_BIST_MAX_ENTRY 64
#define SRAM_BIST_MAX_ENTRY 64

#define DDR_BISTRLTRAM_ADDR      0x0cc01000
#define DDR_BISTCTRL_ADDR        0x0cc00008
#define DDR_BISTREQRAM_ADDR      0x0cc01800
#define QDR_BISTRLTRAM_ADDR      0x0e001000
#define QDR_BISTCTRL_ADDR        0x0e000008
#define QDR_BISTREQRAM_ADDR      0x0e001800
#define EXTCAM_BISTRLTRAM_ADDR   0x0b801800
#define EXTCAM_BISTCTRL_ADDR     0x0b800070
#define EXTCAM_BISTREQRAM_ADDR   0x0b801000
#define INTCAM_BISTRLTRAM_ADDR   0x0bc01a00
#define INTCAM_BISTCTRL_ADDR     0x0bc00040
#define INTCAM_BISTREQRAM_ADDR   0x0bc01000

#define DDR_SRAM_BASE 0x05000000
#define QDR_SRAM_BASE 0x0f000000

#define BIST_ITERATION_ADDRESS_ADD 0x100

#define ctc_sgmac_PLUS_HEADER_LEN    12
#define ctc_sgmac2_HEADER_LEN            16

struct tcam_bist_control_struct
{
    uint32 cfgBistMismatchCount : 16;
    uint32 rsv1                 : 2;
    uint32 trainingEn           : 1;
    uint32 cfgCaptureEn         : 1;
    uint32 cfgCaptureOnce       : 1;
    uint32 cfgBistEn            : 1;
    uint32 cfgStopOnError       : 1;
    uint32 cfgBistOnce          : 1;
    uint32 rsv2                 : 2;
    uint32 cfgBistEntries       : 6;

    uint32 rsv3                 : 25;
    uint32 expectLatency        : 7;
};
typedef struct tcam_bist_control_struct tcam_bist_control_struct_t;

struct tcam_bist_req_ram_struct
{
    uint32 key_valid    : 1;
    uint32 rsv1         : 21;
    uint32 keySize      : 2;
    uint32 keyCmd       : 8;

    uint32 rsv2         : 16;
    uint32 key159To144  : 16;

    uint32 key143To112  : 32;

    uint32 key111To80   : 32;

    uint32 rsv3         : 32;

    uint32 rsv4         : 16;
    uint32 key79To64    : 16;

    uint32 key63To32    : 32;

    uint32 key31To0     : 32;
};
typedef struct tcam_bist_req_ram_struct tcam_bist_req_ram_struct_t;

struct tcam_bist_result_ram_struct
{
    uint32 resultCompareValid       : 1;
    uint32 rsv1                     : 6;
    uint32 indexValid               : 1;
    uint32 rsv2                     : 3;
    uint32 indexAclCompEn           : 1;
    uint32 indexAcl                 : 20;

    uint32 rsv3                     : 11;
    uint32 indexQosCompEn           : 1;
    uint32 indexQos                 : 20;
};
typedef struct tcam_bist_result_ram_struct tcam_bist_result_ram_struct_t;

union tcam_bist_control_union
{
    uint32 bist_control[2];
    tcam_bist_control_struct_t bistControl;
};
typedef union tcam_bist_control_union tcam_bist_control_union_t;

union tcam_bist_req_ram_union
{
    uint32 result_ram[8];
    tcam_bist_req_ram_struct_t bistRequest;
};
typedef union tcam_bist_req_ram_union tcam_bist_req_ram_union_t;

union tcam_bist_result_ram_union
{
    uint32 result_ram[2];
    tcam_bist_result_ram_struct_t bistResult;
};
typedef union tcam_bist_result_ram_union tcam_bist_result_ram_union_t;

enum direction
{
    HOST_2_NETWORK,
    NETWORK_2_HOST
};

#define DDR_ITERATION 1

struct bist_entry_s
{
    uint32  address;
    uint8   ramData71_68;
    uint32  ramData67_36;
    uint8   ramData35_32;
    uint32  ramData31_0;
};
typedef struct bist_entry_s bist_entry_t;

#define ITEM_NAME_MAX 100
struct bist_pin_entry_s
{
    bist_entry_t* data;
    char item_name[ ITEM_NAME_MAX];

    uint8 entry_num;
};
typedef struct bist_pin_entry_s bist_pin_entry_t;

struct bist_case_entry_s
{
    bist_pin_entry_t* case_data;
    uint8 case_entry;
};

typedef struct bist_case_entry_s bist_case_entry_t;

struct tcam_bist_pin_entry_s
{
    char* data_0;
    char* data_1;
    char item_name[ ITEM_NAME_MAX];
    char* data_2;
    char* data_3;
};
typedef struct tcam_bist_pin_entry_s tcam_bist_pin_entry_t;

struct tcam_bist_case_entry_s
{
    tcam_bist_pin_entry_t* case_data;
    uint8 case_entry;
};

typedef struct tcam_bist_case_entry_s tcam_bist_case_entry_t;

/*show humber <0-1> (gmac|xgmac|qmac|muxnetrxtx|ipe|fwd|epe|cpumac|eloop|fabric|interrupt|internal) (all|INDEX) */

enum show_stats_id
{
    GMAC_T = 2,
    XGMAC_T,
    QMAC_T,
    MUXNETRXTX_T,
    IPE_T,
    FWD_T,
    EPE_T,
    CPUMAC_T,
    ELOOP_T,
    FABRIC_T,
    INTERRUPT_T,
    INTERNAL_T,
    OAM_T,
    PARSER_T,
    SHAREDS_T,
    TBINFOARB_T,
    TCAM_T,
    QUEUEIDMON_T,
    QUEUEDEPTH_T,
    SGMAC_T,
    HASHDS_T,
    DISCARDTYPE_T,
    BUS_T
};

enum bist_type_id
{
    DDR_BIST_T = 0,
    QDR_BIST_T,
    TCAM_BIST_T
};

enum si_bist_test_id
{
    SSO_SI_T = 0,
    ISI_SI_T,
    CROSSTALK_SI_T
};

enum si_bist_device_id
{
    DDR_SI_T = 0,
    QDR_SI_T,
    TCAM_SI_T
};

enum
{
    BIST_ERROR_ON_WRITE = -3,
    BIST_ERROR_ON_READ = -2,
    BIST_ERROR_ON_OTHER   =  -1,
    BIST_NO_ERROR   = 0,
};

enum capture_humber_info
{
    EXTCAM = 2,
    INTCAM,
    DDR,
    QDR
};

enum show_humber_bus_info
{
    BUSHA2IM = 2,
    BUSIM2LMPI,
    BUSIM2LMPR,
    BUSLM2PPPI,
    BUSLM2PPPR,
    BUSMFENQMSGFIFO,
    HA2NHPIBUS,
    NH2HPPIBUS,
    PR2HPPRBUS,
    AQOS2EDITPIBUS,
    CLA2EDITPIBUS
};

struct ctc_sgmac_plus_header_s
{
    uint32 ctc_sgmac_plus_start                                                                    : 8;
    uint32 ctc_sgmac_plus_hgi                                                                       : 2;
    uint32 ctc_sgmac_plus_rsv1                                                                      : 1;
    uint32 ctc_sgmac_plus_hdr_ext_len                                                         : 3;
    uint32 ctc_sgmac_plus_src_modid_6                                                        : 1;
    uint32 ctc_sgmac_plus_dst_modid_6                                                        : 1;
    uint32 ctc_sgmac_plus_vid_high                                                               : 8;
    uint32 ctc_sgmac_plus_vid_low                                                                : 8;
    uint32 ctc_sgmac_plus_src_modid                                                            : 5;
    uint32 ctc_sgmac_plus_opcode                                                                 : 3;
    uint32 ctc_sgmac_plus_pfm                                                                      : 2;
    uint32 ctc_sgmac_plus_src_pid                                                                 : 6;
    uint32 ctc_sgmac_plus_dst_port                                                               : 5;
    uint32 ctc_sgmac_plus_cos                                                                       : 3;
    uint32 ctc_sgmac_plus_header_type                                                        : 2;
    uint32 ctc_sgmac_plus_cng                                                                       : 1;
    uint32 ctc_sgmac_plus_dst_modid                                                            : 5;
    /*  uint32 ctc_sgmac_plus_ppd_type                                                              :3;*/
    uint32 ctc_sgmac_plus_dst_t                                                                     : 1;
    uint32 ctc_sgmac_plus_dst_tgid                                                                : 3;
    uint32 ctc_sgmac_plus_ingress_tagged                                                    : 1;
    uint32 ctc_sgmac_plus_mirror_only                                                          : 1;
    uint32 ctc_sgmac_plus_mirror_done                                                         : 1;
    uint32 ctc_sgmac_plus_mirror                                                                   : 1;
    uint32 ctc_sgmac_plus_src_mod_5                                                            : 1;
    uint32 ctc_sgmac_plus_dst_mod_5                                                            : 1;
    uint32 ctc_sgmac_plus_l3                                                                           : 1;
    uint32 ctc_sgmac_plus_label_present                                                       : 1;
    uint32 ctc_sgmac_plus_vc_label_19_16                                                    : 4;
    uint32 ctc_sgmac_plus_vc_label_15_8                                                      : 8;
    uint32 ctc_sgmac_plus_vc_label_7_0                                                        : 8;
};

union ctc_sgmac2_header_u
{
    struct
    {
        uint8 byte[16];
    } overlay0;
    struct      /*ppd type 0*/
    {uint32 ctc_sgmac2_sop               : 8;
     uint32 ctc_sgmac2_rsv1              : 3;
     uint32 ctc_sgmac2_mcst              : 1;
     uint32 ctc_sgmac2_tc                : 4;
     uint32 ctc_sgmac2_dst_modid_mgidh   : 8;
     uint32 ctc_sgmac2_dst_port_mgidl    : 8;
     uint32 ctc_sgmac2_src_modid         : 8;
     uint32 ctc_sgmac2_src_pid           : 8;
     uint32 ctc_sgmac2_lbid              : 8;
     uint32 ctc_sgmac2_dp                : 2;
     uint32 ctc_sgmac2_rsvd_6            : 3;
     uint32 ctc_sgmac2_ppd_ty            : 3;
     uint32 ctc_sgmac2_dst_t             : 1;
     uint32 ctc_sgmac2_dst_tgid          : 3;
     uint32 ctc_sgmac2_ingress_tagged    : 1;
     uint32 ctc_sgmac2_mirror_only       : 1;
     uint32 ctc_sgmac2_mirror_done       : 1;
     uint32 ctc_sgmac2_mirror            : 1;
     uint32 ctc_sgmac2_rsvd_55_54        : 2;
     uint32 ctc_sgmac2_l3                : 1;
     uint32 ctc_sgmac2_label_precent     : 1;
     uint32 ctc_sgmac2_vc_label_19_16    : 4;
     uint32 ctc_sgmac2_vc_label_15_8     : 8;
     uint32 ctc_sgmac2_vc_label_7_0      : 8;
     uint32 ctc_sgmac2_vid_high          : 8;
     uint32 ctc_sgmac2_vid_low           : 8;
     uint32 ctc_sgmac2_pfm               : 2;
     uint32 ctc_sgmac2_src_t             : 1;
     uint32 ctc_sgmac2_rsvd_12_11        : 2;
     uint32 ctc_sgmac2_opcode            : 3;
     uint32 ctc_sgmac2_hdr_ext_len       : 3;
     uint32 ctc_sgmac2_rsvd_4_0          : 5;
    } ppd_ty0;

    struct      /*ppd type 2*/
    {uint32 ctc_sgmac2_sop               : 8;
     uint32 ctc_sgmac2_rsv1              : 3;
     uint32 ctc_sgmac2_mcst              : 1;
     uint32 ctc_sgmac2_tc                : 4;
     uint32 ctc_sgmac2_dst_modid_mgidh   : 8;
     uint32 ctc_sgmac2_dst_port_mgidl    : 8;
     uint32 ctc_sgmac2_src_modid         : 8;
     uint32 ctc_sgmac2_src_pid           : 8;
     uint32 ctc_sgmac2_lbid              : 8;
     uint32 ctc_sgmac2_dp                : 2;
     uint32 ctc_sgmac2_rsvd_6            : 3;
     uint32 ctc_sgmac2_ppd_ty            : 3;
     uint32 ctc_sgmac2_multi_point       : 1;
     uint32 ctc_sgmac2_fwd_type          : 5;
     uint32 ctc_sgmac2_rsvd_25_16        : 10;
     uint32 ctc_sgmac2_dest_vp_high      : 8;
     uint32 ctc_sgmac2_dest_vp_low       : 8;
     uint32 ctc_sgmac2_src_vp_high       : 8;
     uint32 ctc_sgmac2_src_vp_low        : 8;
     uint32 ctc_sgmac2_mirror            : 1;
     uint32 ctc_sgmac2_donot_modify      : 1;
     uint32 ctc_sgmac2_donot_learn       : 1;
     uint32 ctc_sgmac2_lag_failover      : 1;
     uint32 ctc_sgmac2_rsvd_11           : 1;
     uint32 ctc_sgmac2_opcode            : 3;
     uint32 ctc_sgmac2_rsvd_7_0          : 8;
    } ppd_ty2;
};

typedef struct ctc_sgmac_plus_header_s ctc_sgmac_plus_header_t;
typedef union ctc_sgmac2_header_u ctc_sgmac2_header_t;

typedef struct ctc_humber_fatal_field_s
{
    char* string;
    uint16 bit;
    uint16 reset_humber;
    uint16 mask_off;
} ctc_humber_fatal_field_t;

typedef struct humber_fatal_reg_s
{
    char* module_name;
    uint32   value_reg_addr;
    uint32   value_mask;
    uint32   value_reset_reg_addr;
    uint32   value_mask_reset_reg_addr;
    uint32   init_mask_value;
    uint32   reset_value;
    ctc_humber_fatal_field_t* module_field;
    uint8    field_len;
} ctc_humber_fatal_reg_t;

typedef struct ctc_humber_bus_field_s
{
    char* field_name;
    uint16 start_bit;
    uint16 stop_bit;

} ctc_humber_bus_field_t;

typedef struct ctc_humber_bus_message_s
{
    char* bus_name;
    uint32 start_addr;
    uint8 entry_num;
    uint8 word_num;
    uint8 invalid;
    uint8 max_msg_num;
    ctc_humber_bus_field_t* module_field;
    uint8    field_len;
    uint8    is_seq_num;

} ctc_humber_bus_message_t;

typedef struct ctc_humber_bus_bit_info_s
{
    uint16 start_entry_num;
    uint16 start_word_num;
    uint16 start_offset;
    uint16 stop_entry_num;
    uint16 stop_word_num;
    uint16 stop_offset;

} ctc_humber_bus_bit_info_t;

#define string_to_asccii(a)   ((a) > '9') ? (toupper(a) - 'A' + 10) : ((a) - '0')
#define CON_BREAK(exp)      if (exp) break
/* pointer valid check macro define */
#define PTR_CHECK(ptr) \
    if (NULL == (ptr)) \
    { \
        return -1; \
    }

/****************************************************************************
 *
 * Global and Declarations
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

int32 ctc_humber_diag_run_bist(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_check_bist(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_SI_selftest(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_SI_probe(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_register_walk(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_test_tcamLatency(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_test_sramLatency(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_read_tcam(uint32 session, int32 argc, void* argv);
int32 ctc_humber_diag_write_tcam(uint32 session, int32 argc, void* argv);
int32 swap_32(int* data, int32 len, uint8 direction);
int32 stringtochar(char* str, uint8* buff, int* length);
void ctc_humber_diag_run_ddr_bist(uint32 humber_id, uint32 latency);
void ctc_humber_diag_run_qdr_bist(uint32 humber_id,  uint32 latency);
void ctc_humber_diag_run_ext_tcam_bist(uint32 chip_id, uint32 latency);
void ctc_humber_diag_run_init_tcam_bist(uint32 chip_id, uint32 latency);

int32 ctc_humber_diag_check_ddr_bist_rlt(uint32 humber_id);
int32 ctc_humber_diag_check_qdr_bist_rlt(uint32 humber_id);
int32 ctc_humber_diag_check_ext_tcam_bist_rlt(uint32 humber_id);
int32 ctc_humber_diag_check_init_tcam_bist_rlt(uint32 humber_id);
int32 ctc_humber_diag_config_hss(uint32 session, int32 argc, void* argv);

int32 ctc_humber_diag_tcam_mpmi_read_latency(uint32 humber_id);
int32 ctc_humber_diag_tcam_bistLatency(uint32 humber_id);
int32 ctc_humber_diag_ddr_readLatency(uint32 humber_id);
int32 ctc_humber_diag_qdr_readLatency(uint32 humber_id);

void show_humber_diag_Gmac(uint32 humber_id, uint32 index);
void show_humber_diag_GmacAll(uint32 humber_id);
void show_humber_diag_XGmac(uint32 humber_id, uint32 index);
void show_humber_diag_XGmacAll(uint32 humber_id);
void show_humber_diag_SGmac(uint32 humber_id, uint32 index);
void show_humber_diag_SGmacAll(uint32 humber_id);
void show_humber_diag_Qmac(uint32 humber_id, uint32 index);
void show_humber_diag_QmacAll(uint32 humber_id);
void show_humber_diag_MuxNetRxTx(uint32 humber_id);
void show_humber_diag_Ipe(uint32 humber_id);
void show_humber_diag_Fwd(uint32 humber_id);
void show_humber_diag_Epe(uint32 humber_id);
void show_humber_diag_CpuMac(uint32 humber_id);
void show_humber_diag_Eloop(uint32 humber_id);
void show_humber_diag_Fabric(uint32 humber_id);
void show_humber_diag_Oam(uint32 humber_id);
void show_humber_diag_Parser(uint32 humber_id);
void show_humber_diag_ShareDs(uint32 humber_id);
void show_humber_diag_TbInfoArb(uint32 humber_id);
void show_humber_diag_Tcam(uint32 humber_id);
void show_humber_diag_QueueIdMon(uint32 humber_id);
void show_humber_diag_QueueDepth(uint32 humber_id);
void show_humber_diag_HashDs(uint32 humber_id);
void show_humber_diag_DiscardType(uint32 humber_id);
void show_humber_diag_Interrupt(uint32 humber_id);
void show_humber_diag_Sgmaclink(uint32 humber_id);

void clear_humber_diag_DiscardType(uint32 humber_id);

void ctc_humber_diag_start_capture_sram(uint8 humber_id, uint8 type);
void ctc_humber_diag_start_capture_tcam(uint8 humber_id, uint8 type);
void ctc_humber_diag_stop_capture_sram(uint8 humber_id, uint8 type);
void ctc_humber_diag_stop_capture_tcam(uint8 humber_id, uint8 type);
int32 show_humber_diag_bus_get_bits_info(uint8 max_word_num, uint8 invalid, uint16 bit, uint8* bit_entry_num, uint8* bit_word_num, uint8* offset);
int32 show_humber_diag_bus_one_msg_info(uint8 humber_id, ctc_humber_bus_message_t* p_bus_msg, uint32 addr, uint8 addr_word_num);
int32 show_humber_diag_ha2NhPiBus_bus_one_msg_info(uint8 humber_id, ctc_humber_bus_message_t* p_bus_msg, uint32 addr, uint8 addr_word_num);
int32 show_humber_diag_bus_info(uint8 humber_id, ctc_humber_bus_message_t* p_bus_msg, uint32 start_msg, uint32 msg_num);
void  show_humber_diag_Internal(uint8 humber_id);

int32 ctc_humber_diag_ext_tcam_write(uint8 chip_id, int* data, int* mask, uint32 index, uint8 is_register);
int32 ctc_humber_diag_int_tcam_write(uint8 chip_id, int* data, int* mask, uint32 index, uint8 is_register);
int32 ctc_humber_diag_ext_tcam_read(uint8 chip_id, int* data, int* mask, uint32 index, uint8  is_register);
int32 ctc_humber_diag_int_tcam_read(uint8 chip_id, int* data, int* mask, uint32 index, uint8  is_register);
int32 ctc_humber_diag_cfg_4G_port(uint32 humber_id, uint32 port_index, uint32 eq_value, uint32 amp_value,
                                  uint32 slew_value, uint32 coef_value);
int32 ctc_humber_diag_cfg_6G_port(uint32 humber_id, uint32 port_index, uint32 coe0_value, uint32 coe1_value,
                                  uint32 coe2_value, uint32 coe3_value, uint32 polarity_value);
int32 ctc_humber_diag_cfg_4G_all_port(uint32 humber_id, uint32 eq_value, uint32 amp_value,
                                      uint32 slew_value, uint32 coef_value);
int32 ctc_humber_diag_cfg_6G_all_port(uint32 humber_id, uint32 coe0_value, uint32 coe1_value,
                                      uint32 coe2_value, uint32 coe3_value, uint32 polarity_value);
ctc_humber_bus_message_t*
ctc_humber_diag_get_bus_msg(int32 idx);

void ctc_humber_diag_sgmac_plus_hdr(ctc_sgmac_plus_header_t* ctc_sgmac_plus_hdr);
void ctc_humber_diag_sgmac2_hdr(ctc_sgmac2_header_t* ctc_sgmac2_hdr);
void ctc_humber_diag_packet_body(uint32* data, uint32 packetLength);

#ifdef __cplusplus
}
#endif

#endif  /* _CTC_HUMBER_CHIP_DBG_H_ */

