/**
 @file sys_goldengate_efd.c

 @date 2014-10-28

 @version v3.0


*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_error.h"
#include "sys_goldengate_chip.h"
#include "sys_goldengate_efd.h"

#include "drv_enum.h"
#include "drv_io.h"


/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/


struct sys_efd_master_s
{
    ctc_efd_fn_t func;
    void* userdata;
};
typedef struct sys_efd_master_s sys_efd_master_t;

sys_efd_master_t* p_efd_master[CTC_MAX_LOCAL_CHIP_NUM] = {NULL};

#define SYS_EFD_DBG_OUT(level, FMT, ...) \
    do { \
        CTC_DEBUG_OUT(efd, efd, EFD_SYS, level, FMT, ##__VA_ARGS__); \
    } while (0)

/****************************************************************************
 *
 * Function
 *
 *****************************************************************************/

int32
sys_goldengate_efd_set_global_ctl(uint8 lchip, ctc_efd_global_control_type_t type, void* value)
{
    uint32 field_val = 0;
    uint32 cmd = 0;

    switch(type)
    {
    case CTC_EFD_GLOBAL_MODE_TCP:
        field_val = *(bool *)value ? 1 : 0;
        cmd = DRV_IOW(IpeEfdCtl_t, IpeEfdCtl_onlyTcpPktDoEfd_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        break;

    case CTC_EFD_GLOBAL_PRIORITY_EN:
        field_val = *(bool *)value ? 1 : 0;
        cmd = DRV_IOW(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowPriorityValid_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        break;

    case CTC_EFD_GLOBAL_PRIORITY:
        CTC_MAX_VALUE_CHECK(*(uint32*)value, 63);
        field_val = *(uint32*)value;
        cmd = DRV_IOW(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowPriority_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        break;

    case CTC_EFD_GLOBAL_COLOR_EN:
        field_val = *(bool *)value ? 1 : 0;
        cmd = DRV_IOW(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowColorValid_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        break;

    case CTC_EFD_GLOBAL_COLOR:
        CTC_MAX_VALUE_CHECK(*(uint32*)value, 3);
        field_val = *(uint32*)value;
        cmd = DRV_IOW(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowColor_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        break;

    default:
        return CTC_E_NOT_SUPPORT;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_efd_get_global_ctl(uint8 lchip, ctc_efd_global_control_type_t type, void* value)
{
    uint32 field_val = 0;
    uint32 cmd = 0;

    switch(type)
    {
    case CTC_EFD_GLOBAL_MODE_TCP:
        cmd = DRV_IOR(IpeEfdCtl_t, IpeEfdCtl_onlyTcpPktDoEfd_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        *(bool *)value = field_val?TRUE:FALSE;
        break;

    case CTC_EFD_GLOBAL_PRIORITY_EN:
        cmd = DRV_IOR(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowPriorityValid_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        *(bool *)value = field_val?TRUE:FALSE;
        break;

    case CTC_EFD_GLOBAL_PRIORITY:
        cmd = DRV_IOR(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowPriority_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        *(uint32 *)value = field_val;
        break;

    case CTC_EFD_GLOBAL_COLOR_EN:
        cmd = DRV_IOR(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowColorValid_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        *(bool *)value = field_val?TRUE:FALSE;
        break;

    case CTC_EFD_GLOBAL_COLOR:
        cmd = DRV_IOR(IpeAclQosCtl_t, IpeAclQosCtl_elephantFlowColor_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));
        *(uint32 *)value = field_val;
        break;

    default:
        return CTC_E_NOT_SUPPORT;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_efd_register_cb(uint8 lchip, ctc_efd_fn_t callback, void* userdata)
{
    p_efd_master[lchip]->func = callback;
    p_efd_master[lchip]->userdata = userdata;

    return CTC_E_NONE;
}

static int32
_sys_goldengate_global_efd_init(uint8 lchip, uint8 enable)
{
    uint32 cmd = 0;
    uint32 interval = 0;
    uint32 value = 0;
    IpeEfdCtl_m efd_ctl;
    EfdEngineCtl_m efd_engine_ctl;
    EfdEngineTimerCtl_m efd_timer_ctl;
    IpePortEfdCtl_m port_efd_ctl;
    IpeFwdCtl_m ipe_fwd_ctl;

    sal_memset(&efd_ctl, 0, sizeof(efd_ctl));
    sal_memset(&efd_engine_ctl, 0, sizeof(efd_engine_ctl));
    sal_memset(&efd_timer_ctl, 0, sizeof(efd_timer_ctl));
    sal_memset(&port_efd_ctl, 0, sizeof(port_efd_ctl));
    sal_memset(&ipe_fwd_ctl, 0, sizeof(ipe_fwd_ctl));

    if (enable)
    {
        /* set threshold */
        SetEfdEngineCtl(V, conflictBypassEfdUpCnt_f, &efd_engine_ctl, 1);
        SetEfdEngineCtl(V, elephantByteVolumeThrd_f, &efd_engine_ctl, 1);
        SetEfdEngineCtl(V, efdCountShift_f,          &efd_engine_ctl, 0);       /* 0 means shift right 4bit, default unit = 16Byte*/
        SetEfdEngineCtl(V, elephantByteVolumeThrd_f, &efd_engine_ctl, 12000);     /* actual threshold = 12000*16Byte = 192000byte/Tsunit, Tsunit = 30ms. Total 50M bps */
        cmd = DRV_IOW(EfdEngineCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &efd_engine_ctl));

        /* set update timer */
        SetEfdEngineTimerCtl(V, efdUpdMinPtr_f, &efd_timer_ctl, 0);
        SetEfdEngineTimerCtl(V, efdUpdMaxPtr_f, &efd_timer_ctl, 0x3FF);
        SetEfdEngineTimerCtl(V, efdUpdEn_f, &efd_timer_ctl, 1);
        SetEfdEngineTimerCtl(V, efdUpdScanMaxPtr_f, &efd_timer_ctl, 0x3FF);

        SetEfdEngineTimerCtl(V, cfgRefDivCountUpdRstPulse_f,    &efd_timer_ctl, 300);       /* per 30ms update one time */
        SetEfdEngineTimerCtl(V, cfgResetDivCountUpdRstPulse_f,    &efd_timer_ctl, 0);       /* must set 0 */

        /* set flow aging */
        SetEfdEngineTimerCtl(V, flowLetStateMinPtr_f, &efd_timer_ctl, 0);
        SetEfdEngineTimerCtl(V, flowLetStateMaxPtr_f, &efd_timer_ctl, 0x7FF);
        interval = 100;
        SetEfdEngineTimerCtl(V, flowLetStateEvictionInterval_f, &efd_timer_ctl, interval);
        SetEfdEngineTimerCtl(V, flowLetStateEvictionMaxPtr_f,   &efd_timer_ctl, 0x7FF);
        SetEfdEngineTimerCtl(V, flowLetStateEvictionThrd_f,     &efd_timer_ctl, 4);         /* 4 times */
        SetEfdEngineTimerCtl(V, flowLetStateEvictionUpdEn_f,    &efd_timer_ctl, 1);

        SetEfdEngineTimerCtl(V, cfgRefDivAgingRstPulse_f,    &efd_timer_ctl, 300);          /* per 30ms scan all ptr one time */
        SetEfdEngineTimerCtl(V, cfgResetDivAgingRstPulse_f,    &efd_timer_ctl, 0);          /* must set 0 */

        cmd = DRV_IOW(EfdEngineTimerCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &efd_timer_ctl));

        /* Config pulse timer to 0.1ms, low 8 bit is decimal fraction */
        value = (625*25) << 8;
        cmd = DRV_IOW(RefDivShareEfd_t, RefDivShareEfd_cfgRefDivShareEfdPulse_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

        value = 0;
        cmd = DRV_IOW(RefDivShareEfd_t, RefDivShareEfd_cfgResetDivShareEfdPulse_f);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

        /* enable exception to cpu */
        cmd = DRV_IOR(IpeFwdCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_fwd_ctl));
        SetIpeFwdCtl(V, newElephantExceptionEn_f, &ipe_fwd_ctl, 1);
        cmd = DRV_IOW(IpeFwdCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_fwd_ctl));

        /* enable efd */
        SetIpeEfdCtl(V, efdEnable_f, &efd_ctl, 1);
        SetIpeEfdCtl(V, ipgEn_f, &efd_ctl, 1);
        cmd = DRV_IOW(IpeEfdCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &efd_ctl));
    }
    else
    {
        /* disable efd */
        SetIpeEfdCtl(V, efdEnable_f, &efd_ctl, 0);
        cmd = DRV_IOW(IpeEfdCtl_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &efd_ctl));
    }

    return CTC_E_NONE;
}

void
sys_goldengate_efd_process_isr(ctc_efd_data_t* info, void* userdata)
{
    uint8 i = 0;

    for (i=0; i<info->count; i++)
    {
        SYS_EFD_DBG_OUT(CTC_DEBUG_LEVEL_EXPORT, "Efd FlowId %d is aginged !!\n", info->flow_id_array[i]);
    }
}

void
sys_goldengate_efd_sync_data(uint8 lchip, ctc_efd_data_t* info)
{
    if (p_efd_master[lchip]->func)
    {
        p_efd_master[lchip]->func(info, p_efd_master[lchip]->userdata);
    }
}

int32
sys_goldengate_efd_init(uint8 lchip)
{
    p_efd_master[lchip] = (sys_efd_master_t*)mem_malloc(MEM_EFD_MODULE, sizeof(sys_efd_master_t));
    if (NULL == p_efd_master[lchip])
    {
        return CTC_E_NO_MEMORY;
    }
    sal_memset(p_efd_master[lchip], 0, sizeof(sys_efd_master_t));

    CTC_ERROR_RETURN(_sys_goldengate_global_efd_init(lchip, TRUE));

    if (!p_efd_master[lchip]->func)
    {
        sys_goldengate_efd_register_cb(lchip, sys_goldengate_efd_process_isr, NULL);
    }

    return CTC_E_NONE;
}




