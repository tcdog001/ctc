/**
 @file sys_greatbelt_register.h

 @date 2009-11-3

 @version v2.0

Macro, data structure for system common operations

*/

#ifndef _SYS_GREATBELT_REGISTER
#define _SYS_GREATBELT_REGISTER
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_register.h"

#define SYS_GREATBELT_DSNH_INTERNAL_BASE 0x3FFF
#define SYS_GREATBELT_DSNH_INTERNAL_SHIFT   2

extern int32
sys_greatbelt_global_ctl_set(ctc_global_control_type_t type, void* value);

extern int32
sys_greatbelt_global_ctl_get(ctc_global_control_type_t type, void* value);

extern int32
sys_greatbelt_lkup_ttl_index(uint8 ttl, uint32* ttl_index);

extern int32
sys_greatbelt_lkup_ttl(uint8 ttl_index, uint32* ttl);

extern int32
sys_greatbelt_register_init(void);

extern int32
sys_greatbelt_device_feature_init(uint8 lchip);


#ifdef __cplusplus
}
#endif

#endif

