/**
 @file ctc_humber_oam.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-1-19

 @version v2.0

  This file contains  OAM (Ethernet OAM/MPLS OAM/PBX OAM and EFM OAM) associated APIs
*/
#ifndef _CTC_GREATBELT_OAM_H
#define _CTC_GREATBELT_OAM_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "ctc_oam.h"
#include "ctc_parser.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/

/****************************************************************************
 *
* Function
*
****************************************************************************/
/**
 @addtogroup oam OAM
 @{
 */

/**
 @brief   Add ma id for oam

 @param[in] lchip    local chip id

 @param[in]  p_maid    maid data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_add_maid(uint8 lchip, ctc_oam_maid_t* p_maid);

/**
 @brief   Remvoe ma id for oam

 @param[in] lchip    local chip id

 @param[in]  p_maid   maid data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_remove_maid(uint8 lchip, ctc_oam_maid_t* p_maid);

/**
 @brief   add mep lookup chan for oam

 @param[in] lchip    local chip id

 @param[in]chan    chan data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_add_chan(uint8 lchip, ctc_oam_chan_t* p_chan);

/**
 @brief   remove mep lookup chan for ethernet oam

 @param[in] lchip    local chip id

 @param[in]chan   chan data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_remove_chan(uint8 lchip, ctc_oam_chan_t* p_chan);

/**
 @brief   Add local mep

 @param[in] lchip    local chip id

 @param[in]  p_lmep   local mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_add_lmep(uint8 lchip, ctc_oam_lmep_t* p_lmep);

/**
 @brief   Remove local mep

 @param[in] lchip    local chip id

 @param[in]  p_lmep   local mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_remove_lmep(uint8 lchip, ctc_oam_lmep_t* p_lmep);

/**
 @brief   Update local mep

 @param[in] lchip    local chip id

 @param[in]  p_lmep   local mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_update_lmep(uint8 lchip, ctc_oam_update_t* p_lmep);

/**
 @brief   Add remote mep

 @param[in] lchip    local chip id

 @param[in]  p_rmep   remote mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_add_rmep(uint8 lchip, ctc_oam_rmep_t* p_rmep);

/**
 @brief   Remove remote mep

 @param[in] lchip    local chip id

 @param[in]  p_rmep   remote mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_remove_rmep(uint8 lchip, ctc_oam_rmep_t* p_rmep);

/**
 @brief   Update remote mep

 @param[in] lchip    local chip id

 @param[in]  p_rmep   remote mep data sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_update_rmep(uint8 lchip, ctc_oam_update_t* p_rmep);

/**
 @brief   set oam property of oam enable and others

 @param[in] lchip    local chip id

 @param[in] p_prop property sturcture pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_set_property(uint8 lchip, ctc_oam_property_t* p_prop);

/**
 @brief   Read Oam defect cache which keep up defect info

 @param[in] lchip_id    local chip id

 @param[out] p_defect_info    point to ctc_oam_error_cache_list_t

 @return CTC_E_XXX
*/
extern int32
ctc_humber_oam_get_defect_info(uint8 lchip_id, void* p_defect_info);

/**
 @brief   Read  MEP data structure get from both SDK database and ASIC dataset

 @param[in] lchip_id    local chip id

 @param[in,out] p_mep_info    MEP info pointer

 @return CTC_E_XXX
*/
extern int32
ctc_humber_oam_get_mep_info(uint8 lchip_id, ctc_oam_mep_info_t* p_mep_info);

/**
 @brief   Initilization for oam

 @param[in] lchip    local chip id

 @param[in] p_cfg global configuration for oam pointer

 @return CTC_E_XXX

*/
extern int32
ctc_humber_oam_init(uint8 lchip, ctc_oam_global_t* p_cfg);

/**@} end of @addtogroup oam OAM*/
#ifdef __cplusplus
}
#endif

#endif

