#include "sal.h"
#include "drv_lib.h"
#include "ctc_cli.h"
#include "ctc_dkit_cli.h"
#include "ctc_dkit.h"
#include "drv_chip_ctrl.h"

#define CTC_DKIT_INIT_CHECK() \
    do { \
        if (NULL == g_dkit_api){ \
            return CLI_ERROR; } \
    } while (0)

#define CTC_DKIT_NOT_SUPPORT() \
    do { \
            CTC_DKIT_PRINT("Function not support in this chip!!!\n"); \
    } while (0)

extern ctc_dkit_api_t* g_dkit_api;
bool dkits_debug = FALSE;

static ctc_dkit_memory_para_t memory_para_com;

CTC_CLI(cli_dkit_show_version,
        cli_dkit_show_version_cmd,
        "show version",
        CTC_CLI_SHOW_STR,
        "DKits version")
{
    CTC_DKIT_PRINT("    DKits %s Released at %s. Chip Series: %s \n\
    Copyright (C) %s Centec Networks Inc.  All rights reserved.\n",
    CTC_DKITS_VERSION_STR, CTC_DKITS_RELEASE_DATE, CTC_DKITS_CURRENT_CHIP, CTC_DKITS_COPYRIGHT_TIME);

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_list_tbl,
        cli_dkit_list_tbl_cmd,
        "list STRING:TBL_NAME (grep SUB_STR | )(detail |)",
        "List tables",
        "Substring of table name",
        "Grep sub string from result",
        "Sub string",
        "Detail display")
{
    ctc_dkit_memory_para_t* req = &memory_para_com;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();
    sal_memset(req, 0, sizeof(ctc_dkit_memory_para_t));
    req->type = CTC_DKIT_MEMORY_LIST;

    if (argc > 0)
    {
        sal_strncpy((char*)req->buf, argv[0], CTC_DKITS_RW_BUF_SIZE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("grep");
    if (index != 0xFF)
    {
        sal_strncpy((char*)req->buf2, argv[index+1], CTC_DKITS_RW_BUF_SIZE);
        req->grep = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("detail");
    if (index != 0xFF)
    {
        req->detail = 1;
    }

    if (g_dkit_api->memory_process)
    {
        return g_dkit_api->memory_process((void*)req);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(cli_dkit_read_reg_or_tbl,
        cli_dkit_read_reg_or_tbl_cmd,
        "read STRING:TBL_NAME_ID INDEX ( direct | count COUNT (step STEP | ) | ) (lchip CHIP_ID|)",
        "Read table or register",
        "Table name like [DsMac] or table id like [4870]",
        "Table index value <0-0xFFFFFFFF>",
        "Read table by direct I/O, otherwise by ACC I/O",
        "The counts of sequential registers to read from the index",
        "Counts",
        "Step how many count. Default:1",
        "Step count. 2 means 0 2 4...",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_memory_para_t* req = &memory_para_com;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 count = 1;
    uint32 tbl_id = 0;
    uint8 step = 1;
    uint8 arg_index = 0;

    CTC_DKIT_INIT_CHECK();
    sal_memset(req, 0, sizeof(ctc_dkit_memory_para_t));
    req->type = CTC_DKIT_MEMORY_READ;

    /*get tbl name or tbl id*/
    sal_strncpy((char*)req->buf, argv[0], CTC_DKITS_RW_BUF_SIZE);
    tbl_id = MaxTblId_t;
    if ((req->buf[0] >= '0') && (req->buf[0] <= '9'))
    {
        CTC_CLI_GET_UINT32_RANGE("table-id", tbl_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    }

    /*get tbl index*/
    CTC_CLI_GET_UINT32_RANGE("Tbl-index", index, argv[1], 0, 0xFFFFFFFF);

    arg_index = CTC_CLI_GET_ARGC_INDEX("direct");
    if (arg_index != 0xFF)
    {
        req->direct_io = 1;
    }
    arg_index = CTC_CLI_GET_ARGC_INDEX("count");
    if (arg_index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("count", count, argv[arg_index + 1], 0, CTC_MAX_UINT32_VALUE);
    }
    arg_index = CTC_CLI_GET_ARGC_INDEX("step");
    if (arg_index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("step", step, argv[arg_index + 1], 0, CTC_MAX_UINT8_VALUE);
    }
    arg_index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != arg_index)
    {
        CTC_CLI_GET_INTEGER("lchip", chip, argv[arg_index + 1]);
    }

    req->param[1] = chip;
    req->param[2] = index;
    req->param[3] = tbl_id;
    req->param[4] = count;
    req->param[5] = step;

    if (g_dkit_api->memory_process)
    {
        return g_dkit_api->memory_process((void*)req);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_write_reg_or_tbl,
        cli_dkit_write_reg_or_tbl_cmd,
        "write STRING:TBL_NAME_ID INDEX STRING:FLD_NAME_ID VALUE ( mask MASK| direct | ) (lchip CHIP_ID|)",
        "Write table or register",
        "Table name like [DsMac] or table id like [4870]",
        "Table index value <0-0xFFFFFFFF>",
        "Field name or field id",
        "Value",
        "Tcam mask",
        "Tcam mask",
        "Write table by direct I/O, otherwise by ACC I/O",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_memory_para_t* req = &memory_para_com;
    uint32 chip = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    static uint32 value[MAX_ENTRY_WORD] = {0};
    static uint32 mask[MAX_ENTRY_WORD] = {0};
    uint32 tbl_id = 0;
    uint8 arg_index = 0;

    CTC_DKIT_INIT_CHECK();
    sal_memset(req, 0, sizeof(ctc_dkit_memory_para_t));
    sal_memset(&value, 0, sizeof(value));
    sal_memset(&mask, 0, sizeof(mask));
    req->type = CTC_DKIT_MEMORY_WRITE;

    /*get tbl name or tbl id*/
    sal_strncpy((char*)req->buf, argv[0], CTC_DKITS_RW_BUF_SIZE);
    tbl_id = MaxTblId_t;
    if ((req->buf[0] >= '0') && (req->buf[0] <= '9'))
    {
        CTC_CLI_GET_UINT32_RANGE("table-id", tbl_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    }

    /*get tbl index*/
    CTC_CLI_GET_UINT32_RANGE("Tbl-index", index, argv[1], 0, 0xFFFFFFFF);

    /*get field name*/
    sal_strncpy((char*)req->buf2, argv[2], CTC_DKITS_RW_BUF_SIZE);
    field_id = 0xFFFFFFFF;
    if ((req->buf2[0] >= '0') && (req->buf2[0] <= '9'))
    {
        CTC_CLI_GET_UINT32_RANGE("field-id", field_id, argv[2], 0, CTC_MAX_UINT32_VALUE);
    }

    /*get field value*/
    CTC_CLI_GET_INTEGER_N("fld-value", (uint32 *)(value), argv[3]);
    arg_index = CTC_CLI_GET_ARGC_INDEX("mask");
    if (arg_index != 0xFF)
    {
        CTC_CLI_GET_INTEGER_N("fld-value", (uint32 *)(mask), argv[arg_index + 1]);
    }

    arg_index = CTC_CLI_GET_ARGC_INDEX("direct");
    if (arg_index != 0xFF)
    {
        req->direct_io = 1;
    }
    arg_index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != arg_index)
    {
        CTC_CLI_GET_INTEGER("lchip", chip, argv[arg_index + 1]);
    }

    req->param[1] = chip;
    req->param[2] = index;
    req->param[3] = tbl_id;
    req->param[4] = field_id;
    sal_memcpy(req->value, value, 16);
    sal_memcpy(req->mask, mask, 16);

    if (g_dkit_api->memory_process)
    {
        return g_dkit_api->memory_process((void*)req);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_reset_reg_or_tbl,
        cli_dkit_reset_reg_or_tbl_cmd,
        "reset STRING:TBL_NAME_ID INDEX",
        CTC_CLI_CLEAR_STR,
        "Table name like [DsMac] or table id like [4870]",
        "Table index value <0-0xFFFFFFFF>")
{
    ctc_dkit_memory_para_t* req = &memory_para_com;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 tbl_id = 0;

    CTC_DKIT_INIT_CHECK();
    sal_memset(req, 0, sizeof(ctc_dkit_memory_para_t));
    req->type = CTC_DKIT_MEMORY_RESET;

    /*get tbl name or tbl id*/
    sal_strncpy((char*)req->buf, argv[0], CTC_DKITS_RW_BUF_SIZE);
    tbl_id = MaxTblId_t;
    if ((req->buf[0] >= '0') && (req->buf[0] <= '9'))
    {
        CTC_CLI_GET_UINT32_RANGE("table-id", tbl_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    }

    /*get tbl index*/
    CTC_CLI_GET_UINT32_RANGE("Tbl-index", index, argv[1], 0, 0xFFFFFFFF);

    req->param[1] = chip;
    req->param[2] = index;
    req->param[3] = tbl_id;

    if (g_dkit_api->memory_process)
    {
        return g_dkit_api->memory_process(req);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_show_tbl_reg,
        cli_dkit_show_tbl_reg_cmd,
        "show tbl-name STRING:TBL_ID",
        CTC_CLI_SHOW_STR,
        "Table or register name",
        "Table id value <0-MaxTblId_t>")
{
    uint32 id = 0;
    int32 ret = 0;
    char    buf[CTC_DKITS_RW_BUF_SIZE];

    CTC_DKIT_INIT_CHECK();
    CTC_CLI_GET_UINT32_RANGE("Table/Reg Index", id, argv[0], 0, MaxTblId_t);

    ret = drv_get_tbl_string_by_id(id, buf);

    if (CLI_SUCCESS == ret)
    {
        CTC_DKIT_PRINT("------------------------------------------------\n");
        CTC_DKIT_PRINT("ID:%d -> %s\n", id, buf);
        CTC_DKIT_PRINT("------------------------------------------------\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_show_tbl_reg_by_addr,
        cli_dkit_show_tbl_reg_by_addr_cmd,
        "show tbl-name addr ADDRESS",
        CTC_CLI_SHOW_STR,
        "Table or register name",
        "read address 0xXXXXXXXX",
        "address value")
{
    ctc_dkit_memory_para_t* req = &memory_para_com;

    CTC_DKIT_INIT_CHECK();
    sal_memset(req, 0, sizeof(ctc_dkit_memory_para_t));
    req->type = CTC_DKIT_MEMORY_SHOW_TBL_BY_ADDR;

    CTC_CLI_GET_INTEGER("addressOffset", req->param[0], argv[0]);


    if (g_dkit_api->memory_process)
    {
        return g_dkit_api->memory_process(req);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_read_address,
    cli_dkit_read_address_cmd,
    "read address ADDR_OFFSET (count COUNT |) (lchip CHIP_ID|)",
    "read address value cmd",
    "read address 0xXXXXXXXX",
    "address value",
    "replicate time",
    "replicate time",
    CTC_DKITS_CHIP_DESC,
    CTC_DKITS_CHIP_ID_DESC)
{
    int32 ret = DRV_E_NONE;

    uint8 chipid_base = 0;
    uint32 address_offset = 0, rep_time = 1;
    uint32 tmp_i = 0, chip_id = 0;
    uint32 tmp_value = 0;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();
    CTC_CLI_GET_INTEGER("addressOffset", address_offset, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", chip_id, argv[index + 1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("count");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("count", rep_time, argv[index + 1]);
    }

    ret = drv_get_chipid_base(&chipid_base);

    if (ret < DRV_E_NONE)
    {
        CTC_DKIT_PRINT("Get chipId base ERROR! Value = 0x%08x\n", chipid_base);
        return ret;
    }

    for (tmp_i = 0 ; tmp_i < rep_time; tmp_i++)
    {
        ret = drv_chip_read(chip_id - chipid_base, address_offset, &tmp_value);

        if (ret < DRV_E_NONE)
        {
            continue;
        }

        CTC_DKIT_PRINT("Address 0x%08x: 0x%08x\n", address_offset, tmp_value);
        address_offset = address_offset + 4;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_write_address,
    cli_dkit_write_address_cmd,
    "write address ADDR_OFFSET WRITE_VALUE (lchip CHIP_ID|)",
    "write value to address cmd",
    "write address 0xXXXXXXXX <value>",
    "address value",
    "value to write",
    CTC_DKITS_CHIP_DESC,
    CTC_DKITS_CHIP_ID_DESC)
{
    uint8 chipid_base = 0;
    uint32 address_offset = 0, chip_id = 0, value = 0;
    int32 ret = DRV_E_NONE;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();
    CTC_CLI_GET_INTEGER("address", address_offset, argv[0]);
    CTC_CLI_GET_INTEGER("value", value, argv[1]);

    ret = drv_get_chipid_base(&chipid_base);

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", chip_id, argv[index + 1]);
    }

    if (ret < DRV_E_NONE)
    {
        CTC_DKIT_PRINT("Get chipId base ERROR! Value = 0x%08x\n", chipid_base);
        return ret;
    }

    ret = drv_chip_write(chip_id - chipid_base, address_offset, value);

    if (ret < DRV_E_NONE)
    {
        CTC_DKIT_PRINT("0x%08x address write ERROR! Value = 0x%08x\n", address_offset, value);
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_show_interface_status,
    cli_dkit_show_interface_status_cmd,
    "show interface ((mac-id MAC_ID)| (port GPORT) | (mac-en (enable | disable)) | (link (up|down)) \
       | (speed (1g|10g|40g|100g)) | ) (lchip CHIP_ID|)",
    CTC_CLI_SHOW_STR,
    "Interface",
    "Mac id",
    "Mac id, <0-128>",
    "Global port",
    "Global port",
    "Mac enable/disable",
    "Mac enable",
    "Mac disable",
    "Link status",
    "Link up",
    "Link down",
    "Speed",
    "Speed 1g",
    "Speed 10g",
    "Speed 40g",
    "Speed 100g",
    CTC_DKITS_CHIP_DESC,
    CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_interface_para_t para;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));
    para.type = CTC_DKIT_INTERFACE_ALL;
    para.value = 0;

    index = CTC_CLI_GET_ARGC_INDEX("mac-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("mac-id", para.value, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        para.type = CTC_DKIT_INTERFACE_MAC_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", para.value, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        para.type = CTC_DKIT_INTERFACE_GPORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-en");
    if (index != 0xFF)
    {
        para.type = CTC_DKIT_INTERFACE_MAC_EN;
        index = CTC_CLI_GET_ARGC_INDEX("enable");
        if (index != 0xFF)
        {
            para.value = 1;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("link");
    if (index != 0xFF)
    {
        para.type = CTC_DKIT_INTERFACE_LINK_STATUS;
        index = CTC_CLI_GET_ARGC_INDEX("up");
        if (index != 0xFF)
        {
            para.value = 1;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("speed");
    if (index != 0xFF)
    {
        para.type = CTC_DKIT_INTERFACE_SPEED;
        index = CTC_CLI_GET_ARGC_INDEX("1g");
        if (index != 0xFF)
        {
            para.value = CTC_DKIT_INTERFACE_SGMII;
        }
        index = CTC_CLI_GET_ARGC_INDEX("10g");
        if (index != 0xFF)
        {
            para.value = CTC_DKIT_INTERFACE_XFI;
        }
        index = CTC_CLI_GET_ARGC_INDEX("40g");
        if (index != 0xFF)
        {
            para.value = CTC_DKIT_INTERFACE_XLG;
        }
        index = CTC_CLI_GET_ARGC_INDEX("100g");
        if (index != 0xFF)
        {
            para.value = CTC_DKIT_INTERFACE_CG;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_interface_status)
    {
        return g_dkit_api->show_interface_status((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

}


CTC_CLI(cli_dkit_show_discard_type,
        cli_dkit_show_discard_type_cmd,
        "show discard-type (REASON_ID | )",
        CTC_CLI_SHOW_STR,
        "Discard type description",
        "Discard reason id, <0-0xFFFFFFFF>")
{
    ctc_dkit_discard_para_t para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));
    para.reason_id = 0xFFFFFFFF;

    if (argc > 0)
    {
        CTC_CLI_GET_UINT32_RANGE("reason-id", para.reason_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    }

    if (g_dkit_api->show_discard_type)
    {
        return g_dkit_api->show_discard_type((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_show_discard,
        cli_dkit_show_discard_cmd,
        "show discard (on-line| ) (history | ) (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Discard",
        "On line status",
        "Discard history",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{

    uint8 index = 0;
    ctc_dkit_discard_para_t para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));

    index = CTC_CLI_GET_ARGC_INDEX("on-line");
    if (index != 0xFF)
    {
        para.on_line = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("capture");
    if (index != 0xFF)
    {
        para.captured = 1;
        CTC_CLI_GET_UINT8_RANGE("capture session id", para.captured_session, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("history");
    if (index != 0xFF)
    {
        para.history = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_discard)
    {
        return g_dkit_api->show_discard((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_install_capture_flow,
        cli_dkit_install_capture_flow_cmd,
        "install capture SESSION_ID flow ({gport PORT| mac-da MACDA| mac-sa MACSA| svlan-id SVLANID| cvlan-id CVLANID| ether-type ETHTYPE|\
        ( ipv4 {da A.B.C.D | sa A.B.C.D | checksum CHECKSUM}| \
          ipv6 {da X:X::X:X | sa X:X::X:X }| \
          mpls {label0 LABEL| label1 LABEL | label2 LABEL| label3 LABEL} | \
          slow-protocol {sub-type SUBTYPE|flags FLAGS|code CODE} | \
          ether-oam {level LEVEL|version VERSION|opcode OPCODE|rx-fcb RXFCB|tx-fcf TXFCF|tx-fcb TXFCB}) | \
        l4-src-port L4PORT | l4-dest-port L4PORT} |) (lchip CHIP_ID|)",
        "Install capture flow",
        "Install capture flow",
        "Captured session id",
        "Flow",
        "Global source port",
        "gport",
        "MAC DA address",
        "MAC address in HHHH.HHHH.HHHH format",
        "MAC SA address",
        "MAC address in HHHH.HHHH.HHHH format",
        "Svlan id",
        "<0-4095>",
        "Cvlan id",
        "<0-4095>",
        "Ether type",
        "<0-0xFFFF>",
        "Ipv4 packet",
        "Ipv4 da",
        "IPv4 address in A.B.C.D format",
        "Ipv4 sa",
        "IPv4 address in A.B.C.D format",
        "Ipv4 checksum",
        "<0-0xFFFF>",
        "Ipv6 packet",
        "Ipv6 da",
        "IPv6 address in X:X::X:X format",
        "Ipv6 sa",
        "IPv6 address in X:X::X:X format",
        "Mpls packet",
        "The first lable",
        "<0-0xFFFFFFFF>",
        "The second lable",
        "<0-0xFFFFFFFF>",
        "The third lable",
        "<0-0xFFFFFFFF>",
        "The fourth lable",
        "<0-0xFFFFFFFF>",
        "Slow protocal packet",
        "Sub type",
        "<0-0xFF>",
        "Flags",
        "<0-0xFFFF>",
        "Code",
        "<0-0xFF>",
        "Ether oam packet",
        "Level",
        "<0-7>",
        "Version",
        "Version",
        "Opcode",
        "0-0xFF",
        "Rx fcb","0-0xFFFFFFFF",
        "Tx fcf","0-0xFFFFFFFF",
        "Tx fcb","0-0xFFFFFFFF",
        "Layer4 source port",
        "<0-0xFFFF>",
        "Layer4 dest port",
        "<0-0xFFFF>",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_captured_t para;
    uint8 index = 0;
    ipv6_addr_t ipv6_address;

    CTC_DKIT_INIT_CHECK();
    sal_memset(&para, 0, sizeof(para));

    CTC_CLI_GET_UINT8_RANGE("capture session id", para.captured_session, argv[0], 0, CTC_MAX_UINT8_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", para.flow_info.port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        para.flow_info_mask.port = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-da");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac address", para.flow_info.mac_da, argv[index + 1]);
        para.flow_info_mask.mac_da[0] = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("mac address", para.flow_info.mac_sa, argv[index + 1]);
        para.flow_info_mask.mac_sa[0] = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("svlan-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("svlan-id", para.flow_info.svlan_id, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        para.flow_info_mask.svlan_id = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("cvlan-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("cvlan-id", para.flow_info.cvlan_id, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        para.flow_info_mask.cvlan_id = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ether-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("ether-type", para.flow_info.ether_type, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        para.flow_info_mask.ether_type = 1;
    }

    /*Layer3*/
    /*ipv4*/
    index = CTC_CLI_GET_ARGC_INDEX("ipv4");
    if (index != 0xFF)
    {
        para.flow_info.l3_type = CTC_DKIT_CAPTURED_IPV4;
        para.flow_info_mask.l3_type = 1;
        index = CTC_CLI_GET_ARGC_INDEX("da");
        if (index != 0xFF)
        {
            CTC_CLI_GET_IPV4_ADDRESS("ip", para.flow_info.u_l3.ipv4.ip_da, argv[index + 1]);
            para.flow_info_mask.u_l3.ipv4.ip_da = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("sa");
        if (index != 0xFF)
        {
            CTC_CLI_GET_IPV4_ADDRESS("ip", para.flow_info.u_l3.ipv4.ip_sa, argv[index + 1]);
            para.flow_info_mask.u_l3.ipv4.ip_sa = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("checksum");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("checksum", para.flow_info.u_l3.ipv4.ip_check_sum, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
            para.flow_info_mask.u_l3.ipv4.ip_check_sum = 1;
        }
    }
    /*ipv6*/
    index = CTC_CLI_GET_ARGC_INDEX("ipv6");
    if (index != 0xFF)
    {
        para.flow_info.l3_type = CTC_DKIT_CAPTURED_IPV6;
        para.flow_info_mask.l3_type = 1;
        index = CTC_CLI_GET_ARGC_INDEX("da");
        if (index != 0xFF)
        {
            CTC_CLI_GET_IPV6_ADDRESS("ip", ipv6_address, argv[index + 1]);
            /* adjust endian */
            para.flow_info.u_l3.ipv6.ip_da[0] = sal_htonl(ipv6_address[0]);
            para.flow_info.u_l3.ipv6.ip_da[1] = sal_htonl(ipv6_address[1]);
            para.flow_info.u_l3.ipv6.ip_da[2] = sal_htonl(ipv6_address[2]);
            para.flow_info.u_l3.ipv6.ip_da[3] = sal_htonl(ipv6_address[3]);
            para.flow_info_mask.u_l3.ipv6.ip_da[0] = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("sa");
        if (index != 0xFF)
        {
            CTC_CLI_GET_IPV6_ADDRESS("ip", ipv6_address, argv[index + 1]);
            /* adjust endian */
            para.flow_info.u_l3.ipv6.ip_sa[0] = sal_htonl(ipv6_address[0]);
            para.flow_info.u_l3.ipv6.ip_sa[1] = sal_htonl(ipv6_address[1]);
            para.flow_info.u_l3.ipv6.ip_sa[2] = sal_htonl(ipv6_address[2]);
            para.flow_info.u_l3.ipv6.ip_sa[3] = sal_htonl(ipv6_address[3]);
            para.flow_info_mask.u_l3.ipv6.ip_sa[0] = 1;
        }
    }
    /*mpls*/
    index = CTC_CLI_GET_ARGC_INDEX("mpls");
    if (index != 0xFF)
    {
        para.flow_info.l3_type = CTC_DKIT_CAPTURED_MPLS;
        para.flow_info_mask.l3_type = 1;
        index = CTC_CLI_GET_ARGC_INDEX("label0");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("label", para.flow_info.u_l3.mpls.mpls_label0, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.mpls.mpls_label0 = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("label1");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("label", para.flow_info.u_l3.mpls.mpls_label1, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.mpls.mpls_label1 = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("label2");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("label", para.flow_info.u_l3.mpls.mpls_label2, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.mpls.mpls_label2 = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("label3");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("label", para.flow_info.u_l3.mpls.mpls_label3, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.mpls.mpls_label3 = 1;
        }
    }
    /*slow protocol*/
    index = CTC_CLI_GET_ARGC_INDEX("slow-protocol");
    if (index != 0xFF)
    {
        para.flow_info.l3_type = CTC_DKIT_CAPTURED_SLOW_PROTOCOL;
        para.flow_info_mask.l3_type = 1;
        index = CTC_CLI_GET_ARGC_INDEX("sub-type");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8_RANGE("sub-type", para.flow_info.u_l3.slow_proto.sub_type, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
            para.flow_info_mask.u_l3.slow_proto.sub_type = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("flags");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("flags", para.flow_info.u_l3.slow_proto.flags, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
            para.flow_info_mask.u_l3.slow_proto.flags = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("code");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8_RANGE("code", para.flow_info.u_l3.slow_proto.code, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
            para.flow_info_mask.u_l3.slow_proto.code = 1;
        }
    }
    /*ether oam*/
    index = CTC_CLI_GET_ARGC_INDEX("ether-oam");
    if (index != 0xFF)
    {
        para.flow_info.l3_type = CTC_DKIT_CAPTURED_ETHOAM;
        para.flow_info_mask.l3_type = 1;
        index = CTC_CLI_GET_ARGC_INDEX("level");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8_RANGE("level", para.flow_info.u_l3.ether_oam.level, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
            para.flow_info_mask.u_l3.ether_oam.level = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("version");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8_RANGE("version", para.flow_info.u_l3.ether_oam.version, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
            para.flow_info_mask.u_l3.ether_oam.version = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("opcode");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT8_RANGE("opcode", para.flow_info.u_l3.ether_oam.opcode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
            para.flow_info_mask.u_l3.ether_oam.opcode = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("rx-fcb");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("rx-fcb", para.flow_info.u_l3.ether_oam.rx_fcb, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.ether_oam.rx_fcb = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("tx-fcf");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("tx-fcf", para.flow_info.u_l3.ether_oam.tx_fcf, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.ether_oam.tx_fcf = 1;
        }
        index = CTC_CLI_GET_ARGC_INDEX("tx-fcb");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT32_RANGE("tx-fcb", para.flow_info.u_l3.ether_oam.tx_fcb, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
            para.flow_info_mask.u_l3.ether_oam.tx_fcb = 1;
        }
    }
    /*Layer3*/
    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
    if (index != 0xFF)
    {
        index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("l4-src-port", para.flow_info.u_l4.l4port.source_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
            para.flow_info_mask.u_l4.l4port.source_port = 1;
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("l4-dest-port");
    if (index != 0xFF)
    {
        index = CTC_CLI_GET_ARGC_INDEX("l4-dest-port");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("l4-dest-port", para.flow_info.u_l4.l4port.dest_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
            para.flow_info_mask.u_l4.l4port.dest_port = 1;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->install_captured_flow)
    {
        return g_dkit_api->install_captured_flow((void*)&para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_clear_capture,
        cli_dkit_clear_capture_cmd,
        "clear capture SESSION_ID (flow |result | ) (lchip CHIP_ID|)",
        CTC_CLI_CLEAR_STR,
        "Clear capture",
        "Captured session id",
        "Clear captured flow",
        "Clear captured result",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_captured_t para;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();
    sal_memset(&para, 0, sizeof(para));
    para.flag = CTC_DKIT_CAPTURED_CLEAR_ALL;

    CTC_CLI_GET_UINT8_RANGE("capture session id", para.captured_session, argv[0], 0, CTC_MAX_UINT8_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("flow");
    if (index != 0xFF)
    {
        para.flag = CTC_DKIT_CAPTURED_CLEAR_FLOW;
    }
    index = CTC_CLI_GET_ARGC_INDEX("result");
    if (index != 0xFF)
    {
        para.flag = CTC_DKIT_CAPTURED_CLEAR_RESULT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->clear_captured_flow)
    {
        return g_dkit_api->clear_captured_flow((void*)&para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_show_path,
        cli_dkit_show_path_cmd,
        "show path {capture SESSION_ID | detail | clear (flow|result) | } (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Show packet process path",
        "Use captured infomation",
        "Captured session id",
        "Detail display",
        "Clear capture",
        "Clear captured flow",
        "Clear captured result",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_path_para_t para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));
    para.captured = 0;
    para.on_line = 0;

    index = CTC_CLI_GET_ARGC_INDEX("capture");
    if (index != 0xFF)
    {
        para.captured = 1;
        para.on_line = 1;
        CTC_CLI_GET_UINT8_RANGE("capture session id", para.captured_session, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("detail");
    if (index != 0xFF)
    {
        para.detail = 1;
    }


    index = CTC_CLI_GET_ARGC_INDEX("clear");
    if (index != 0xFF)
    {
        para.flag = CTC_DKIT_CAPTURED_CLEAR_ALL;
        index = CTC_CLI_GET_ARGC_INDEX("flow");
        if (index != 0xFF)
        {
            para.flag = CTC_DKIT_CAPTURED_CLEAR_FLOW;
        }
        index = CTC_CLI_GET_ARGC_INDEX("result");
        if (index != 0xFF)
        {
            para.flag = CTC_DKIT_CAPTURED_CLEAR_RESULT;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }


    if (g_dkit_api->show_path)
    {
        return g_dkit_api->show_path((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_show_monitor_q_id,
        cli_dkit_show_monitor_q_id_cmd,
        "show monitor queue-id (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Show monitor result",
        "Queue ID",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_monitor_para_t para;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_queue_id)
    {
        return g_dkit_api->show_queue_id((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_show_monitor_q_depth,
        cli_dkit_show_monitor_q_depth_cmd,
        "show monitor (queue-depth | queue-resource (ingress | egress ) (port GPORT | )) (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Show monitor result",
        "Queue depth",
        "Queue resource manager",
        "Ingress queue monitor",
        "Egress queue monitor",
        "Global port",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_monitor_para_t para;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));
    para.gport = 0xFFFF;
    para.dir = CTC_DKIT_BOTH_DIRECTION;

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if (index != 0xFF)
    {
        para.dir = CTC_DKIT_INGRESS;
    }
    else
    {
        index = CTC_CLI_GET_ARGC_INDEX("egress");
        if (index != 0xFF)
        {
            para.dir = CTC_DKIT_EGRESS;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", para.gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_queue_depth)
    {
        return g_dkit_api->show_queue_depth((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_show_monitor_sensor,
        cli_dkit_show_monitor_sensor_cmd,
        "show monitor (temperature | voltage) (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Show monitor result",
        "Temperature value",
        "Voltage value",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_monitor_para_t para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));

    index = CTC_CLI_GET_ARGC_INDEX("temperature");
    if (index != 0xFF)
    {
        para.sensor_mode = CTC_DKIT_MONITOR_SENSOR_TEMP;
    }

    index = CTC_CLI_GET_ARGC_INDEX("voltage");
    if (index != 0xFF)
    {
        para.sensor_mode = CTC_DKIT_MONITOR_SENSOR_VOL;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_sensor_result)
    {
        return g_dkit_api->show_sensor_result((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_monitor_temperature,
        cli_dkit_monitor_temperature_cmd,
        "monitor temperature (enable TMPMPERTURE0 TMPMPERTURE1 INTERVAL (log FILE |) | disable) (lchip CHIP_ID|)",
        "Monitor",
        "Temperature",
        "Enable",
        "Monitor temperature",
        "Power off temperature",
        "Monitor interval, 0~255, second",
        "Record to log",
        "Log file name",
        "Disable",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_monitor_para_t para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&para, 0, sizeof(para));
    para.sensor_mode = CTC_DKIT_MONITOR_SENSOR_TEMP_NOMITOR;

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (index != 0xFF)
    {
        para.enable = 1;
        CTC_CLI_GET_UINT8_RANGE("Temperature", para.temperature, argv[index+1], 0, CTC_MAX_UINT8_VALUE);
        CTC_CLI_GET_UINT8_RANGE("Temperature", para.power_off_temp, argv[index+2], 0, CTC_MAX_UINT8_VALUE);
        CTC_CLI_GET_UINT8_RANGE("interval", para.interval, argv[index+3], 0, CTC_MAX_UINT8_VALUE);
        index = CTC_CLI_GET_ARGC_INDEX("log");
        if (index != 0xFF)
        {
            para.log = 1;
            sal_strncpy(para.str, argv[index + 1], 32);
        }

    }
    else
    {
        para.enable = 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->show_sensor_result)
    {
        return g_dkit_api->show_sensor_result((void*)(&para));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_tcam_scan,
        cli_dkit_tcam_scan_cmd,
        "tcam scan (((tcam-type ({igs-scl | igs-acl | egs-acl | lpm-ip | lpm-nat} (priority PRIORITY |))) ((key-type KEY_TYPE (index INDEX | all)) |)) | all) (lchip CHIP_ID|)",
        "Tcam module",
        "Scan tcam key",
        "Tcam type",
        "Ingress scl tcam",
        "Ingress acl tcam",
        "Egress acl tcam",
        "Lpm ip tcam",
        "Lpm nat/pbr tcam",
        "Priority",
        "<0-3>",
        "Key type",
        "<0-3>",
        "Key index",
        "<0-0xFFFFFFFF>",
        "Specified tcam type's all key index",
        "All Tcam type and all its key index",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkits_tcam_info_t tcam_info;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&tcam_info, 0, sizeof(ctc_dkits_tcam_info_t));
    tcam_info.index = 0x0FFFFFFFF;
    tcam_info.key_type = 0x0FFFFFFFF;
    tcam_info.priority = 0x0FFFFFFFF;

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tcam-type");
    if (0xFF != index)
    {
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-scl");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-acl");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("egs-acl");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-ip");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-nat");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("priority");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32("priority", tcam_info.priority, argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("key-type");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32("key-type", tcam_info.key_type, argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("index");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32("index", tcam_info.index, argv[index + 1]);
        }

    }
    else
    {
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("all");
        if (0xFF != index)
        {
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
            DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", tcam_info.lchip, argv[index + 1]);
    }

    if (g_dkit_api->tcam_scan)
    {
        return g_dkit_api->tcam_scan((void*)(&tcam_info));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_tcam_show_key_type,
        cli_dkit_tcam_show_key_type_cmd,
        "show tcam key-type",
        CTC_CLI_SHOW_STR,
        "Tcam module",
        "Tcam type's key type")
{
    CTC_DKIT_INIT_CHECK();
    if (g_dkit_api->show_tcam_key_type)
    {
        return g_dkit_api->show_tcam_key_type();
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_tcam_capture_start,
        cli_dkit_tcam_capture_start_cmd,
        "tcam capture start ({igs-scl | igs-acl | egs-acl | lpm-ip | lpm-nat} | all) (lchip CHIP_ID|)",
        "Tcam module",
        "Capture tcam key",
        "Start",
        "Ingress Scl tcam",
        "Ingress acl tcam",
        "Egress acl tcam",
        "Lpm ip tcam",
        "Lpm nat/pbr tcam",
        "All tcam",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkits_tcam_info_t tcam_info;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&tcam_info, 0, sizeof(ctc_dkits_tcam_info_t));

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-scl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("egs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-ip");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-nat");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("all");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", tcam_info.lchip, argv[index + 1]);
    }

    if (g_dkit_api->tcam_capture_start)
    {
        return g_dkit_api->tcam_capture_start(&tcam_info);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_tcam_capture_stop,
        cli_dkit_tcam_capture_stop_cmd,
        "tcam capture stop ({igs-scl | igs-acl | egs-acl | lpm-ip | lpm-nat} | all) (lchip CHIP_ID|)",
        "Tcam module",
        "Capture tcam key",
        "Stop",
        "Ingress Scl tcam",
        "Ingress acl tcam",
        "Egress acl tcam",
        "Lpm ip tcam",
        "Lpm nat/pbr tcam",
        "All tcam",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkits_tcam_info_t tcam_info;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&tcam_info, 0, sizeof(ctc_dkits_tcam_info_t));

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-scl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("egs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-ip");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-nat");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("all");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", tcam_info.lchip, argv[index + 1]);
    }

    if (g_dkit_api->tcam_capture_stop)
    {
        return g_dkit_api->tcam_capture_stop(&tcam_info);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_tcam_capture_show,
        cli_dkit_tcam_capture_show_cmd,
        "show tcam capture ({igs-scl | igs-acl | egs-acl | lpm-ip | lpm-nat} | all) (lchip CHIP_ID|)",
        CTC_CLI_SHOW_STR,
        "Tcam module",
        "Capture tcam key",
        "Ingress Scl tcam",
        "Ingress acl tcam",
        "Egress acl tcam",
        "Lpm ip tcam",
        "Lpm nat/pbr tcam",
        "All tcam",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkits_tcam_info_t tcam_info;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&tcam_info, 0, sizeof(ctc_dkits_tcam_info_t));

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-scl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("egs-acl");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-ip");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lpm-nat");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("all");
    if (0xFF != index)
    {
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_SCL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_EGS_ACL);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPPREFIX);
        DKITS_SET_FLAG(tcam_info.tcam_type, CTC_DKITS_TCAM_TYPE_FLAG_IPNAT);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", tcam_info.lchip, argv[index + 1]);
    }

    if (g_dkit_api->tcam_capture_show)
    {
        return g_dkit_api->tcam_capture_show(&tcam_info);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_dkit_dump_cfg_dump,
        ctc_dkit_dump_cfg_dump_cmd,
        "dump-cfg store (static (serdes | clktree | all) | dynamic ({scl | acl | ipfix | oam | fdb | ipuc | ipmc } | all)) FILE_NAME",
        "Dump cfg cmd",
        "Store centec file",
        "Static table",
        "Hss and clktree",
        "Serdes table",
        "All static table",
        "Dynamic table",
        "Scl key",
        "Acl key",
        "Ipfix Key",
        "Oam key",
        "Fdb key",
        "Ipuc key",
        "Ipmc key",
        "All key",
        "Centec file",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkits_dump_cfg_t dump_cfg;
    CTC_DKIT_INIT_CHECK();
    sal_memset(&dump_cfg, 0, sizeof(ctc_dkits_dump_cfg_t));

    index = CTC_CLI_GET_ARGC_INDEX("static");
    if (0xFF != index)
    {
        index = CTC_CLI_GET_ARGC_INDEX("all");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_STATIC_ALL);
        }

        index = CTC_CLI_GET_ARGC_INDEX("clktree");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_STATIC_HSS);
        }

        index = CTC_CLI_GET_ARGC_INDEX("serdes");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_STATIC_SERDES);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("dynamic");
    if (0xFF != index)
    {
        index = CTC_CLI_GET_ARGC_INDEX("oam");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_OAM);
        }

        index = CTC_CLI_GET_ARGC_INDEX("fdb");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_FDB);
        }

        index = CTC_CLI_GET_ARGC_INDEX("scl");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_SCL);
        }

        index = CTC_CLI_GET_ARGC_INDEX("acl");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_ACL);
        }

        index = CTC_CLI_GET_ARGC_INDEX("ipuc");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPUC);
        }

        index = CTC_CLI_GET_ARGC_INDEX("ipmc");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPMC);
        }

        index = CTC_CLI_GET_ARGC_INDEX("ipfix");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPFIX);
        }

        index = CTC_CLI_GET_ARGC_INDEX("all");
        if (0xFF != index)
        {
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_FDB);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_SCL);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_ACL);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_OAM);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPUC);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPMC);
            DKITS_BIT_SET(dump_cfg.func_flag, CTC_DKITS_DUMP_FUNC_DYN_IPFIX);
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", dump_cfg.lchip, argv[index + 1]);
    }

    sal_memset(dump_cfg.file, 0, sizeof(dump_cfg.file));
    sal_memcpy(dump_cfg.file, argv[argc - 1], sal_strlen(argv[argc - 1]));

    if (g_dkit_api->cfg_dump)
    {
        (g_dkit_api->cfg_dump(&dump_cfg));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_dkit_dump_cfg_cmp,
        ctc_dkit_dump_cfg_cmp_cmd,
        "dump-cfg diff FILE_NAME1 FILE_NAME2",
        "Dump chip cfg cmd",
        "Diff centec file",
        "Centec file1",
        "Centec file2")
{
    if (g_dkit_api->cfg_cmp)
    {
        (g_dkit_api->cfg_cmp(argv[0], argv[1]));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_dkit_dump_cfg_decode,
        ctc_dkit_dump_cfg_decode_cmd,
        "dump-cfg decode FILE_NAME",
        "Dump centec configure file cmd",
        "Decode centec file",
        "Centec file")
{
    char* p_file_name = argv[0];

    if (g_dkit_api->cfg_decode)
    {
        (g_dkit_api->cfg_decode(p_file_name));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_dump_memory_usage,
        cli_dkit_dump_memory_usage_cmd,
        "dump-cfg usage (hash (key (detail|) | memory) | tcam) (lchip CHIP_ID|)",
        "Dump centec cfg usage cmd",
        "Key and memory usage",
        "Hash",
        "Key",
        "Detail",
        "Memory",
        "Tcam",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint32 index = 0, type = 0;
    uint8 lchip = 0;
    CTC_DKIT_INIT_CHECK();
    index = CTC_CLI_GET_ARGC_INDEX("hash");
    if (0xFF != index)
    {
        index = CTC_CLI_GET_ARGC_INDEX("memory");
        if (0xFF != index)
        {
            type = CTC_DKITS_DUMP_USAGE_HASH_MEM;
        }
        else
        {
            index = CTC_CLI_GET_ARGC_INDEX("detail");
            if (0xFF != index)
            {
                type = CTC_DKITS_DUMP_USAGE_HASH_DETAIL;
            }
            else
            {
                type = CTC_DKITS_DUMP_USAGE_HASH_BRIEF;
            }
        }
    }
    else
    {
        type = CTC_DKITS_DUMP_USAGE_TCAM_KEY;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", lchip, argv[index + 1]);
    }

    if (g_dkit_api->cfg_usage)
    {
        (g_dkit_api->cfg_usage(lchip, &type));
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(cli_dkit_serdes_loopback,
        cli_dkit_serdes_loopback_cmd,
        "serdes SERDES_ID loopback (internal | external) (enable|disable) (lchip CHIP_ID|)",
        "Serdes",
        "Serdes ID",
        "Set serdes loopback",
        "Internal loopback, Tx->Rx",
        "External loopback, Rx->Tx",
        "Enable",
        "Disable",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_serdes_ctl_para_t ctc_dkit_serdes_ctl_para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&ctc_dkit_serdes_ctl_para, 0, sizeof(ctc_dkit_serdes_ctl_para_t));

    ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_LOOPBACK;
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.serdes_id, argv[0], 0, CTC_MAX_UINT32_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("internal");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.para[1] = CTC_DKIT_SERDIS_LOOPBACK_INTERNAL;
    }
    else
    {
        ctc_dkit_serdes_ctl_para.para[1] = CTC_DKIT_SERDIS_LOOPBACK_EXTERNAL;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("enable");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_CTL_ENABLE;
    }
    else
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_CTL_DISABLE;
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", ctc_dkit_serdes_ctl_para.lchip, argv[index + 1]);
    }


    if (g_dkit_api->serdes_ctl)
    {
        return g_dkit_api->serdes_ctl(&ctc_dkit_serdes_ctl_para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(cli_dkit_serdes_pbrs,
        cli_dkit_serdes_pbrs_cmd,
        "serdes SERDES_ID prbs PATTERN (enable | disable | check (keep |)) (lchip CHIP_ID|)",
        "Serdes",
        "Serdes ID",
        "Set serdes prbs",
        "PRBS pattern, 0:PRBS7+, 1:PRBS7-, 2:PRBS15+, 3:PRBS15-, 4:PRBS23+, 5:PRBS23-, 6:PRBS31+, 7:PRBS31-, 8:PRBS9, 9:Squareware(8081)",
        "Tx enable",
        "Tx disable",
        "Rx check",
        "Keep current status after check",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_serdes_ctl_para_t ctc_dkit_serdes_ctl_para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&ctc_dkit_serdes_ctl_para, 0, sizeof(ctc_dkit_serdes_ctl_para_t));

    ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_PRBS;
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.serdes_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT8_RANGE("pattern", ctc_dkit_serdes_ctl_para.para[1], argv[1], 0, CTC_MAX_UINT8_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("enable");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_CTL_ENABLE;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("disable");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_CTL_DISABLE;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("check");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_CTL_CEHCK;
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("keep");
        if (0xFF != index)
        {
            ctc_dkit_serdes_ctl_para.para[2] = 1;
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", ctc_dkit_serdes_ctl_para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->serdes_ctl)
    {
        return g_dkit_api->serdes_ctl(&ctc_dkit_serdes_ctl_para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_serdes_eye,
        cli_dkit_serdes_eye_cmd,
        "serdes SERDES_ID eye (((height | width | width-slow | ) times TIMES ((precision (e3 | e6)) |)) | scope ) (lchip CHIP_ID|)",
        "Serdes",
        "Serdes ID",
        "Digital eye measure",
        "Eye height",
        "Eye width",
        "Eye width test slowly",
        "Times of measure",
        "Times of measure",
        "Precision",
        "E3",
        "E6",
        "Eye scope",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_serdes_ctl_para_t ctc_dkit_serdes_ctl_para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&ctc_dkit_serdes_ctl_para, 0, sizeof(ctc_dkit_serdes_ctl_para_t));
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.serdes_id, argv[0], 0, CTC_MAX_UINT32_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("scope");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_EYE_SCOPE;
    }
    else
    {
        ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_EYE_ALL;
        ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_EYE;
        index = CTC_CLI_GET_ARGC_INDEX("times");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32_RANGE("times", ctc_dkit_serdes_ctl_para.para[1] , argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        }

        index = CTC_CLI_GET_ARGC_INDEX("height");
        if (0xFF != index)
        {
            ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_EYE_HEIGHT;
        }

        index = CTC_CLI_GET_ARGC_INDEX("width");
        if (0xFF != index)
        {
            ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_EYE_WIDTH;
        }

        index = CTC_CLI_GET_ARGC_INDEX("width-slow");
        if (0xFF != index)
        {
            ctc_dkit_serdes_ctl_para.para[0] = CTC_DKIT_SERDIS_EYE_WIDTH_SLOW;
        }

        index = CTC_CLI_GET_ARGC_INDEX("e3");
        if (0xFF != index)
        {
            ctc_dkit_serdes_ctl_para.precision = CTC_DKIT_EYE_METRIC_PRECISION_TYPE_E3;
        }
        else
        {
            ctc_dkit_serdes_ctl_para.precision = CTC_DKIT_EYE_METRIC_PRECISION_TYPE_E6;
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", ctc_dkit_serdes_ctl_para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->serdes_ctl)
    {
        return g_dkit_api->serdes_ctl(&ctc_dkit_serdes_ctl_para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dkit_serdes_ffe,
        cli_dkit_serdes_ffe_cmd,
        "serdes SERDES_ID ffe DEST_SERDES_ID PATTERN COEFFICIENT (c0 C0_MIN C0_MAX) (c1 C1_MIN C1_MAX) (c2 C2_MIN C2_MAX) \
        (c3 C3_MIN C3_MAX | ) { file FILENAME | delay DELAY | } (lchip CHIP_ID|)",
        "Serdes",
        "Serdes ID",
        "FFE para test",
        "Dest serdes ID",
        "PRBS pattern, 0:PRBS7+, 1:PRBS7-, 2:PRBS15+, 3:PRBS15-, 4:PRBS23+, 5:PRBS23-, 6:PRBS31+, 7:PRBS31-",
        "Coefficient sum threshold",
        "Coefficient0",
        "Coefficient0 minimum value",
        "Coefficient0 maximum value",
        "Coefficient1",
        "Coefficient1 minimum value",
        "Coefficient1 maximum value",
        "Coefficient2",
        "Coefficient2 minimum value",
        "Coefficient2 maximum value",
        "Coefficient3",
        "Coefficient3 minimum value",
        "Coefficient3 maximum value",
        "File name",
        "File name",
        "Delay between scan",
        "Unit: ms",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8 index = 0;
    ctc_dkit_serdes_ctl_para_t ctc_dkit_serdes_ctl_para;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&ctc_dkit_serdes_ctl_para, 0, sizeof(ctc_dkit_serdes_ctl_para_t));
    ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_FFE;
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.serdes_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.para[0], argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT8_RANGE("pattern", ctc_dkit_serdes_ctl_para.para[1], argv[2], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("coefficient-sum", ctc_dkit_serdes_ctl_para.para[2], argv[3], 0, CTC_MAX_UINT32_VALUE);


    index = CTC_CLI_GET_ARGC_INDEX("c0");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("c0", ctc_dkit_serdes_ctl_para.ffe.coefficient0_min, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        CTC_CLI_GET_UINT16_RANGE("c0", ctc_dkit_serdes_ctl_para.ffe.coefficient0_max, argv[index + 2], 0, CTC_MAX_UINT16_VALUE);
    }
    index = CTC_CLI_GET_ARGC_INDEX("c1");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("c1", ctc_dkit_serdes_ctl_para.ffe.coefficient1_min, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        CTC_CLI_GET_UINT16_RANGE("c1", ctc_dkit_serdes_ctl_para.ffe.coefficient1_max, argv[index + 2], 0, CTC_MAX_UINT16_VALUE);
    }
    index = CTC_CLI_GET_ARGC_INDEX("c2");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("c2", ctc_dkit_serdes_ctl_para.ffe.coefficient2_min, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        CTC_CLI_GET_UINT16_RANGE("c2", ctc_dkit_serdes_ctl_para.ffe.coefficient2_max, argv[index + 2], 0, CTC_MAX_UINT16_VALUE);
    }
    index = CTC_CLI_GET_ARGC_INDEX("c3");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("c3", ctc_dkit_serdes_ctl_para.ffe.coefficient3_min, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        CTC_CLI_GET_UINT16_RANGE("c3", ctc_dkit_serdes_ctl_para.ffe.coefficient3_max, argv[index + 2], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("delay");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("delay", ctc_dkit_serdes_ctl_para.para[3], argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("file");
    if (0xFF != index)
    {
        ctc_dkit_serdes_ctl_para.str= argv[index + 1];
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", ctc_dkit_serdes_ctl_para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->serdes_ctl)
    {
        return g_dkit_api->serdes_ctl(&ctc_dkit_serdes_ctl_para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(cli_dkit_serdes_status,
        cli_dkit_serdes_status_cmd,
        "serdes SERDES_ID status (lchip CHIP_ID|)",
        "Serdes",
        "Serdes ID",
        "Serdes status",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    ctc_dkit_serdes_ctl_para_t ctc_dkit_serdes_ctl_para;
    uint8 index = 0;

    CTC_DKIT_INIT_CHECK();

    sal_memset(&ctc_dkit_serdes_ctl_para, 0, sizeof(ctc_dkit_serdes_ctl_para_t));
    CTC_CLI_GET_UINT32_RANGE("serdes-id", ctc_dkit_serdes_ctl_para.serdes_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    ctc_dkit_serdes_ctl_para.type = CTC_DKIT_SERDIS_CTL_STATUS;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", ctc_dkit_serdes_ctl_para.lchip, argv[index + 1]);
    }

    if (g_dkit_api->serdes_ctl)
    {
        return g_dkit_api->serdes_ctl(&ctc_dkit_serdes_ctl_para);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_integrity_check,
        cli_dkit_integrity_check_cmd,
        "integrity-check GOLDEN_FILE RESULT_FILE (verbos |) (lchip CHIP_ID|)",
        "integrity check cmd",
        "Integrity check file name",
        "Result file name",
        "Show detail error message",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8  index = 0;
    int32  ret = DRV_E_NONE;
    char*  p_golden_file = NULL;
    char*  p_result_file = NULL;
    uint32 verbos = 0;
    sal_file_t p_f = NULL;
    uint8 lchip = 0;

    p_golden_file = argv[0];
    p_result_file = argv[1];
    CTC_DKIT_INIT_CHECK();
    index = CTC_CLI_GET_ARGC_INDEX("verbos");
    if (0xFF != index)
    {
        verbos = 1;
    }
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", lchip, argv[index + 1]);
    }

    if (g_dkit_api->integrity_check)
    {
        ret = g_dkit_api->integrity_check(lchip, p_golden_file, p_result_file, &verbos);
        if (CLI_SUCCESS != ret)
        {
            CTC_DKIT_PRINT("Integrity check result error!\n");
            if (argc > 2)
            {
                p_f = sal_fopen(argv[3], "r");
                if (NULL == p_f)
                {
                    CTC_DKIT_PRINT("Open stats debug file:%s failed!\n", argv[2]);
                }
                else
                {
                    sal_fclose(p_f);
                    ret = ctc_vti_command(g_ctc_vti, argv[3]);
                    if(ret && source_quiet_on)
                    {
                        CTC_DKIT_PRINT("%s\n", argv[3]);
                    }
                }
            }
        }
        return ret;
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_dkit_debug,
    cli_dkit_debug_cmd,
    "debug dkits (on | off)",
    "Debug info",
    "Dkits",
    "On",
    "Off")
{
    uint8 index = 0;
    index = CTC_CLI_GET_ARGC_INDEX("on");
    if (0xFF != index)
    {
        dkits_debug = TRUE;
    }
    else
    {
        dkits_debug = FALSE;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_dkit_packet_dump,
        ctc_dkit_packet_dump_cmd,
        "packet (capture net-tx | dump (net-tx|net-rx|bsr (pkt-len PKT_LEN|))) gport GPORT (lchip CHIP_ID|)",
        "Packet cmd",
        "Capture",
        "Net tx buffer",
        "Dump",
        "Net tx buffer",
        "Net rx buffer",
        "Bsr buffer",
        "Packet length",
        "<0-4096> Byte",
        "Global port",
        "Gchip(5bit) | lport(8bit)",
        CTC_DKITS_CHIP_DESC,
        CTC_DKITS_CHIP_ID_DESC)
{
    uint8  index = 0;
    uint16 gport = 0;
    uint32 pkt_len = 0;
    uint8 lchip = 0;
    ctc_dkits_dump_packet_type_t dump_packet_type = 0;
    CTC_DKIT_INIT_CHECK();
    CTC_CLI_GET_UINT16("gport", gport, argv[argc - 1]);

    index = CTC_CLI_GET_ARGC_INDEX("capture");
    if (0xFF != index)
    {
        dump_packet_type = CTC_DKITS_DUMP_PACKET_TYPE_CAPTURE;
    }
    else
    {
        index = CTC_CLI_GET_ARGC_INDEX("net-tx");
        if (0xFF != index)
        {
            dump_packet_type = CTC_DKITS_DUMP_PACKET_TYPE_NETTX;
        }
        index = CTC_CLI_GET_ARGC_INDEX("net-rx");
        if (0xFF != index)
        {
            dump_packet_type = CTC_DKITS_DUMP_PACKET_TYPE_NETRX;
        }
        index = CTC_CLI_GET_ARGC_INDEX("bsr");
        if (0xFF != index)
        {
            dump_packet_type = CTC_DKITS_DUMP_PACKET_TYPE_BSR;

            index = CTC_CLI_GET_ARGC_INDEX("pkt-len");
            if (0xFF != index)
            {
                CTC_CLI_GET_UINT32("pkt-len", pkt_len, argv[index + 1]);
            }
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_INTEGER("lchip", lchip, argv[index + 1]);
    }

    if (g_dkit_api->packet_dump)
    {
        g_dkit_api->packet_dump(lchip, &dump_packet_type, &gport, &pkt_len);
    }
    else
    {
        CTC_DKIT_NOT_SUPPORT();
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

int32
ctc_dkit_cli_init(uint8 cli_tree_mode)
{
    ctc_dkit_init();/*init drv and api*/

    ctc_com_cli_init(cli_tree_mode);

    /*1. Basic function*/
    install_element(cli_tree_mode, &cli_dkit_show_version_cmd);

    install_element(cli_tree_mode, &cli_dkit_list_tbl_cmd);
    install_element(cli_tree_mode, &cli_dkit_read_reg_or_tbl_cmd);
    install_element(cli_tree_mode, &cli_dkit_write_reg_or_tbl_cmd);

    install_element(CTC_SDK_MODE, &cli_dkit_list_tbl_cmd);
    install_element(CTC_SDK_MODE, &cli_dkit_read_reg_or_tbl_cmd);
    install_element(CTC_SDK_MODE, &cli_dkit_write_reg_or_tbl_cmd);

#if 0
    install_element(CTC_SDK_MODE, &cli_dbg_tool_write_tbl_reg_fld_cmd);
#endif

    //install_element(cli_tree_mode, &cli_dkit_reset_reg_or_tbl_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_tbl_reg_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_interface_status_cmd);

#if(SDK_WORK_PLATFORM == 0)
    install_element(cli_tree_mode, &cli_dkit_read_address_cmd);
    install_element(cli_tree_mode, &cli_dkit_write_address_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_tbl_reg_by_addr_cmd);
#endif

    /*2. Normal function*/
    install_element(cli_tree_mode, &cli_dkit_install_capture_flow_cmd);
    install_element(cli_tree_mode, &cli_dkit_clear_capture_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_discard_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_discard_type_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_path_cmd);
    install_element(cli_tree_mode, &cli_dkit_tcam_scan_cmd);
    install_element(cli_tree_mode, &cli_dkit_tcam_show_key_type_cmd);
    install_element(cli_tree_mode, &cli_dkit_tcam_capture_start_cmd);
    install_element(cli_tree_mode, &cli_dkit_tcam_capture_stop_cmd);
    install_element(cli_tree_mode, &cli_dkit_tcam_capture_show_cmd);

    /*3. Advanced function*/
    install_element(cli_tree_mode, &cli_dkit_show_monitor_q_id_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_monitor_q_depth_cmd);
    install_element(cli_tree_mode, &cli_dkit_show_monitor_sensor_cmd);
    install_element(cli_tree_mode, &cli_dkit_monitor_temperature_cmd);

    install_element(cli_tree_mode, &ctc_dkit_dump_cfg_dump_cmd);
    install_element(cli_tree_mode, &ctc_dkit_dump_cfg_decode_cmd);
    install_element(cli_tree_mode, &ctc_dkit_dump_cfg_cmp_cmd);
    install_element(cli_tree_mode, &cli_dkit_dump_memory_usage_cmd);

    install_element(cli_tree_mode, &cli_dkit_serdes_loopback_cmd);
    install_element(cli_tree_mode, &cli_dkit_serdes_pbrs_cmd);
    install_element(cli_tree_mode, &cli_dkit_serdes_eye_cmd);
    install_element(cli_tree_mode, &cli_dkit_serdes_ffe_cmd);
    install_element(cli_tree_mode, &cli_dkit_serdes_status_cmd);

    install_element(cli_tree_mode, &cli_dkit_integrity_check_cmd);
    install_element(cli_tree_mode, &ctc_dkit_packet_dump_cmd);

    install_element(cli_tree_mode, &cli_dkit_debug_cmd);

    return CLI_SUCCESS;
}

