/**
 @file ctc_goldengate_vlan.c

 @date 2009-10-17

 @version v2.0

 The file contains all vlan APIs
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_const.h"

#include "ctc_goldengate_vlan.h"
#include "sys_goldengate_scl.h"
#include "sys_goldengate_vlan.h"
#include "sys_goldengate_vlan_classification.h"
#include "sys_goldengate_vlan_mapping.h"
#include "sys_goldengate_nexthop_api.h"

/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/
/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/

/**
 @brief init the vlan module
*/
int32
ctc_goldengate_vlan_init(uint8 lchip, ctc_vlan_global_cfg_t* vlan_global_cfg)
{
    ctc_vlan_global_cfg_t vlan_cfg;

    if (NULL == vlan_global_cfg)
    {
        /*set default value*/
        sal_memset(&vlan_cfg, 0, sizeof(ctc_vlan_global_cfg_t));
        vlan_cfg.vlanptr_mode = CTC_VLANPTR_MODE_USER_DEFINE1;
        vlan_global_cfg = &vlan_cfg;
    }

    CTC_ERROR_RETURN(sys_goldengate_vlan_init(lchip, vlan_global_cfg));
    CTC_ERROR_RETURN(sys_goldengate_vlan_class_init(lchip, vlan_global_cfg));
    CTC_ERROR_RETURN(sys_goldengate_vlan_mapping_init(lchip));

    return CTC_E_NONE;
}

/**
 @brief The function is to create a vlan
*/
int32
ctc_goldengate_vlan_create_vlan(uint8 lchip, uint16 vlan_id)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_create_vlan(lchip, vlan_id));

    return CTC_E_NONE;
}

/**
 @brief The function is to create a vlan with uservlanptr
*/
int32
ctc_goldengate_vlan_create_uservlan(uint8 lchip, ctc_vlan_uservlan_t* user_vlan)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_create_uservlan(lchip, user_vlan));

    return CTC_E_NONE;
}

/**
 @brief The function is to remove the vlan
*/
int32
ctc_goldengate_vlan_destroy_vlan(uint8 lchip, uint16 vlan_id)
{

    CTC_ERROR_RETURN(sys_goldengate_vlan_destory_vlan(lchip, vlan_id));

    return CTC_E_NONE;
}

/**
 @brief The function is to add member port to a vlan
*/
int32
ctc_goldengate_vlan_add_port(uint8 lchip, uint16 vlan_id, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_port(lchip, vlan_id, gport));

    return CTC_E_NONE;
}

/**
 @brief The function is to show vlan's member port
*/
int32
ctc_goldengate_vlan_get_ports(uint8 lchip, uint16 vlan_id, uint8 gchip, ctc_port_bitmap_t port_bitmap)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_ports(lchip, vlan_id, gchip, port_bitmap));

    return CTC_E_NONE;
}

/**
 @brief The function is to remove member port to a vlan
*/
int32
ctc_goldengate_vlan_remove_port(uint8 lchip, uint16 vlan_id, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_port(lchip, vlan_id, gport));

    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_set_tagged_port(uint8 lchip, uint16 vlan_id, uint32 gport, bool tagged)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_tagged_port(lchip, vlan_id, gport, tagged));

    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_get_tagged_ports(uint8 lchip, uint16 vlan_id, uint8 gchip, ctc_port_bitmap_t port_bitmap)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_tagged_ports(lchip, vlan_id, gchip, port_bitmap));

    return CTC_E_NONE;
}

/**
 @brief The function is to set receive enable on vlan
*/
int32
ctc_goldengate_vlan_set_receive_en(uint8 lchip, uint16 vlan_id, bool enable)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_RECEIVE_EN, enable));

    return CTC_E_NONE;
}

/**
 @brief The function is to get receive on vlan
*/
int32
ctc_goldengate_vlan_get_receive_en(uint8 lchip, uint16 vlan_id, bool* enable)
{
    uint32 value = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_RECEIVE_EN, &value));
    *enable = value ? TRUE : FALSE;
    return CTC_E_NONE;
}

/**
 @brief The function is to set tranmit enable on vlan
*/
int32
ctc_goldengate_vlan_set_transmit_en(uint8 lchip, uint16 vlan_id, bool enable)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_TRANSMIT_EN, enable));

    return CTC_E_NONE;
}

/**
 @brief The function is to get tranmit on vlan
*/
int32
ctc_goldengate_vlan_get_transmit_en(uint8 lchip, uint16 vlan_id, bool* enable)
{
    uint32 value = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_TRANSMIT_EN, &value));
    *enable = value ? TRUE : FALSE;
    return CTC_E_NONE;
}

/**
 @brief The function is to set bridge enable on vlan
*/
int32
ctc_goldengate_vlan_set_bridge_en(uint8 lchip, uint16 vlan_id, bool enable)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_BRIDGE_EN, enable));

    return CTC_E_NONE;
}

/**
 @brief The function is to get bridge on vlan
*/
int32
ctc_goldengate_vlan_get_bridge_en(uint8 lchip, uint16 vlan_id, bool* enable)
{
    uint32 value = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_BRIDGE_EN, &value));
    *enable = value ? TRUE : FALSE;
    return CTC_E_NONE;
}

/**
 @brief The fucntion is to set fid of vlan
*/
int32
ctc_goldengate_vlan_set_fid(uint8 lchip, uint16 vlan_id, uint16 fid)
{

    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_FID, fid));

    return CTC_E_NONE;
}

/**
 @brief The fucntion is to get vrfid of vlan
*/
int32
ctc_goldengate_vlan_get_fid(uint8 lchip, uint16 vlan_id, uint16* fid)
{
    uint32 value_32  = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_FID, &value_32));
    *fid = value_32 & 0xffff;

    return CTC_E_NONE;

}

/**
 @brief The function is set mac learning enable/disable on the vlan
*/
int32
ctc_goldengate_vlan_set_learning_en(uint8 lchip, uint16 vlan_id, bool enable)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_LEARNING_EN, enable));
    return CTC_E_NONE;
}

/**
 @brief The function is get mac learning enable/disable on the vlan
*/
int32
ctc_goldengate_vlan_get_learning_en(uint8 lchip, uint16 vlan_id, bool* enable)
{
    uint32 value = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_LEARNING_EN, &value));
    *enable = value ? TRUE : FALSE;
    return CTC_E_NONE;
}

/**
 @brief The function is to set igmp snooping enable on the vlan
*/
int32
ctc_goldengate_vlan_set_igmp_snoop_en(uint8 lchip, uint16 vlan_id, bool enable)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_IGMP_SNOOP_EN, enable));
    return CTC_E_NONE;
}

/**
 @brief The function is to get igmp snooping enable of the vlan
*/
int32
ctc_goldengate_vlan_get_igmp_snoop_en(uint8 lchip, uint16 vlan_id, bool* enable)
{
    uint32 value = 0;

    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_IGMP_SNOOP_EN, &value));
    *enable = value ? TRUE : FALSE;
    return CTC_E_NONE;
}

/**
 @brief The function is to set dhcp exception action of the vlan
*/
int32
ctc_goldengate_vlan_set_dhcp_excp_type(uint8 lchip, uint16 vlan_id, ctc_exception_type_t type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_DHCP_EXCP_TYPE, type));
    return CTC_E_NONE;
}

/**
 @brief The function is to get dhcp exception action of the vlan
*/
int32
ctc_goldengate_vlan_get_dhcp_excp_type(uint8 lchip, uint16 vlan_id, ctc_exception_type_t* type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_DHCP_EXCP_TYPE, (uint32*)type));
    return CTC_E_NONE;
}

/**
 @brief The function is to set arp exception action of the vlan
*/
int32
ctc_goldengate_vlan_set_arp_excp_type(uint8 lchip, uint16 vlan_id, ctc_exception_type_t type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, CTC_VLAN_PROP_ARP_EXCP_TYPE, type));
    return CTC_E_NONE;
}

/**
 @brief The function is to get arp exception action of the vlan
*/
int32
ctc_goldengate_vlan_get_arp_excp_type(uint8 lchip, uint16 vlan_id, ctc_exception_type_t* type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, CTC_VLAN_PROP_ARP_EXCP_TYPE, (uint32*)type));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_set_property(uint8 lchip, uint16 vlan_id, ctc_vlan_property_t vlan_prop, uint32 value)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_property(lchip, vlan_id, vlan_prop, value));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_get_property(uint8 lchip, uint16 vlan_id, ctc_vlan_property_t vlan_prop, uint32* value)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_property(lchip, vlan_id, vlan_prop, value));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_set_direction_property(uint8 lchip, uint16 vlan_id, ctc_vlan_direction_property_t vlan_prop, ctc_direction_t dir, uint32 value)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_set_direction_property(lchip, vlan_id, vlan_prop, dir, value));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_get_direction_property(uint8 lchip, uint16 vlan_id, ctc_vlan_direction_property_t vlan_prop, ctc_direction_t dir, uint32* value)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_direction_property(lchip, vlan_id, vlan_prop, dir, value));
    return CTC_E_NONE;
}

/***************************************************************
 *
 *  Vlan Classification Begin
 *
 ***************************************************************/

/**
 @brief The function is to add one vlan classification rule
*/
int32
ctc_goldengate_vlan_add_vlan_class(uint8 lchip, ctc_vlan_class_t* p_vlan_class)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_vlan_class(lchip, p_vlan_class));
    return CTC_E_NONE;
}

/**
 @brief The fucntion is to remove on vlan classification rule
*/
int32
ctc_goldengate_vlan_remove_vlan_class(uint8 lchip, ctc_vlan_class_t* p_vlan_class)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_vlan_class(lchip, p_vlan_class));
    return CTC_E_NONE;
}

/**
 @brief The fucntion is to flush vlan classification by type
*/
int32
ctc_goldengate_vlan_remove_all_vlan_class(uint8 lchip, ctc_vlan_class_type_t type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_all_vlan_class(lchip, type));
    return CTC_E_NONE;
}

/**
 @brief Add vlan classification default entry per label
*/
int32
ctc_goldengate_vlan_add_default_vlan_class(uint8 lchip, ctc_vlan_class_type_t type, ctc_vlan_miss_t* p_action)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_default_vlan_class(lchip, type, p_action));
    return CTC_E_NONE;
}

/**
 @brief Remove vlan classification default entry per label
*/
int32
ctc_goldengate_vlan_remove_default_vlan_class(uint8 lchip, ctc_vlan_class_type_t type)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_default_vlan_class(lchip, type));
    return CTC_E_NONE;
}

/**
 @brief The function is to create a vlan range
*/
int32
ctc_goldengate_vlan_create_vlan_range_group(uint8 lchip, ctc_vlan_range_info_t* vrange_info, bool is_svlan)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_create_vlan_range(lchip, vrange_info, is_svlan));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_get_vlan_range_type(uint8 lchip, ctc_vlan_range_info_t* vrange_info, bool* is_svlan)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_vlan_range_type(lchip, vrange_info, is_svlan));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_destroy_vlan_range_group(uint8 lchip, ctc_vlan_range_info_t* vrange_info)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_destroy_vlan_range(lchip, vrange_info));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_add_vlan_range(uint8 lchip, ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_t* vlan_range)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_vlan_range_member(lchip, vrange_info, vlan_range));
    return CTC_E_NONE;
}

/**
 @brief remove vlan range from a vrange_group
*/

int32
ctc_goldengate_vlan_remove_vlan_range(uint8 lchip, ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_t* vlan_range)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_vlan_range_member(lchip, vrange_info, vlan_range));
    return CTC_E_NONE;
}

int32
ctc_goldengate_vlan_get_vlan_range(uint8 lchip, ctc_vlan_range_info_t* vrange_info, ctc_vlan_range_group_t* vrange_group, uint8* count)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_get_vlan_range_member(lchip, vrange_info, vrange_group, count));
    return CTC_E_NONE;

}

/**
 @brief The function is to add one vlan mapping entry on the port in IPE
*/
int32
ctc_goldengate_vlan_add_vlan_mapping(uint8 lchip, uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_vlan_mapping(lchip, gport, p_vlan_mapping));
    return CTC_E_NONE;
}

/**
 @brief The function is to update one vlan mapping entry on the port in IPE
*/
int32
ctc_goldengate_vlan_update_vlan_mapping(uint8 lchip, uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_update_vlan_mapping(lchip, gport, p_vlan_mapping));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove one vlan mapping entry on the port in IPE
*/
int32
ctc_goldengate_vlan_remove_vlan_mapping(uint8 lchip, uint32 gport, ctc_vlan_mapping_t* p_vlan_mapping)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_vlan_mapping(lchip, gport, p_vlan_mapping));
    return CTC_E_NONE;
}

/**
 @brief The function is to add vlan mapping default entry on the port
*/
int32
ctc_goldengate_vlan_add_default_vlan_mapping(uint8 lchip, uint32 gport, ctc_vlan_miss_t* p_action)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_default_vlan_mapping(lchip, gport, p_action));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove vlan mapping miss match default entry of port
*/
int32
ctc_goldengate_vlan_remove_default_vlan_mapping(uint8 lchip, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_default_vlan_mapping(lchip, gport));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove all vlan mapping entries on port
*/
int32
ctc_goldengate_vlan_remove_all_vlan_mapping_by_port(uint8 lchip, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_all_vlan_mapping_by_port(lchip, gport));
    return CTC_E_NONE;
}

/**
 @brief The function is to add one egress vlan mapping entry on the port in EPE
*/
int32
ctc_goldengate_vlan_add_egress_vlan_mapping(uint8 lchip, uint32 gport, ctc_egress_vlan_mapping_t* p_vlan_mapping)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_egress_vlan_mapping(lchip, gport, p_vlan_mapping));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove one egress vlan mapping entry on the port in EPE
*/
int32
ctc_goldengate_vlan_remove_egress_vlan_mapping(uint8 lchip, uint32 gport, ctc_egress_vlan_mapping_t* p_vlan_mapping)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_egress_vlan_mapping(lchip, gport, p_vlan_mapping));
    return CTC_E_NONE;
}

/**
 @brief The function is to add egress vlan mapping default entry on the port
*/
int32
ctc_goldengate_vlan_add_default_egress_vlan_mapping(uint8 lchip, uint32 gport, ctc_vlan_miss_t* p_action)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_add_default_egress_vlan_mapping(lchip, gport, p_action));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove egress vlan mapping default entry of port
*/
int32
ctc_goldengate_vlan_remove_default_egress_vlan_mapping(uint8 lchip, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_default_egress_vlan_mapping(lchip, gport));
    return CTC_E_NONE;
}

/**
 @brief The function is to remove all egress vlan mapping entries on port
*/
int32
ctc_goldengate_vlan_remove_all_egress_vlan_mapping_by_port(uint8 lchip, uint32 gport)
{
    CTC_ERROR_RETURN(sys_goldengate_vlan_remove_all_egress_vlan_mapping_by_port(lchip, gport));
    return CTC_E_NONE;
}

