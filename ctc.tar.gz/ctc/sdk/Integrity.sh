#!/bin/bash

prefix="#@"

if [[ -z $1 ]]
then
	echo "Please specify file name."
	exit 0
fi

if [ -e  convert_$1 ]
then
	rm ./convert_$1
fi

while read line
do
	if [[ ! -z $line ]] && [ "${line:0:1}" == "[" ]
	then
        key1=$(echo $line | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*'='\s*\)\([0-9]*\)/\2 \4 \6 \8/g')
        tbl_name1=$(echo $key1 | awk '{ print $1 }')
		tbl_idx1=$(echo $key1 | awk '{ print $2 }')
		field_name1=$(echo $key1 | awk '{ print $3 }')
        field_val1=$(echo $key1 | awk '{ print $4 }')
		equal=$(echo $line | sed 's/\(.*\']'\)\(\s*\)\('='\)\(\s*\)\(\'['.*\)/\3/g')
		operand=$(echo $line | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)\('\{'\s*'op'\s*'+'\s*'\}'\)\(.*\)/\8/g')

		if [ "${tbl_name1:0:1}" != "[" ] && [ "${equal:0:1}" != "=" ] && [ "$operand" != "{op +}" ]
		then
			str1=$(grep -w "$tbl_name1"_t $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			tblid1=$(echo $str1 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			str2=$(grep -w "$tbl_name1"_"$field_name1"_f $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			fldid1=$(echo $str2 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			echo $prefix$line >> convert_$1
			echo "["$tblid1"."$tbl_idx1"."$fldid1"] = "$field_val1 >> convert_$1
			echo "" >> convert_$1
		elif  [ "${equal:0:1}" == "=" ] &&  [ "$operand" != "{op +}" ]
		then
			left_str=$(echo $line | sed 's/\(.*\']'\)\(\s*\)\('='\)\(\s*\)\(\'['.*\)/\1/g')
			key2=$(echo $left_str | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)/\2 \4 \6/g')
			tbl_name2=$(echo $key2 | awk '{ print $1 }')
			tbl_idx2=$(echo $key2 | awk '{ print $2 }') 				
			field_name2=$(echo $key2 | awk '{ print $3 }') 

			str3=$(grep -w "$tbl_name2"_t $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			tblid2=$(echo $str3 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			str4=$(grep -w "$tbl_name2"_"$field_name2"_f $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			fldid2=$(echo $str4 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')

			right_str=$(echo $line | sed 's/\(.*\']'\)\(\s*\)\('='\)\(\s*\)\(\'['.*\)/\5/g')
			key3=$(echo $right_str | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)/\2 \4 \6/g')
			tbl_name3=$(echo $key3 | awk '{ print $1 }')
			tbl_idx3=$(echo $key3 | awk '{ print $2 }')	
			field_name3=$(echo $key3 | awk '{ print $3 }')
			str5=$(grep -w "$tbl_name3"_t $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			tblid3=$(echo $str5 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			str6=$(grep -w "$tbl_name3"_"$field_name3"_f $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			fldid3=$(echo $str6 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			echo $prefix$line >> convert_$1
			echo "["$tblid2"."$tbl_idx2"."$fldid2"] = ["$tblid3"."$tbl_idx3"."$fldid3"]" >> convert_$1
			echo "" >> convert_$1
		elif [ "$operand" = "{op +}" ]
		then
			multi_operand_str=""
			remain=$line
			while [ "$operand" == "{op +}" ]
			do
				key4=$(echo $remain | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)\('\{'\s*'op'\s*'+'\s*'\}'\)\(.*\)/\2 \4 \6/g')
				tbl_name4=$(echo $key4 | awk '{ print $1 }')
				tbl_idx4=$(echo $key4 | awk '{ print $2 }')
				field_name4=$(echo $key4 | awk '{ print $3 }')
				str7=$(grep -w "$tbl_name4"_t $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
				tblid4=$(echo $str7 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
				str8=$(grep -w "$tbl_name4"_"$field_name4"_f $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
				fldid4=$(echo $str8 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
				multi_operand_str=$multi_operand_str"["$tblid4"."$tbl_idx4"."$fldid4"]"" {op +} "
                remain=$(echo $remain | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)\('\{'\s*'op'\s*'+'\s*'\}'\)\(.*\)/\9/g')
			    operand=$(echo $remain | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*\)\('\{'\s*'op'\s*'+'\s*'\}'\)\(.*\)/\8/g')
			done

			key5=$(echo $remain | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*'='\s*\)\([0-9]*\)/\2 \4 \6/g')
			tbl_name5=$(echo $key5 | awk '{ print $1 }')
			tbl_idx5=$(echo $key5 | awk '{ print $2 }')
			field_name5=$(echo $key5 | awk '{ print $3 }')

			str9=$(grep -w "$tbl_name5"_t $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
            tblid5=$(echo $str9 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			str10=$(grep -w "$tbl_name5"_"$field_name5"_f $HOME/sdklink/sdk/driver/goldengate/include/drv_enum.h)
			fldid5=$(echo $str10 | sed 's/\(\s*\w*\s*\)\(\s*'='\s*\)\([0-9]*\)\(.*\)/\3/g')
			total_val=$(echo $remain | sed 's/\(\s*\'['\s*\)\([A-Za-z0-9_]*\)\(\s*'.'\s*\)\([0-9]*\)\(\s*'.'\s*\)\([A-Za-z0-9_]*\)\(\s*\']'\s*'='\s*\)\([0-9]*\)/\8/g') 
			multi_operand_str=$multi_operand_str"["$tblid5"."$tbl_idx5"."$fldid5"]"" = "$total_val
			echo $prefix$line >> convert_$1
			echo $multi_operand_str >> convert_$1
			echo "" >> convert_$1
		else
			echo $line >> convert_$1
		fi

	elif [[ ! -z $line ]] && [ "${line:0:1}" == "#" ]
	then
		echo $line >> convert_$1
	elif [[ ! -z $line ]]
	then
		echo "Fail to parser line:\""$line"\""
	fi
done<./$1
