/**
 @file sys_humber_port.c

 @date 2009-10-16

 @version v2.0

*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_debug.h"

#include "sys_humber_port.h"
#include "sys_humber_chip.h"
#include "sys_humber_l3if.h"
#include "sys_humber_usrid.h"
#include "sys_humber_vlan.h"
#include "sys_humber_nexthop_api.h"
#include "sys_humber_nexthop.h"
#include "sys_humber_internal_port.h"
#include "sys_humber_queue_enq.h"
#include "drv_io.h"
#include "drv_humber.h"
#include "drv_humber_data_path.h"
/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/
enum sys_serdes_eye_mode_e
{
    SERDES_EYE_MODE_0_HEIGHT=1,  /**< 0's eye height */
    SERDES_EYE_MODE_1_HEIGHT,  /**< 1's eye height */
    SERDES_EYE_MODE_1E2BER=4,  /**< 1e-2 BER */
    SERDES_EYE_MODE_1E4BER,  /**< 1e-4 BER */
    SERDES_EYE_MODE_1E5BER,  /**< 1e-5 BER */
    SERDES_EYE_MODE_1E6BER   /**< 1e-6 BER */
};
typedef enum sys_serdes_eye_mode_e sys_serdes_eye_mode_t;

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
sys_port_master_t* p_port_master = NULL;
extern sys_chip_master_t* p_chip_master;

/****************************************************************************
 *
* Function
*
*****************************************************************************/
/**
 @brief initialize the port module
*/
int32
sys_humber_port_init(void)
{
    int32 ret = CTC_E_NONE;
    uint32 index = 0;
    uint16 gport = 0;
    uint32 lport = 0;
    uint8 chip = 0;
    uint8 gchip = 0;
    uint8 lchip_num = 0;
    ds_phy_port_t phy_port;
    ds_phy_port_ext_t phy_port_ext;
    ds_src_port_t src_port;
    ds_dest_phy_port_t dest_phy_port;
    phy_port_map_table_t ipe_phyport_map;
    ds_dest_port_t dest_port;
    uint32 cmd = 0;
    uint32 phy_cmd = 0;
    uint32 phy_ext_cmd = 0;
    uint32 src_cmd = 0;
    uint32 dest_phy_cmd = 0;
    uint32 dest_cmd = 0;
    uint32 oam_port_cmd = 0;

    if (p_port_master != NULL)
    {
        return CTC_E_NONE;
    }

    lchip_num = sys_humber_get_local_chip_num();

    /*alloc&init DB and mutex*/
    p_port_master = (sys_port_master_t*)mem_malloc(MEM_PORT_MODULE, sizeof(sys_port_master_t));

    if (NULL == p_port_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_port_master, 0, sizeof(sys_port_master_t));
    ret = sal_mutex_create(&(p_port_master->p_port_mutex));

    if (ret || !(p_port_master->p_port_mutex))
    {
        mem_free(p_port_master);

        return CTC_E_FAIL_CREATE_MUTEX;
    }

    MALLOC_2D_POINTER(sys_igs_port_prop_t, p_port_master->igs_port_prop,
                      lchip_num, MAX_PORT_NUM_PER_CHIP);

    if (NULL == p_port_master->igs_port_prop)
    {
        sal_mutex_destroy(p_port_master->p_port_mutex);
        mem_free(p_port_master);

        return CTC_E_NO_MEMORY;
    }

    MALLOC_2D_POINTER(sys_egs_port_prop_t, p_port_master->egs_port_prop,
                      lchip_num, MAX_PORT_NUM_PER_CHIP);

    if (NULL == p_port_master->egs_port_prop)
    {
        mem_free(p_port_master->igs_port_prop);
        sal_mutex_destroy(p_port_master->p_port_mutex);
        mem_free(p_port_master);

        return CTC_E_NO_MEMORY;
    }

    /*init asic table*/
    sal_memset(&phy_port, 0, sizeof(ds_phy_port_t));
    sal_memset(&phy_port_ext, 0, sizeof(ds_phy_port_ext_t));
    sal_memset(&src_port, 0, sizeof(ds_src_port_t));
    sal_memset(&dest_phy_port, 0, sizeof(ds_dest_phy_port_t));
    sal_memset(&dest_port, 0, sizeof(ds_dest_port_t));
    sal_memset(&ipe_phyport_map, 0, sizeof(phy_port_map_table_t));

    phy_port.keep_vlan_tag = 1;
    phy_port.outer_vlan_is_cvlan = 0;
    phy_port_ext.default_vlan_id = 1;
    phy_port_ext.oam_obey_user_id = 1;
    phy_port_ext.src_outer_vlan_is_svlan = 1;
    src_port.bridge_en = 1;
    src_port.source_port_isolated = 0x3F;
    src_port.vpls_src_port = 0x1FFF;
    src_port.use_stag_cos  = 1;
    src_port.routed_port_vlan_ptr = 0x3FFF;
    src_port.port_security_en = 1;
    dest_port.bridge_en = 1;
    dest_port.default_vlan_id = 1;
    dest_port.bridge_l2_match_disable = 0;
    dest_port.dest_port_isolation_id = 0x3F;
    dest_port.dot1q_en = CTC_DOT1Q_TYPE_BOTH;
    dest_port.untag_default_svlan = 1;
    dest_port.untag_default_vlan_id = 1;

    phy_cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DRV_ENTRY_FLAG);
    phy_ext_cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DRV_ENTRY_FLAG);
    src_cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DRV_ENTRY_FLAG);
    dest_phy_cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DRV_ENTRY_FLAG);
    dest_cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DRV_ENTRY_FLAG);
    oam_port_cmd = DRV_IOW(IOC_TABLE, OAM_DS_PORT_PROPERTY, OAM_DS_PORT_PROPERTY_MAC_SA_BYTE);

    for (chip = 0; chip < lchip_num; chip++)
    {
        sys_humber_get_gchip_id(chip, &gchip);

        for (index = 0; index < MAX_PORT_NUM_PER_CHIP; index++)
        {
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, phy_cmd, &phy_port));
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, phy_ext_cmd, &phy_port_ext));
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, src_cmd, &src_port));
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, dest_phy_cmd, &dest_phy_port));
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, dest_cmd, &dest_port));
            CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, oam_port_cmd, &index));

            gport = CTC_MAP_LPORT_TO_GPORT(gchip, index);
            sys_humber_port_set_global_port(chip, index, gport);

            p_port_master->igs_port_prop[chip][index].keep_vlan_tag = 1;
            p_port_master->igs_port_prop[chip][index].src_outer_is_svlan = 1;
            p_port_master->igs_port_prop[chip][index].default_vlan = 1;
            p_port_master->igs_port_prop[chip][index].logic_port = 0x1FFF;
            p_port_master->igs_port_prop[chip][index].route_enable = 1;
            p_port_master->igs_port_prop[chip][index].learning_enable = 1;
            p_port_master->egs_port_prop[chip][index].default_vlan = 1;
            p_port_master->igs_port_prop[chip][index].l3if_id = 0x3FF;
            p_port_master->igs_port_prop[chip][index].port_mac_type = CTC_PORT_MAC_MAX;
            p_port_master->egs_port_prop[chip][index].dot1q_type = CTC_DOT1Q_TYPE_BOTH;
        }

        cmd = DRV_IOW(IOC_TABLE, PHY_PORT_MAP_TABLE, DRV_ENTRY_FLAG);

        /* gmac use lport 0~47 */
        for (index = 0; index < DRV_MAX_GMAC_NUM; index++)
        {
            if (drv_humber_gmac_is_enable(chip, index))
            {
                ipe_phyport_map.local_phy_port = index;

                CTC_ERROR_RETURN(drv_tbl_ioctl(chip, index, cmd, &ipe_phyport_map));
                p_port_master->igs_port_prop[chip][index].port_mac_type = CTC_PORT_MAC_GMAC;
                p_port_master->egs_port_prop[chip][index].tx_threshold = 10;
                p_port_master->egs_port_prop[chip][index].pading_en = 1;
            }
        }

        /* xgmac use lport 0,12,24,36 */
        for (index = 0; index < DRV_MAX_XGMAC_NUM; index++)
        {
            if (drv_humber_xgmac_is_enable(chip, index))
            {
                lport = index * 12;
                ipe_phyport_map.local_phy_port = lport;

                CTC_ERROR_RETURN(drv_tbl_ioctl(chip, lport, cmd, &ipe_phyport_map));
                p_port_master->igs_port_prop[chip][lport].port_mac_type = CTC_PORT_MAC_XGMAC;
                p_port_master->egs_port_prop[chip][lport].tx_threshold = 7;
                p_port_master->egs_port_prop[chip][lport].pading_en = 1;
            }
        }

        /* sgmac use lport 48,49,50,51 */
        for (index = 0; index < DRV_MAX_SGMAC_NUM; index++)
        {
            if (drv_humber_sgmac_is_enable(chip, index))
            {
                lport = index + 48;
                ipe_phyport_map.local_phy_port = lport;
                CTC_ERROR_RETURN(drv_tbl_ioctl(chip, lport, cmd, &ipe_phyport_map));
                p_port_master->igs_port_prop[chip][lport].port_mac_type = CTC_PORT_MAC_SGMAC;
                p_port_master->egs_port_prop[chip][lport].tx_threshold = 7;
                p_port_master->egs_port_prop[chip][lport].pading_en = 1;
            }
        }

        /* cpu mac use lport 53 */
        p_port_master->igs_port_prop[chip][CTC_LPORT_CPU].port_mac_type = CTC_PORT_MAC_CPUMAC;

        /* disable flow control 0~51 and 53*/
        for (index = 0; index <= 51; index++)
        {
            gport = CTC_MAP_LPORT_TO_GPORT(gchip, index);
            sys_humber_port_set_flow_ctl_en(gport, CTC_BOTH_DIRECTION, 0);
        }

        gport = CTC_MAP_LPORT_TO_GPORT(gchip, CTC_LPORT_CPU);
        sys_humber_port_set_flow_ctl_en(gport, CTC_BOTH_DIRECTION, 0);
    }

    return CTC_E_NONE;

}

/**
 @brief set the port default configure
*/
int32
sys_humber_port_set_default_cfg(uint16 gport)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    ds_phy_port_t phy_port;
    ds_phy_port_ext_t phy_port_ext;
    ds_src_port_t src_port;
    ds_dest_port_t dest_port;
    uint32 phy_cmd = 0;
    uint32 phy_ext_cmd = 0;
    uint32 src_cmd = 0;
    uint32 dest_cmd = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d default configure!\n", gport);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    sal_memset(&phy_port, 0, sizeof(ds_phy_port_t));
    sal_memset(&phy_port_ext, 0, sizeof(ds_phy_port_ext_t));
    sal_memset(&src_port, 0, sizeof(ds_src_port_t));
    sal_memset(&dest_port, 0, sizeof(ds_dest_port_t));

    phy_port.keep_vlan_tag = 1;
    phy_port.outer_vlan_is_cvlan = 0;
    phy_port_ext.global_src_port = gport;
    phy_port_ext.src_outer_vlan_is_svlan = 1;
    phy_port_ext.oam_obey_user_id = 1;
    phy_port_ext.svlan_key_first = 1;
    phy_port_ext.default_vlan_id = 1;
    src_port.receive_en = 1;
    src_port.bridge_en = 1;
    src_port.ingress_filtering_en = 1;
    src_port.vpls_src_port = 0x1FFF;
    src_port.source_port_isolated = 0x3F;
    src_port.port_security_en = 1;
    src_port.routed_port_vlan_ptr = 0x3FFF;
    src_port.use_stag_cos = 1;

    dest_port.default_vlan_id = 1;
    dest_port.bridge_en = 1;
    dest_port.transmit_en = 1;
    dest_port.untag_default_vlan_id = 1;
    dest_port.dot1q_en = 0x3;
    dest_port.untag_default_svlan = 1;
    dest_port.dest_port_isolation_id = 0x3F;

    phy_cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DRV_ENTRY_FLAG);
    phy_ext_cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DRV_ENTRY_FLAG);
    src_cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DRV_ENTRY_FLAG);
    dest_cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DRV_ENTRY_FLAG);

    /*do write table*/
    PORT_LOCK;
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, phy_cmd, &phy_port), p_port_master->p_port_mutex);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, phy_ext_cmd, &phy_port_ext), p_port_master->p_port_mutex);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, src_cmd, &src_port), p_port_master->p_port_mutex);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, dest_cmd, &dest_port), p_port_master->p_port_mutex);

    p_port_master->igs_port_prop[lchip][lport].keep_vlan_tag = 1;
    p_port_master->igs_port_prop[lchip][lport].global_src_port = gport;
    p_port_master->igs_port_prop[lchip][lport].src_outer_is_svlan = 1;
    p_port_master->igs_port_prop[lchip][lport].default_vlan = 1;
    p_port_master->igs_port_prop[lchip][lport].receive_en = 1;
    p_port_master->igs_port_prop[lchip][lport].bridge_en = 1;
    p_port_master->egs_port_prop[lchip][lport].default_vlan = 1;
    p_port_master->egs_port_prop[lchip][lport].bridge_en = 1;
    p_port_master->egs_port_prop[lchip][lport].transmit_en = 1;
    p_port_master->egs_port_prop[lchip][lport].dot1q_type = 3;
    PORT_UNLOCK;

    ret = sys_humber_brguc_nh_create(gport, CTC_NH_PARAM_BRGUC_SUB_TYPE_ALL);
    if (CTC_E_ENTRY_EXIST != ret && CTC_E_NONE != ret)
    {
        return ret;
    }

    return CTC_E_NONE;
}

/**
 @brief set the port global_src_port and global_dest_port in system
*/
int32
sys_humber_port_set_global_port(uint8 lchip_id, uint8 lport, uint16 gport)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = gport;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_GLOBAL_PORT_CHECK(gport);
    SYS_PORT_DEBUG_INFO("Set Global port, chip_id=%d, lport=%d, gport=%d\n", lchip_id, lport, gport);

    /*do write table*/
    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip_id][lport].global_src_port, gport);
    PORT_DB_SET(p_port_master->egs_port_prop[lchip_id][lport].global_dest_port, gport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_GLOBAL_SRC_PORT);
    ret = drv_tbl_ioctl(lchip_id, lport, cmd, &field_value);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_GLOBAL_DEST_PORT);
    ret = ret ? ret : drv_tbl_ioctl(lchip_id, lport, cmd, &field_value);

    cmd = DRV_IOW(IOC_TABLE, OAM_DS_PORT_PROPERTY, OAM_DS_PORT_PROPERTY_GLOBAL_SRC_PORT);
    ret = ret ? ret : drv_tbl_ioctl(lchip_id, lport, cmd, &field_value);

    PORT_UNLOCK;
    return ret;
}

/**
 @brief set the port global_src_port and global_dest_port in system
*/
int32
sys_humber_port_get_global_port(uint8 lchip_id, uint8 lport, uint16* gport)
{
    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(gport);

    /*do write table*/
    PORT_LOCK;
    PORT_DB_GET(gport, p_port_master->igs_port_prop[lchip_id][lport].global_src_port);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set port whether the port is enable
*/
int32
sys_humber_port_set_port_en(uint16 gport, bool enable)
{
    int32 ret = CTC_E_NONE;

    enable = enable ? 1 : 0;

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d port enable:%d!\n", gport, enable);

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    ret = sys_humber_port_set_transmit_en(gport, enable);
    ret = ret ? ret : sys_humber_port_set_receive_en(gport, enable);
    ret = ret ? ret : sys_humber_brguc_nh_create(gport, CTC_NH_PARAM_BRGUC_SUB_TYPE_BASIC);
    if (CTC_E_ENTRY_EXIST != ret && CTC_E_NONE != ret)
    {
        return ret;
    }

    return CTC_E_NONE;
}

/**
 @brief set port whether the port is enable
*/
int32
sys_humber_port_get_port_en(uint16 gport, bool* enable)
{
    bool value = 0;
    int32 ret = CTC_E_NONE;

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d port enable:%d!\n", gport, enable);

    /*Sanity check*/
    CTC_PTR_VALID_CHECK(enable);
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    /*When port transmit,receive are all enable,it will return TRUE*/
    ret = sys_humber_port_get_transmit_en(gport, &value);
    *enable = value ? 1 : 0;
    ret = ret ? ret : sys_humber_port_get_receive_en(gport, &value);
    *enable = *enable ? value : *enable;

    return ret;
}

/**
 @brief set port whether the tranmist is enable
*/
int32
sys_humber_port_set_transmit_en(uint16 gport, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d transmit enable:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    PORT_LOCK;
    PORT_DB_SET(p_port_master->egs_port_prop[lchip][lport].transmit_en, enable);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_TRANSMIT_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    PORT_UNLOCK;

    return ret;
}

/**
 @brief get port whether the tranmist is enable
*/
int32
sys_humber_port_get_transmit_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d transmit enable!\n", gport);

    /*do read*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    PORT_LOCK;
    PORT_DB_GET(enable, p_port_master->egs_port_prop[lchip][lport].transmit_en);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set port whether the receive is enable
*/
int32
sys_humber_port_set_receive_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d receive enable:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].receive_en, enable);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_RECEIVE_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief set port whether the receive is enable
*/
int32
sys_humber_port_get_receive_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d receive enable!\n", gport);

    /*do read*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    PORT_LOCK;
    PORT_DB_GET(enable, p_port_master->igs_port_prop[lchip][lport].receive_en);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set port whehter layer2 bridge function is enable
*/
int32
sys_humber_port_set_bridge_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d bridge enable:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].bridge_en, enable);
    PORT_DB_SET(p_port_master->egs_port_prop[lchip][lport].bridge_en, enable);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_BRIDGE_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_BRIDGE_EN);
    ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief set port whether the bridge is enable
*/
int32
sys_humber_port_get_bridge_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d bridge enable!\n", gport);

    /*do read*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    PORT_LOCK;
    PORT_DB_GET(enable, p_port_master->igs_port_prop[lchip][lport].bridge_en);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set port whether the bridge is enable by ingress/egress separately
*/
int32
sys_humber_port_set_bridge(uint16 gport, ctc_direction_t dir, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d bridge dir: %d enable:%d!\n", gport, dir, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if ((dir == CTC_INGRESS) || (dir == CTC_BOTH_DIRECTION))
    {
        PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].bridge_en, enable);
        cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_BRIDGE_EN);
        ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    }

    if ((dir == CTC_EGRESS) || (dir == CTC_BOTH_DIRECTION))
    {
        PORT_DB_SET(p_port_master->egs_port_prop[lchip][lport].bridge_en, enable);
        cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_BRIDGE_EN);
        ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    }

    PORT_UNLOCK;

    return ret;
}

/**
 @brief decide the port whether is routed port
*/
int32
_sys_humber_port_set_routed_port(uint16 gport, bool is_routed)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == is_routed) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d routed port:%d!\n", gport, is_routed);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    p_port_master->igs_port_prop[lchip][lport].routed_port = is_routed;
    p_port_master->egs_port_prop[lchip][lport].routed_port = is_routed;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ROUTED_PORT);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_ROUTED_PORT);
    ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

/**
 @brief bind phy_if to port
*/
int32
sys_humber_port_set_phy_if_en(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    bool is_phy = FALSE;
    uint16 vlan_ptr = 0x3FFF;
    uint16 l3if_id = 0x3FF;
    uint32 field_value = 0;
    uint32 cmd = 0;
    sys_vlan_info_t vlan_info;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d phy_if ,l3if_id:%d enable:%d\n", gport, l3if_id, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    vlan_info.vlan_ptr_type = SYS_VLAN_PTR_TYPE_PHY_IF;
    vlan_info.gport         = p_port_master->igs_port_prop[lchip][lport].global_src_port;
    vlan_info.vid    = 0xFFFF;

    is_phy = sys_humber_l3if_is_port_phy_if(p_port_master->igs_port_prop[lchip][lport].global_src_port);

    if ((TRUE == enable) && (FALSE == is_phy))
    {
        CTC_ERROR_RETURN_WITH_UNLOCK(CTC_E_L3IF_NOT_EXIST, p_port_master->p_port_mutex);
    }

    if ((FALSE == enable) && (TRUE == is_phy))
    {
        CTC_ERROR_RETURN_WITH_UNLOCK(CTC_E_L3IF_EXIST, p_port_master->p_port_mutex);
    }

    if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            ret = sys_humber_vlan_get_vlan_ptr(&vlan_info, &vlan_ptr);
            ret = ret ? ret : sys_humber_vlan_get_l3if_id(&vlan_info, &l3if_id);

            p_port_master->igs_port_prop[lchip][lport].l3if_id  = l3if_id;
            p_port_master->igs_port_prop[lchip][lport].flag     = SYS_PORT_PHY_IF;
            p_port_master->igs_port_prop[lchip][lport].default_vlan = 0;

            ret = ret ? ret : _sys_humber_port_set_routed_port(gport, TRUE);

            field_value = vlan_ptr;
            cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ROUTED_PORT_VLAN_PTR);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);

            field_value = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_VLAN_ID);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
        }
        else
        {
            ret = CTC_E_NONE;
        }
    }
    else if (SYS_PORT_PHY_IF == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            uint16 tmp_vlan_ptr = 0x3FFF;

            cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ROUTED_PORT_VLAN_PTR);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
            if (CTC_E_NONE == ret)
            {
                tmp_vlan_ptr = field_value;
                ret = sys_humber_vlan_get_vlan_ptr(&vlan_info, &vlan_ptr);
                if ((CTC_E_NONE == ret) && (vlan_ptr != tmp_vlan_ptr))
                /*Update vlan ptr*/
                {
                    field_value = vlan_ptr;
                    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ROUTED_PORT_VLAN_PTR);
                    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
                }
            }
        }
        else
        {
            p_port_master->igs_port_prop[lchip][lport].l3if_id  = l3if_id;
            p_port_master->igs_port_prop[lchip][lport].flag     = 0;
            p_port_master->igs_port_prop[lchip][lport].default_vlan = 1;

            ret = ret ? ret : _sys_humber_port_set_routed_port(gport, FALSE);

            field_value = vlan_ptr;
            cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ROUTED_PORT_VLAN_PTR);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);

            field_value = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_VLAN_ID);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
        }
    }
    else
    {
        if (TRUE == enable)
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_phy_if_en(uint16 gport, uint16* l3if_id, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    CTC_PTR_VALID_CHECK(l3if_id);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d phyical interface!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    *enable = (SYS_PORT_PHY_IF == p_port_master->igs_port_prop[lchip][lport].flag) ? TRUE : FALSE;
    PORT_DB_GET(l3if_id, p_port_master->igs_port_prop[lchip][lport].l3if_id);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief enable sub-if on tihs port
*/
int32
sys_humber_port_set_sub_if_en(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint16 gl_port = 0;
    bool is_sub = FALSE;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d sub_if, enable:%d\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    gl_port = p_port_master->igs_port_prop[lchip][lport].global_src_port;
    is_sub  = sys_humber_l3if_is_port_sub_if(gl_port);

    if ((TRUE == enable) && (FALSE == is_sub))
    {
        /*gport is not sub if*/
        CTC_ERROR_RETURN_WITH_UNLOCK(CTC_E_L3IF_NOT_EXIST, p_port_master->p_port_mutex);
    }

    if ((FALSE == enable) && (TRUE == is_sub))
    {
        /*l3if exist, remove l3if first*/
        CTC_ERROR_RETURN_WITH_UNLOCK(CTC_E_L3IF_EXIST, p_port_master->p_port_mutex);
    }

    if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_SUB_IF;

            field_val = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_PORT_USRID_VLAN;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_NONE;
        }
    }
    else if (SYS_PORT_SUB_IF == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            ret = CTC_E_NONE;
        }
        else
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
    }
    else
    {
        if (TRUE == enable)
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_sub_if_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d default vid!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    *enable = (SYS_PORT_SUB_IF == p_port_master->igs_port_prop[lchip][lport].flag) ? TRUE : FALSE;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set default vlan id of packet which receive from this port
*/
int32
sys_humber_port_set_default_vlan(uint16 gport, uint16 vid)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = vid;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_VLAN_RANGE_CHECK(vid);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d default vlan:%d!\n", gport, vid);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    p_port_master->igs_port_prop[lchip][lport].default_vlan = vid;
    p_port_master->egs_port_prop[lchip][lport].default_vlan = vid;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_VLAN_ID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_DEFAULT_VLAN_ID);
    ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;

}

/**
 @brief get default vlan id on the Port
*/
int32
sys_humber_port_get_default_vlan(uint16 gport, uint16* vid)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(vid);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d default vid!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(vid, p_port_master->igs_port_prop[lchip][lport].default_vlan);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set default cos of vlantag of packet which receive from the port
*/
int32
sys_humber_port_set_default_pcp(uint16 gport, uint8 pcp)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = pcp;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d default pcp:%d!\n", gport, pcp);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_PCP);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

/**
 @brief get default cos on this port
*/
int32
sys_humber_port_get_default_pcp(uint16 gport, uint8* pcp)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(pcp);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d default pcp!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_PCP);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *pcp = field_val;

    return ret;
}

/**
 @brief set default cfi of vlan tag of packet which receive from the port
*/
int32
sys_humber_port_set_default_dei(uint16 gport, uint8 dei)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = dei;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d default cfi:%d!\n", gport, dei);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_DEI);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

/**
 @brief get default cfi on this port
*/
int32
sys_humber_port_get_default_dei(uint16 gport, uint8* dei)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(dei);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d default cfi!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_DEFAULT_DEI);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *dei = field_val;

    return ret;
}

/**
 @brief set protocol vlan enable on port
*/
int32
sys_humber_port_set_protocol_vlan_en(uint16 gport, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d protocol:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PROTOCOL_VLAN_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

/**
 @brief set protocol vlan enable on port
*/
int32
sys_humber_port_get_protocol_vlan_en(uint16 gport, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d protocol enable!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PROTOCOL_VLAN_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

/**
 @brief set vlan mapping enable on port
*/
int32
sys_humber_port_set_vlan_mapping_en(uint16 gport, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan mapping enable:%d\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if (SYS_PORT_VLAN_MAPPING == p_port_master->igs_port_prop[lchip][lport].flag)
    /*orignal is enable*/
    {
        if (TRUE == enable)     /*current setting is enable*/
        {
            ret = CTC_E_NONE;
        }
        else                    /*current setting is disable*/
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
    }
    else
    /*orignal is disable*/
    {
        if (TRUE == enable)     /*current setting is enable*/
        {
            if (0 != p_port_master->igs_port_prop[lchip][lport].flag)
            {
                ret = CTC_E_PORT_HAS_OTHER_FEATURE;
            }
            else
            {
                p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_VLAN_MAPPING;

                field_val = SYS_PORT_USRID_VLAN;
                cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
                ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

                field_val = 1;
                cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
                ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
            }
        }
        else                    /*current setting is disable*/
        {
            ret = CTC_E_NONE;
        }
    }

    PORT_UNLOCK;

    return ret;
}

/**
 @brief Get vlan mapping enable/disable on port
*/
int32
sys_humber_port_get_vlan_mapping_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d vlan mapping enable\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if (SYS_PORT_VLAN_MAPPING == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        *enable = TRUE;
    }
    else
    {
        *enable = FALSE;
    }

    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_vlan_classify_enable(uint16 gport, ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan classification enable, type:%d\n", gport, type);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;

    switch (type)
    {
    case CTC_VLAN_CLASS_MAC:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_VLAN_MAC;

            field_val = SYS_PORT_USRID_MAC;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else if (SYS_PORT_VLAN_MAC == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }

        break;

    case CTC_VLAN_CLASS_IPV4:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_VLAN_IPV4;

            field_val = SYS_PORT_USRID_IP;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else if (SYS_PORT_VLAN_IPV4 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }

        break;

    case CTC_VLAN_CLASS_IPV6:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_VLAN_IPV6;

            field_val = SYS_PORT_USRID_IP;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else if (SYS_PORT_VLAN_IPV6 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            field_val = SYS_USRID_RESERVE_LABEL_FOR_VLAN_CLASS;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }

        break;

    case CTC_VLAN_CLASS_PROTOCOL:
        break;

    default:
        ret = CTC_E_VLAN_CLASS_INVALID_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_set_vlan_classify_disable(uint16 gport, ctc_vlan_class_type_t type)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan classification disable, type:%d\n", gport, type);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    PORT_LOCK;

    switch (type)
    {
    case CTC_VLAN_CLASS_MAC:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            ret = CTC_E_NONE;
        }
        else if (SYS_PORT_VLAN_MAC == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;
            field_val = FALSE;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }

        break;

    case CTC_VLAN_CLASS_IPV4:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            ret = CTC_E_NONE;
        }
        else if (SYS_PORT_VLAN_IPV4 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;
            field_val = FALSE;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }

        break;

    case CTC_VLAN_CLASS_IPV6:

        if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            ret = CTC_E_NONE;
        }
        else if (SYS_PORT_VLAN_IPV6 == p_port_master->igs_port_prop[lchip][lport].flag)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;
            field_val = FALSE;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }

        break;

    case CTC_VLAN_CLASS_PROTOCOL:
        break;

    default:
        ret = CTC_E_VLAN_CLASS_INVALID_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_vlan_classify_enable(uint16 gport, ctc_vlan_class_type_t* type)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d vlan classification\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;

    switch (p_port_master->igs_port_prop[lchip][lport].flag)
    {
    case SYS_PORT_VLAN_MAC:
        *type = CTC_VLAN_CLASS_MAC;
        break;

    case SYS_PORT_VLAN_IPV4:
        *type = CTC_VLAN_CLASS_IPV4;
        break;

    case SYS_PORT_VLAN_IPV6:
        *type = CTC_VLAN_CLASS_IPV6;
        break;

    default:
        *type = CTC_VLAN_CLASS_MAX;
    }

    PORT_UNLOCK;

    return CTC_E_NONE;
}

/***********************************************************
*   OAM
***********************************************************/
int32
sys_humber_port_set_oam_tunnel_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_OAM_TUNNEL_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;

}

int32
sys_humber_port_get_oam_tunnel_en(uint16 gport, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_MD_LEVEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *enable = (field_value == 1) ? TRUE : FALSE;
    return ret;

}

int32
sys_humber_port_set_igs_oam_max_md_level(uint16 gport, uint8 md_level)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = md_level;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_MD_LEVEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;
}

int32
sys_humber_port_get_igs_oam_max_md_level(uint16 gport, uint8* md_level)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_MD_LEVEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *md_level = field_value;
    return ret;
}

int32
sys_humber_port_set_igs_oam_valid(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ETHER_OAM_VALID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;
}

int32
sys_humber_port_get_igs_oam_valid(uint16 gport, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_ETHER_OAM_VALID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *enable = (field_value == 1) ? TRUE : FALSE;
    return ret;
}

extern int32
sys_humber_port_set_egs_oam_max_md_level(uint16 gport, uint8 md_level)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = md_level;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_MD_LEVEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

extern int32
sys_humber_port_get_egs_oam_max_md_level(uint16 gport, uint8* md_level)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_MD_LEVEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *md_level = field_value;
    return ret;
}

extern int32
sys_humber_port_set_egs_oam_valid(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_ETHER_OAM_VALID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;
}

extern int32
sys_humber_port_get_egs_oam_valid(uint16 gport, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_ETHER_OAM_VALID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *enable = (field_value == 1) ? TRUE : FALSE;
    return ret;

}

/**
 @brief set port enable discard 8023 oam
*/
int32
sys_humber_port_set_discard_none_8023oam_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_DISCARD_NON8023_OAM);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;
}

/**
 @brief set port enable replace tag with default vlan id
*/
int32
sys_humber_port_set_replace_tag_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_DEFAULT_REPLACE_TAG_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    return ret;
}

/**
 @brief get port enable replace tag with default vlan id
*/
int32
sys_humber_port_get_replace_tag_en(uint16 gport, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_DEFAULT_REPLACE_TAG_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    *enable = (field_value == 1) ? TRUE : FALSE;
    return ret;
}

/**
 @brief set port enable ptp
*/
int32
sys_humber_port_set_ptp_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint8 reg_step;
    uint8 field_step;
    uint16 reg_id;
    uint16 field_id;

    uint8 rx_reg_step;
    uint8 rx_field_step;
    uint16 rx_reg_id;
    uint16 rx_field_id;
    uint32 old_mac_rx_value;
    uint32 field_value;

    uint8 tx_reg_step;
    uint8 tx_field_step;
    uint16 tx_reg_id;
    uint16 tx_field_id;

#define MAX_BUFFER_COUNT_READ_TIME 1000
    uint32 rx_channel_buffer_count = 0;
    uint32 rx_channel_buffer_count_field_id = 0;
    uint32 time_out = 0;

    uint8 rsv_port_start = SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_START;
    uint8 rsv_port_end   = SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_START + \
        SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_NUM;
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (!drv_humber_get_ptp_en(lchip))
    {
        return CTC_E_NONE;
    }

    PORT_LOCK;
    if (p_port_master->igs_port_prop[lchip][lport].ptp_en == enable)
    {
        PORT_UNLOCK;
        return CTC_E_NONE;
    }

    /* check for rsv port for oam efm loopback */
    if ((lport >= rsv_port_start) && (lport < rsv_port_end))
    {
        field_value = enable ? 1 : 0;
        cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_PTP_EN);
        CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, cmd, &field_value), p_port_master->p_port_mutex);
        p_port_master->igs_port_prop[lchip][lport].ptp_en = enable;
        PORT_UNLOCK;
        return CTC_E_NONE;
    }

    switch (p_port_master->igs_port_prop[lchip][lport].port_mac_type)
    {
    case CTC_PORT_MAC_GMAC:
        reg_step = GMAC1_GMAC_PTP_EN - GMAC0_GMAC_PTP_EN;
        reg_id = GMAC0_GMAC_PTP_EN + lport * reg_step;
        field_step = GMAC1_GMAC_PTP_EN_PTP_EN - GMAC0_GMAC_PTP_EN_PTP_EN;
        field_id = GMAC0_GMAC_PTP_EN_PTP_EN + lport * field_step;

        rx_reg_step = GMAC1_GMACWRAPPER_GMAC_RX_CTRL - GMAC0_GMACWRAPPER_GMAC_RX_CTRL;
        rx_reg_id = GMAC0_GMACWRAPPER_GMAC_RX_CTRL + lport * reg_step;
        rx_field_step = GMAC1_GMACWRAPPER_GMAC_RX_CTRL_RX_ENABLE - GMAC0_GMACWRAPPER_GMAC_RX_CTRL_RX_ENABLE;
        rx_field_id = GMAC0_GMACWRAPPER_GMAC_RX_CTRL_RX_ENABLE + lport * field_step;

        tx_reg_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL - GMAC0_GMACWRAPPER_GMAC_TX_CTRL;
        tx_reg_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + lport * reg_step;
        tx_field_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD - GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD;
        tx_field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD + lport * field_step;

        break;

    case CTC_PORT_MAC_XGMAC:
        reg_step = XGMAC1_XGMAC_PTP_EN - XGMAC0_XGMAC_PTP_EN;
        reg_id = XGMAC0_XGMAC_PTP_EN + (lport / 12) * reg_step;
        field_step = XGMAC1_XGMAC_PTP_EN_PTP_EN - XGMAC0_XGMAC_PTP_EN_PTP_EN;
        field_id = XGMAC0_XGMAC_PTP_EN_PTP_EN + (lport / 12) * field_step;

        rx_reg_step = XGMAC1_XGMAC_CONFIG1 - XGMAC0_XGMAC_CONFIG1;
        rx_reg_id = XGMAC0_XGMAC_CONFIG1 + (lport / 12) * reg_step;
        rx_field_step = XGMAC1_XGMAC_CONFIG1_RX_ENABLE - XGMAC0_XGMAC_CONFIG1_RX_ENABLE;
        rx_field_id = XGMAC0_XGMAC_CONFIG1_RX_ENABLE + (lport / 12) * field_step;

        tx_reg_step = XGMAC1_XGMAC_CONFIG4 - XGMAC0_XGMAC_CONFIG4;
        tx_reg_id = XGMAC0_XGMAC_CONFIG4 + (lport / 12) * reg_step;
        tx_field_step = XGMAC1_XGMAC_CONFIG4_TX_THRESHOLD - XGMAC0_XGMAC_CONFIG4_TX_THRESHOLD;
        tx_field_id = XGMAC0_XGMAC_CONFIG4_TX_THRESHOLD + (lport / 12) * field_step;
        break;

    case CTC_PORT_MAC_SGMAC:
        reg_step = SGMAC1_SGMAC_PTP_EN - SGMAC0_SGMAC_PTP_EN;
        reg_id = SGMAC0_SGMAC_PTP_EN + (lport - SYS_MAX_GMAC_NUM) * reg_step;
        field_step = SGMAC1_SGMAC_PTP_EN_PTP_EN - SGMAC0_SGMAC_PTP_EN_PTP_EN;
        field_id = SGMAC0_SGMAC_PTP_EN_PTP_EN + (lport - SYS_MAX_GMAC_NUM) * field_step;

        rx_reg_step = SGMAC1_SGMAC_CONFIG1 - SGMAC0_SGMAC_CONFIG1;
        rx_reg_id = SGMAC0_SGMAC_CONFIG1 + (lport - SYS_MAX_GMAC_NUM) * reg_step;
        rx_field_step = SGMAC1_SGMAC_CONFIG1_RX_ENABLE - SGMAC0_SGMAC_CONFIG1_RX_ENABLE;
        rx_field_id = SGMAC0_SGMAC_CONFIG1_RX_ENABLE + (lport - SYS_MAX_GMAC_NUM) * field_step;

        tx_reg_step = SGMAC1_SGMAC_CONFIG4 - SGMAC0_SGMAC_CONFIG4;
        tx_reg_id = SGMAC0_SGMAC_CONFIG4 + (lport - SYS_MAX_GMAC_NUM) * reg_step;
        tx_field_step = SGMAC1_SGMAC_CONFIG4_TX_THRESHOLD - SGMAC0_SGMAC_CONFIG4_TX_THRESHOLD;
        tx_field_id = SGMAC0_SGMAC_CONFIG4_TX_THRESHOLD + (lport - SYS_MAX_GMAC_NUM) * field_step;
        break;

    default:
        PORT_UNLOCK;
        return CTC_E_INVALID_PORT_MAC_TYPE;
    }

    /* store the original mac rx enable value*/
    cmd = DRV_IOR(IOC_REG, rx_reg_id, rx_field_id);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &old_mac_rx_value), p_port_master->p_port_mutex);

    /* disable MAC rxEn */
    field_value = 0;
    cmd = DRV_IOW(IOC_REG, rx_reg_id, rx_field_id);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &field_value), p_port_master->p_port_mutex);

    /* enable/disable mac ptp en */
    field_value = enable ? 1 : 0;
    cmd = DRV_IOW(IOC_REG, reg_id, field_id);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &field_value), p_port_master->p_port_mutex);

    /* read channel buffer counter until it is cleared */
    rx_channel_buffer_count_field_id = NET_RX_CHANNEL_BUFFER_COUNT_CHANNEL_BUFFER_COUNT0 + lport;
    cmd = DRV_IOR(IOC_TABLE, NET_RX_CHANNEL_BUFFER_COUNT, rx_channel_buffer_count_field_id);

    do
    {
        CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &rx_channel_buffer_count), p_port_master->p_port_mutex);
        time_out++;
    }
    while ((rx_channel_buffer_count != 0) && (time_out < MAX_BUFFER_COUNT_READ_TIME));

    field_value = enable ? 0 : p_port_master->egs_port_prop[lchip][lport].tx_threshold;
    cmd = DRV_IOW(IOC_REG, tx_reg_id, tx_field_id);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &field_value), p_port_master->p_port_mutex);

    field_value = enable ? 1 : 0;
    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_PTP_EN);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_tbl_ioctl(lchip, lport, cmd, &field_value), p_port_master->p_port_mutex);

    /* restore MAC rxEn */
    cmd = DRV_IOW(IOC_REG, rx_reg_id, rx_field_id);
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &old_mac_rx_value), p_port_master->p_port_mutex);
    p_port_master->igs_port_prop[lchip][lport].ptp_en = enable;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief get port enable ptp
*/
int32
sys_humber_port_get_ptp_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint8 rsv_port_start = SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_START;
    uint8 rsv_port_end   = SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_START + \
        SYS_HUMBER_STATIC_RESERVED_INTERNAL_PORT_NUM;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /* internal port should be valid */
    if ((lport >= CTC_MAX_HUMBER_PHY_PORT) && ((lport < rsv_port_start) || (lport >= rsv_port_end)))
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    PORT_LOCK;
    *enable = p_port_master->igs_port_prop[lchip][lport].ptp_en;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set port's vlan tag control mode
*/
int32
sys_humber_port_set_vlanctl(uint16 gport, ctc_vlantag_ctl_t mode)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = mode;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    if (mode >= MAX_CTC_VLANTAG_CTL)
    {
        return CTC_E_VLAN_EXCEED_MAX_VLANCTL;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan tag control:%d!\n", gport, mode);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].vlanctl_mode, mode);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_VLAN_TAG_CTL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief get port's vlan tag control mode
*/
int32
sys_humber_port_get_vlanctl(uint16 gport, ctc_vlantag_ctl_t* mode)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(mode);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d vlan tag control!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(mode, p_port_master->igs_port_prop[lchip][lport].vlanctl_mode);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief set packet received from this port vlan tag outer vlan is cvlan
*/
int32
sys_humber_port_set_vlan_domain(uint16 gport, uint32 enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (enable == TRUE) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan domain:%d!\n", gport, enable);
    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].outer_is_cvlan, (uint8)field_value);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_OUTER_VLAN_IS_CVLAN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief Get packet received from this port vlan tag outer vlan is cvlan
*/
int32
sys_humber_port_get_vlan_domain(uint16 gport, uint32* value)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(value);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d outer is cvlan!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(value, p_port_master->igs_port_prop[lchip][lport].outer_is_cvlan);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_src_outer_is_svlan(uint16 gport, bool is_svlan)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (is_svlan == TRUE) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d outer is svlan:%d!\n", gport, is_svlan);
    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].src_outer_is_svlan, is_svlan);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_SRC_OUTER_VLAN_IS_SVLAN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_src_outer_is_svlan(uint16 gport, bool* is_svlan)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(is_svlan);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d outer is svlan!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(is_svlan, p_port_master->igs_port_prop[lchip][lport].src_outer_is_svlan);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
 @brief For double tagged packet, this port is use ctag cos or not
*/
int32
sys_humber_port_set_use_inner_cos(uint16 gport, bool is_inner)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (is_inner == TRUE) ? 0 : 1;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d use inner cos:%d!\n", gport, is_inner);
    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_USE_STAG_COS);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief For double tagged packet, Get this port is use ctag cos
*/
int32
sys_humber_port_get_use_inner_cos(uint16 gport, bool* is_inner)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(is_inner);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d use stag cos!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_USE_STAG_COS);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    *is_inner = (field_value == TRUE) ? 0 : 1;

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_stag_tpid_index_igs(uint8 lchip, uint8 lport, uint8 index)
{
    int32 ret = 0;
    uint32 cmd = 0;
    uint32 field_val = index;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_SVLAN_TPID_INDEX);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

static int32
_sys_humber_port_set_stag_tpid_index_egs(uint8 lchip, uint8 lport, uint8 index)
{
    int32 ret = 0;
    uint32 cmd = 0;
    uint32 field_val = index;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_SVLAN_TPID_INDEX);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_set_stag_tpid_index(uint16 gport, ctc_direction_t dir, uint8 index)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(index, 3);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%dsvlan tpid direction:%d, index:%d\n", gport, dir, index);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(_sys_humber_port_set_stag_tpid_index_igs(lchip, lport, index));
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(_sys_humber_port_set_stag_tpid_index_egs(lchip, lport, index));
    }

    return CTC_E_NONE;
}

int32
sys_humber_port_get_stag_tpid_index(uint16 gport, ctc_direction_t dir, uint8* index)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(index);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d svlan tpid index direction:%d!\n", gport, dir);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_SVLAN_TPID_INDEX);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_SVLAN_TPID_INDEX);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *index = field_val;

    return ret;
}

static int32
_sys_humber_port_set_igs_vlan_filter(uint8 lchip, uint8 lport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    if (enable && (CTC_VLANPTR_MODE_USER_DEFINE1 == sys_humber_vlan_get_vlanptr_mode()))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_INGRESS_FILTERING_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_egs_vlan_filter(uint8 lchip, uint8 lport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    if (enable && (CTC_VLANPTR_MODE_USER_DEFINE1 == sys_humber_vlan_get_vlanptr_mode()))
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_EGRESS_FILTER_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

/**
 @brief set vlan filtering enable/disable on the port
*/
int32
sys_humber_port_set_vlan_filter_en(uint16 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d vlan filtering direction:%d enable:%d!\n", gport, dir, enable);
    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(_sys_humber_port_set_igs_vlan_filter(lchip, lport, enable));
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        CTC_ERROR_RETURN(_sys_humber_port_set_egs_vlan_filter(lchip, lport, enable));
    }

    return CTC_E_NONE;
}

/**
 @brief Get vlan filtering enable/disable on the port
*/
int32
sys_humber_port_get_vlan_filter_en(uint16 gport, ctc_direction_t dir, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d vlan filtering direction:%d enable!\n", gport, dir);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_INGRESS_FILTERING_EN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_EGRESS_FILTER_EN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

/**
 @brief Set port cross connect
*/
int32
sys_humber_port_set_cross_connect(uint16 gport, uint32 nhid)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;
    bool enable = (0xFFFFFFFF == nhid) ? FALSE : TRUE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d cross connect enable:%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    field_value = (TRUE == enable) ? 1 : 0;
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_CROSS_CONNECT);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;

}

/**
 @brief Get port cross connect
*/
int32
sys_humber_port_get_cross_connect(uint16 gport, uint32* p_value)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(p_value);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d cross connect!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_CROSS_CONNECT);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *p_value = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

/**
 @brief Set learning enable/disable on port
*/
int32
sys_humber_port_set_learning_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 0 : 1;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d learning enable:%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].learning_enable, enable);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_LEARNING_DISABLE);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief Get learning enable/disable on port
*/
int32
sys_humber_port_get_learning_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d learning enable!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(enable, p_port_master->igs_port_prop[lchip][lport].learning_enable);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_keep_vlan_tag(uint16 gport, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d keep vlan tag enable:%d\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_KEEP_VLAN_TAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_keep_vlan_tag(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d keep vlan tag\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_KEEP_VLAN_TAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    *enable = (field_val == 1) ? TRUE : FALSE;

    return CTC_E_NONE;
}

/**
 @brief Set port dot1q type
*/
int32
sys_humber_port_set_dot1q_type(uint16 gport, ctc_dot1q_type_t type)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_val = type;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(type, CTC_DOT1Q_TYPE_BOTH);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d dot1q type(0-untag,1-ctag,2-stag,3-dtag):%d!\n", gport, type);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_SET(p_port_master->egs_port_prop[lchip][lport].dot1q_type, type);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_DOT1Q_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    PORT_UNLOCK;

    return ret;
}

/**
 @brief Get port dot1q type
*/
int32
sys_humber_port_get_dot1q_type(uint16 gport, ctc_dot1q_type_t* type)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(type);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d dot1q type(0-untag,1-ctag,2-stag,3-dtag)!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    PORT_DB_GET(type, p_port_master->egs_port_prop[lchip][lport].dot1q_type);
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_use_outer_ttl(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port%d use outer ttl enable%d\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_USE_OUTER_TTL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_use_outer_ttl(uint16 gport, bool* enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d use outer ttl.\n", gport);

    CTC_PTR_VALID_CHECK(enable);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_USE_OUTER_TTL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

/**
 @brief Set port untag default vlan id
*/
int32
sys_humber_port_set_untag_dft_vid(uint16 gport, bool enable, bool untag_svlan)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_val;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d untag default vlan id enable:%d, is svlan:%d!\n", gport, enable, untag_svlan);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    field_val = (TRUE == untag_svlan) ? 1 : 0;
    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UNTAG_DEFAULT_SVLAN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    field_val = (TRUE == enable) ? 1 : 0;
    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UNTAG_DEFAULT_VLAN_ID);
    ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_untag_dft_vid(uint16 gport, bool* enable, bool* untag_svlan)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    CTC_PTR_VALID_CHECK(untag_svlan);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d untag default vlan!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UNTAG_DEFAULT_VLAN_ID);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UNTAG_DEFAULT_SVLAN);
    ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *untag_svlan = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_exception_en(uint16 gport, uint16 bitmap)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = bitmap;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d exception enable:0x%2X!\n", gport, bitmap);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_EXCEPTION2_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_exception_en(uint16 gport, uint16* bitmap)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d exception enable!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_EXCEPTION2_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *bitmap = field_val;

    return ret;
}

int32
sys_humber_port_set_exception_discard(uint16 gport, uint16 bitmap)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = bitmap;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d exception discard:0x%2X!\n", gport, bitmap);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_EXCEPTION2_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_exception_discard(uint16 gport, uint16* bitmap)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d exception discard!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_EXCEPTION2_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *bitmap = field_val;

    return ret;
}

int32
sys_humber_port_set_security_excp_en(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d security exception enable:%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_SECURITY_EXCEPTION_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_security_excp_en(uint16 gport, bool* enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d security exception!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_SECURITY_EXCEPTION_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (field_val == 1) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_security_en(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d security enable :%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_SECURITY_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_security_en(uint16 gport, bool* enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d security exception!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_SECURITY_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (field_val == 1) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_mac_security_discard(uint16 gport, bool discard)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == discard) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d mac security discard:%d!\n", gport, discard);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_MAC_SECURITY_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_get_mac_security_discard(uint16 gport, bool* discard)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port%d mac security discard!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_MAC_SECURITY_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *discard = (field_val == 1) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_ipsg_en(uint16 gport, bool enable)
{
    int32 ret = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d ip source guard enable:%d", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if (0 == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            p_port_master->igs_port_prop[lchip][lport].flag = SYS_PORT_IPSRC_GUARD;

            field_val = 1;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_PORT_USRID_IP;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            field_val = SYS_USRID_RESERVE_LABEL_FOR_IPSG;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
        else
        {
            ret = CTC_E_NONE;
        }
    }
    else if (SYS_PORT_IPSRC_GUARD == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        if (TRUE == enable)
        {
            ret = CTC_E_NONE;
        }
        else
        {
            p_port_master->igs_port_prop[lchip][lport].flag = 0;

            field_val = 0;
            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
            ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);

            cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
            ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
        }
    }
    else
    {
        if (TRUE == enable)
        {
            ret = CTC_E_PORT_HAS_OTHER_FEATURE;
        }
        else
        {
            ret = CTC_E_PORT_FEATURE_MISMATCH;
        }
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_ipsg_en(uint16 gport, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d IP source guard enable\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if (SYS_PORT_IPSRC_GUARD == p_port_master->igs_port_prop[lchip][lport].flag)
    {
        *enable = TRUE;
    }
    else
    {
        *enable = FALSE;
    }

    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_isolation_id(uint16 gport, ctc_direction_t dir, uint8 isolation_id)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = isolation_id;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(isolation_id, SYS_MAX_ISOLUTION_ID_NUM);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_SOURCE_PORT_ISOLATED);
        ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_DEST_PORT_ISOLATION_ID);
        ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    }

    return ret;
}

int32
sys_humber_port_get_isolation_id(uint16 gport, ctc_direction_t dir, uint8* isolation_id)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(isolation_id);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write table*/
    if (CTC_INGRESS == dir)
    {
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_SOURCE_PORT_ISOLATED);
        ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    }
    else if (CTC_EGRESS == dir)
    {
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_DEST_PORT_ISOLATION_ID);
        ret = ret ? ret : drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    *isolation_id = field_val;

    return ret;
}

int32
sys_humber_port_set_ucast_flooding_en(uint16 gport, bool enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UCAST_FLOODING_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_ucast_flooding_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    CTC_PTR_VALID_CHECK(enable);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_UCAST_FLOODING_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    *enable = (1 == field_val) ? TRUE : FALSE;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_mcast_flooding_en(uint16 gport, bool enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_MCAST_FLOODING_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_mcast_flooding_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    CTC_PTR_VALID_CHECK(enable);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_MCAST_FLOODING_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    *enable = (1 == field_val) ? TRUE : FALSE;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_reflective_bridge_en(uint16 gport, bool enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_BRIDGE_L2_MATCH_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_reflective_bridge_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    CTC_PTR_VALID_CHECK(enable);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_BRIDGE_L2_MATCH_DISABLE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

    *enable = (1 == field_val) ? TRUE : FALSE;

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_random_log_igs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_RANDOM_LOG_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_random_log_egs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_RANDOM_LOG_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_random_log_en(uint16 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_random_log_igs_en(lchip, lport, enable);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_random_log_egs_en(lchip, lport, enable);
    }

    return ret;
}

int32
sys_humber_port_get_random_log_en(uint16 gport, ctc_direction_t dir, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);

    /*do read, soft table high priority*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_RANDOM_LOG_EN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_RANDOM_LOG_EN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_random_threshold_igs(uint8 chip, uint8 port, uint16 threshold)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = threshold;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_RANDOM_THRESHOLD);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_random_threshold_egs(uint8 chip, uint8 port, uint16 threshold)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = threshold;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_RANDOM_THRESHOLD);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_random_log_percent(uint16 gport, ctc_direction_t dir, uint8 percent)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;
    uint16 threshold = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    percent = (percent > 100) ? 100 : percent;
    threshold = 0x7FFF * percent / 100;

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_random_threshold_igs(lchip, lport, threshold);
        if (CTC_E_NONE == ret)
        {
            PORT_LOCK;
            p_port_master->igs_port_prop[lchip][lport].random_log_percent = percent;
            PORT_UNLOCK;
        }
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_random_threshold_egs(lchip, lport, threshold);
        if (CTC_E_NONE == ret)
        {
            PORT_LOCK;
            p_port_master->egs_port_prop[lchip][lport].random_log_percent = percent;
            PORT_UNLOCK;
        }
    }

    return ret;
}

int32
sys_humber_port_get_random_log_percent(uint16 gport, ctc_direction_t dir, uint8* percent)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(percent);

    /*do read, soft table high priority*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    switch (dir)
    {
    case CTC_INGRESS:
        PORT_LOCK;
        *percent = p_port_master->igs_port_prop[lchip][lport].random_log_percent;
        PORT_UNLOCK;
        break;

    case CTC_EGRESS:
        *percent = p_port_master->egs_port_prop[lchip][lport].random_log_percent;
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    return ret;
}

/**
 @brief mirror APIs for sys calling
*/
static int32
_sys_humber_port_set_span_igs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_L2_SPAN_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_span_egs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_L2_SPAN_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_span_en(uint16 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_span_igs_en(lchip, lport, enable);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_span_egs_en(lchip, lport, enable);
    }

    return ret;
}

int32
sys_humber_port_get_span_en(uint16 gport, ctc_direction_t dir, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);

    /*do read, soft table high priority*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_L2_SPAN_EN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_L2_SPAN_EN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_span_igs_id(uint8 chip, uint8 port, uint8 span_id)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = span_id;

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_L2_SPAN_ID);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;

}

static int32
_sys_humber_port_set_span_egs_id(uint8 chip, uint8 port, uint8 span_id)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = span_id;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_L2_SPAN_ID);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_span_id(uint16 gport, ctc_direction_t dir, uint8 span_id)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_span_igs_id(lchip, lport, span_id);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_span_egs_id(lchip, lport, span_id);
    }

    return ret;
}

int32
sys_humber_port_get_span_id(uint16 gport, ctc_direction_t dir, uint8* span_id)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(span_id);

    /*do read, soft table high priority*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_L2_SPAN_ID);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_L2_SPAN_ID);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *span_id = field_val;

    return ret;
}

/**
 @brief Userid APIs for sys calling
*/
int32
sys_humber_port_set_usrid_enable(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_usrid_enable(uint16 gport, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);

    /*do read table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_usrid_type(uint16 gport, sys_port_usrid_type_t type)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_value = type;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_usrid_type(uint16 gport, sys_port_usrid_type_t* type)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(type);

    /*do read table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_TYPE);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *type = field_val;

    return ret;
}

int32
sys_humber_port_set_usrid_label(uint16 gport, uint8 label_id)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = label_id;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_usrid_label(uint16 gport, uint8* label_id)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(label_id);

    /*do read table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DS_PHY_PORT_EXT_USER_ID_LABEL);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *label_id = field_val;

    return ret;
}

/**
 @brief Acl&Qos APIs for sys calling
*/

static int32
_sys_humber_port_set_l2acl_igs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2acl_egs_en(uint8 chip, uint8 port, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2acl_enable(uint16 gport, ctc_direction_t dir, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2acl_igs_en(lchip, lport, enable);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_l2acl_egs_en(lchip, lport, enable);
    }

    return ret;
}

int32
sys_humber_port_get_l2acl_enable(uint16 gport, ctc_direction_t dir, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_EN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_EN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_l2acl_igs_label(uint8 chip, uint8 port, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = label;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_LABEL);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2acl_egs_label(uint8 chip, uint8 port, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = label;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_LABEL);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2acl_label(uint16 gport, ctc_direction_t dir, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2acl_igs_label(lchip, lport, label);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        label += 0x80;  /* egress acl label range is <128-255> */
        ret = ret ? ret : _sys_humber_port_set_l2acl_egs_label(lchip, lport, label);
    }

    return ret;
}

int32
sys_humber_port_get_l2acl_label(uint16 gport, ctc_direction_t dir, uint8* label)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_LABEL);
        CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

        *label = field_val;
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_LABEL);
        CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

        if (field_val < 0x80)
        {
            return CTC_E_PORT_INVALID_ACL_LABEL;
        }

        *label = field_val - 0x80;
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_l2acl_igs_prio(uint8 chip, uint8 port, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == l2_high_prio) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_HIGH_PRIORITY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2acl_egs_prio(uint8 chip, uint8 port, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == l2_high_prio) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_HIGH_PRIORITY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2acl_prio(uint16 gport, ctc_direction_t dir, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2acl_igs_prio(lchip, lport, l2_high_prio);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_l2acl_egs_prio(lchip, lport, l2_high_prio);
    }

    return ret;
}

int32
sys_humber_port_get_l2acl_prio(uint16 gport, ctc_direction_t dir, bool* l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_ACL_HIGH_PRIORITY);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_ACL_HIGH_PRIORITY);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *l2_high_prio = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_l2qos_igs_en(uint8 chip, uint8 port, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_LOOKUP_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2qos_egs_en(uint8 chip, uint8 port, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_LOOKUP_EN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2qos_enable(uint16 gport, ctc_direction_t dir, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2qos_igs_en(lchip, lport, enable);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_l2qos_egs_en(lchip, lport, enable);
    }

    return ret;
}

int32
sys_humber_port_get_l2qos_enable(uint16 gport, ctc_direction_t dir, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_LOOKUP_EN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_LOOKUP_EN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_l2qos_igs_label(uint8 chip, uint8 port, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = label;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_LABEL);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2qos_egs_label(uint8 chip, uint8 port, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = label;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_LABLE);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2qos_label(uint16 gport, ctc_direction_t dir, uint8 label)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2qos_igs_label(lchip, lport, label);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        label += 0x80;  /* egress acl label range is <128-255> */
        ret = ret ? ret : _sys_humber_port_set_l2qos_egs_label(lchip, lport, label);
    }

    return ret;
}

int32
sys_humber_port_get_l2qos_label(uint16 gport, ctc_direction_t dir, uint8* label)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_LABEL);
        CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

        *label = field_val;
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_LABLE);
        CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_val));

        if (field_val < 0x80)
        {
            return CTC_E_PORT_INVALID_ACL_LABEL;
        }

        *label = field_val - 0x80;
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_l2qos_igs_prio(uint8 chip, uint8 port, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == l2_high_prio) ? TRUE : FALSE;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_HIGH_PRIORITY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_l2qos_egs_prio(uint8 chip, uint8 port, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == l2_high_prio) ? TRUE : FALSE;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_HIGH_PRIORITY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_l2qos_prio(uint16 gport, ctc_direction_t dir, bool l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_l2qos_igs_prio(lchip, lport, l2_high_prio);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_l2qos_egs_prio(lchip, lport, l2_high_prio);
    }

    return ret;
}

int32
sys_humber_port_get_l2qos_prio(uint16 gport, ctc_direction_t dir, bool* l2_high_prio)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_L2_QOS_HIGH_PRIORITY);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_L2_QOS_HIGH_PRIORITY);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *l2_high_prio = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_igs_qos_domain(uint8 chip, uint8 port, uint8 qos_domain)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = qos_domain;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_QOS_DOMAIN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_egs_qos_domain(uint8 chip, uint8 port, uint8 qos_domain)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = qos_domain;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_QOS_DOMAIN);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_qos_domain(uint16 gport, ctc_direction_t dir, uint8 domain)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_igs_qos_domain(lchip, lport, domain);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_egs_qos_domain(lchip, lport, domain);
    }

    return ret;
}

int32
sys_humber_port_get_qos_domain(uint16 gport, ctc_direction_t dir, uint8* domain)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_QOS_DOMAIN);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_QOS_DOMAIN);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *domain = field_val;

    return ret;
}

int32
sys_humber_port_set_qos_policy(uint16 gport, uint8 policy)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = policy;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_QOS_POLICY);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_qos_policy(uint16 gport, uint8* policy)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(policy);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_QOS_POLICY);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *policy = field_val;

    return ret;
}

static int32
_sys_humber_port_set_port_igs_policer_valid(uint8 chip, uint8 port, bool valid)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == valid) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_POLICER_VALID);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_port_egs_policer_valid(uint8 chip, uint8 port, bool valid)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == valid) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_PORT_POLICER_VALID);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_port_policer_valid(uint16 gport, ctc_direction_t dir, bool valid)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_port_igs_policer_valid(lchip, lport, valid);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_port_egs_policer_valid(lchip, lport, valid);
    }

    return ret;
}

int32
sys_humber_port_get_port_policer_valid(uint16 gport, ctc_direction_t dir,  bool* valid)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_POLICER_VALID);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_PORT_POLICER_VALID);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *valid = (field_val == 1) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_qacl_igs_force_ipv4_mackey(uint8 chip, uint8 port, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == force_mac_key) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_FORCE_ACL_QOS_IPV4_TO_MAC_KEY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_qacl_egs_force_ipv4_mackey(uint8 chip, uint8 port, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == force_mac_key) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_FORCE_IPV4_TO_MAC_KEY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_qacl_force_ipv4_mackey(uint16 gport, ctc_direction_t dir, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_qacl_igs_force_ipv4_mackey(lchip, lport, force_mac_key);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_qacl_egs_force_ipv4_mackey(lchip, lport, force_mac_key);
    }

    return ret;

}

int32
sys_humber_port_get_qacl_force_ipv4_mackey(uint16 gport, ctc_direction_t dir, bool* force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_FORCE_ACL_QOS_IPV4_TO_MAC_KEY);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_FORCE_IPV4_TO_MAC_KEY);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *force_mac_key = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_set_qacl_igs_force_ipv6_mackey(uint8 chip, uint8 port, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == force_mac_key) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_FORCE_ACL_QOS_IPV6_TO_MAC_KEY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

static int32
_sys_humber_port_set_qacl_egs_force_ipv6_mackey(uint8 chip, uint8 port, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd = 0;
    uint32 field_value = (TRUE == force_mac_key) ? 1 : 0;

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_FORCE_IPV6_TO_MAC_KEY);
    ret = drv_tbl_ioctl(chip, port, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_set_qacl_force_ipv6_mackey(uint16 gport, ctc_direction_t dir, bool force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do write*/
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = _sys_humber_port_set_qacl_igs_force_ipv6_mackey(lchip, lport, force_mac_key);
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        ret = ret ? ret : _sys_humber_port_set_qacl_egs_force_ipv6_mackey(lchip, lport, force_mac_key);
    }

    return ret;
}

int32
sys_humber_port_get_qacl_force_ipv6_mackey(uint16 gport, ctc_direction_t dir, bool* force_mac_key)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    /*do read*/
    switch (dir)
    {
    case CTC_INGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_FORCE_ACL_QOS_IPV6_TO_MAC_KEY);
        break;

    case CTC_EGRESS:
        cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_FORCE_IPV6_TO_MAC_KEY);
        break;

    default:
        return CTC_E_INVALID_DIR;
    }

    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);
    *force_mac_key = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_replace_cos_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    ;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d replace cos enable:%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_REPLACE_COS);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_replace_cos_en(uint16 gport, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d replace cos!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_REPLACE_COS);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

int32
sys_humber_port_set_replace_dscp_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    ;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d replace dscp enable:%d!\n", gport, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_REPLACE_DSCP);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

int32
sys_humber_port_get_replace_dscp_en(uint16 gport, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d replace dscp!\n", gport);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_REPLACE_DSCP);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_hss4g_link_power_up(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;

    /*Old humber version not support powerdown serdes*/
    if (drv_humber_old_version(lchip))
    {
        return 0;
    }

    /*---- Power up Hss4G -----*/
    table_id = HSS_N0_CTL + (lport / CTC_MAC_NUM_PER_MACRO);
    if ((lport % CTC_MAC_NUM_PER_MACRO) < 4)
    {
        field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + ((lport % CTC_MAC_NUM_PER_MACRO) * 16);
    }
    else
    {
        field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + 4 * 16 + ((lport % CTC_MAC_NUM_PER_MACRO) - 4) * 15;
    }

    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    table_id = HSS_N0_CTL + (lport / CTC_MAC_NUM_PER_MACRO);
    field_id = HSS_N0_CTL_CFG_N0_TXA_PWR_DWN + ((lport % CTC_MAC_NUM_PER_MACRO) * 13);
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

static int32
_sys_humber_port_hss4g_link_power_down(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 1;

    /*Old humber version not support powerdown serdes*/
    if (drv_humber_old_version(lchip))
    {
        return 0;
    }

    table_id = HSS_N0_CTL + (lport / CTC_MAC_NUM_PER_MACRO);
    if ((lport % CTC_MAC_NUM_PER_MACRO) < 4)
    {
        field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + ((lport % CTC_MAC_NUM_PER_MACRO) * 16);
    }
    else
    {
        field_id = HSS_N0_CTL_CFG_N0_RXA_PWR_DWN + 4 * 16 + ((lport % CTC_MAC_NUM_PER_MACRO) - 4) * 15;
    }

    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*If cpumac use internal ref clk and serdes is also for cpumac clk, shouldn't be power down.*/
    if (!drv_humber_cpumac_use_internal_refclk(lchip) || (lport != DRV_CPUMAC_CLK_SERDES))
    {
        table_id = HSS_N0_CTL + (lport / CTC_MAC_NUM_PER_MACRO);
        field_id = HSS_N0_CTL_CFG_N0_TXA_PWR_DWN + ((lport % CTC_MAC_NUM_PER_MACRO) * 13);
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    }

    return ret;
}

static int32
_sys_humber_port_hss4g_xg_link_power_up(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint8 serdes_link;

    for (serdes_link = (lport / 12) * 4; serdes_link < (lport / 12 + 1) * 4; serdes_link++)
    {
        ret = ret ? ret : _sys_humber_port_hss4g_link_power_up(lchip, serdes_link);
    }

    return ret;
}

static int32
_sys_humber_port_hss4g_xg_link_power_down(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint8 serdes_link;

    for (serdes_link = (lport / 12) * 4; serdes_link < (lport / 12 + 1) * 4; serdes_link++)
    {
        ret = ret ? ret : _sys_humber_port_hss4g_link_power_down(lchip, serdes_link);
    }

    return ret;
}

static int32
_sys_humber_port_hss4g_sg_link_power_up(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint8 serdes_link;

    if (drv_humber_sgmac_use_hss4g(lchip))
    {
        for (serdes_link = (lport - 48) * 4 + 16; serdes_link < (lport - 48 + 1) * 4 + 16; serdes_link++)
        {
            ret = ret ? ret : _sys_humber_port_hss4g_link_power_up(lchip, serdes_link);
        }
    }

    return ret;
}

static int32
_sys_humber_port_hss4g_sg_link_power_down(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint8 serdes_link;

    if (drv_humber_sgmac_use_hss4g(lchip))
    {
        for (serdes_link = (lport - 48) * 4 + 16; serdes_link < (lport - 48 + 1) * 4 + 16; serdes_link++)
        {
            ret = ret ? ret : _sys_humber_port_hss4g_link_power_down(lchip, serdes_link);
        }
    }

    return ret;
}

/* Release reset sequence depending on <HumberHss configuration guide.doc> Rev1.1*/
static int32
_sys_humber_port_release_gmac_reset(uint8 lchip, uint8 lport, ctc_port_speed_t speed_mode)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;
    uint32 clk_divider;
    uint32 mode;
    gmac_pcs_config1_t gmac_pcs;
    gmac_pcs_soft_rst_t gmac_pcs_rst;

    gmac_pcs_rst.gmii_rx_soft_rst = 1;
    gmac_pcs_rst.gmii_tx_soft_rst = 0;
    gmac_pcs_rst.pcs_rx_soft_rst = 1;
    gmac_pcs_rst.pcs_tx_soft_rst = 0;
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &gmac_pcs_rst);

    /*!!!!!!!!!!!!!!!keep order!!!!!!!!!!!!!!!!!!!!!!*/
    switch (speed_mode)
    {
    case CTC_PORT_SPEED_10M:
        clk_divider = 2;
        gmac_pcs.sgmii100m_mode_cfg = 0;
        gmac_pcs.sgmii1g_mode_cfg = 0;
        mode = 0;

        break;

    case CTC_PORT_SPEED_100M:
        clk_divider = 1;
        gmac_pcs.sgmii100m_mode_cfg = 1;
        gmac_pcs.sgmii1g_mode_cfg = 0;
        mode = 1;
        break;

    case CTC_PORT_SPEED_1G:
        clk_divider = 0;
        gmac_pcs.sgmii100m_mode_cfg = 0;
        gmac_pcs.sgmii1g_mode_cfg = 1;
        mode = 2;
        break;

    case CTC_PORT_SPEED_2G5:
        clk_divider = 0;
        gmac_pcs.sgmii100m_mode_cfg = 0;
        gmac_pcs.sgmii1g_mode_cfg = 1;
        mode = 3;
        break;

    default:
        return CTC_E_INVALID_PORT_SPEED_MODE;
    }

    /* 1. ----- cfg GMII refClk divide base on speed  -----*/
    table_id = GMAC0_GMAC_CLK_DIVIDER + (lport * 20);
    field_id = GMAC0_GMAC_CLK_DIVIDER_CLK_DIVIDER;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &clk_divider);

    /* 2. ----- Release GMII refClk divider reset  --------*/
    table_id = GMAC0_GMAC_CLK_DIVIDER + (lport * 20);
    field_id = GMAC0_GMAC_CLK_DIVIDER_RST_CLK_DIVIDER;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /* 3. -----  enable gmac clock  --------*/
    field_val = 1;
    field_id = lport + MODULE_GATED_CLK_CTL_EN_CLK_SUP_GMAC_WRAPPER0;
    cmd = DRV_IOW(IOC_REG, MODULE_GATED_CLK_CTL, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    field_val = 0;

    /* 4. -----    cfg gmac mode      --------*/
    table_id = GMAC0_GMACWRAPPER_GMAC_MAC_MODE + (lport * 20);
    field_id = GMAC0_GMACWRAPPER_GMAC_MAC_MODE_SPEED_MODE;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &mode);

    /* 5. -----    cfg gmac SGMII mode   --------*/
    table_id = GMAC0_GMAC_PCS_CONFIG1 + (lport * 20);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &gmac_pcs);

    /* 6. ------- release sup logic reset --------------*/
    field_id = lport + RESET_INT_RELATED_RESET_SUP_GMAC0;
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*7. ----------- release PCS Tx reset -----------*/
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    field_id = GMAC0_GMAC_PCS_SOFT_RST_PCS_TX_SOFT_RST;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*8. ---------- release GMII Tx reset -----------*/
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    field_id = GMAC0_GMAC_PCS_SOFT_RST_GMII_TX_SOFT_RST;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*9. ------------ release PCS Rx reset -----------*/
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    field_id = GMAC0_GMAC_PCS_SOFT_RST_PCS_RX_SOFT_RST;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*10. ------------release GMII Rx reset  -----------*/
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    field_id = GMAC0_GMAC_PCS_SOFT_RST_GMII_RX_SOFT_RST;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

/* Reset sequence depending on <HumberHss configuration guide.doc> Rev1.1*/
static int32
_sys_humber_port_reset_gmac_reset(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 1;
    gmac_pcs_soft_rst_t gmac_pcs_rst;

    /*!!!!!!!!!!!!!!!keep order!!!!!!!!!!!!!!!!!!!!!!*/
    gmac_pcs_rst.gmii_rx_soft_rst = 1;
    gmac_pcs_rst.gmii_tx_soft_rst = 1;
    gmac_pcs_rst.pcs_rx_soft_rst = 1;
    gmac_pcs_rst.pcs_tx_soft_rst = 1;
    /*1. --------- set GMAC logic reset ----------*/
    field_id = lport + RESET_INT_RELATED_RESET_SUP_GMAC0;
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*2. -----reset PCS Rx/Tx, GMII Rx/Tx reset -----*/
    table_id = GMAC0_GMAC_PCS_SOFT_RST + (lport * 20);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &gmac_pcs_rst);

    /*3. --------disable GMAC clock ------------*/
    field_val = 0;
    field_id = lport + MODULE_GATED_CLK_CTL_EN_CLK_SUP_GMAC_WRAPPER0;
    cmd = DRV_IOW(IOC_REG, MODULE_GATED_CLK_CTL, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    field_val = 1;

    /*4. set divider soft reset*/
    table_id = GMAC0_GMAC_CLK_DIVIDER + (lport * 20);
    field_id = GMAC0_GMAC_CLK_DIVIDER_RST_CLK_DIVIDER;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

static int32
_sys_humber_port_release_xgmac_reset(uint8 lchip, uint8 lport)
{
    int32 cmd;
    int32 ret = CTC_E_NONE;
    uint32 field_val;
    uint32 field_id;
    uint32 table_id;
    xgmac0_xgmac_config4_t xgmac_cfg4;
    xgmac0_xgmac_ptp_en_t xgmac_ptp;
    xgmac0_xgmac_soft_rst_t xgmac_soft_rst;

    /*!!!!!!!!!!!!!!!keep order!!!!!!!!!!!!!!!!!!!!!!*/
    xgmac_soft_rst.pcs_tx_soft_rst = 0;
    xgmac_soft_rst.pcs_rx_soft_rst = 1;
    xgmac_soft_rst.serdes_rx0_soft_rst = 1;
    xgmac_soft_rst.serdes_rx1_soft_rst = 1;
    xgmac_soft_rst.serdes_rx2_soft_rst = 1;
    xgmac_soft_rst.serdes_rx3_soft_rst = 1;
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    /*reset sup logic reset*/
    field_id = RESET_INT_RELATED_RESET_SUP_XGMAC0 + (lport / 12);
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    field_val = 1;
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    sal_task_sleep(1);
    /*release sup logic reset*/
    field_id = RESET_INT_RELATED_RESET_SUP_XGMAC0 + (lport / 12);
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    field_val = 0;
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release MDIO soft reset*/
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_SOFT_RST_MDIO_SOFT_RST /*+ ((lport/12) * 123 )*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*init xgmac*/
    sal_memset(&xgmac_cfg4, 0, sizeof(xgmac0_xgmac_config4_t));
    table_id = XGMAC0_XGMAC_CONFIG4 + ((lport / 12) * 36);

    xgmac_cfg4.ignore_remote_fault  = 1;
    xgmac_cfg4.pad_enable           = p_port_master->egs_port_prop[lchip][lport].pading_en;
    xgmac_cfg4.crc_enable           = 1;
    xgmac_cfg4.pause_off_enable     = 1;
    xgmac_cfg4.sig_det_active_value = 1;
    xgmac_cfg4.tx_threshold         = p_port_master->igs_port_prop[lchip][lport].ptp_en ? 0
        : p_port_master->egs_port_prop[lchip][lport].tx_threshold;
    xgmac_cfg4.full_threshold       = 0x13;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_cfg4);

    /*when xg/sg up/down, the xgmac/sgmac should not disable PTP while Phyport do nothing*/
    /*re-configue ptpEn*/
    sal_memset(&xgmac_ptp, 0, sizeof(xgmac0_xgmac_ptp_en_t));
    xgmac_ptp.ptp_en = p_port_master->igs_port_prop[lchip][lport].ptp_en ? 1 : 0;
    table_id = XGMAC0_XGMAC_PTP_EN + ((lport / 12) * 36);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_ptp);

    /*clear drain enable*/
    table_id = XGMAC0_XGMAC_DRAIN_EN + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_DRAIN_EN_XGMAC_DRAIN_EN /*+ ((lport/12) *123)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release PCS Tx soft reset*/
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_SOFT_RST_PCS_TX_SOFT_RST /*+ ((lport/12) *123)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release PCS Rx soft reset*/
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_SOFT_RST_PCS_RX_SOFT_RST /*+ ((lport/12) *123)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release serdes[0:3] soft reset */
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    xgmac_soft_rst.serdes_rx0_soft_rst = 0;
    xgmac_soft_rst.serdes_rx1_soft_rst = 0;
    xgmac_soft_rst.serdes_rx2_soft_rst = 0;
    xgmac_soft_rst.serdes_rx3_soft_rst = 0;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    /*set drain enable*/
    table_id = XGMAC0_XGMAC_DRAIN_EN + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_DRAIN_EN_XGMAC_DRAIN_EN /*+ ((lport/12) *123)*/;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*open Tx enable*/
    table_id = XGMAC0_XGMAC_CONFIG1 + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_CONFIG1_TX_ENABLE /*+ ((lport/12) *123)*/;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*recover flow control configuration*/
    /* RX */
    table_id = XGMAC0_XGMAC_CONFIG1 + (lport / 12) * XGMAC_FLOW_CTL_REG_ID_INTERVAL;
    field_id = XGMAC0_XGMAC_CONFIG1_PAUSE_FRAME_ENABLE;
    field_val = p_port_master->igs_port_prop[lchip][lport].pause_rx_en ? 1 : 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /* TX */
    table_id = XGMAC0_XGMAC_CONFIG5 + (lport / 12) * XGMAC_FLOW_CTL_REG_ID_INTERVAL;
    field_id = XGMAC0_XGMAC_CONFIG5_BUF_STORE_STALL_MASK;
    field_val = p_port_master->egs_port_prop[lchip][lport].pause_tx_en ? 0 : 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /* sup reset will reset mdio status reg */
    if (0 == lport || 12 == lport || 24 == lport)
    {
        p_chip_master->mdio_used[lport / 12] = 0;
    }

    return ret;
}

static int32
_sys_humber_port_reset_xgmac_reset(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;
    xgmac0_xgmac_soft_rst_t xgmac_soft_rst;

    /*!!!!!!!!!!!!!!!keep order!!!!!!!!!!!!!!!!!!!!!!*/

    /*clear Tx enable*/
    table_id = XGMAC0_XGMAC_CONFIG1 + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_CONFIG1_TX_ENABLE /* + ((lport/12) *123)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*reset PCS Tx,Rx soft reset*/
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    xgmac_soft_rst.pcs_rx_soft_rst = 1;
    xgmac_soft_rst.pcs_tx_soft_rst = 1;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    /*reset serdes[0:3] soft reset*/
    table_id = XGMAC0_XGMAC_SOFT_RST + ((lport / 12) * 36);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    xgmac_soft_rst.serdes_rx0_soft_rst = 1;
    xgmac_soft_rst.serdes_rx1_soft_rst = 1;
    xgmac_soft_rst.serdes_rx2_soft_rst = 1;
    xgmac_soft_rst.serdes_rx3_soft_rst = 1;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &xgmac_soft_rst);

    /*clear drain enable*/
    table_id = XGMAC0_XGMAC_DRAIN_EN + ((lport / 12) * 36);
    field_id = XGMAC0_XGMAC_DRAIN_EN_XGMAC_DRAIN_EN /*+ ((lport/12) *123)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

static int32
_sys_humber_port_release_sgmac_reset(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val;
    sgmac0_sgmac_config4_t sgmac_cfg4;
    sgmac0_sgmac_ptp_en_t sgmac_ptp;
    sgmac0_sgmac_soft_rst_t sgmac_soft_rst;

    sgmac_soft_rst.pcs_tx_soft_rst = 0;
    sgmac_soft_rst.pcs_rx_soft_rst = 1;
    sgmac_soft_rst.serdes_rx0_soft_rst = 1;
    sgmac_soft_rst.serdes_rx1_soft_rst = 1;
    sgmac_soft_rst.serdes_rx2_soft_rst = 1;
    sgmac_soft_rst.serdes_rx3_soft_rst = 1;
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    /*reset sup logic reset*/
    field_id = RESET_INT_RELATED_RESET_SUP_SG_MAC0 + (lport - 48);
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    field_val = 1;
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    sal_task_sleep(1);

    /*release sup logic reset*/
    field_id = RESET_INT_RELATED_RESET_SUP_SG_MAC0 + (lport - 48);
    cmd = DRV_IOW(IOC_REG, RESET_INT_RELATED, field_id);
    field_val = 0;
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*init sgmac*/
    sal_memset(&sgmac_cfg4, 0, sizeof(sgmac0_sgmac_config4_t));
    table_id = SGMAC0_SGMAC_CONFIG4 + ((lport - 48) * 42);

    sgmac_cfg4.ignore_remote_fault  = 1;
    sgmac_cfg4.pad_enable           = p_port_master->egs_port_prop[lchip][lport].pading_en;
    sgmac_cfg4.crc_enable           = 1;
    sgmac_cfg4.pause_off_enable     = 1;
    sgmac_cfg4.sig_det_active_value = 1;
    sgmac_cfg4.e2e_crc_bit_swizzle  = 1;
    sgmac_cfg4.e2e_msg_error_en     = 1;
    sgmac_cfg4.tx_threshold         = p_port_master->igs_port_prop[lchip][lport].ptp_en ? 0
        : p_port_master->egs_port_prop[lchip][lport].tx_threshold;
    sgmac_cfg4.full_threshold       = 0x13;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_cfg4);

    /*when xg/sg up/down, the xgmac/sgmac should not disable PTP while Phyport do nothing*/
    /*re-configue ptpEn*/
    sal_memset(&sgmac_ptp, 0, sizeof(sgmac0_sgmac_ptp_en_t));
    sgmac_ptp.ptp_en = p_port_master->igs_port_prop[lchip][lport].ptp_en ? 1 : 0;
    table_id = SGMAC0_SGMAC_PTP_EN + ((lport - 48) * 42);
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_ptp);

    /*clear drain enable*/
    table_id = SGMAC0_SGMAC_DRAIN_EN + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_DRAIN_EN_SGMAC_DRAIN_EN /*+ ((lport - 48) *147)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release PCS Tx soft reset*/
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_SOFT_RST_PCS_TX_SOFT_RST /*+ ((lport - 48) *147)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release PCS Rx soft reset*/
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_SOFT_RST_PCS_RX_SOFT_RST /*+ ((lport - 48) *147)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*release serdes[0:3] soft reset */
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    sgmac_soft_rst.serdes_rx0_soft_rst = 0;
    sgmac_soft_rst.serdes_rx1_soft_rst = 0;
    sgmac_soft_rst.serdes_rx2_soft_rst = 0;
    sgmac_soft_rst.serdes_rx3_soft_rst = 0;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    /*set drain enable*/
    table_id = SGMAC0_SGMAC_DRAIN_EN + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_DRAIN_EN_SGMAC_DRAIN_EN /*+ ((lport - 48) *147)*/;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*open Tx enable*/
    table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_CONFIG1_TX_ENABLE /*+ ((lport - 48)*147)*/;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*recover flow control configuration*/
    /* RX */
    table_id = SGMAC0_SGMAC_CONFIG1 + (lport - 48) * SGMAC_FLOW_CTL_REG_ID_INTERVAL;
    field_id = SGMAC0_SGMAC_CONFIG1_PAUSE_FRAME_ENABLE;
    field_val = p_port_master->igs_port_prop[lchip][lport].pause_rx_en ? 1 : 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /* TX */
    table_id = SGMAC0_SGMAC_CONFIG5 + (lport - 48) * SGMAC_FLOW_CTL_REG_ID_INTERVAL;
    field_id = SGMAC0_SGMAC_CONFIG5_BUF_STORE_STALL_MASK;
    field_val = p_port_master->egs_port_prop[lchip][lport].pause_tx_en ? 0 : 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

static int32
_sys_humber_port_reset_sgmac_reset(uint8 lchip, uint8 lport)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;
    sgmac0_sgmac_soft_rst_t sgmac_soft_rst;

    /*!!!!!!!!!!!!!!!keep order!!!!!!!!!!!!!!!!!!!!!!*/

    /*clear Tx enable*/
    table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_CONFIG1_TX_ENABLE /*+ ((lport - 48)*147)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*reset PCS Tx,Rx soft reset*/
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    sgmac_soft_rst.pcs_rx_soft_rst = 1;
    sgmac_soft_rst.pcs_tx_soft_rst = 1;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    /*reset serdes[0:3] soft reset*/
    table_id = SGMAC0_SGMAC_SOFT_RST + ((lport - 48) * 42);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    sgmac_soft_rst.serdes_rx0_soft_rst = 1;
    sgmac_soft_rst.serdes_rx1_soft_rst = 1;
    sgmac_soft_rst.serdes_rx2_soft_rst = 1;
    sgmac_soft_rst.serdes_rx3_soft_rst = 1;

    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &sgmac_soft_rst);

    /*clear drain enable*/
    table_id = SGMAC0_SGMAC_DRAIN_EN + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_DRAIN_EN_SGMAC_DRAIN_EN /*+ ((lport - 48) *147)*/;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    return ret;
}

int32
sys_humber_port_set_gmac_en(uint8 lchip, uint8 lport, bool enable)
{
    int32 ret = CTC_E_NONE;

    if (TRUE == enable)
    {
        ret = _sys_humber_port_hss4g_link_power_up(lchip, lport);
        ret = ret ? ret : _sys_humber_port_release_gmac_reset(lchip, lport, p_port_master->igs_port_prop[lchip][lport].speed_mode);
    }
    else
    {
        ret = _sys_humber_port_reset_gmac_reset(lchip, lport);
        ret = ret ? ret : _sys_humber_port_hss4g_link_power_down(lchip, lport);
    }

    return ret;
}

static int32
_sys_humber_port_set_xgmac_en(uint8 lchip, uint8 lport, bool enable)
{
    int32 ret = CTC_E_NONE;

    if (enable)
    {
        ret = _sys_humber_port_hss4g_xg_link_power_up(lchip, lport);
        ret = ret ? ret : _sys_humber_port_release_xgmac_reset(lchip, lport);
    }
    else
    {
        ret = _sys_humber_port_hss4g_xg_link_power_down(lchip, lport);
        ret = ret ? ret : _sys_humber_port_reset_xgmac_reset(lchip, lport);
    }

    return ret;
}

static int32
_sys_humber_port_set_sgmac_en(uint8 lchip, uint8 lport, bool enable)
{
    int32 ret;

    if (enable)
    {
        ret = _sys_humber_port_hss4g_sg_link_power_up(lchip, lport);
        ret = ret ? ret : _sys_humber_port_release_sgmac_reset(lchip, lport);
    }
    else
    {
        ret = _sys_humber_port_hss4g_sg_link_power_down(lchip, lport);
        ret = ret ? ret : _sys_humber_port_reset_sgmac_reset(lchip, lport);
    }

    return ret;
}

int32
sys_humber_port_set_mac_en(uint16 gport, bool enable)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        ret = sys_humber_port_set_gmac_en(lchip, lport, enable);
        break;

    case CTC_PORT_MAC_XGMAC:
        ret = _sys_humber_port_set_xgmac_en(lchip, lport, enable);
        break;

    case CTC_PORT_MAC_SGMAC:
        ret = _sys_humber_port_set_sgmac_en(lchip, lport, enable);
        break;

    case CTC_PORT_MAC_CPUMAC:
        ret = sys_humber_set_cpu_mac_en(enable);
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    if (CTC_E_NONE == ret)
    {
        p_port_master->igs_port_prop[lchip][lport].port_mac_en  = enable;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_mac_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    *enable = p_port_master->igs_port_prop[lchip][lport].port_mac_en;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_speed(uint16 gport, ctc_port_speed_t speed_mode)
{
    uint8 lchip;
    uint8 lport;
    int32 ret;
    ctc_port_mac_type_t mac_type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    mac_type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (mac_type)
    {
    case CTC_PORT_MAC_GMAC:
        /*Only when port enable, cfg real speed; else just store speed mode, and will cfg when enable*/
        if (p_port_master->igs_port_prop[lchip][lport].port_mac_en)
        {
            ret = _sys_humber_port_reset_gmac_reset(lchip, lport);
            ret = ret ? ret : _sys_humber_port_release_gmac_reset(lchip, lport, speed_mode);
        }
        else
        {
            ret = CTC_E_NONE;
        }

        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    if (CTC_E_NONE == ret)
    {
        p_port_master->igs_port_prop[lchip][lport].speed_mode = speed_mode;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_speed(uint16 gport, ctc_port_speed_t* speed_mode)
{
    uint8 lchip;
    uint8 lport;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(speed_mode);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    *speed_mode = p_port_master->igs_port_prop[lchip][lport].speed_mode;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_set_max_frame_size(ctc_frame_size_t index, uint16 value)
{
    uint8 chip_id;
    uint8 lchip_num;
    uint32 cmd;
    uint32 field_val;

    if (value >= SYS_MAX_FRAME_VALUE)
    {
        return CTC_E_INVALID_PARAM;
    }

    switch (index)
    {
    case CTC_FRAME_SIZE_0:
        cmd = DRV_IOW(IOC_REG, NET_RX_MAX_PKT_SIZE, NET_RX_MAX_PKT_SIZE_MAX_PKT_SIZE0);
        break;

    case CTC_FRAME_SIZE_1:
        cmd = DRV_IOW(IOC_REG, NET_RX_MAX_PKT_SIZE, NET_RX_MAX_PKT_SIZE_MAX_PKT_SIZE1);
        break;

    default:
        return CTC_E_UNEXPECT;
    }

    lchip_num = sys_humber_get_local_chip_num();
    field_val = value;

    for (chip_id = 0; chip_id < lchip_num; chip_id++)
    {
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd, &field_val));
    }

    return CTC_E_NONE;
}

int32
sys_humber_get_max_frame_size(ctc_frame_size_t index, uint16* max_size)
{
    uint32 cmd;
    uint32 field_val;

    switch (index)
    {
    case CTC_FRAME_SIZE_0:
        cmd = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE, NET_RX_MAX_PKT_SIZE_MAX_PKT_SIZE0);
        break;

    case CTC_FRAME_SIZE_1:
        cmd = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE, NET_RX_MAX_PKT_SIZE_MAX_PKT_SIZE1);
        break;

    default:
        return CTC_E_UNEXPECT;
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &field_val));

    *max_size = field_val & 0x3FFF;

    return CTC_E_NONE;
}

int32
sys_humber_set_ipg_size(ctc_ipg_size_t index, uint8 size)
{
    uint8 chip_id;
    uint8 lchip_num;
    uint32 cmd_i;
    uint32 cmd_e;
    uint32 field_val;

    lchip_num = sys_humber_get_local_chip_num();
    field_val = size;

    switch (index)
    {
    case CTC_IPG_SIZE_0:
        cmd_i = DRV_IOW(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG0);
        cmd_e = DRV_IOW(IOC_REG, EPE_IPG_CTL, EPE_IPG_CTL_IPG0);
        break;

    case CTC_IPG_SIZE_1:
        cmd_i = DRV_IOW(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG1);
        cmd_e = DRV_IOW(IOC_REG, EPE_IPG_CTL, EPE_IPG_CTL_IPG1);
        break;

    case CTC_IPG_SIZE_2:
        cmd_i = DRV_IOW(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG2);
        cmd_e = DRV_IOW(IOC_REG, EPE_IPG_CTL, EPE_IPG_CTL_IPG2);
        break;

    case CTC_IPG_SIZE_3:
        cmd_i = DRV_IOW(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG3);
        cmd_e = DRV_IOW(IOC_REG, EPE_IPG_CTL, EPE_IPG_CTL_IPG3);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    for (chip_id = 0; chip_id < lchip_num; chip_id++)
    {
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd_i, &field_val));
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd_e, &field_val));
    }

    return CTC_E_NONE;
}

int32
sys_humber_get_ipg_size(ctc_ipg_size_t index, uint8* size)
{
    uint32 cmd;
    uint32 field_val;

    switch (index)
    {
    case CTC_IPG_SIZE_0:
        cmd = DRV_IOR(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG0);
        break;

    case CTC_IPG_SIZE_1:
        cmd = DRV_IOR(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG1);
        break;

    case CTC_IPG_SIZE_2:
        cmd = DRV_IOR(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG2);
        break;

    case CTC_IPG_SIZE_3:
        cmd = DRV_IOR(IOC_REG, IPE_IPG_CTL, IPE_IPG_CTL_IPG3);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &field_val));
    *size = field_val;

    return CTC_E_NONE;
}

int32
sys_humber_set_cpu_mac_en(bool enable)
{
    uint8 chip_id;
    uint8 lchip_num;
    uint32 cmd, cmd2;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    cmd = DRV_IOW(IOC_REG, CPUMAC_GMAC_TX_CTRL, CPUMAC_GMAC_TX_CTRL_TX_ENABLE);
    cmd2 = DRV_IOW(IOC_REG, CPUMAC_GMAC_RX_CTRL, CPUMAC_GMAC_RX_CTRL_RX_ENABLE);

    lchip_num = sys_humber_get_local_chip_num();

    for (chip_id = 0; chip_id < lchip_num; chip_id++)
    {
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd, &field_val));
        CTC_ERROR_RETURN(drv_reg_ioctl(chip_id, 0, cmd2, &field_val));
    }

    return CTC_E_NONE;
}

int32
sys_humber_get_cpu_mac_en(bool* enable)
{
    uint32 cmd;
    uint32 field_val;

    cmd = DRV_IOR(IOC_REG, CPUMAC_GMAC_TX_CTRL, CPUMAC_GMAC_TX_CTRL_TX_ENABLE);

    CTC_ERROR_RETURN(drv_reg_ioctl(0, 0, cmd, &field_val));

    *enable = (1 == field_val) ? TRUE : FALSE;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_max_frame(uint16 gport, ctc_frame_size_t index)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd_r;
    uint32 cmd_w;
    uint32 field_value;

    if (index >= CTC_FRAME_SIZE_MAX)
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    if (lport < BITS_NUM_OF_WORD)
    {
        cmd_r = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_LO);
        cmd_w = DRV_IOW(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_LO);
    }
    else
    {
        cmd_r = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_HI);
        cmd_w = DRV_IOW(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_HI);
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd_r, &field_value));

    if (CTC_FRAME_SIZE_1 == index)
    {
        CTC_SET_FLAG(field_value, 1 << (lport % BITS_NUM_OF_WORD));
    }
    else
    {
        CTC_UNSET_FLAG(field_value, 1 << (lport % BITS_NUM_OF_WORD));
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd_w, &field_value));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_max_frame(uint16 gport, ctc_frame_size_t* index)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_val;

    CTC_PTR_VALID_CHECK(index);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    if (lport < BITS_NUM_OF_WORD)
    {
        cmd = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_LO);
    }
    else
    {
        cmd = DRV_IOR(IOC_REG, NET_RX_MAX_PKT_SIZE_SELECT, NET_RX_MAX_PKT_SIZE_SELECT_MAX_PKT_SIZE_SELECT_HI);
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_val));

    if (CTC_FLAG_ISSET(field_val, 1 << (lport % BITS_NUM_OF_WORD)))
    {
        *index = CTC_FRAME_SIZE_1;
    }
    else
    {
        *index = CTC_FRAME_SIZE_0;
    }

    return CTC_E_NONE;
}

int32
sys_humber_port_set_ipg(uint16 gport, ctc_ipg_size_t index)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_value;

    if (index >= CTC_IPG_SIZE_MAX)
    {
        return CTC_E_INVALID_PARAM;
    }

    field_value = index;
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_IPG_INDEX);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_value));

    cmd = DRV_IOW(IOC_TABLE, DS_DEST_PORT, DS_DEST_PORT_IPG_INDEX);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_value));

    return CTC_E_NONE;
}

int32
sys_humber_port_get_ipg(uint16 gport, ctc_ipg_size_t* index)
{
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 field_value;

    CTC_PTR_VALID_CHECK(index);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_IPG_INDEX);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_value));

    *index = field_value;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_flow_ctl_en(uint16 gport, ctc_direction_t dir, uint32 enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 reg_id = 0;
    uint32 field_id = 0;
    ctc_port_mac_type_t type;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:     /* GMAC */
        if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            /*rx pause frame*/
            reg_id = GMAC0_GMACWRAPPER_GMAC_RX_CTRL + (lport * GMAC_FLOW_CTL_REG_ID_INTERVAL);
            field_id = GMAC0_GMACWRAPPER_GMAC_RX_CTRL_RX_FLOW_CTRL_ENABLE;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            /*tx pause frame*/
            reg_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + (lport * GMAC_FLOW_CTL_REG_ID_INTERVAL);
            field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_FLOW_CTRL_ENABLE;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        break;

    case CTC_PORT_MAC_XGMAC:        /* XGMAC */
        if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            reg_id = XGMAC0_XGMAC_CONFIG1 + (lport / 12) * XGMAC_FLOW_CTL_REG_ID_INTERVAL;
            field_id = XGMAC0_XGMAC_CONFIG1_PAUSE_FRAME_ENABLE;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        field_val = (TRUE == enable) ? 0 : 1;
        if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            /*tx pause frame*/
            reg_id = XGMAC0_XGMAC_CONFIG5 + (lport / 12) * XGMAC_FLOW_CTL_REG_ID_INTERVAL;
            field_id = XGMAC0_XGMAC_CONFIG5_BUF_STORE_STALL_MASK;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        break;

    case CTC_PORT_MAC_SGMAC:        /* SGMAC */
        if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            reg_id = SGMAC0_SGMAC_CONFIG1 + (lport - 48) * SGMAC_FLOW_CTL_REG_ID_INTERVAL;
            field_id = SGMAC0_SGMAC_CONFIG1_PAUSE_FRAME_ENABLE;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        field_val = (TRUE == enable) ? 0 : 1;
        if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            reg_id = SGMAC0_SGMAC_CONFIG5 + (lport - 48) * SGMAC_FLOW_CTL_REG_ID_INTERVAL;
            field_id = SGMAC0_SGMAC_CONFIG5_BUF_STORE_STALL_MASK;
            cmd = DRV_IOW(IOC_REG, reg_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        break;

    case CTC_PORT_MAC_CPUMAC:        /* CPUMAC */
        if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            /*rx pause frame*/
            cmd = DRV_IOW(IOC_REG, CPUMAC_GMAC_RX_CTRL, CPUMAC_GMAC_RX_CTRL_RX_FLOW_CTRL_ENABLE);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
        {
            /*tx pause frame*/
            cmd = DRV_IOW(IOC_REG, CPUMAC_GMAC_TX_CTRL, CPUMAC_GMAC_TX_CTRL_TX_FLOW_CTRL_ENABLE);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        }

        break;

    default:
        PORT_UNLOCK;
        return CTC_E_INVALID_PORT_MAC_TYPE;
    }

    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        p_port_master->igs_port_prop[lchip][lport].pause_rx_en = enable ? 1 : 0;
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        p_port_master->egs_port_prop[lchip][lport].pause_tx_en = enable ? 1 : 0;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_flow_ctl_en(uint16 gport, ctc_direction_t dir, uint32* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;

    CTC_PTR_VALID_CHECK(enable);
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport > 53)
    {
        return CTC_E_INVALID_PARAM;
    }

    PORT_LOCK;
    if ((CTC_INGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        *enable = p_port_master->igs_port_prop[lchip][lport].pause_rx_en ? TRUE : FALSE;
    }

    if ((CTC_EGRESS == dir) || (CTC_BOTH_DIRECTION == dir))
    {
        *enable = p_port_master->egs_port_prop[lchip][lport].pause_tx_en ? TRUE : FALSE;
    }

    PORT_UNLOCK;

    return ret;
}

static int32
_sys_humber_port_set_gmac_preamble(uint8 lchip, uint8 lport, uint8 pre_bytes)
{
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val = pre_bytes;

    CTC_VALUE_RANGE_CHECK(pre_bytes, SYS_MIN_PREAMBLE_FOR_GMAC, SYS_MAX_PREAMBLE_FOR_GMAC);

    table_id = GMAC0_GMACWRAPPER_GMAC_PRE_LENGTH + (lport * 20);
    field_id = GMAC0_GMACWRAPPER_GMAC_PRE_LENGTH_PRE_LENGTH /*+ (lport * 55)*/;

    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_val));

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_xgmac_preamble(uint8 lchip, uint8 lport, uint8 pre_bytes)
{
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;

    /*only 4Bytes and 8Bytes can be configed to xgmac*/
    if (SYS_MIN_PREAMBLE_FOR_SGMAC_XGMAC == pre_bytes)
    {
        field_val = 1;
    }
    else if (SYS_MAX_PREAMBLE_FOR_SGMAC_XGMAC == pre_bytes)
    {
        field_val = 0;
    }
    else
    {
        return CTC_E_INVALID_PREAMBLE;
    }

    table_id = XGMAC0_XGMAC_CONFIG1 + (lport / 16);
    field_id = XGMAC0_XGMAC_CONFIG1_PREAMBLE4_BYTES /*+ ((lport /16) *123)*/;

    cmd = DRV_IOW(IOC_REG, table_id, field_id);

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_val));

    return CTC_E_NONE;
}

static int32
_sys_humber_port_set_sgmac_preamble(uint8 lchip, uint8 lport, uint8 pre_bytes)
{
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;

    /*only 4Bytes and 8Bytes can be configed to sgmac*/
    if (SYS_MIN_PREAMBLE_FOR_SGMAC_XGMAC == pre_bytes)
    {
        field_val = 1;
    }
    else if (SYS_MAX_PREAMBLE_FOR_SGMAC_XGMAC == pre_bytes)
    {
        field_val = 0;
    }
    else
    {
        return CTC_E_INVALID_PREAMBLE;
    }

    table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
    field_id = SGMAC0_SGMAC_CONFIG1_PREAMBLE4_BYTES /*+ ((lport - 48) *147)*/;

    cmd = DRV_IOW(IOC_REG, table_id, field_id);

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_set_preamble(uint16 gport, uint8 pre_bytes)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        ret = _sys_humber_port_set_gmac_preamble(lchip, lport, pre_bytes);
        break;

    case CTC_PORT_MAC_XGMAC:
        ret = _sys_humber_port_set_xgmac_preamble(lchip, lport, pre_bytes);
        break;

    case CTC_PORT_MAC_SGMAC:
        ret = _sys_humber_port_set_sgmac_preamble(lchip, lport, pre_bytes);
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_preamble(uint16 gport, uint8* pre_bytes)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;

    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        table_id = GMAC0_GMACWRAPPER_GMAC_PRE_LENGTH + (lport * 20);
        field_id = GMAC0_GMACWRAPPER_GMAC_PRE_LENGTH_PRE_LENGTH /*+ (lport * 55)*/;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        *pre_bytes = field_val;
        break;

    case CTC_PORT_MAC_XGMAC:
        table_id = XGMAC0_XGMAC_CONFIG1 + ((lport / 12) * 36);
        field_id = XGMAC0_XGMAC_CONFIG1_PREAMBLE4_BYTES /*+ ((lport /12) *123)*/;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        *pre_bytes = (1 == field_val) ? 4 : 8;
        break;

    case CTC_PORT_MAC_SGMAC:
        table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
        field_id = SGMAC0_SGMAC_CONFIG1_PREAMBLE4_BYTES /* + ((lport - 48) *147)*/;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        *pre_bytes = (1 == field_val) ? 4 : 8;
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

static int32
_sys_humber_port_set_gmac_min_frame_size(uint8 lchip, uint8 lport, uint8 size)
{
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val = size;

    CTC_VALUE_RANGE_CHECK(size, SYS_MIN_LENGTH_FOR_GMAC, SYS_MAX_LENGTH_FOR_GMAC);

    table_id = GMAC0_GMACWRAPPER_GMAC_PKT_LENGTH + (lport * 20);
    field_id = GMAC0_GMACWRAPPER_GMAC_PKT_LENGTH_MIN_PKT_LEN;

    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &field_val));

    return CTC_E_NONE;
}

int32
sys_humber_port_set_min_frame_size(uint16 gport, uint8 size)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        ret = _sys_humber_port_set_gmac_min_frame_size(lchip, lport, size);
        break;

    /*not support config sgmac and xgmac min pktlen, they are fixed*/
    case CTC_PORT_MAC_XGMAC:
    case CTC_PORT_MAC_SGMAC:
        ret = CTC_E_INVALID_GLOBAL_PORT;
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_min_frame_size(uint16 gport, uint8* size)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    uint32 cmd;
    uint32 table_id;
    uint32 field_id;
    uint32 field_val;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;

    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        table_id = GMAC0_GMACWRAPPER_GMAC_PKT_LENGTH + (lport * 20);
        field_id = GMAC0_GMACWRAPPER_GMAC_PKT_LENGTH_MIN_PKT_LEN;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
        *size = field_val;
        break;

    case CTC_PORT_MAC_XGMAC:
    case CTC_PORT_MAC_SGMAC:
        ret = CTC_E_INVALID_GLOBAL_PORT;
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_set_stretch_mode_en(uint16 gport, bool enable)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    uint32 table_id;
    uint32 field_id;
    uint32 cmd;
    uint32 field_val;
    sgmac0_sgmac_stretch_mode_t mode;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (TRUE == enable)
    {
        field_val = 0;
        mode.ifs_stretch_count_init = 0;
        mode.ifs_stretch_size_init  = 14;
        mode.ifs_stretch_ratio      = 13;
        mode.ifs_stretch_mode       = 1;
    }
    else
    {
        field_val = 1;
        sal_memset(&mode, 0, sizeof(sgmac0_sgmac_stretch_mode_t));
    }

    PORT_LOCK;

    switch (p_port_master->igs_port_prop[lchip][lport].port_mac_type)
    {
    case CTC_PORT_MAC_XGMAC:
        table_id = XGMAC0_XGMAC_CONFIG1 + (lport / 12) * 36;
        field_id = XGMAC0_XGMAC_CONFIG1_DIC_CNT_ENABLE /*+ (lport /12)*123*/;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = XGMAC0_XGMAC_STRETCH_MODE + (lport / 12) * 36;
        cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &mode);
        break;

    case CTC_PORT_MAC_SGMAC:
        table_id = SGMAC0_SGMAC_CONFIG1 + (lport - 48) * 42;
        field_id = SGMAC0_SGMAC_CONFIG1_DIC_CNT_ENABLE /* + (lport - 48)*147*/;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = SGMAC0_SGMAC_STRETCH_MODE + (lport - 48) * 42;
        cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &mode);
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    if (CTC_E_NONE == ret)
    {
        p_port_master->igs_port_prop[lchip][lport].stretch_en = enable ? 1 : 0;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_stretch_mode_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    *enable = p_port_master->igs_port_prop[lchip][lport].stretch_en ? TRUE : FALSE;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_pading_en(uint16 gport, bool enable)
{
    uint8 lchip;
    uint8 lport;
    uint8 reg_step;
    uint8 field_step;
    uint16 reg_id;
    uint16 field_id;
    uint32 cmd;
    uint32 field_value;
    int32 ret;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    if (lport < SYS_MAX_GMAC_NUM)
    {
        reg_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL - GMAC0_GMACWRAPPER_GMAC_TX_CTRL;
        reg_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + lport * reg_step;
        field_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL_PAD_ENABLE - GMAC0_GMACWRAPPER_GMAC_TX_CTRL_PAD_ENABLE;
        field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_PAD_ENABLE /* + lport*field_step*/;
    }
    else
    {
        reg_step = SGMAC1_SGMAC_CONFIG4 - SGMAC0_SGMAC_CONFIG4;
        reg_id = SGMAC0_SGMAC_CONFIG4 + (lport - SYS_MAX_GMAC_NUM) * reg_step;
        field_step = SGMAC1_SGMAC_CONFIG4_PAD_ENABLE - SGMAC0_SGMAC_CONFIG4_PAD_ENABLE;
        field_id = SGMAC0_SGMAC_CONFIG4_PAD_ENABLE /*+ (lport-SYS_MAX_GMAC_NUM)*field_step*/;
    }

    PORT_LOCK;
    field_value = enable ? 1 : 0;
    cmd = DRV_IOW(IOC_REG, reg_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_value);

    if (CTC_E_NONE == ret)
    {
        p_port_master->egs_port_prop[lchip][lport].pading_en = enable ? 1 : 0;
    }

    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_get_pading_en(uint16 gport, bool* enable)
{
    uint8 lchip;
    uint8 lport;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    PORT_LOCK;
    *enable = p_port_master->egs_port_prop[lchip][lport].pading_en ? TRUE : FALSE;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

int32
sys_humber_port_set_tx_threshold(uint16 gport, uint8 tx_threshold)
{
    uint8 lchip;
    uint8 lport;
    uint8 reg_step;
    uint8 field_step;
    uint16 reg_id;
    uint16 field_id;
    uint32 cmd;
    uint8 reg_value;
    int32 ret = CTC_E_NONE;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);
    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    if (CTC_PORT_MAC_GMAC == p_port_master->igs_port_prop[lchip][lport].port_mac_type)
    {
        /*tx_threshold of gmac has 7 bits*/
        if (tx_threshold > 0x7f)
        {
            return CTC_E_INVALID_TX_THRESHOLD;
        }
    }
    else
    {
        /*tx_threshold of xgmac/sgmac has 6 bits*/
        if (tx_threshold > 0x3f)
        {
            return CTC_E_INVALID_TX_THRESHOLD;
        }
    }

    PORT_LOCK;

    switch (p_port_master->igs_port_prop[lchip][lport].port_mac_type)
    {
    case CTC_PORT_MAC_GMAC:
        reg_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL - GMAC0_GMACWRAPPER_GMAC_TX_CTRL;
        reg_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + lport * reg_step;
        field_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD - GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD;
        field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_THRESHOLD /*+ lport*field_step*/;
        break;

    case CTC_PORT_MAC_XGMAC:
        reg_step = XGMAC1_XGMAC_CONFIG4 - XGMAC0_XGMAC_CONFIG4;
        reg_id = XGMAC0_XGMAC_CONFIG4 + (lport / 12) * reg_step;
        field_step = XGMAC1_XGMAC_CONFIG4_TX_THRESHOLD - XGMAC0_XGMAC_CONFIG4_TX_THRESHOLD;
        field_id = XGMAC0_XGMAC_CONFIG4_TX_THRESHOLD /*+ (lport/12)*field_step*/;
        break;

    case CTC_PORT_MAC_SGMAC:
        reg_step = SGMAC1_SGMAC_CONFIG4 - SGMAC0_SGMAC_CONFIG4;
        reg_id = SGMAC0_SGMAC_CONFIG4 + (lport - SYS_MAX_GMAC_NUM) * reg_step;
        field_step = SGMAC1_SGMAC_CONFIG4_TX_THRESHOLD - SGMAC0_SGMAC_CONFIG4_TX_THRESHOLD;
        field_id = SGMAC0_SGMAC_CONFIG4_TX_THRESHOLD /*+ (lport-SYS_MAX_GMAC_NUM)*field_step*/;
        break;

    default:
        PORT_UNLOCK;
        return CTC_E_INVALID_PORT_MAC_TYPE;
    }

    reg_value = p_port_master->igs_port_prop[lchip][lport].ptp_en ? 0 : tx_threshold;
    cmd = DRV_IOW(IOC_REG, reg_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &reg_value);
    if (CTC_E_NONE == ret)
    {
        p_port_master->egs_port_prop[lchip][lport].tx_threshold = tx_threshold;
    }

    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_tx_threshold(uint16 gport, uint8* tx_threshold)
{
    uint8 lchip;
    uint8 lport;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(tx_threshold);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    PORT_LOCK;
    *tx_threshold = p_port_master->egs_port_prop[lchip][lport].tx_threshold;
    PORT_UNLOCK;

    return CTC_E_NONE;
}

/**
@brief set port whether the src_discard is enable
*/
int32
sys_humber_port_set_srcdiscard_en(uint16 gport, bool enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = (TRUE == enable) ? 1 : 0;

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d src_discard enable:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_SRC_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    return ret;
}

/**
 @brief get port whether the srcdiscard is enable
*/
int32
sys_humber_port_get_srcdiscard_en(uint16 gport, bool* enable)
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 field_value = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d srcdiscard enable!\n", gport);

    /*do read*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT, DS_PHY_PORT_SRC_DISCARD);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);

    *enable = field_value ? TRUE : FALSE;

    return ret;
}

int32
_sys_humber_port_maping_to_local_phy_port(uint8 lchip_id, uint8 lport, uint8 local_phy_port)
{
    uint32 cmd = 0;
    uint32 field_value = local_phy_port;

    cmd = DRV_IOW(IOC_TABLE, PHY_PORT_MAP_TABLE, PHY_PORT_MAP_TABLE_LOCAL_PHY_PORT);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip_id, lport, cmd, &field_value));

    return CTC_E_NONE;
}

int32
sys_humber_port_set_lbk_port_property(ctc_port_lbk_param_t* p_port_lbk, uint8 inter_lport)
{
    uint8 lchip, gchip;
    uint16 src_gport   = 0, inter_gport = 0;
    uint8  src_lport   = 0;
    uint32 cmd         = 0;
    ds_phy_port_ext_t inter_phy_port_ext;
    uint8 enable = p_port_lbk->lbk_enable ? 1 : 0;

    src_gport = p_port_lbk->src_gport;
    SYS_MAP_GPORT_TO_LPORT(src_gport, lchip, src_lport);
    gchip = CTC_MAP_GPORT_TO_GCHIP(src_gport);
    inter_gport = CTC_MAP_LPORT_TO_GPORT(gchip, inter_lport);

    CTC_ERROR_RETURN(sys_humber_port_set_cross_connect(inter_gport, enable));
    CTC_ERROR_RETURN(sys_humber_port_set_receive_en(inter_gport, enable));
    CTC_ERROR_RETURN(sys_humber_port_set_bridge_en(inter_gport, enable));
    CTC_ERROR_RETURN(sys_humber_port_set_replace_tag_en(inter_gport, enable));

    /*l2pdu same to src port*/
    cmd = DRV_IOR(IOC_TABLE, DS_PHY_PORT_EXT, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, inter_lport, cmd, &inter_phy_port_ext));
    if (enable)
    {
        if (p_port_lbk->efm_to_cpu_en)
        {
            if (p_port_lbk->efm_to_cpu_index >= 16)
            {
                return CTC_E_PDU_INVALID_INDEX;
            }

            inter_phy_port_ext.exception2_en = 1 << p_port_lbk->efm_to_cpu_index;
            inter_phy_port_ext.exception2_discard = 1 << p_port_lbk->efm_to_cpu_index;
        }
        else
        {
            inter_phy_port_ext.exception2_en      = 0;
            inter_phy_port_ext.exception2_discard = 0;
        }

        inter_phy_port_ext.default_vlan_id = 0;
    }
    else
    {
        inter_phy_port_ext.exception2_en      = 0;
        inter_phy_port_ext.exception2_discard = 0;
        inter_phy_port_ext.default_vlan_id    = 1;
    }

    cmd = DRV_IOW(IOC_TABLE, DS_PHY_PORT_EXT, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, inter_lport, cmd, &inter_phy_port_ext));

    return CTC_E_NONE;

}

int32
sys_humber_port_set_loopback(ctc_port_lbk_param_t* p_port_lbk)
{
    uint16 inter_gport = 0;
    uint8  inter_lport = 0;
    uint16 src_gport   = 0;
    uint8  src_lport   = 0;
    uint16 dst_gport   = 0;
    uint8  gchip       = 0;
    uint8  lchip       = 0;
    int32  ret         = CTC_E_NONE;
    uint8  channel     = 0;
    sys_nh_param_crscnt_t crscnt_param;

#define RET_PROCESS_WITH_ERROR(func) ret = ret ? ret : (func)

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(p_port_lbk);
    SYS_PORT_DEBUG_FUNC();
    src_gport = p_port_lbk->src_gport;
    dst_gport = p_port_lbk->dst_gport;
    /*not support linkagg*/
    if (CTC_IS_LINKAGG_PORT(src_gport))
    {
        return CTC_E_INVALID_PARAM;
    }

    SYS_MAP_GPORT_TO_LPORT(src_gport, lchip, src_lport);
    gchip = CTC_MAP_GPORT_TO_GCHIP(src_gport);
    CTC_GLOBAL_CHIPID_CHECK(gchip);
    sal_memset(&crscnt_param, 0, sizeof(sys_nh_param_crscnt_t));
    if (p_port_lbk->lbk_enable)
    {
        if (p_port_master->igs_port_prop[lchip][src_lport].lbk_en)
        {
            return CTC_E_ENTRY_EXIST;
        }

        /* allocate internal port */
        CTC_ERROR_RETURN(sys_humber_get_rsv_internal_port(lchip, &inter_lport));
        inter_gport = CTC_MAP_LPORT_TO_GPORT(gchip, inter_lport);

        SYS_PORT_DEBUG_INFO("src_gport:0x%x, dst_gport:0x%x, inter_lport= %d!\n", src_gport, dst_gport, inter_lport);

        if (src_gport == dst_gport)
        {
            if (src_lport >= SYS_HUMBER_INTERNAL_PORT_START)
            {
                RET_PROCESS_WITH_ERROR(sys_humber_get_port_channel(src_gport, &channel));
                RET_PROCESS_WITH_ERROR(sys_humber_add_port_to_channel(inter_gport, channel));
                crscnt_param.srcport = src_gport;
            }
            else
            {
                RET_PROCESS_WITH_ERROR(sys_humber_add_port_to_channel(inter_gport, src_lport));
                crscnt_param.srcport = inter_gport;
            }

            RET_PROCESS_WITH_ERROR(sys_humber_add_port_to_channel(src_gport, SYS_DROP_CHANNEL_ID_START));
            crscnt_param.destport = inter_gport;
        }
        else
        {
            crscnt_param.srcport = inter_gport;
            crscnt_param.destport = dst_gport;
        }

        p_port_lbk->lbk_gport = inter_gport;

        switch (p_port_lbk->lbk_type)
        {
        case CTC_PORT_LBK_TYPE_SWAP_MAC:
            crscnt_param.swap_mac = TRUE;
            break;

        case CTC_PORT_LBK_TYPE_BYPASS:
            crscnt_param.swap_mac = FALSE;
            break;

        default:
            RET_PROCESS_WITH_ERROR(CTC_E_INVALID_PARAM);
        }

        RET_PROCESS_WITH_ERROR(sys_humber_nh_update_port_crscnt_nexthop(&crscnt_param));

        /*set lbk port property*/
        if (src_lport >= SYS_HUMBER_INTERNAL_PORT_START)
        {
            /* is src_lport is a internal port, cannot do port maping */
            RET_PROCESS_WITH_ERROR(sys_humber_port_set_lbk_port_property(p_port_lbk, src_lport));
        }
        else
        {
            RET_PROCESS_WITH_ERROR(sys_humber_port_set_lbk_port_property(p_port_lbk, inter_lport));
            /* map to internal port*/
            RET_PROCESS_WITH_ERROR(_sys_humber_port_maping_to_local_phy_port(lchip, src_lport, inter_lport));
        }

        if (CTC_E_NONE != ret)
        {
            sys_humber_free_rsv_internal_port(lchip, inter_lport);
            return ret;
        }

        /*save the port*/
        PORT_LOCK;
        p_port_master->igs_port_prop[lchip][src_lport].inter_lport = inter_lport;
        p_port_master->igs_port_prop[lchip][src_lport].lbk_en = TRUE;
        PORT_UNLOCK;

    }
    else
    {

        if (!p_port_master->igs_port_prop[lchip][src_lport].lbk_en)
        {
            return CTC_E_ENTRY_NOT_EXIST;
        }

        PORT_LOCK;
        p_port_master->igs_port_prop[lchip][src_lport].lbk_en = FALSE;
        inter_lport = p_port_master->igs_port_prop[lchip][src_lport].inter_lport;
        PORT_UNLOCK;

        if (src_lport >= SYS_HUMBER_INTERNAL_PORT_START)
        {
            CTC_ERROR_RETURN(sys_humber_port_set_lbk_port_property(p_port_lbk, src_lport));
        }
        else
        {
            CTC_ERROR_RETURN(_sys_humber_port_maping_to_local_phy_port(lchip, src_lport, src_lport));
            CTC_ERROR_RETURN(sys_humber_port_set_lbk_port_property(p_port_lbk, inter_lport));
        }

        if (inter_lport)
        {
            inter_gport = CTC_MAP_LPORT_TO_GPORT(gchip, inter_lport);

            if (src_gport == dst_gport)
            {
                if (src_lport >= SYS_HUMBER_INTERNAL_PORT_START)
                {
                    CTC_ERROR_RETURN(sys_humber_get_port_channel(inter_gport, &channel));
                    CTC_ERROR_RETURN(sys_humber_remove_port_from_channel(inter_gport, channel));
                    CTC_ERROR_RETURN(sys_humber_add_port_to_channel(src_gport, channel));
                }
                else
                {
                    CTC_ERROR_RETURN(sys_humber_remove_port_from_channel(inter_gport, src_lport));
                    CTC_ERROR_RETURN(sys_humber_remove_port_from_channel(src_gport, SYS_DROP_CHANNEL_ID_START));
                }
            }

            /* Release internal port */
            CTC_ERROR_RETURN(sys_humber_free_rsv_internal_port(lchip, inter_lport));
        }
    }

    return CTC_E_NONE;
}

/**
 @brief set port whether the src port match check is enable
*/
int32
sys_humber_port_set_port_check_en(uint16 gport, bool enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = (TRUE == enable) ? 1 : 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d match check:%d!\n", gport, enable);

    /*do write table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_CHECK_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    return ret;
}

/**
 @brief get port whether the src port match check is enable
*/
int32
sys_humber_port_get_port_check_en(uint16 gport, bool* enable)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_val = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);
    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d src match check enable!\n", gport);

    /*do read table*/
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOR(IOC_TABLE, DS_SRC_PORT, DS_SRC_PORT_PORT_CHECK_EN);
    ret = drv_tbl_ioctl(lchip, lport, cmd, &field_val);

    *enable = (1 == field_val) ? TRUE : FALSE;

    return ret;
}

static int32
_sys_humber_port_get_gmac_link_up(uint8 lchip, uint8 lport, bool* is_up)
{
    int32 ret;
    uint32 cmd;
    uint32 table_id, reg_step;
    uint32 field_id;
    uint32 field_val;

    table_id = GMAC0_GMAC_PCS_STATUS + (lport * 20);
    field_id = GMAC0_GMAC_PCS_STATUS_SYNC_STATUS /*+ (lport * 55)*/;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);

    if (field_val)
    {
        *is_up = TRUE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 0)
        {
            /*set mac tx enable*/
            field_val = 1;
            reg_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL - GMAC0_GMACWRAPPER_GMAC_TX_CTRL;
            table_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + lport * reg_step;
            field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 1;
        }
    }
    else
    {
        *is_up = FALSE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 1)
        {
            /*set mac tx disable*/
            field_val = 0;
            reg_step = GMAC1_GMACWRAPPER_GMAC_TX_CTRL - GMAC0_GMACWRAPPER_GMAC_TX_CTRL;
            table_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL + lport * reg_step;
            field_id = GMAC0_GMACWRAPPER_GMAC_TX_CTRL_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 0;
        }
    }

    return ret;
}

static int32
_sys_humber_port_get_xgmac_link_up(uint8 lchip, uint8 lport, bool* is_up)
{
    int32 ret;
    uint32 cmd;
    uint32 table_id;
    sgmac0_sgmac_dbg1_t xgmac_dbg;
    uint32 field_id = 0;
    uint32 field_val = 0;

    sal_memset(&xgmac_dbg, 0, sizeof(xgmac_dbg));

    table_id = XGMAC0_XGMAC_DBG1 + ((lport / 12) * 36);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    ret = drv_reg_ioctl(lchip, 0, cmd, &xgmac_dbg);

    if (xgmac_dbg.align_status && (xgmac_dbg.sync_status == 0xF))
    {
        *is_up = TRUE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 0)
        {
            /*set xgmac tx enable*/
            field_val = 1;
            table_id = XGMAC0_XGMAC_CONFIG1 + ((lport / 12) * 36);
            field_id = XGMAC0_XGMAC_CONFIG1_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 1;
        }
    }
    else
    {
        *is_up = FALSE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 1)
        {
            /*set xgmac tx disable*/
            field_val = 0;
            table_id = XGMAC0_XGMAC_CONFIG1 + ((lport / 12) * 36);
            field_id = XGMAC0_XGMAC_CONFIG1_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 0;
        }
    }

    return ret;
}

static int32
_sys_humber_port_get_sgmac_link_up(uint8 lchip, uint8 lport, bool* is_up)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 table_id;
    sgmac0_sgmac_dbg1_t sgmac_dbg;
    uint32 field_id = 0;
    uint32 field_val = 0;

    sal_memset(&sgmac_dbg, 0, sizeof(sgmac_dbg));

    table_id = SGMAC0_SGMAC_DBG1 + ((lport - 48) * 42);
    cmd = DRV_IOR(IOC_REG, table_id, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &sgmac_dbg));

    if (sgmac_dbg.align_status && (sgmac_dbg.sync_status == 0xF))
    {
        *is_up = TRUE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 0)
        {
            /*set sgmac tx enable*/
            field_val = 1;
            table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
            field_id = SGMAC0_SGMAC_CONFIG1_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 1;
        }
    }
    else
    {
        *is_up = FALSE;
        if (p_port_master->egs_port_prop[lchip][lport].linkup == 1)
        {
            /*set sgmac tx disable*/
            field_val = 0;
            table_id = SGMAC0_SGMAC_CONFIG1 + ((lport - 48) * 42);
            field_id = SGMAC0_SGMAC_CONFIG1_TX_ENABLE;
            cmd = DRV_IOW(IOC_REG, table_id, field_id);
            ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
            p_port_master->egs_port_prop[lchip][lport].linkup = 0;
        }
    }

    return ret;
}

int32
sys_humber_port_get_mac_link_up(uint16 gport, bool* is_up)
{
    int32 ret;
    uint8 lchip;
    uint8 lport;
    ctc_port_mac_type_t type;

    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

    switch (type)
    {
    case CTC_PORT_MAC_GMAC:
        ret = _sys_humber_port_get_gmac_link_up(lchip, lport, is_up);
        break;

    case CTC_PORT_MAC_XGMAC:
        ret = _sys_humber_port_get_xgmac_link_up(lchip, lport, is_up);
        break;

    case CTC_PORT_MAC_SGMAC:
        ret = _sys_humber_port_get_sgmac_link_up(lchip, lport, is_up);
        break;

    case CTC_PORT_MAC_CPUMAC:
        *is_up = TRUE;      /* always up */
        ret = CTC_E_NONE;
        break;

    default:
        ret = CTC_E_INVALID_PORT_MAC_TYPE;
    }

    PORT_UNLOCK;

    return ret;
}

static int32
_sys_humber_port_test_hss4g_eye_width(uint8 lchip, uint8 lport, sys_serdes_eye_mode_t mode, uint16* width)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;
    uint32 hss_div_sel;
    uint8 lserdes_id;
    uint8 count = 0;

    lserdes_id = lport / CTC_MAC_NUM_PER_MACRO;
    /*1. make sure recv link HSSPLL is in locked state*/
    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_PLL_LOCK;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
    if ((ret != CTC_E_NONE) || (field_val == 0))
    {
        return CTC_E_SERDES_STATUS_NOT_READY;
    }

    /*2. set eye mode and select link.*/
    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_MODE_SEL;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    field_val = mode;
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_LINK_SEL;
    field_val = lport % CTC_MAC_NUM_PER_MACRO;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PAT_SEL;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*3. set eye reset and eye center, then de-assert*/
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*4. wait eye done */
    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_EYE_DONE;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);

    while (count < 3)
    {
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        if (field_val == 1)
        {
            break;
        }

        sal_task_sleep(1);
        count++;
    }

    if ((ret != CTC_E_NONE) || (field_val != 1))
    {
        return CTC_E_SERDES_EYE_TEST_NOT_DONE;
    }

    /*5. calculate eye width */
    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_EYE_RESULT;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_DIV_SEL;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &hss_div_sel);
    /*For 1.25GE  val/64 bit time, 1bit time=1s/1.25GE = 0.8 ns = 800 ps*/
    if (hss_div_sel == 2)
    {
        *width = field_val * 800 / 64;
    }
    else /*For 3.125GE, val/32 bit time, 1bit time=1s/3.125GE = 0.32ns = 320 ps*/
    {
        *width = field_val * 10;  /* field_val/32*320*/
    }

    return ret;
}

static int32
_sys_humber_port_test_hss4g_eye_height(uint8 lchip, uint8 lport, sys_serdes_eye_mode_t mode, sys_port_4g_eye_sig_t* eye_sig)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;
    uint8 lserdes_id;
    uint8 seq;

    lserdes_id = lport / CTC_MAC_NUM_PER_MACRO;
    /*1. make sure recv link HSSPLL is in locked state*/
    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_PLL_LOCK;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
    if ((ret != CTC_E_NONE) || (field_val == 0))
    {
        return CTC_E_SERDES_STATUS_NOT_READY;
    }

    /*2. set eye mode(up or down) and select link*/
    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_MODE_SEL;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    field_val = mode;
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_LINK_SEL;
    field_val = lport % CTC_MAC_NUM_PER_MACRO;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PAT_SEL;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*3. set eye reset and eye center, then de-assert*/
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    sal_task_sleep(1);
    /*4. test the eye height*/
    /*4.1. get center value. wait 100000 bit times, set eye enable to 0 and read result*/
    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    table_id = HSS_N0_MON + lserdes_id;
    field_id = HSS_N0_MON_MON_N0_HSS_EYE_RESULT;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    if (mode == SERDES_EYE_MODE_1_HEIGHT)
    {
        eye_sig->height_1_mid = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
    }
    else
    {
        eye_sig->height_0_mid = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
    }

    /*4.2. move up and get result*/
    for (seq = 0; seq < eye_sig->height_count; seq++)
    {
        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
        field_val = 1;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_UP;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        field_val = 1;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        field_val = 0;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
        field_val = 1;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        field_val = 0;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        /*4.2. wait 100000 bit times*/
        sal_task_sleep(1);
        /*4.3. set eye enable to 0, read eye result*/
        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
        field_val = 0;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = HSS_N0_MON + lserdes_id;
        field_id = HSS_N0_MON_MON_N0_HSS_EYE_RESULT;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        if (mode == SERDES_EYE_MODE_1_HEIGHT)
        {
            eye_sig->height_1_right[seq] = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
        }
        else
        {
            eye_sig->height_0_right[seq] = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
        }
    }

    /*4.2. return to center*/
    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    table_id = HSS_N0_CTL + lserdes_id;
    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 1;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_CENTER;
    field_val = 0;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*4.3. move down and get result*/
    for (seq = 0; seq < eye_sig->height_count; seq++)
    {
        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_PR_DN;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        field_val = 1;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        field_val = 0;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_RESET;
        field_val = 1;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        field_val = 0;
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        sal_task_sleep(1);
        table_id = HSS_N0_CTL + lserdes_id;
        field_id = HSS_N0_CTL_CFG_N0_HSS_EYE_ENABLE;
        field_val = 0;
        cmd = DRV_IOW(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

        table_id = HSS_N0_MON + lserdes_id;
        field_id = HSS_N0_MON_MON_N0_HSS_EYE_RESULT;
        cmd = DRV_IOR(IOC_REG, table_id, field_id);
        ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
        if (mode == SERDES_EYE_MODE_1_HEIGHT)
        {
            eye_sig->height_1_left[seq] = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
        }
        else
        {
            eye_sig->height_0_left[seq] = (field_val & 0x3f) * 8 | ((field_val & 0x40) << 9);
        }
    }

    return ret;
}

int32
sys_humber_port_test_hss4g_eye_sig(uint16 gport, sys_port_4g_eye_sig_t* eye_signal)
{
    int32 ret = CTC_E_NONE;
    uint8 lchip;
    uint8 lport;

    CTC_PTR_VALID_CHECK(eye_signal);
    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (lport >= CTC_MAX_HUMBER_PHY_PORT)
    {
        return CTC_E_INVALID_LOCAL_PORT;
    }

    if (eye_signal->height_count > HSS4G_HEIGHT_STEP_MAX)
    {
        return CTC_E_INVALID_PARAM;
    }

    if ((eye_signal->eye_mode == SYS_PORT_EYE_MODE_ALL)
        || (eye_signal->eye_mode == SYS_PORT_EYE_MODE_WIDTH))
    {
        ret = _sys_humber_port_test_hss4g_eye_width(lchip, lport, SERDES_EYE_MODE_1E2BER, &(eye_signal->width));
    }

    if ((eye_signal->eye_mode == SYS_PORT_EYE_MODE_ALL)
        || (eye_signal->eye_mode == SYS_PORT_EYE_MODE_HEIGHT))
    {
        ret = _sys_humber_port_test_hss4g_eye_height(lchip, lport, SERDES_EYE_MODE_1_HEIGHT, eye_signal);
        ret = ret ? ret : _sys_humber_port_test_hss4g_eye_height(lchip, lport, SERDES_EYE_MODE_0_HEIGHT, eye_signal);
    }

    return ret;
}

int32
sys_humber_link_test_hss6g_eye_sig(uint8 lchip, uint8 link, sys_port_6g_eye_sig_t* eye_signal)
{
    int32 ret = CTC_E_NONE;
    uint32 cmd;
    uint32 field_id;
    uint32 table_id;
    uint32 field_val = 0;

    /*1. Freeze link DFE*/
    table_id = HSS_WRITE_DATA;
    field_id = HSS_WRITE_DATA_HSS_WRITE_DATA;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    field_val = 0x30;
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
    table_id = HSS_ACCESS;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    field_val = (0x80010008 | (link << 5));
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);

    /*2. read Hss6G RX eye height, linkA-AMin*/
    table_id = HSS_ACCESS;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    field_val = (0x80110013 | (link << 5));
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    table_id = HSS_READ_DATA;
    field_id = HSS_READ_DATA_HSS_READ_DATA;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    eye_signal->height_am = (field_val & 0xff);

    /*3. read Hss6G RX eye height,  linkA-AN/AP*/
    table_id = HSS_ACCESS;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    field_val = (0x80110012 | (link << 5));
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    table_id = HSS_READ_DATA;
    field_id = HSS_READ_DATA_HSS_READ_DATA;
    cmd = DRV_IOR(IOC_REG, table_id, field_id);
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    eye_signal->height_ap = (field_val & 0xff);
    eye_signal->height_an = (field_val >> 8 & 0xff);

    /*4. Release linkA DFE*/
    table_id = HSS_WRITE_DATA;
    field_id = HSS_WRITE_DATA_HSS_WRITE_DATA;
    cmd = DRV_IOW(IOC_REG, table_id, field_id);
    field_val = 0x10;
    ret = drv_reg_ioctl(lchip, 0, cmd, &field_val);
    table_id = HSS_ACCESS;
    cmd = DRV_IOW(IOC_REG, table_id, DRV_ENTRY_FLAG);
    field_val = (0x80010008 | (link << 5));
    ret = ret ? ret : drv_reg_ioctl(lchip, 0, cmd, &field_val);
    return ret;
}

int32
sys_humber_port_set_mux_demux_en(uint16 gport, ctc_port_mux_demux_type_t type, bool enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_value = 0;
    ipe_hdr_adj_phy_port_mux_ctl_t mux_en;
    uint32 tableid = 0;
    int32 ret = CTC_E_NONE;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(type, CTC_PORT_TYPE_DEMUX);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d mux-demux %d enable:%d!\n", gport, type, enable);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    PORT_LOCK;
    if (CTC_PORT_TYPE_DEMUX == type)
    {
        if (lport >= CTC_MAX_PHY_PORT)
        {
            PORT_UNLOCK;
            return CTC_E_INVALID_PARAM;
        }

        PORT_DB_SET(p_port_master->igs_port_prop[lchip][lport].demux_en, enable);

        cmd = DRV_IOR(IOC_REG, IPE_HDR_ADJ_PHY_PORT_MUX_CTL, DRV_ENTRY_FLAG);
        ret = drv_reg_ioctl(lchip, 0, cmd,  &mux_en);

        if (enable)
        {
            if (lport < 32)
            {
                CTC_BIT_SET(mux_en.mux_en31to0, lport);
            }
            else
            {
                CTC_BIT_SET(mux_en.mux_en51to32, (lport-32));
            }
            field_value = 1;
        }
        else
        {
            if (lport < 32)
            {
                CTC_BIT_UNSET(mux_en.mux_en31to0, lport);
            }
            else
            {
                CTC_BIT_UNSET(mux_en.mux_en51to32, (lport-32));
            }
            field_value = 0;
        }

        cmd = DRV_IOW(IOC_REG, IPE_HDR_ADJ_PHY_PORT_MUX_CTL, DRV_ENTRY_FLAG);
        ret = ret? ret:drv_reg_ioctl(lchip, 0, cmd,  &mux_en);

        /* for sgmac/xgmac, must enable following register */
        if (p_port_master->igs_port_prop[lchip][lport].port_mac_type == CTC_PORT_MAC_XGMAC)
        {
            tableid = XGMAC0_XGMAC_CONFIG4 + 36*(lport/12);
            cmd = DRV_IOW(IOC_REG, tableid, XGMAC0_XGMAC_CONFIG4_MUX_PORT_ENABLE);
            drv_reg_ioctl(lchip, 0, cmd,  &field_value);
        }
        else if (p_port_master->igs_port_prop[lchip][lport].port_mac_type == CTC_PORT_MAC_SGMAC)
        {
            tableid = SGMAC0_SGMAC_CONFIG4 + 42*(lport-48);
            cmd = DRV_IOW(IOC_REG, tableid, SGMAC0_SGMAC_CONFIG4_MUX_PORT_ENABLE);
            drv_reg_ioctl(lchip, 0, cmd,  &field_value);
        }
    }
    else
    {
        if (lport < SYS_RESERVED_INTERNAL_PORT_FOR_DROP)
        {
            PORT_UNLOCK;
            return CTC_E_INVALID_PARAM;
        }

        PORT_DB_SET(p_port_master->egs_port_prop[lchip][lport].mux_en, enable);

        if (enable)
        {
            field_value = 2;    /* refer to spec */
        }
        cmd = DRV_IOW(IOC_TABLE, DS_DEST_PHY_PORT, DS_DEST_PHY_PORT_MUX_PORT_TYPE);
        ret = drv_tbl_ioctl(lchip, lport, cmd, &field_value);
    }
    PORT_UNLOCK;

    return ret;
}

int32
sys_humber_port_get_mux_demux_en(uint16 gport, ctc_port_mux_demux_type_t type, bool* enable)
{
    uint8 lchip = 0;
    uint8 lport = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(enable);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Get port:%d mux demux enable!\n", gport);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    if (CTC_PORT_TYPE_DEMUX == type)
    {
        if (lport >= CTC_MAX_PHY_PORT)
        {
            return CTC_E_INVALID_PARAM;
        }

        PORT_LOCK;
        PORT_DB_GET(enable, p_port_master->igs_port_prop[lchip][lport].demux_en);
        PORT_UNLOCK;
    }
    else
    {
        if (lport < SYS_RESERVED_INTERNAL_PORT_FOR_DROP)
        {
            return CTC_E_INVALID_PARAM;
        }

        PORT_LOCK;
        PORT_DB_GET(enable, p_port_master->egs_port_prop[lchip][lport].mux_en);
        PORT_UNLOCK;
    }

    return CTC_E_NONE;
}

/**
@brief  Set Port MAC PreFix
*/
int32
sys_humber_port_set_port_mac_prefix(ctc_port_mac_prefix_t* port_mac)
{
    uint8 lchip  = 0;
    uint8 lchip_num = 0;
    uint32 cmd           = 0;
    oam_rx_proc_ether_ctl_t     oam_rx_proc_ether_ctl;
    oam_tx_proc_ether_mac_t     oam_tx_proc_ether_mac;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(port_mac);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port prefix!\n");

    lchip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
        cmd = DRV_IOR(IOC_REG, OAM_RX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_rx_proc_ether_ctl));

        sal_memset(&oam_tx_proc_ether_mac, 0, sizeof(oam_tx_proc_ether_mac));
        cmd = DRV_IOR(IOC_REG, OAM_TX_PROC_ETHER_MAC, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_tx_proc_ether_mac));

        oam_rx_proc_ether_ctl.port_mac47to32    = port_mac->port_mac[0][0] << 8 | port_mac->port_mac[0][1];
        oam_rx_proc_ether_ctl.port_mac31to8     = port_mac->port_mac[0][2] << 16 | port_mac->port_mac[0][3] << 8
            | port_mac->port_mac[0][4];
        oam_tx_proc_ether_mac.tx_port_mac47to32 = oam_rx_proc_ether_ctl.port_mac47to32;
        oam_tx_proc_ether_mac.tx_port_mac31to8  = oam_rx_proc_ether_ctl.port_mac31to8;

        cmd = DRV_IOW(IOC_REG, OAM_RX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_rx_proc_ether_ctl));

        cmd = DRV_IOW(IOC_REG, OAM_TX_PROC_ETHER_MAC, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_tx_proc_ether_mac));
    }

    return CTC_E_NONE;
}

/**
@brief  Set Port MAC PostFix
*/
int32
sys_humber_port_set_port_mac_postfix(uint16 gport, ctc_port_mac_postfix_t* port_mac)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd = 0;
    uint32 field_value = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(port_mac);
    CTC_GLOBAL_PORT_CHECK(gport);

    SYS_PORT_DEBUG_FUNC();
    SYS_PORT_DEBUG_INFO("Set port:%d postfix, low_8bits_mac:%d!\n", gport, port_mac->low_8bits_mac);

    if (CTC_IS_LINKAGG_PORT(gport))
    {
        return CTC_E_INVALID_GLOBAL_PORT;
    }

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    cmd = DRV_IOW(IOC_TABLE, OAM_DS_PORT_PROPERTY, OAM_DS_PORT_PROPERTY_MAC_SA_BYTE);
    field_value = port_mac->low_8bits_mac;
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_value));

    return CTC_E_NONE;
}

/**
@brief  Get Port MAC
*/
int32
sys_humber_port_get_port_mac(uint16 gport, mac_addr_t* port_mac)
{
    uint8 lchip = 0;
    uint8 lport = 0;
    uint32 cmd  = 0;
    uint32 field_value = 0;
    oam_rx_proc_ether_ctl_t     oam_rx_proc_ether_ctl;

    CTC_PTR_VALID_CHECK(port_mac);

    SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport);

    sal_memset(&oam_rx_proc_ether_ctl, 0, sizeof(oam_rx_proc_ether_ctl));
    cmd = DRV_IOR(IOC_REG, OAM_RX_PROC_ETHER_CTL, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &oam_rx_proc_ether_ctl));

    cmd = DRV_IOR(IOC_TABLE, OAM_DS_PORT_PROPERTY, OAM_DS_PORT_PROPERTY_MAC_SA_BYTE);
    CTC_ERROR_RETURN(drv_tbl_ioctl(lchip, lport, cmd, &field_value));

    (*port_mac)[0] = ((oam_rx_proc_ether_ctl.port_mac47to32 >> 8) & 0xFF);
    (*port_mac)[1] = (oam_rx_proc_ether_ctl.port_mac47to32 & 0xFF);
    (*port_mac)[2] = ((oam_rx_proc_ether_ctl.port_mac31to8 >> 16) & 0xFF);
    (*port_mac)[3] = ((oam_rx_proc_ether_ctl.port_mac31to8 >> 8) & 0xFF);
    (*port_mac)[4] = (oam_rx_proc_ether_ctl.port_mac31to8 & 0xFF);
    (*port_mac)[5] = field_value;

    return CTC_E_NONE;

}

/**
@brief   Config port's properties
*/
int32
sys_humber_port_set_property(uint16 gport, ctc_port_property_t port_prop, uint32 value)
{
    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PORT_DEBUG_INFO("%s()\n", __FUNCTION__);
    SYS_PORT_DEBUG_INFO("Set port property, gport:%d, property:%d, value:%d\n", \
                        gport, port_prop, value);

    switch (port_prop)
    {
    case CTC_PORT_PROP_REPLACE_STAG_COS:
        CTC_ERROR_RETURN(sys_humber_port_set_replace_cos_en(gport, value));
        break;

    case CTC_PORT_PROP_REPLACE_DSCP_EN:
        CTC_ERROR_RETURN(sys_humber_port_set_replace_dscp_en(gport, value));
        break;

    case CTC_PORT_PROP_DEFAULT_PCP:
        CTC_ERROR_RETURN(sys_humber_port_set_default_pcp(gport, value));
        break;

    case CTC_PORT_PROP_DEFAULT_DEI:
        CTC_ERROR_RETURN(sys_humber_port_set_default_dei(gport, value));
        break;

    case CTC_PORT_PROP_QOS_POLICY:
        CTC_ERROR_RETURN(sys_humber_port_set_qos_policy(gport, value));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

/**
@brief    Get port's properties according to gport id
*/
int32
sys_humber_port_get_property(uint16 gport, ctc_port_property_t port_prop, uint32* value)
{
    uint8 value8 = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(value);
    SYS_PORT_DEBUG_INFO("%s()\n", __FUNCTION__);
    SYS_PORT_DEBUG_INFO("Get port property, gport:%d, property:%d!\n", gport, port_prop);

    /* zero value */
    *value = 0;

    switch (port_prop)
    {
    case CTC_PORT_PROP_REPLACE_STAG_COS:
        CTC_ERROR_RETURN(sys_humber_port_get_replace_cos_en(gport, (bool*)value));
        break;

    case CTC_PORT_PROP_REPLACE_DSCP_EN:
        CTC_ERROR_RETURN(sys_humber_port_get_replace_dscp_en(gport, (bool*)value));
        break;

    case CTC_PORT_PROP_DEFAULT_PCP:
        CTC_ERROR_RETURN(sys_humber_port_get_default_pcp(gport, &value8));
        *value = value8;
        break;

    case CTC_PORT_PROP_DEFAULT_DEI:
        CTC_ERROR_RETURN(sys_humber_port_get_default_dei(gport, &value8));
        *value = value8;
        break;

    case CTC_PORT_PROP_QOS_POLICY:
        CTC_ERROR_RETURN(sys_humber_port_get_qos_policy(gport, &value8));
        *value = value8;
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

/**
@brief  Set port's properties with direction according to gport id
*/
int32
sys_humber_port_set_direction_property(uint16 gport, ctc_port_direction_property_t port_prop, ctc_direction_t dir, uint32 value)
{
    bool acl_en = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(dir, CTC_BOTH_DIRECTION);

    SYS_PORT_DEBUG_INFO("%s()\n", __FUNCTION__);
    SYS_PORT_DEBUG_INFO("Set port property with direction, gport:%d, property:%d, dir:%d,\
                                              value:%d\n", gport, port_prop, dir, value);

    /*do write*/
    switch (port_prop)
    {
    case CTC_PORT_DIR_PROP_ACL_EN:
        CTC_MAX_VALUE_CHECK(value, CTC_ACL_EN_0 + CTC_ACL_EN_1);

        acl_en = CTC_FLAG_ISSET(value, CTC_ACL_EN_0);
        CTC_ERROR_RETURN(sys_humber_port_set_l2acl_enable(gport, dir, acl_en));

        acl_en = CTC_FLAG_ISSET(value, CTC_ACL_EN_1);
        CTC_ERROR_RETURN(sys_humber_port_set_l2qos_enable(gport, dir, acl_en));
        break;

    case CTC_PORT_DIR_PROP_ACL_CLASSID_0:
        CTC_MAX_VALUE_CHECK(value, CTC_ACL_PORT_CLASSID_MAX);
        CTC_ERROR_RETURN(sys_humber_port_set_l2acl_label(gport, dir, value));
        break;

    case CTC_PORT_DIR_PROP_ACL_CLASSID_1:
        CTC_MAX_VALUE_CHECK(value, CTC_ACL_PORT_CLASSID_MAX);
        CTC_ERROR_RETURN(sys_humber_port_set_l2qos_label(gport, dir, value));
        break;

    case CTC_PORT_DIR_PROP_ACL_IPV4_FORCE_MAC:
        CTC_ERROR_RETURN(sys_humber_port_set_qacl_force_ipv4_mackey(gport, dir, value));
        break;

    case CTC_PORT_DIR_PROP_ACL_IPV6_FORCE_MAC:
        CTC_ERROR_RETURN(sys_humber_port_set_qacl_force_ipv6_mackey(gport, dir, value));
        break;

    case CTC_PORT_DIR_PROP_QOS_DOMAIN:
        CTC_MAX_VALUE_CHECK(value, 7);
        CTC_ERROR_RETURN(sys_humber_port_set_qos_domain(gport, dir, value));
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

/**
@brief  Get port's properties with direction according to gport id
*/
int32
sys_humber_port_get_direction_property(uint16 gport, ctc_port_direction_property_t port_prop, ctc_direction_t dir, uint32* value)
{
    uint8 value8 = 0;
    bool acl_en = 0;

    /*Sanity check*/
    if (NULL == p_port_master)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_PTR_VALID_CHECK(value);
    CTC_MAX_VALUE_CHECK(dir, CTC_BOTH_DIRECTION - 1);

    SYS_PORT_DEBUG_INFO("%s()\n", __FUNCTION__);
    SYS_PORT_DEBUG_INFO("Get port property with direction, gport:%d, property:%d, dir:%d" \
                        , gport, port_prop, dir);

    /* zero value */
    *value = 0;

    /*do read,only get value by CTC_INGRESS or CTC_EGRESS,no CTC_BOTH_DIRECTION*/
    switch (port_prop)
    {
    case CTC_PORT_DIR_PROP_ACL_EN:
        CTC_ERROR_RETURN(sys_humber_port_get_l2acl_enable(gport, dir, &acl_en));
        if (acl_en)
        {
            CTC_SET_FLAG(*value, CTC_ACL_EN_0);
        }

        CTC_ERROR_RETURN(sys_humber_port_get_l2qos_enable(gport, dir, &acl_en));
        if (acl_en)
        {
            CTC_SET_FLAG(*value, CTC_ACL_EN_1);
        }

        break;

    case CTC_PORT_DIR_PROP_ACL_CLASSID_0:
        CTC_ERROR_RETURN(sys_humber_port_get_l2acl_label(gport, dir, &value8));
        *value = value8;
        break;

    case CTC_PORT_DIR_PROP_ACL_CLASSID_1:
        CTC_ERROR_RETURN(sys_humber_port_get_l2qos_label(gport, dir, &value8));
        *value = value8;
        break;

    case CTC_PORT_DIR_PROP_ACL_IPV4_FORCE_MAC:
        CTC_ERROR_RETURN(sys_humber_port_get_qacl_force_ipv4_mackey(gport, dir, (bool*)value));
        break;

    case CTC_PORT_DIR_PROP_ACL_IPV6_FORCE_MAC:
        CTC_ERROR_RETURN(sys_humber_port_get_qacl_force_ipv6_mackey(gport, dir, (bool*)value));
        break;

    case CTC_PORT_DIR_PROP_QOS_DOMAIN:
        CTC_ERROR_RETURN(sys_humber_port_get_qos_domain(gport, dir, &value8));
        *value = value8;
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    return CTC_E_NONE;
}

