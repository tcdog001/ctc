/* sys layer function declearation of cfm oam */
/**
 @file sys_humber_oam_cfm.h

 @date 2010-3-9

 @version v2.0

  This file contains sys layer function declarations for Ethernet OAM
*/
#ifndef _SYS_HUMBER_OAM_CFM_H
#define _SYS_HUMBER_OAM_CFM_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************************
 *
 * Header Files
 *
****************************************************************************/
#include "ctc_oam.h"
#include "ctc_parser.h"

/****************************************************************************
*
* Defines and Macros
*
****************************************************************************/

/****************************************************************************
 *
* Function
*
****************************************************************************/

/***************************************************************************************************
----------------          Ethernet OAM (support IEEE 802.1ag and  ITU Y1731 OAM)        ------------
***************************************************************************************************/
/**
 @brief   initilization for ethernet oam
*/
extern int32
sys_humber_eth_oam_init(ctc_oam_global_t* oam_global);

/**
 @brief   add ma id for ethernet oam
*/
extern int32
sys_humber_eth_oam_add_maid(ctc_oam_maid_t* p_maid);

/**
 @brief   add ma id for ethernet oam
*/
extern int32
sys_humber_eth_oam_remove_maid(ctc_oam_maid_t* p_maid);

/**
 @brief   add mep lookup chan for ethernet oam
*/
extern int32
sys_humber_eth_oam_add_lmep_lkup_chan(ctc_oam_chan_t* p_chan);

/**
 @brief   remove mep lookup chan for ethernet oam
*/
extern int32
sys_humber_eth_oam_remove_lmep_lkup_chan(ctc_oam_chan_t* p_chan);

/**
 @brief   add local mep
*/
extern int32
sys_humber_eth_oam_add_lmep(ctc_oam_lmep_t* p_lmep);

/**
 @brief   remove local mep
*/
extern int32
sys_humber_eth_oam_remove_lmep(ctc_oam_lmep_t* p_lmep);

/**
 @brief   update local mep
*/
extern int32
sys_humber_eth_oam_update_lmep(ctc_oam_update_t* lmep);

/**
 @brief   add remote mep
*/
extern int32
sys_humber_eth_oam_add_rmep(ctc_oam_rmep_t* p_rmep);

/**
 @brief   remove remote mep
*/
extern int32
sys_humber_eth_oam_remove_rmep(ctc_oam_rmep_t* p_rmep);

/**
 @brief   update remote mep
*/
extern int32
sys_humber_eth_oam_update_rmep(ctc_oam_update_t* rmep);

/**
 @brief   get eth oam rmep's mac addr in hardware
*/
extern int32
sys_humber_eth_oam_get_rmep_mac_addr(ctc_oam_rmep_t* p_rmep, mac_addr_t rmep_mac_addr);

/**
 @brief   set eth oam property param
*/
extern int32
sys_humber_eth_oam_set_property(ctc_oam_property_t* p_prop);

#ifdef __cplusplus
}
#endif

#endif

