/**
 @file ctc_greatbelt_packet_cli.c

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-11-25

 @version v2.0

 This file define packet CLI functions

*/

#include "sal.h"
#include "ctc_api.h"
#include "ctc_cli.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_packet.h"
#include "ctc_greatbelt_packet.h"
#include "ctc_greatbelt_packet_cli.h"
#include "sys_greatbelt_packet.h"

extern int32
sys_greatbelt_packet_dump();
extern int32
sys_greatbelt_packet_stats_dump();
extern int32
sys_greatbelt_packet_stats_clear();

extern int32
sys_greatbelt_packet_buffer_dump(uint8 buf_cnt, uint8 flag);
extern int32
sys_greatbelt_packet_buffer_clear();
extern int32
sys_greatbelt_packet_set_reason_log(uint16 reason_id, uint8 enable, uint8 is_all, uint8 is_detail);

extern int32
_ctc_cli_packet_get_from_file(char* file, uint8* buf, uint32* pkt_len);

CTC_CLI(ctc_cli_gb_packet_show_packet_info,
        ctc_cli_gb_packet_show_packet_info_cmd,
        "show packet",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PACKET_M_STR)
{
    int32 ret = CTC_E_NONE;

    ret = sys_greatbelt_packet_dump();
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_packet_show_packet_stats,
        ctc_cli_gg_packet_show_packet_stats_cmd,
        "show packet stats",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PACKET_M_STR,
        "Stats")
{
    int32 ret = CTC_E_NONE;

    ret = sys_greatbelt_packet_stats_dump();
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_packet_clear_packet_stats,
        ctc_cli_gg_packet_clear_packet_stats_cmd,
        "clear packet stats",
        CTC_CLI_CLEAR_STR,
        CTC_CLI_PACKET_M_STR,
        "Stats")
{
    int32 ret = CTC_E_NONE;

    ret = sys_greatbelt_packet_stats_clear();
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_gg_packet_show_packet_buffer,
        ctc_cli_gg_packet_show_packet_buffer_cmd,
        "show packet rx {buffer-count CNT | packet-header |}",
        CTC_CLI_SHOW_STR,
        CTC_CLI_PACKET_M_STR,
        "Rx",
        "Buffer cnt",
        "<1-32>",
        "Packet header info")
{
    int32 ret = CTC_E_NONE;
    uint8 index = 0;
    uint8 buf_cnt = 0;
    uint8 flag = 0;


    index = CTC_CLI_GET_ARGC_INDEX("buffer-count");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_UINT8("buffer-count", buf_cnt, argv[index + 1]);
        CTC_BIT_SET(flag, 0);
    }

    index = CTC_CLI_GET_ARGC_INDEX("packet-header");
    if (INDEX_VALID(index))
    {
        CTC_BIT_SET(flag, 1);
    }

    ret = sys_greatbelt_packet_buffer_dump(buf_cnt, flag);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_packet_clear_packet_buffer,
        ctc_cli_gg_packet_clear_packet_buffer_cmd,
        "clear packet rx",
        CTC_CLI_CLEAR_STR,
        CTC_CLI_PACKET_M_STR,
        "Rx")
{
    int32 ret = CTC_E_NONE;

    ret = sys_greatbelt_packet_buffer_clear();
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

int32
ctc_greatbelt_packet_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gb_packet_show_packet_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_packet_show_packet_stats_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_packet_clear_packet_stats_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_packet_show_packet_buffer_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_packet_clear_packet_buffer_cmd);

    return CLI_SUCCESS;
}

