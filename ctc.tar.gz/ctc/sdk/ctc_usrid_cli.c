/**
 @date 2009-10-30

 @version v2.0

---file comments----
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_usrid_cli.h"
#include "ctc_api.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "sys_humber_usrid.h"
#include "ctc_port_mapping_cli.h"

CTC_CLI(ctc_cli_scl_show_vlan_by_port,
        humber_cli_usr_show_vlan_by_port_cmd,
        "show usrid vlan (port GPORT_ID|) (count|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_USERID_STR,
        "Userid vlan entry",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC,
        "Show count")
{
    int32 ret = 0;
    uint16 gport = CTC_MAX_UINT16_VALUE;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", gport, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("co");
    if (index != 0xFF)
    {
        ret = sys_humber_usrid_show_vlan_count_by_port(gport);
    }
    else
    {
        ret = sys_humber_usrid_show_vlan_by_port(gport);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_scl_show_mac_by_label,
        humber_cli_usr_show_mac_by_label_cmd,
        "show usrid mac label LABEL_ID (count|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_USERID_STR,
        "Userid mac entry",
        "Userid label",
        "<0~63>",
        "Show count")
{
    int32 ret = 0;
    uint8 label_id = 0;

    CTC_CLI_GET_UINT8_RANGE("userid label", label_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    if (argc > 1)
    {
        ret = sys_humber_usrid_show_mac_count_by_label(label_id);
    }
    else
    {
        ret = sys_humber_usrid_show_mac_by_label(label_id);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_scl_show_ipv4_by_label,
        humber_cli_usr_show_ipv4_by_label_cmd,
        "show usrid ipv4 label LABEL_ID (count|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_USERID_STR,
        "Userid ipv4 entry",
        "Userid label",
        "<0~63>",
        "Show count")
{
    int32 ret = 0;
    uint8 label_id = 0;

    CTC_CLI_GET_UINT8_RANGE("userid label", label_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    if (argc > 1)
    {
        ret = sys_humber_usrid_show_ipv4_count_by_label(label_id);
    }
    else
    {
        ret = sys_humber_usrid_show_ipv4_by_label(label_id);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_scl_show_ipv6_by_label,
        humber_cli_usr_show_ipv6_by_label_cmd,
        "show usrid ipv6 label LABEL_ID (count |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_USERID_STR,
        "Userid ipv6 entry",
        "Userid label",
        "<0~63>",
        "Show count")
{
    int32 ret = 0;
    uint8 label_id = 0;

    CTC_CLI_GET_UINT8_RANGE("userid label", label_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    if (argc > 1)
    {
        ret = sys_humber_usrid_show_ipv6_count_by_label(label_id);
    }
    else
    {
        ret = sys_humber_usrid_show_ipv6_by_label(label_id);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_scl_show_debug,
        ctc_cli_scl_show_debug_cmd,
        "show debug usrid (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_USERID_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = SCL_CTC;
    }
    else
    {
        typeenum = SCL_SYS;
    }

    ctc_cli_out("userid:%s debug %s\n", argv[0],
                (ctc_debug_get_flag("scl", "scl", typeenum, &level) == TRUE) ? "on" : "off");

    return CLI_SUCCESS;
}

extern int32 sys_humber_test_vlan_range(uint16 VlanStart, uint16 VlanEnd);

CTC_CLI(ctc_cli_scl_test_vlan_range,
        ctc_cli_scl_test_vlan_range_cmd,
        "show usrid vlan-range vlanstart VLAN_ID vlanend VLAN_ID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_USERID_STR,
        "Vlan range testing",
        "Start vlan",
        CTC_CLI_VLAN_RANGE_DESC,
        "End vlan",
        CTC_CLI_VLAN_RANGE_DESC)
{
    int32 ret = 0;
    uint16 VlanStart;
    uint16 VlanEnd;

    CTC_CLI_GET_UINT16_RANGE("start vlan", VlanStart, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT16_RANGE("end   vlan", VlanEnd, argv[1], 0, CTC_MAX_UINT16_VALUE);

    ret = sys_humber_test_vlan_range(VlanStart, VlanEnd);

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
    }

    return ret;
}

int32
ctc_usrid_cli_init(void)
{
    install_element(CTC_SDK_MODE, &humber_cli_usr_show_vlan_by_port_cmd);
    install_element(CTC_SDK_MODE, &humber_cli_usr_show_mac_by_label_cmd);
    install_element(CTC_SDK_MODE, &humber_cli_usr_show_ipv4_by_label_cmd);
    install_element(CTC_SDK_MODE, &humber_cli_usr_show_ipv6_by_label_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_scl_show_debug_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_scl_test_vlan_range_cmd);

    return 0;
}

