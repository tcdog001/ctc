/**
 @file ctc_app_isr.h

 @date 2010-3-2

 @version v2.0

 This file define the isr APIs
*/

#ifndef _CTC_ISR_H
#define _CTC_ISR_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_interrupt.h"
/****************************************************************
*
* Defines and Macros
*
****************************************************************/
typedef int32 callback_func (uint8*);

struct ctc_isr_master_s
{
    callback_func* normal_intr_call_func[CTC_INTERRUPT_NORMAL_INTR_TYPE_MAX]; /**< specific normal interrupt handle callback function */
    callback_func* fatal_intr_call_func[CTC_INTERRUPT_FATAL_INTR_TYPE_MAX]; /**< specific fatal interrupt handle callback function */
    uint8 fatal_intr_num[(CTC_INTERRUPT_FATAL_INTR_TYPE_MAX / 4 + 1) * 4];        /**< specific fatal interrupt occur times */
};
typedef struct ctc_isr_master_s ctc_isr_master_t;

/****************************************************************************
 *
* Function
*
*****************************************************************************/

extern int32
ctc_app_isr_get_intr_cfg(ctc_intr_global_cfg_t* p_intr_cfg, uint8 interrupt_mode);

extern int32
ctc_app_isr_init(void);

#ifdef __cplusplus
}
#endif

#endif

