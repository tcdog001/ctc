/**
 @file ctc_ipuc_cli.c

 @date 2009-12-30

 @version v2.0

 The file apply clis of ipuc module
*/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_ipuc_cli.h"
#include "ctc_api.h"
#include "ctc_ipuc.h"
#include "ctc_port_mapping_cli.h"

#define CTC_CLI_RPF_SET_GLOBAL_SRC_PORT(port, num)                                                         \
{                                                                                                          \
    if ((index + 1 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 1])))                              \
    {                                                                                                      \
        CTC_CLI_GET_UINT16("gport", port[0], argv[index + 1]);                                             \
        num++;                                                                                             \
                                                                                                           \
        if ((index + 2 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 2])))                          \
        {                                                                                                  \
            CTC_CLI_GET_UINT16("gport", port[1], argv[index + 2]);                                         \
            num++;                                                                                         \
                                                                                                           \
            if ((index + 3 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 3])))                      \
            {                                                                                              \
                CTC_CLI_GET_UINT16("gport", port[2], argv[index + 3]);                                     \
                num++;                                                                                     \
                                                                                                           \
                if ((index + 4 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 4])))                  \
                {                                                                                          \
                    CTC_CLI_GET_UINT16("gport", port[3], argv[index + 4]);                                 \
                    num++;                                                                                 \
                                                                                                           \
                    if ((index + 5 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 5])))              \
                    {                                                                                      \
                        CTC_CLI_GET_UINT16("gport", port[4], argv[index + 5]);                             \
                        num++;                                                                             \
                                                                                                           \
                        if ((index + 6 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 6])))          \
                        {                                                                                  \
                            CTC_CLI_GET_UINT16("gport", port[5], argv[index + 6]);                         \
                            num++;                                                                         \
                                                                                                           \
                            if ((index + 7 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 7])))      \
                            {                                                                              \
                                CTC_CLI_GET_UINT16("gport", port[6], argv[index + 7]);                     \
                                num++;                                                                     \
                                                                                                           \
                                if ((index + 8 < argc) && (0 == ctc_cmd_judge_is_num(argv[index + 8])))  \
                                {                                                                          \
                                    CTC_CLI_GET_UINT16("gport", port[7], argv[index + 8]);                 \
                                    num++;                                                                 \
                                }                                                                          \
                            }                                                                              \
                        }                                                                                  \
                    }                                                                                      \
                }                                                                                          \
            }                                                                                              \
        }                                                                                                  \
    }                                                                                                      \
}

CTC_CLI(ctc_cli_ipuc_add_ipv4,
        ctc_cli_ipuc_add_ipv4_cmd,
        "ipuc add VRFID A.B.C.D MASK_LEN NHID {ecmp | {ttl-check | ttl-no-check} | rpf-check (port PORT0 (PORT1 (PORT2 (PORT3 (PORT4 (PORT5 (PORT6 (PORT7 |)|)|)|)|)|)|)|) | icmp-check | icmp-err-check | copy-to-cpu | protocol-entry | self-address | is-neighbor | is-connect l3if L3IFID | aging | l4-dst-port L4PORT (tcp-port|) | assign-port PORT | stats-id STATISID |}",
        CTC_CLI_IPUC_M_STR,
        "Add route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV4_FORMAT,
        CTC_CLI_IPV4_MASK_LEN_FORMAT,
        CTC_CLI_NH_ID_STR,
        "ECMP group",
        "TTL check enable",
        "TTL check disable",
        "RPF check enable",
        "RPF permit global source port",
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        "ICMP redirect check",
        "ICMP error message check",
        "Copy to cpu",
        "Protocol-entry",
        "Self address, used for oam or ptp",
        "This route is a Neighbor",
        "This route is a Connect route",
        "L3 interface of this connect route",
        "L3 interface ID",
        "Aging enable(only for host route)",
        "Layer4 destination port for NAPT",
        CTC_CLI_L4_PORT_VALUE,
        "If set, indicate it is a tcp port, or is a udp port",
        "Specify assign dest gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Stats id",
        CTC_CLI_STATS_ID_VAL)
{
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint8 masklen = 0;
    uint8 index = 0;
    uint16 gport = 0;
    ctc_ipuc_param_t ipuc_info = {0};

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV4_ADDRESS("ip", ipuc_info.ip.ipv4, argv[1]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    CTC_CLI_GET_UINT32("nexthop id", ipuc_info.nh_id, argv[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        ipuc_info.is_ecmp_nh = TRUE;
    }
    else
    {
        ipuc_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-no-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_TTL_NO_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_TTL_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("port");
    if (index != 0xFF)
    {
        CTC_CLI_RPF_SET_GLOBAL_SRC_PORT(ipuc_info.rpf_port, ipuc_info.rpf_port_num);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("icmp-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ICMP_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("icmp-err-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ICMP_ERR_MSG_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("copy-to-cpu");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_CPU;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("protocol-entry");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_PROTOCOL_ENTRY;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("self-address");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_SELF_ADDRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("is-neighbor");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_NEIGHBOR;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("is-connect");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_CONNECT;

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("l3 interface", ipuc_info.l3_inf, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("aging");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_AGING_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst-port", ipuc_info.l4_dst_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tcp-port");
        if (index != 0xFF)
        {
            ipuc_info.is_tcp_port = 1;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("assign-port");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ASSIGN_PORT;
        CTC_CLI_GET_UINT16("gport", gport, argv[index + 1]);
        ipuc_info.gport = gport;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("stats-id", ipuc_info.stats_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        ipuc_info.route_flag |= CTC_IPUC_FLAG_STATS_EN;
    }

    ret = ctc_ipuc_add(&ipuc_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_add_ipv4_nat_sa,
        ctc_cli_ipuc_add_ipv4_nat_sa_cmd,
        "ipuc nat-sa add VRFID A.B.C.D (l4-src-port L4PORT (tcp-port|)|) (new-ipsa A.B.C.D) (new-l4-src-port L4PORT|)",
        CTC_CLI_IPUC_M_STR,
        "Nat sa",
        "Add",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV4_FORMAT,
        "Layer4 source port for NAPT",
        CTC_CLI_L4_PORT_VALUE,
        "Indicate l4-src-port is tcp port or not. If set is TCP port else is UDP port",
        "New ipsa",
        CTC_CLI_IPV4_FORMAT,
        "Layer4 destination port for NAPT",
        CTC_CLI_L4_PORT_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint8 index = 0;
    ctc_ipuc_nat_sa_param_t nat_info = {0};

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    nat_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV4_ADDRESS("ip", nat_info.ipsa.ipv4, argv[1]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src-port", nat_info.l4_src_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tcp-port");
        if (index != 0xFF)
        {
            nat_info.flag |= CTC_IPUC_NAT_FLAG_USE_TCP_PORT;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("new-ipsa");
    if (index != 0xFF)
    {
        CTC_CLI_GET_IPV4_ADDRESS("new ip", nat_info.new_ipsa.ipv4, argv[index+1]);
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("new-l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("new-l4-src-port", nat_info.new_l4_src_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    ret = ctc_ipuc_add_nat_sa(&nat_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_add_ipv4_tunnel,
        ctc_cli_ipuc_add_ipv4_tunnel_cmd,
        "ipuc tunnel add A.B.C.D {vrf VRFID | nhid NHID | tunnel-payload-type TUNNEL_PAYLOAD_TYPE | gre-key GREKEY  \
        | ip-sa A.B.C.D | ecmp | ttl-check | use-outer-ttl | lookup-by-outer | isatap-source-check | copy-to-cpu    \
        | rpf-check (l3if l3ifid0 VALUE  (l3ifid1 VALUE | ) (l3ifid2 VALUE |) (l3ifid3 VALUE |) (more-rpf |) |)     \
        | use-outer-info | qos-use-outer-info | service-id SERVICE_ID | (logic-port GPHYPORT_ID | metadata METADATA) | service-acl-en | service-queue-en \
        | service-policer-en | stats STATS_ID | discard | use-flex | scl-id SCL_ID |}",
        CTC_CLI_IPUC_M_STR,
        "This route is ip tunnel",
        "Add ip tunnel route",
        CTC_CLI_IPV4_FORMAT,
        CTC_CLI_VRFID_ID_DESC ", inner route will lookup by this VRFID",
        CTC_CLI_VRFID_ID_DESC ", inner route will lookup by this VRFID",
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_ID_STR,
        "Tunnel payload layer 4 type (default is IPv6)",
        "Tunnel payload layer 4 type: \r\n0 for GRE \r\n1 for IPv4 \r\n2 for IPv6",
        "Set Gre key value",
        "Gre key value <1-4294967295>",
        "Set IP Sa",
        CTC_CLI_IPV4_FORMAT,
        "ECMP group",
        "Do ttl check for tunnel outer header",
        "Use outer ttl for later process , or use inner ttl",
        "Packet will do router by tunnel outer header , or use payload header",
        "ISATAP source adderss check",
        "Copy to CPU",
        "RPF check enable",
        "L3 interface of this tunnel route, only need when do RPF check and packet do router by inner header",
        "The 1st L3 interface ID",
        "The 1st L3 interface ID <0-1022>, 0 means invalid",
        "The 2nd L3 interface ID",
        "The 2nd L3 interface ID <0-1022>, 0 means invalid",
        "The 3rd L3 interface ID",
        "The 3rd L3 interface ID <0-1022>, 0 means invalid",
        "The 4th L3 interface ID",
        "The 4th L3 interface ID <0-1022>, 0 means invalid",
        "RPF check fail packet will send to cpu",
        "Use outer header info do acl lookup, default use the inner",
        "Use outer dscp/cos do qos classification, default use inner",
        "Service Id",
        CTC_CLI_SCL_SERVICE_ID_VALUE,
        "Logic port",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Metadata",
        "metadata: <0-0x3FFF>",
        "Enable service acl",
        "Enable service queue",
        "Enable service policer",
        "Enable stats",
        CTC_CLI_STATS_ID_VAL,
        "Discard",
        "Use flex key",
        "Scl ID",
        CTC_CLI_SCL_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    ctc_ipuc_tunnel_param_t tunnel_info = {0};

    tunnel_info.payload_type = 2;
    CTC_CLI_GET_IPV4_ADDRESS("ip", tunnel_info.ip_da.ipv4, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("vrf");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_INNER_VRF_EN;
        CTC_CLI_GET_UINT16("vrf id", tunnel_info.vrf_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("nhid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("nexthop id", tunnel_info.nh_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-payload-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("tunnel payload type", tunnel_info.payload_type, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gre-key");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_GRE_WITH_KEY;
        CTC_CLI_GET_UINT32_RANGE("Gre key", tunnel_info.gre_key, argv[index + 1], 1, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ip-sa");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_WITH_IPSA;
        CTC_CLI_GET_IPV4_ADDRESS("IP Sa", tunnel_info.ip_sa.ipv4, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        tunnel_info.is_ecmp_nh = TRUE;
    }
    else
    {
        tunnel_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_TTL_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-outer-ttl");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_USE_OUTER_TTL;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lookup-by-outer");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_BY_OUTER_HEAD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("isatap-source-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_ISATAP_CHECK_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("copy-to-cpu");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_COPY_TO_CPU;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if");
    if (index != 0xFF)
    {
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid0");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 1nd l3 interface", tunnel_info.l3_inf[0], argv[index + 1]);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid1");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 2nd l3 interface", tunnel_info.l3_inf[1], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid2");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 3rd l3 interface", tunnel_info.l3_inf[2], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid3");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 4th l3 interface", tunnel_info.l3_inf[3], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("more-rpf");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_MORE_RPF;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-outer-info");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_ACL_LKUP_BY_OUTER_HEAD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("qos-use-outer-info");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_QOS_USE_OUTER_INFO;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("service-id", tunnel_info.service_id, argv[index + 1]);

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("logic-port");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("logic-port", tunnel_info.logic_port, argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX("metadata");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32("metadata", tunnel_info.metadata, argv[index + 1]);
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_METADATA_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-acl-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_ACL_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-queue-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_QUEUE_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-policer-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_POLICER_EN;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("stats", tunnel_info.stats_id, argv[index + 1]);
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_STATS_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("discard");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_DISCARD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_USE_FLEX;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("scl-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("scl id", tunnel_info.scl_id, argv[index + 1]);
    }

    ret = ctc_ipuc_add_tunnel(&tunnel_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_add_ipv6,
        ctc_cli_ipuc_add_ipv6_cmd,
        "ipuc ipv6 add VRFID X:X::X:X MASK_LEN NHID {ecmp | {ttl-check | ttl-no-check} | rpf-check (port PORT0 (PORT1 (PORT2 (PORT3 (PORT4 (PORT5 (PORT6 (PORT7 |)|)|)|)|)|)|)|) | icmp-check | icmp-err-check | copy-to-cpu | protocol-entry | self-address | is-neighbor | is-connect l3if L3IFID | aging | assign-port PORT | stats-id STATISID |}",
        CTC_CLI_IPUC_M_STR,
        CTC_CLI_IPV6_STR,
        "Add ipv6 route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV6_FORMAT,
        CTC_CLI_IPV6_MASK_LEN_FORMAT,
        CTC_CLI_NH_ID_STR,
        "ECMP group",
        "TTL check enable",
        "RPF check enable",
        "RPF permit global source port",
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        "ICMP redirect check",
        "ICMP error message check",
        "Copy to cpu",
        "Protocol-entry",
        "Self address, used for oam or ptp",
        "This route is a Neighbor",
        "This route is a Connect route",
        "L3 interface of this connect route",
        "L3 interface ID",
        CTC_CLI_L3IF_ID_RANGE_DESC,
        "Aging enable",
        "Specify assign dest gport",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Stats id",
        CTC_CLI_STATS_ID_VAL)
{
    uint16 gport = 0;
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint32 masklen = 0;
    uint8 index = 0;
    ipv6_addr_t ipv6_address;
    ctc_ipuc_param_t ipuc_info;

    sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
    ipuc_info.ip_ver = CTC_IP_VER_6;

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[1]);

    /* adjust endian */
    ipuc_info.ip.ipv6[0] = sal_htonl(ipv6_address[0]);
    ipuc_info.ip.ipv6[1] = sal_htonl(ipv6_address[1]);
    ipuc_info.ip.ipv6[2] = sal_htonl(ipv6_address[2]);
    ipuc_info.ip.ipv6[3] = sal_htonl(ipv6_address[3]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    CTC_CLI_GET_UINT32("nexthop id", ipuc_info.nh_id, argv[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        ipuc_info.is_ecmp_nh = TRUE;
    }
    else
    {
        ipuc_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-no-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_TTL_NO_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_TTL_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("port");
    if (index != 0xFF)
    {
        CTC_CLI_RPF_SET_GLOBAL_SRC_PORT(ipuc_info.rpf_port, ipuc_info.rpf_port_num);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("icmp-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ICMP_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("icmp-err-check");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ICMP_ERR_MSG_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("copy-to-cpu");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_CPU;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("protocol-entry");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_PROTOCOL_ENTRY;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("self-address");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_SELF_ADDRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("is-neighbor");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_NEIGHBOR;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("is-connect");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_CONNECT;

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16_RANGE("l3 interface", ipuc_info.l3_inf, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("aging");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_AGING_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("assign-port");
    if (index != 0xFF)
    {
        ipuc_info.route_flag |= CTC_IPUC_FLAG_ASSIGN_PORT;
        CTC_CLI_GET_UINT16("gport", ipuc_info.gport, argv[index + 1]);
        ipuc_info.gport = gport;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32_RANGE("stats-id", ipuc_info.stats_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        ipuc_info.route_flag |= CTC_IPUC_FLAG_STATS_EN;
    }

    ret = ctc_ipuc_add(&ipuc_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_add_ipv6_tunnel,
        ctc_cli_ipuc_add_ipv6_tunnel_cmd,
        "ipuc ipv6 tunnel add X:X::X:X {vrf VRFID |nhid NHID | tunnel-payload-type TUNNEL_PAYLOAD_TYPE | gre-key GREKEY " \
        "| ip-sa X:X::X:X | ecmp | ttl-check | use-outer-ttl | lookup-by-outer | copy-to-cpu "\
        "| rpf-check (l3if l3ifid0 VALUE  (l3ifid1 VALUE | ) (l3ifid2 VALUE |) (l3ifid3 VALUE |) (more-rpf |) |) "    \
        "| use-outer-info | qos-use-outer-info "\
        "| service-id SERVICE_ID | (logic-port GPHYPORT_ID | metadata METADATA) | service-acl-en | service-queue-en | service-policer-en "       \
        "| stats STATS_ID | discard | scl-id SCL_ID |}",
        CTC_CLI_IPUC_M_STR,
        "Add ipv6 route",
        "This route is ip tunnel",
        "Add ip tunnel route",
        CTC_CLI_IPV6_FORMAT,
        "used to do route lookup, Inner route will lookup by this VRFID (HUMBER not support)",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_ID_STR,
        "Tunnel payload layer 4 type (default is IPv4)",
        "Tunnel payload layer 4 type: 0 for GRE, 1 for IPv4, 2 for IPv6",
        "Set Gre key value",
        "Gre key value <1-4294967295>",
        "Set IP Sa",
        CTC_CLI_IPV6_FORMAT,
        "ECMP group (Only HUMBER support)",
        "Do ttl check for tunnel outer header",
        "Use outer ttl for later process , or use inner ttl",
        "Packet will do router by tunnel outer header , or use payload header",
        "Copy to CPU (Only HUMBER support)",
        "RPF check enable",
        "L3 interface of this tunnel route, only need when do RPF check and packet do router by inner header",
        "The 1st L3 interface ID",
        "The 1st L3 interface ID <0-1022>, 0 means invalid",
        "The 2nd L3 interface ID",
        "The 2nd L3 interface ID <0-1022>, 0 means invalid",
        "The 3rd L3 interface ID",
        "The 3rd L3 interface ID <0-1022>, 0 means invalid",
        "The 4th L3 interface ID",
        "The 4th L3 interface ID <0-1022>, 0 means invalid",
        "RPF check fail packet will send to cpu",
        "Use outer header info do acl lookup, default use the inner",
        "Use outer dscp/cos do qos classification, default use inner",
        "Service Id",
        CTC_CLI_SCL_SERVICE_ID_VALUE,
        "Logic port",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Metadata",
        "metadata: <0-0x3FFF>",
        "Enable service acl",
        "Enable service queue",
        "Enable service policer",
        "Enable stats",
        "Stats ID",
        "Discard",
        "Scl ID",
        CTC_CLI_SCL_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    ipv6_addr_t ipv6_address;
    ctc_ipuc_tunnel_param_t tunnel_info = {0};

    tunnel_info.ip_ver = CTC_IP_VER_6;
    tunnel_info.payload_type = 1;

    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[0]);
    /* adjust endian */
    tunnel_info.ip_da.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_info.ip_da.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_info.ip_da.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_info.ip_da.ipv6[3] = sal_htonl(ipv6_address[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("vrf");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_INNER_VRF_EN;
        CTC_CLI_GET_UINT16("vrf id", tunnel_info.vrf_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("nhid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("nexthop id", tunnel_info.nh_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-payload-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("tunnel payload type", tunnel_info.payload_type, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gre-key");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_GRE_WITH_KEY;
        CTC_CLI_GET_UINT32_RANGE("Gre key", tunnel_info.gre_key, argv[index + 1], 1, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ip-sa");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_WITH_IPSA;
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index + 1]);
        /* adjust endian */
        tunnel_info.ip_sa.ipv6[0] = sal_htonl(ipv6_address[0]);
        tunnel_info.ip_sa.ipv6[1] = sal_htonl(ipv6_address[1]);
        tunnel_info.ip_sa.ipv6[2] = sal_htonl(ipv6_address[2]);
        tunnel_info.ip_sa.ipv6[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        tunnel_info.is_ecmp_nh = TRUE;
    }
    else
    {
        tunnel_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ttl-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_TTL_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-outer-ttl");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_USE_OUTER_TTL;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("lookup-by-outer");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_BY_OUTER_HEAD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("copy-to-cpu");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_COPY_TO_CPU;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if");
    if (index != 0xFF)
    {
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid0");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 1nd l3 interface", tunnel_info.l3_inf[0], argv[index + 1]);
        }
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid1");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 2nd l3 interface", tunnel_info.l3_inf[1], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid2");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 3rd l3 interface", tunnel_info.l3_inf[2], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3ifid3");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("The 4th l3 interface", tunnel_info.l3_inf[3], argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("more-rpf");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_MORE_RPF;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-outer-info");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_ACL_LKUP_BY_OUTER_HEAD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("qos-use-outer-info");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_QOS_USE_OUTER_INFO;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("service-id", tunnel_info.service_id, argv[index + 1]);

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("logic-port");
        if (index != 0xFF)
        {
            CTC_CLI_GET_UINT16("logic-port", tunnel_info.logic_port, argv[index + 1]);
        }

        index = CTC_CLI_GET_ARGC_INDEX("metadata");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT32("metadata", tunnel_info.metadata, argv[index + 1]);
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_METADATA_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-acl-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_ACL_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-queue-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_QUEUE_EN;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-policer-en");
        if (index != 0xFF)
        {
            tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_SERVICE_POLICER_EN;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("stats", tunnel_info.stats_id, argv[index + 1]);
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_STATS_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("discard");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_DISCARD;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("scl-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("scl id", tunnel_info.scl_id, argv[index + 1]);
    }

    ret = ctc_ipuc_add_tunnel(&tunnel_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_remove_ipv4,
        ctc_cli_ipuc_remove_ipv4_cmd,
        "ipuc remove VRFID A.B.C.D MASK_LEN NHID ( ecmp  |) (l4-dst-port L4PORT (tcp-port|)|)",
        CTC_CLI_IPUC_M_STR,
        "Remove route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV4_FORMAT,
        CTC_CLI_IPV4_MASK_LEN_FORMAT,
        CTC_CLI_NH_ID_STR,
        "ECMP group",
        "Layer4 destination port for NAPT",
        CTC_CLI_L4_PORT_VALUE,
        "If set, indicate it is a tcp port, or is a udp port")
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    uint32 vrfid = 0;
    uint32 masklen = 0;
    ctc_ipuc_param_t ipuc_info = {0};

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV4_ADDRESS("ip", ipuc_info.ip.ipv4, argv[1]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    CTC_CLI_GET_UINT32("nexthop id", ipuc_info.nh_id, argv[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        ipuc_info.is_ecmp_nh = TRUE;
    }
    else
    {
        ipuc_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l4-dst-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-dst-port", ipuc_info.l4_dst_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tcp-port");
        if (index != 0xFF)
        {
            ipuc_info.is_tcp_port = 1;
        }
    }

    ret = ctc_ipuc_remove(&ipuc_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_remove_ipv4_nat_sa,
        ctc_cli_ipuc_remove_ipv4_nat_sa_cmd,
        "ipuc nat-sa remove VRFID A.B.C.D (l4-src-port L4PORT (tcp-port|)|)",
        CTC_CLI_IPUC_M_STR,
        "Nat sa",
        "Remove",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV4_FORMAT,
        "Layer4 source port for NAPT",
        CTC_CLI_L4_PORT_VALUE,
        "If set, indicate it is a tcp port, or is a udp port")
{
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint8 index = 0;
    ctc_ipuc_nat_sa_param_t nat_info = {0};

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    nat_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV4_ADDRESS("ip", nat_info.ipsa.ipv4, argv[1]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l4-src-port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("l4-src-port", nat_info.l4_src_port, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tcp-port");
        if (index != 0xFF)
        {
            nat_info.flag |= CTC_IPUC_NAT_FLAG_USE_TCP_PORT;
        }
    }

    ret = ctc_ipuc_remove_nat_sa(&nat_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_remove_ipv4_tunnel,
        ctc_cli_ipuc_remove_ipv4_tunnel_cmd,
        "ipuc tunnel remove A.B.C.D ({ vrf VRFID | tunnel-payload-type TUNNEL_PAYLOAD_TYPE | gre-key GREKEY  | ip-sa A.B.C.D | use-flex | rpf-check | scl-id SCL_ID} | ) ",
        CTC_CLI_IPUC_M_STR,
        "This route is ip tunnel",
        "Remove ip tunnel route",
        CTC_CLI_IPV4_FORMAT,
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_VRFID_ID_DESC,
        "Tunnel payload layer 4 type (default is IPv6)",
        "Tunnel payload layer 4 type: 0 for GRE, 1 for IPv4, 2 for IPv6",
        "Set Gre key value",
        "Gre key value <1-4294967295>",
        "Set IP Sa",
        CTC_CLI_IPV4_FORMAT,
        "Use flex key",
        "RPF check key need remove",
        "Scl ID",
        CTC_CLI_SCL_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    ctc_ipuc_tunnel_param_t tunnel_info = {0};

    tunnel_info.payload_type = 2;
    CTC_CLI_GET_IPV4_ADDRESS("ip", tunnel_info.ip_da.ipv4, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("vrf");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("nexthop id", tunnel_info.vrf_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-payload-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("tunnel payload type", tunnel_info.payload_type, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gre-key");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_GRE_WITH_KEY;
        CTC_CLI_GET_UINT32_RANGE("Gre key", tunnel_info.gre_key, argv[index + 1], 1, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ip-sa");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_WITH_IPSA;
        CTC_CLI_GET_IPV4_ADDRESS("IP Sa", tunnel_info.ip_sa.ipv4, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_USE_FLEX;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        tunnel_info.is_ecmp_nh = TRUE;
    }
    else
    {
        tunnel_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("scl-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("scl id", tunnel_info.scl_id, argv[index + 1]);
    }

    ret = ctc_ipuc_remove_tunnel(&tunnel_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_remove_ipv6,
        ctc_cli_ipuc_remove_ipv6_cmd,
        "ipuc ipv6 remove VRFID X:X::X:X MASK_LEN NHID ( ecmp | )",
        CTC_CLI_IPUC_M_STR,
        CTC_CLI_IPV6_STR,
        "Remove ipv6 route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV6_FORMAT,
        CTC_CLI_IPV6_MASK_LEN_FORMAT,
        CTC_CLI_NH_ID_STR,
        "ECMP group")
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    uint32 vrfid = 0;
    uint32 masklen = 0;
    ipv6_addr_t ipv6_address;
    ctc_ipuc_param_t ipuc_info = {0};

    ipuc_info.ip_ver = CTC_IP_VER_6;

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[1]);

    /* adjust endian */
    ipuc_info.ip.ipv6[0] = sal_htonl(ipv6_address[0]);
    ipuc_info.ip.ipv6[1] = sal_htonl(ipv6_address[1]);
    ipuc_info.ip.ipv6[2] = sal_htonl(ipv6_address[2]);
    ipuc_info.ip.ipv6[3] = sal_htonl(ipv6_address[3]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    CTC_CLI_GET_UINT32("nexthop id", ipuc_info.nh_id, argv[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        ipuc_info.is_ecmp_nh = TRUE;
    }
    else
    {
        ipuc_info.is_ecmp_nh = FALSE;
    }

    ret = ctc_ipuc_remove(&ipuc_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_remove_ipv6_tunnel,
        ctc_cli_ipuc_remove_ipv6_tunnel_cmd,
        "ipuc ipv6 tunnel remove X:X::X:X ({ vrf VRFID | tunnel-payload-type TUNNEL_PAYLOAD_TYPE | gre-key GREKEY  | ip-sa X:X::X:X | rpf-check | scl-id SCL_ID} | )",
        CTC_CLI_IPUC_M_STR,
        "IPv6 route",
        "This route is ip tunnel",
        "Remove ip tunnel route",
        CTC_CLI_IPV6_FORMAT,
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_VRFID_ID_DESC,
        "Tunnel payload layer 4 type (default is IPv4)",
        "Tunnel payload layer 4 type: \r\n0 for GRE \r\n1 for IPv4 \r\n2 for IPv6",
        "Set Gre key value",
        "Gre key value <1-4294967295>",
        "Set IP Sa",
        CTC_CLI_IPV6_FORMAT,
        "RPF check key need remove",
        "Scl ID",
        CTC_CLI_SCL_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    ipv6_addr_t ipv6_address;
    ctc_ipuc_tunnel_param_t tunnel_info = {0};

    tunnel_info.ip_ver = CTC_IP_VER_6;
    tunnel_info.payload_type = 1;

    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[0]);
    /* adjust endian */
    tunnel_info.ip_da.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_info.ip_da.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_info.ip_da.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_info.ip_da.ipv6[3] = sal_htonl(ipv6_address[3]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("vrf");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("nexthop id", tunnel_info.vrf_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-payload-type");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("tunnel payload type", tunnel_info.payload_type, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gre-key");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_GRE_WITH_KEY;
        CTC_CLI_GET_UINT32_RANGE("Gre key", tunnel_info.gre_key, argv[index + 1], 1, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ip-sa");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_LKUP_WITH_IPSA;
        CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[index + 1]);
        /* adjust endian */
        tunnel_info.ip_sa.ipv6[0] = sal_htonl(ipv6_address[0]);
        tunnel_info.ip_sa.ipv6[1] = sal_htonl(ipv6_address[1]);
        tunnel_info.ip_sa.ipv6[2] = sal_htonl(ipv6_address[2]);
        tunnel_info.ip_sa.ipv6[3] = sal_htonl(ipv6_address[3]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ecmp");
    if (index != 0xFF)
    {
        tunnel_info.is_ecmp_nh = TRUE;
    }
    else
    {
        tunnel_info.is_ecmp_nh = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("rpf-check");
    if (index != 0xFF)
    {
        tunnel_info.flag |= CTC_IPUC_TUNNEL_FLAG_V4_RPF_CHECK;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("scl-id");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("scl id", tunnel_info.scl_id, argv[index + 1]);
    }

    ret = ctc_ipuc_remove_tunnel(&tunnel_info);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_add_default,
        ctc_cli_ipuc_add_default_cmd,
        "ipuc (ipv6 | ) default NHID",
        CTC_CLI_IPUC_M_STR,
        CTC_CLI_IPV6_STR,
        "Default route",
        CTC_CLI_NH_ID_STR)
{
    int32 ret = CLI_SUCCESS;
    uint32 nh_id = 0;
    uint8 ip_ver;

    CTC_CLI_GET_UINT32("nexthop id", nh_id, argv[argc - 1]);
    if (argc == 1)
    {
        ip_ver = CTC_IP_VER_4;
    }
    else
    {
        ip_ver = CTC_IP_VER_6;
    }

    ret = ctc_ipuc_add_default_entry(ip_ver, nh_id);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_set_global_property,
        ctc_cli_ipuc_set_global_property_cmd,
        "ipuc global-config {ipv4-martian-check (enable | disable) | ipv6-martian-check (enable | disable) | mcast-match-check (enable | disable) | ipv4-sa-search (enable | disable) | ipv6-sa-search (enable | disable) | ip-ttl-threshold THRESHOLD }",
        CTC_CLI_IPUC_M_STR,
        "Global config for ip module",
        "Martian address check for ipv4",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "Martian address check for ipv6",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "Unmatched muticast MAC/IP address check",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "IPSA lookup for IPv4",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "IPSA lookup for IPv6",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE,
        "Threshold for TTL check",
        "TTL threshold value <0-0xFF> ")
{
    int32 ret = 0;
    uint8 index = 0xFF;
    uint16 ip_ttl_threshold = 0;
    ctc_ipuc_global_property_t global_prop = { 0 };

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ipv4-martian-check");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_V4_MARTIAN_CHECK_EN;

        global_prop.v4_martian_check_en =
            (0 == sal_memcmp(argv[index + 1], "enable", sal_strlen("enable"))) ? 1 : 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ipv6-martian-check");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_V6_MARTIAN_CHECK_EN;

        global_prop.v6_martian_check_en =
            (0 == sal_memcmp(argv[index + 1], "enable", sal_strlen("enable"))) ? 1 : 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("mcast-match-check");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_MCAST_MACDA_IP_UNMATCH_CHECK;

        global_prop.mcast_match_check_en =
            (0 == sal_memcmp(argv[index + 1], "enable", sal_strlen("enable"))) ? 1 : 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ipv4-sa-search");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_IPUC_V4_IPSA_SERACH_EN;

        global_prop.ipv4_sa_search_en =
            (0 == sal_memcmp(argv[index + 1], "enable", sal_strlen("enable"))) ? 1 : 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ipv6-sa-search");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_IPUC_V6_IPSA_SERACH_EN;

        global_prop.ipv6_sa_search_en =
            (0 == sal_memcmp(argv[index + 1], "enable", sal_strlen("enable"))) ? 1 : 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("ip-ttl-threshold");
    if (0xFF != index)
    {
        global_prop.valid_flag |= CTC_IP_GLB_PROP_TTL_THRESHOLD;
        CTC_CLI_GET_UINT8("THRESHOLD", ip_ttl_threshold, argv[index + 1]);
        global_prop.ip_ttl_threshold = ip_ttl_threshold;
    }

    ret = ctc_ipuc_set_global_property(&global_prop);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_debug_on,
        ctc_cli_ipuc_debug_on_cmd,
        "debug ipuc (ctc | sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_IPUC_M_STR,
        "Ctc layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPUC_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = IPUC_SYS;
    }

    ctc_debug_set_flag("ip", "ipuc", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_debug_off,
        ctc_cli_ipuc_debug_off_cmd,
        "no debug ipuc (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_IPUC_M_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPUC_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = IPUC_SYS;
    }

    ctc_debug_set_flag("ip", "ipuc", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_debug_show,
        ctc_cli_ipuc_debug_show_cmd,
        "show debug ipuc (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_IPUC_M_STR,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = IPUC_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = IPUC_SYS;
    }

    ctc_cli_out("ipuc:%s debug %s level:%s\n\r", argv[0],
                ctc_debug_get_flag("ipuc", "ipuc", typeenum, &level) ? "on" : "off", ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

int32
ctc_ipuc_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_ipv4_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_ipv4_nat_sa_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_ipv6_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_remove_ipv4_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_remove_ipv4_nat_sa_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_remove_ipv6_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_ipv4_tunnel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_ipv6_tunnel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_remove_ipv4_tunnel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_remove_ipv6_tunnel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_add_default_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_set_global_property_cmd);

    install_element(CTC_SDK_MODE,  &ctc_cli_ipuc_debug_on_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_ipuc_debug_off_cmd);
    install_element(CTC_SDK_MODE,  &ctc_cli_ipuc_debug_show_cmd);

    return CLI_SUCCESS;
}

