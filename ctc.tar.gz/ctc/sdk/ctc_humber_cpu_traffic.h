/**
 @file ##ctc_humber_cpu_traffic.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-01-13

 @version v2.0

   The file provide the CPU traffic interface for customer.
*/

#ifndef _CTC_HUMBER_CPU_TRAFFIC_H_
#define _CTC_HUMBER_CPU_TRAFFIC_H_
#ifdef __cplusplus
extern "C" {
#endif

#if 1
/****************************************************************************
 *
 * Function
 *
 ****************************************************************************/

/**
 @addtogroup cpu_traffic CPU_TRAFFIC
 @{
*/

/**
 @brief Set exception to local cpu, remote port or drop.

 @param[in] lchip    local chip id

 @param[in] excp  normal exception index, CTC_EXCEPTION_xxxxxx of enum ctc_packet_tocpu_reason_e

 @param[in] dest_id  dest_type ==CTC_EXCP_DEST_TO_LOCAL_PORT or CTC_EXCP_DEST_TO_REMOTE_PORT indicate gloal port id,
                     else dest_type == CTC_EXCP_DEST_TO_LOCAL_CPU indicate cpu mac index

 @param[in] dest_type ctc_excp_dest_type_t (to local cpu, remote port or drop).

 @return CTC_E_XXX
*/
extern int32
ctc_humber_cpu_traffic_set_exception(uint8 lchip, uint8 excp, uint16 dest_id, ctc_excp_dest_type_t dest_type);

/**
 @brief Set fatal exception to local cpu, remote port or drop.

 @param[in] lchip    local chip id

 @param[in] excp  fatal exception index,, CTC_EXCEPTION_xxxxxx of enum ctc_packet_tocpu_reason_e

 @param[in] dest_id  dest_type ==CTC_EXCP_DEST_TO_LOCAL_PORT or CTC_EXCP_DEST_TO_REMOTE_PORT indicate gloal port id,
                     else dest_type == CTC_EXCP_DEST_TO_LOCAL_CPU indicate cpu mac index

 @param[in] dest_type ctc_excp_dest_type_t (to local cpu, remote port or drop).

 @return CTC_E_XXX
*/
extern int32
ctc_humber_cpu_traffic_set_fatal_exception(uint8 lchip, uint8 excp, uint16 dest_id, ctc_excp_dest_type_t dest_type);

/**
 @brief CPU traffic initialization.

 @param[in] lchip    local chip id

 @param[in] p_global_cfg point to global configure

 @return CTC_E_XXX
*/
extern int32
ctc_humber_cpu_traffic_init(uint8 lchip, void* p_global_cfg);

/**@} end of @addtogroup cpu_traffic CPU_TRAFFIC  */

#endif

#ifdef __cplusplus
}
#endif

#endif

