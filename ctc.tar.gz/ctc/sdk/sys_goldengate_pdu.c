/**
 @file sys_goldengate_pdu.c

 @date 2009-12-30

 @version v2.0

---file comments----
*/

#include "sal.h"
#include "ctc_error.h"
#include "ctc_vector.h"
#include "sys_goldengate_pdu.h"
#include "sys_goldengate_chip.h"
#include "sys_goldengate_port.h"
#include "sys_goldengate_common.h"
#include "sys_goldengate_l3if.h"

#include "drv_enum.h"
#include "drv_io.h"
#include "drv_common.h"

/***************************************************************
 *
 *  Defines and Macros
 *
 ***************************************************************/
#define MAX_SYS_PDU_L2PDU_BASED_L2HDR_PTL_ENTRY 16
#define MAX_SYS_PDU_L2PDU_BASED_MACDA_LOW24_ENTRY 10
#define MAX_SYS_PDU_L2PDU_BASED_MACDA_ENTRY 8
#define MAX_SYS_PDU_L2PDU_BASED_L3TYPE_ENTRY 15
#define MAX_SYS_PDU_L2PDU_BASED_BPDU_ENTRY 1

#define MAX_SYS_PDU_L3PDU_BASED_L3HDR_PROTO 8
#define MAX_SYS_PDU_L3PDU_BASED_PORT 8
#define MAX_SYS_PDU_L3PDU_BASED_IPDA 4
#define PDU_SET_MAC(d, s)       sal_memcpy(d, s, sizeof(mac_addr_t))
#define PDU_SET_HW_MAC(d, s)    SYS_GOLDENGATE_SET_HW_MAC(d, s)

#define IS_MAC_ALL_ZERO(mac)      (!mac[0] && !mac[1] && !mac[2] && !mac[3] && !mac[4] && !mac[5])
#define IS_MAC_LOW24BIT_ZERO(mac) (!mac[3] && !mac[4] && !mac[5])
#define SYS_PDU_SET_SHOW_ITEM(i, f, v) \
        do {                           \
            item[i].field = f;         \
            item[i].p_val = v;           \
        } while (0);

enum sys_pdu_show_l3_column_e
{
    SYS_PDU_SHOW_L3_COLUMN_TYPE,
    SYS_PDU_SHOW_L3_COLUMN_L3TYPE,
    SYS_PDU_SHOW_L3_COLUMN_IPDA,
    SYS_PDU_SHOW_L3_COLUMN_PROTOCOL,
    SYS_PDU_SHOW_L3_COLUMN_L4PORT,
    SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX,
    SYS_PDU_SHOW_L3_COLUMN_VALID,
    SYS_PDU_SHOW_L3_COLUMN_NUM
};
typedef enum sys_pdu_show_l3_column_e sys_pdu_show_l3_column_t;

enum sys_pdu_show_l2_column_e
{
    SYS_PDU_SHOW_L2_COLUMN_TYPE,
    SYS_PDU_SHOW_L2_COLUMN_MACDA,
    SYS_PDU_SHOW_L2_COLUMN_ETHTYPE,
    SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX,
    SYS_PDU_SHOW_L2_COLUMN_VALID,
    SYS_PDU_SHOW_L2_COLUMN_NUM
};
typedef enum sys_pdu_show_l2_column_e sys_pdu_show_l2_column_t;

enum sys_pdu_show_type_e
{
    SYS_PDU_SHOW_COLUMN_TITLE,
    SYS_PDU_SHOW_IGNORE,
    SYS_PDU_SHOW_DESC,
    SYS_PDU_SHOW_IP_VER,
    SYS_PDU_SHOW_IPV4_ADDR,
    SYS_PDU_SHOW_IPV6_ADDR,
    SYS_PDU_SHOW_MAC_ADDR,
    SYS_PDU_SHOW_FREE,
    SYS_PDU_SHOW_PROTOCOL,
    SYS_PDU_SHOW_FIXED,
    SYS_PDU_SHOW_FLEX,
    SYS_PDU_SHOW_L3_TYPE,
    SYS_PDU_SHOW_EMPTY,
    SYS_PDU_SHOW_ACTION_INDEX,
    SYS_PDU_SHOW_VALID,
    SYS_PDU_SHOW_USER_PDU,
    SYS_PDU_SHOW_NUM
};
typedef enum sys_pdu_show_type_e sys_pdu_show_type_t;

typedef char* (* sys_goldengate_pdu_show_token_t)(uint8, uint8, void*);

struct sys_pdu_show_item_s
{
    uint8  field;
    void*  p_val;
};
typedef struct sys_pdu_show_item_s sys_pdu_show_item_t;

enum sys_pdu_token_alignment_type_e
{
    SYS_PDU_TOKEN_ALIGNMENT_LEFT,
    SYS_PDU_TOKEN_ALIGNMENT_MIDDLE,
    SYS_PDU_TOKEN_ALIGNMENT_RIGHT,
    SYS_PDU_TOKEN_ALIGNMENT_NUM
};
typedef enum sys_pdu_token_alignment_type_e sys_pdu_token_alignment_type_t;

/***************************************************************
*
*  Functions
*
***************************************************************/
static int32
_sys_goldengate_l2pdu_classify_l2pdu_by_l2hdr_proto(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    uint32 field = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("ethertype:0x%x\n", p_entry->l2hdr_proto);

    field = p_entry->l2hdr_proto;

    if (index >= MAX_SYS_PDU_L2PDU_BASED_L2HDR_PTL_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBpduProtocolEscapeCam3_array_1_cam3EntryValid_f - IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f;
    cmd = DRV_IOW(IpeBpduProtocolEscapeCam3_t, IpeBpduProtocolEscapeCam3_array_0_cam3EtherType_f + (index * step));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_classified_key_by_l2hdr_proto(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    uint32 field = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_L2HDR_PTL_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBpduProtocolEscapeCam3_array_1_cam3EntryValid_f - IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f;
    cmd = DRV_IOR(IpeBpduProtocolEscapeCam3_t, IpeBpduProtocolEscapeCam3_array_0_cam3EtherType_f + (index * step));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));

    p_entry->l2hdr_proto = field;

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_classify_l2pdu_by_macda(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* p_entry)
{
    uint32 cmd = 0;
    int32  index_step = IpeBpduProtocolEscapeCam_array_1_cam1MacDaValue_f
                        - IpeBpduProtocolEscapeCam_array_0_cam1MacDaValue_f;
    uint32 mac_da_value_field_id = IpeBpduProtocolEscapeCam_array_0_cam1MacDaValue_f;
    uint32 mac_da_mask_field_id = IpeBpduProtocolEscapeCam_array_0_cam1MacDaMask_f;
    IpeBpduProtocolEscapeCam_m cam;
    hw_mac_addr_t mac_addr;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("macda:%x %x %x %x %x %x\n", p_entry->l2pdu_by_mac.mac[0], p_entry->l2pdu_by_mac.mac[1], \
                      p_entry->l2pdu_by_mac.mac[2], p_entry->l2pdu_by_mac.mac[3], p_entry->l2pdu_by_mac.mac[4], p_entry->l2pdu_by_mac.mac[5]);
    SYS_PDU_DBG_PARAM("mask: %x %x %x %x %x %x\n", p_entry->l2pdu_by_mac.mac_mask[0], p_entry->l2pdu_by_mac.mac_mask[1], \
                      p_entry->l2pdu_by_mac.mac_mask[2], p_entry->l2pdu_by_mac.mac_mask[3], p_entry->l2pdu_by_mac.mac_mask[4], p_entry->l2pdu_by_mac.mac_mask[5]);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    if ((p_entry->l2pdu_by_mac.mac_mask[0] == 0) && (p_entry->l2pdu_by_mac.mac_mask[1] == 0)
        && (p_entry->l2pdu_by_mac.mac_mask[2] == 0) && (p_entry->l2pdu_by_mac.mac_mask[3] == 0)
        && (p_entry->l2pdu_by_mac.mac_mask[4] == 0) && (p_entry->l2pdu_by_mac.mac_mask[5] == 0))
    {
        sal_memset(p_entry->l2pdu_by_mac.mac_mask, 0xFF, sizeof(mac_addr_t));
    }

    cmd = DRV_IOR(IpeBpduProtocolEscapeCam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    mac_da_value_field_id += index_step * index;
    mac_da_mask_field_id += index_step * index;

    PDU_SET_HW_MAC(mac_addr, p_entry->l2pdu_by_mac.mac);
    DRV_SET_FIELD_A(IpeBpduProtocolEscapeCam_t, mac_da_value_field_id, &cam, (uint32*)&mac_addr);
    PDU_SET_HW_MAC(mac_addr, p_entry->l2pdu_by_mac.mac_mask);
    DRV_SET_FIELD_A(IpeBpduProtocolEscapeCam_t, mac_da_mask_field_id, &cam, (uint32*)&mac_addr);

    cmd = DRV_IOW(IpeBpduProtocolEscapeCam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_classified_key_by_macda(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* p_entry)
{
    uint32 cmd = 0;
    int32  index_step = IpeBpduProtocolEscapeCam_array_1_cam1MacDaValue_f
                        - IpeBpduProtocolEscapeCam_array_0_cam1MacDaValue_f;
    uint32 mac_da_value_field_id = IpeBpduProtocolEscapeCam_array_0_cam1MacDaValue_f;
    uint32 mac_da_mask_field_id = IpeBpduProtocolEscapeCam_array_0_cam1MacDaMask_f;
    IpeBpduProtocolEscapeCam_m cam;
    hw_mac_addr_t mac_addr;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    sal_memset(&cam, 0, sizeof(IpeBpduProtocolEscapeCam_m));

    cmd = DRV_IOR(IpeBpduProtocolEscapeCam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    mac_da_value_field_id += index_step * index;
    mac_da_mask_field_id += index_step * index;

    DRV_GET_FIELD_A(IpeBpduProtocolEscapeCam_t, mac_da_value_field_id, &cam, (uint32*)&mac_addr);
    SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac, mac_addr);

    DRV_GET_FIELD_A(IpeBpduProtocolEscapeCam_t, mac_da_mask_field_id, &cam, (uint32*)&mac_addr);
    SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac_mask, mac_addr);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_classify_l2pdu_by_macda_low24(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* entry)
{
    int32  cam2_index_step = IpeBpduProtocolEscapeCam2_array_1_cam2MacDaValue_f
                             - IpeBpduProtocolEscapeCam2_array_0_cam2MacDaValue_f;
    int32  cam4_index_step = IpeBpduProtocolEscapeCam4_array_1_cam4MacDa_f
                             - IpeBpduProtocolEscapeCam4_array_0_cam4MacDa_f;
    uint32 cmd = 0;
    uint32 cam2_mac_da_mask = 0;
    uint32 cam2_mac_da_value = 0;
    uint32 cam4_mac_da_value = 0;
    uint32 cam2_mac_da_mask_field_id = IpeBpduProtocolEscapeCam2_array_0_cam2MacDaMask_f;
    uint32 cam2_mac_da_value_field_id = IpeBpduProtocolEscapeCam2_array_0_cam2MacDaValue_f;
    uint32 cam4_mac_da_value_field_id = IpeBpduProtocolEscapeCam4_array_0_cam4MacDa_f;
    IpeBpduProtocolEscapeCam2_m cam2;
    IpeBpduProtocolEscapeCam4_m cam4;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("macda:%x %x %x %x %x %x\n", entry->l2pdu_by_mac.mac[0], entry->l2pdu_by_mac.mac[1], \
                      entry->l2pdu_by_mac.mac[2], entry->l2pdu_by_mac.mac[3], entry->l2pdu_by_mac.mac[4], entry->l2pdu_by_mac.mac[5]);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_LOW24_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    cam2_mac_da_mask_field_id += cam2_index_step * index;
    cam2_mac_da_value_field_id += cam2_index_step * index;
    cam4_mac_da_value_field_id += cam4_index_step * (index - 2);

    if ((entry->l2pdu_by_mac.mac[0] != 0x01) || (entry->l2pdu_by_mac.mac[1] != 0x80)
        || (entry->l2pdu_by_mac.mac[2] != 0xc2))
    {
        return CTC_E_PDU_INVALID_MACDA;
    }

    if (index < 2)
    {
        if ((entry->l2pdu_by_mac.mac_mask[0] != 0xff) || (entry->l2pdu_by_mac.mac_mask[1] != 0xff)
           || (entry->l2pdu_by_mac.mac_mask[2] != 0xff))
        {
            if ((entry->l2pdu_by_mac.mac_mask[0] == 0) && (entry->l2pdu_by_mac.mac_mask[1] == 0)
                && (entry->l2pdu_by_mac.mac_mask[2] == 0) && (entry->l2pdu_by_mac.mac_mask[3] == 0)
                && (entry->l2pdu_by_mac.mac_mask[4] == 0) && (entry->l2pdu_by_mac.mac_mask[5] == 0))
            {
                cam2_mac_da_mask = 0xffffff;
            }
            else
            {
                return CTC_E_PDU_INVALID_MACDA_MASK;
            }
        }

        if (0xffffff != cam2_mac_da_mask)
        {
            cam2_mac_da_mask = entry->l2pdu_by_mac.mac_mask[3] << 16
                             | entry->l2pdu_by_mac.mac_mask[4] << 8 | entry->l2pdu_by_mac.mac_mask[5];
            cam2_mac_da_mask &= 0xffffff;
        }

        cam2_mac_da_value = entry->l2pdu_by_mac.mac[2] << 24 | entry->l2pdu_by_mac.mac[3] << 16
                            | entry->l2pdu_by_mac.mac[4] << 8 | entry->l2pdu_by_mac.mac[5];
        cam2_mac_da_value &= 0xffffff;

        sal_memset(&cam2, 0, sizeof(IpeBpduProtocolEscapeCam2_m));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam2_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam2));

        DRV_SET_FIELD_V(IpeBpduProtocolEscapeCam2_t, cam2_mac_da_value_field_id, &cam2, cam2_mac_da_value);
        DRV_SET_FIELD_V(IpeBpduProtocolEscapeCam2_t, cam2_mac_da_mask_field_id, &cam2, cam2_mac_da_mask);

        cmd = DRV_IOW(IpeBpduProtocolEscapeCam2_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam2));
    }
    else
    {
        cam4_mac_da_value = entry->l2pdu_by_mac.mac[2] << 24 | entry->l2pdu_by_mac.mac[3] << 16
            | entry->l2pdu_by_mac.mac[4] << 8 | entry->l2pdu_by_mac.mac[5];
        cam4_mac_da_value &= 0xffffff;

        sal_memset(&cam4, 0, sizeof(IpeBpduProtocolEscapeCam4_m));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam4_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam4));

        DRV_SET_FIELD_V(IpeBpduProtocolEscapeCam4_t, cam4_mac_da_value_field_id, &cam4, cam4_mac_da_value);

        cmd = DRV_IOW(IpeBpduProtocolEscapeCam4_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam4));
    }

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_classified_key_by_macda_low24(uint8 lchip, uint8 index, ctc_pdu_l2pdu_key_t* p_entry)
{
    int32  step1 = IpeBpduProtocolEscapeCam2_array_1_cam2MacDaValue_f
                   - IpeBpduProtocolEscapeCam2_array_0_cam2MacDaValue_f;
    int32  step2 = IpeBpduProtocolEscapeCam4_array_1_cam4MacDa_f
                   - IpeBpduProtocolEscapeCam4_array_0_cam4MacDa_f;
    uint32 cmd = 0;
    uint32 cam_mac_da_value[2] = {0};
    uint32 cam_mac_da_mask[2] = {0};
    uint32 cam2_mac_da_mask_field_id = IpeBpduProtocolEscapeCam2_array_0_cam2MacDaMask_f;
    uint32 cam2_mac_da_value_field_id = IpeBpduProtocolEscapeCam2_array_0_cam2MacDaValue_f;
    uint32 cam4_mac_da_value_field_id = IpeBpduProtocolEscapeCam4_array_0_cam4MacDa_f;

    IpeBpduProtocolEscapeCam2_m cam2;
    IpeBpduProtocolEscapeCam4_m cam4;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_LOW24_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    cam2_mac_da_mask_field_id += step1 * index;
    cam2_mac_da_value_field_id += step1 * index;
    cam4_mac_da_value_field_id += step2 * (index - 2);

    if (index < 2)
    {
        sal_memset(&cam2, 0, sizeof(IpeBpduProtocolEscapeCam2_m));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam2_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam2));

        cam_mac_da_value[0] = 0xc2 << 24;
        cam_mac_da_value[0] |= DRV_GET_FIELD_V(IpeBpduProtocolEscapeCam2_t, cam2_mac_da_value_field_id, &cam2);
        cam_mac_da_value[1] = 0x0180;
        SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac, cam_mac_da_value);

        cam_mac_da_mask[0] = 0xFF << 24;
        cam_mac_da_mask[0] |= DRV_GET_FIELD_V(IpeBpduProtocolEscapeCam2_t, cam2_mac_da_mask_field_id, &cam2);
        cam_mac_da_value[1] = 0xFFFF;
        SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac_mask, cam_mac_da_mask);
    }
    else
    {
        sal_memset(&cam4, 0, sizeof(IpeBpduProtocolEscapeCam4_m));
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam4_t, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam4));

        cam_mac_da_value[0] = 0xc2 << 24;
        cam_mac_da_value[0] = DRV_GET_FIELD_V(IpeBpduProtocolEscapeCam4_t, cam4_mac_da_value_field_id, &cam4);
        cam_mac_da_value[1] = 0x0180;
        SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac, cam_mac_da_value);

        cam_mac_da_mask[0] = 0xFFFFFFFF;
        cam_mac_da_mask[1] = 0xFFFF;
        SYS_GOLDENGATE_SET_USER_MAC(p_entry->l2pdu_by_mac.mac_mask, cam_mac_da_mask);
    }

    return CTC_E_NONE;
}

/**
 @brief  Classify layer2 pdu based on macda,macda-low24 bit, layer2 header protocol
*/
int32
sys_goldengate_l2pdu_classify_l2pdu(uint8 lchip, ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_l2pdu_key_t* p_key)
{
    CTC_PTR_VALID_CHECK(p_key);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l2pdu type:%d\n", l2pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l2pdu_type)
    {
    case CTC_PDU_L2PDU_TYPE_L2HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_classify_l2pdu_by_l2hdr_proto(lchip, index, p_key));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_classify_l2pdu_by_macda(lchip, index, p_key));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA_LOW24:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_classify_l2pdu_by_macda_low24(lchip, index, p_key));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l2pdu_get_classified_key(uint8 lchip, ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index, ctc_pdu_l2pdu_key_t* p_key)
{
    CTC_PTR_VALID_CHECK(p_key);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l2pdu type:%d\n", l2pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l2pdu_type)
    {
    case CTC_PDU_L2PDU_TYPE_L2HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_classified_key_by_l2hdr_proto(lchip, index, p_key));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_classified_key_by_macda(lchip, index, p_key));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA_LOW24:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_classified_key_by_macda_low24(lchip, index, p_key));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
_sys_goldengate_l2pdu_set_global_action_by_l3type(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_ctl)
{
    int32  step = 0;
    uint32 cmd = 0;
    uint32 protocol_exception = 0;
    uint32 exception_sub_index = 0;
    uint32 exception_sub_index_field_id = 0;
    IpeBridgeCtl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_ctl->action_index);
    SYS_PDU_DBG_PARAM("copy to cpu:%d\n", p_ctl->entry_valid);

    if (index >= MAX_CTC_PARSER_L3_TYPE)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBridgeCtl_array_1_protocolExceptionSubIndex_f - IpeBridgeCtl_array_0_protocolExceptionSubIndex_f;
    exception_sub_index_field_id = IpeBridgeCtl_array_0_protocolExceptionSubIndex_f + (index * step);
    exception_sub_index = p_ctl->action_index;

    sal_memset(&ctl, 0, sizeof(IpeBridgeCtl_m));
    cmd = DRV_IOR(IpeBridgeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    GetIpeBridgeCtl(A, protocolException_f, &ctl, &protocol_exception);
    if (p_ctl->entry_valid)
    {
        protocol_exception |= (1 << index);
    }
    else
    {
        protocol_exception &= (~(1 << index));
    }

    SetIpeBridgeCtl(V, protocolException_f, &ctl, protocol_exception);
    DRV_SET_FIELD_V(IpeBridgeCtl_t, exception_sub_index_field_id, &ctl, exception_sub_index);

    cmd = DRV_IOW(IpeBridgeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_global_action_by_l3type(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_ctl)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 protocol_exception = 0;
    uint32 exception_sub_index = 0;
    uint32 exception_sub_index_field_id = 0;
    IpeBridgeCtl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_CTC_PARSER_L3_TYPE)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBridgeCtl_array_1_protocolExceptionSubIndex_f - IpeBridgeCtl_array_0_protocolExceptionSubIndex_f;
    exception_sub_index_field_id = IpeBridgeCtl_array_0_protocolExceptionSubIndex_f + (index * step);

    sal_memset(&ctl, 0, sizeof(IpeBridgeCtl_m));
    cmd = DRV_IOR(IpeBridgeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    GetIpeBridgeCtl(A, protocolException_f, &ctl, &protocol_exception);
    p_ctl->entry_valid = (protocol_exception & (1 << index)) ? 1 : 0;

    DRV_GET_FIELD_A(IpeBridgeCtl_t, exception_sub_index_field_id, &ctl, &exception_sub_index);
    p_ctl->action_index = exception_sub_index;
    if (p_ctl->action_index)
    {
        p_ctl->entry_valid = 1;
    }

    SYS_PDU_DBG_INFO("action index:%d\n", p_ctl->action_index);
    SYS_PDU_DBG_INFO("copy to cpu:%d\n", p_ctl->entry_valid);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_set_global_action_of_fixed_l2pdu(uint8 lchip, ctc_pdu_l2pdu_type_t type,
                                                       ctc_pdu_global_l2pdu_action_t* p_action)
{
    
    uint32 cmd = 0;
    uint32 enable = p_action->entry_valid ? 1 : 0;
    IpeBpduEscapeCtl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_action->action_index);
    SYS_PDU_DBG_PARAM("copy to cpu:%d\n", p_action->entry_valid);

    sal_memset(&ctl, 0, sizeof(IpeBpduEscapeCtl_m));

    cmd = DRV_IOR(IpeBpduEscapeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    switch (type)
    {
    case CTC_PDU_L2PDU_TYPE_BPDU:
        SetIpeBpduEscapeCtl(V, bpduExceptionEn_f, &ctl, enable);
        SetIpeBpduEscapeCtl(V, bpduExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L2PDU_TYPE_SLOW_PROTO:
        SetIpeBpduEscapeCtl(V, slowProtocolExceptionEn_f, &ctl, enable);
        SetIpeBpduEscapeCtl(V, slowProtocolExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L2PDU_TYPE_EFM_OAM:
        SetIpeBpduEscapeCtl(V, efmSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L2PDU_TYPE_EAPOL:
        SetIpeBpduEscapeCtl(V, eapolExceptionEn_f, &ctl, enable);
        SetIpeBpduEscapeCtl(V, eapolExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L2PDU_TYPE_LLDP:
        SetIpeBpduEscapeCtl(V, lldpExceptionEn_f, &ctl, enable);
        SetIpeBpduEscapeCtl(V, lldpExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L2PDU_TYPE_ISIS:
        SetIpeBpduEscapeCtl(V, l2isisExceptionEn_f, &ctl, enable);
        SetIpeBpduEscapeCtl(V, l2isisExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    default:
        break;
    }

    cmd = DRV_IOW(IpeBpduEscapeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_global_action_of_fixed_l2pdu(uint8 lchip, ctc_pdu_l2pdu_type_t type,
                                                       ctc_pdu_global_l2pdu_action_t* p_action)
{
    uint32 cmd = 0;
    uint32 exception_en = 0;
    uint32 exception_sub_index = 0;
    IpeBpduEscapeCtl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    sal_memset(&ctl, 0, sizeof(IpeBpduEscapeCtl_m));
    cmd = DRV_IOR(IpeBpduEscapeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    switch (type)
    {
    case CTC_PDU_L2PDU_TYPE_BPDU:
        GetIpeBpduEscapeCtl(A, bpduExceptionEn_f, &ctl, &exception_en);
        GetIpeBpduEscapeCtl(A, bpduExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L2PDU_TYPE_SLOW_PROTO:
        GetIpeBpduEscapeCtl(A, slowProtocolExceptionEn_f, &ctl, &exception_en);
        GetIpeBpduEscapeCtl(A, slowProtocolExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L2PDU_TYPE_EFM_OAM:
        exception_en = 1;
        GetIpeBpduEscapeCtl(A, efmSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L2PDU_TYPE_EAPOL:
        GetIpeBpduEscapeCtl(A, eapolExceptionEn_f, &ctl, &exception_en);
        GetIpeBpduEscapeCtl(A, eapolExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L2PDU_TYPE_LLDP:
        GetIpeBpduEscapeCtl(A, lldpExceptionEn_f, &ctl, &exception_en);
        GetIpeBpduEscapeCtl(A, lldpExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L2PDU_TYPE_ISIS:
        GetIpeBpduEscapeCtl(A, l2isisExceptionEn_f, &ctl, &exception_en);
        GetIpeBpduEscapeCtl(A, l2isisExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    default:
        break;
    }

    p_action->entry_valid = exception_en;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("action index:%d\n", p_action->action_index);
    SYS_PDU_DBG_INFO("copy to cpu:%d\n", p_action->entry_valid);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_set_global_action_by_l2hdr_proto(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 field = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("entry valid:%d\n", p_action->entry_valid);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_action->action_index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_L2HDR_PTL_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBpduProtocolEscapeCamResult3_array_1_cam3ExceptionSubIndex_f
           - IpeBpduProtocolEscapeCamResult3_array_0_cam3ExceptionSubIndex_f;
    field = p_action->action_index;
    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult3_t, IpeBpduProtocolEscapeCamResult3_array_0_cam3ExceptionSubIndex_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));

    step = IpeBpduProtocolEscapeCam3_array_1_cam3EntryValid_f
           - IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f;
    field = p_action->entry_valid;
    cmd = DRV_IOW(IpeBpduProtocolEscapeCam3_t, IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_global_action_by_l2hdr_proto(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_action)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 field = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_L2HDR_PTL_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBpduProtocolEscapeCamResult3_array_1_cam3ExceptionSubIndex_f
           - IpeBpduProtocolEscapeCamResult3_array_0_cam3ExceptionSubIndex_f;

    cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult3_t,
                  IpeBpduProtocolEscapeCamResult3_array_0_cam3ExceptionSubIndex_f + (index * step) );
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));
    p_action->action_index = field;

    step = IpeBpduProtocolEscapeCam3_array_1_cam3EntryValid_f - IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f;

    cmd = DRV_IOR(IpeBpduProtocolEscapeCam3_t, IpeBpduProtocolEscapeCam3_array_0_cam3EntryValid_f + (index * step));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field));

    p_action->entry_valid = field;

    SYS_PDU_DBG_INFO("entry valid:%d\n", p_action->entry_valid);
    SYS_PDU_DBG_INFO("action index:%d\n", p_action->action_index);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_set_global_action_by_macda(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_ctl)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("entry valid:%d\n", p_ctl->entry_valid);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_ctl->action_index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    entry_valid = p_ctl->entry_valid ? 1 : 0;
    exception_sub_index = p_ctl->action_index;

    step = IpeBpduProtocolEscapeCam_array_1_cam1EntryValid_f - IpeBpduProtocolEscapeCam_array_0_cam1EntryValid_f;
    cmd = DRV_IOW(IpeBpduProtocolEscapeCam_t, IpeBpduProtocolEscapeCam_array_0_cam1EntryValid_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

    step = IpeBpduProtocolEscapeCamResult_array_1_cam1ExceptionSubIndex_f - IpeBpduProtocolEscapeCamResult_array_0_cam1ExceptionSubIndex_f;
    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult_t, IpeBpduProtocolEscapeCamResult_array_0_cam1ExceptionSubIndex_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_global_action_by_macda(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_action)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeBpduProtocolEscapeCam_array_1_cam1EntryValid_f - IpeBpduProtocolEscapeCam_array_0_cam1EntryValid_f;
    cmd = DRV_IOR(IpeBpduProtocolEscapeCam_t, IpeBpduProtocolEscapeCam_array_0_cam1EntryValid_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

    step = IpeBpduProtocolEscapeCamResult_array_1_cam1ExceptionSubIndex_f - IpeBpduProtocolEscapeCamResult_array_0_cam1ExceptionSubIndex_f;
    cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult_t, IpeBpduProtocolEscapeCamResult_array_0_cam1ExceptionSubIndex_f + (step * index));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("entry valid:%d\n", p_action->entry_valid);
    SYS_PDU_DBG_INFO("action index:%d\n", p_action->action_index);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_set_global_action_by_macda_low24(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("entry valid:%d\n", p_action->entry_valid);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_action->action_index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_LOW24_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    entry_valid = p_action->entry_valid ? 1 : 0;
    exception_sub_index = p_action->action_index;

    if (index < 2)
    {
        step = IpeBpduProtocolEscapeCam2_array_1_cam2EntryValid_f
               - IpeBpduProtocolEscapeCam2_array_0_cam2EntryValid_f;
        cmd = DRV_IOW(IpeBpduProtocolEscapeCam2_t, IpeBpduProtocolEscapeCam2_array_0_cam2EntryValid_f + (step * index));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

        step = IpeBpduProtocolEscapeCamResult2_array_1_cam2ExceptionSubIndex_f
               - IpeBpduProtocolEscapeCamResult2_array_0_cam2ExceptionSubIndex_f;
        cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult2_t, IpeBpduProtocolEscapeCamResult2_array_0_cam2ExceptionSubIndex_f + (step * index));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));
    }
    else
    {
        step = IpeBpduProtocolEscapeCam4_array_1_cam4EntryValid_f - IpeBpduProtocolEscapeCam4_array_0_cam4EntryValid_f;
        cmd = DRV_IOW(IpeBpduProtocolEscapeCam4_t,
                      IpeBpduProtocolEscapeCam4_array_0_cam4EntryValid_f + (step * (index - 2)));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

        step = IpeBpduProtocolEscapeCamResult4_array_1_cam4ExceptionSubIndex_f
               - IpeBpduProtocolEscapeCamResult4_array_0_cam4ExceptionSubIndex_f;
        cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult4_t,
                      IpeBpduProtocolEscapeCamResult4_array_0_cam4ExceptionSubIndex_f + (step * (index - 2)));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));
    }

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_get_global_action_by_macda_low24(uint8 lchip, uint8 index, ctc_pdu_global_l2pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L2PDU_BASED_MACDA_LOW24_ENTRY)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    if (index < 2)
    {
        step = IpeBpduProtocolEscapeCam2_array_1_cam2EntryValid_f - IpeBpduProtocolEscapeCam2_array_0_cam2EntryValid_f;
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam2_t, IpeBpduProtocolEscapeCam2_array_0_cam2EntryValid_f + (step * index));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

        step = IpeBpduProtocolEscapeCamResult2_array_1_cam2ExceptionSubIndex_f
               - IpeBpduProtocolEscapeCamResult2_array_0_cam2ExceptionSubIndex_f;
        cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult2_t, IpeBpduProtocolEscapeCamResult2_array_0_cam2ExceptionSubIndex_f + (step * index));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));
    }
    else
    {
        step = IpeBpduProtocolEscapeCam4_array_1_cam4EntryValid_f - IpeBpduProtocolEscapeCam4_array_0_cam4EntryValid_f;
        cmd = DRV_IOR(IpeBpduProtocolEscapeCam4_t,
                      IpeBpduProtocolEscapeCam4_array_0_cam4EntryValid_f + (step * (index - 2)));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &entry_valid));

        step = IpeBpduProtocolEscapeCamResult4_array_1_cam4ExceptionSubIndex_f
               - IpeBpduProtocolEscapeCamResult4_array_0_cam4ExceptionSubIndex_f;
        cmd = DRV_IOR(IpeBpduProtocolEscapeCamResult4_t,
                      IpeBpduProtocolEscapeCamResult4_array_0_cam4ExceptionSubIndex_f + (step * (index - 2)));
        CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &exception_sub_index));
    }

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("entry valid:%d\n", p_action->entry_valid);
    SYS_PDU_DBG_INFO("action index:%d\n", p_action->action_index);

    return CTC_E_NONE;
}

/**
 @brief  Set layer2 pdu global property
*/
int32
sys_goldengate_l2pdu_set_global_action(uint8 lchip, ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index,
                                       ctc_pdu_global_l2pdu_action_t* p_action)
{
    CTC_PTR_VALID_CHECK(p_action);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l2pdu type:%d\n", l2pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    /*layer3 type pdu can not per port control, action index: 32-53*/
    if (CTC_PDU_L2PDU_TYPE_L3TYPE == l2pdu_type)
    {
        return CTC_E_FEATURE_NOT_SUPPORT;
    }
    else
    {
        if (p_action->action_index > MAX_SYS_L2PDU_PER_PORT_ACTION_INDEX)
        {
            return CTC_E_PDU_INVALID_ACTION_INDEX;
        }

        switch (l2pdu_type)
        {
        case CTC_PDU_L2PDU_TYPE_BPDU:
        case CTC_PDU_L2PDU_TYPE_SLOW_PROTO:
        case CTC_PDU_L2PDU_TYPE_EFM_OAM:
        case CTC_PDU_L2PDU_TYPE_EAPOL:
        case CTC_PDU_L2PDU_TYPE_LLDP:
        case CTC_PDU_L2PDU_TYPE_ISIS:
            CTC_ERROR_RETURN(_sys_goldengate_l2pdu_set_global_action_of_fixed_l2pdu(lchip, l2pdu_type, p_action));
            break;

        case CTC_PDU_L2PDU_TYPE_L2HDR_PROTO:
            CTC_ERROR_RETURN(_sys_goldengate_l2pdu_set_global_action_by_l2hdr_proto(lchip, index, p_action));
            break;

        case CTC_PDU_L2PDU_TYPE_MACDA:
            CTC_ERROR_RETURN(_sys_goldengate_l2pdu_set_global_action_by_macda(lchip, index, p_action));
            break;

        case CTC_PDU_L2PDU_TYPE_MACDA_LOW24:
            CTC_ERROR_RETURN(_sys_goldengate_l2pdu_set_global_action_by_macda_low24(lchip, index, p_action));
            break;

        default:
            break;
        }
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l2pdu_get_global_action(uint8 lchip, ctc_pdu_l2pdu_type_t l2pdu_type, uint8 index,
                                      ctc_pdu_global_l2pdu_action_t* p_action)
{
    CTC_PTR_VALID_CHECK(p_action);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l2pdu type:%d\n", l2pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l2pdu_type)
    {
    case CTC_PDU_L2PDU_TYPE_L2HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_global_action_by_l2hdr_proto(lchip, index, p_action));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_global_action_by_macda(lchip, index, p_action));
        break;

    case CTC_PDU_L2PDU_TYPE_MACDA_LOW24:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_global_action_by_macda_low24(lchip, index, p_action));
        break;

    case CTC_PDU_L2PDU_TYPE_L3TYPE:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_global_action_by_l3type(lchip, index, p_action));
        break;

    case CTC_PDU_L2PDU_TYPE_BPDU:
    case CTC_PDU_L2PDU_TYPE_SLOW_PROTO:
    case CTC_PDU_L2PDU_TYPE_EFM_OAM:
    case CTC_PDU_L2PDU_TYPE_EAPOL:
    case CTC_PDU_L2PDU_TYPE_LLDP:
    case CTC_PDU_L2PDU_TYPE_ISIS:
        CTC_ERROR_RETURN(_sys_goldengate_l2pdu_get_global_action_of_fixed_l2pdu(lchip, l2pdu_type, p_action));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief  Per port control layer2 pdu action
*/
int32
sys_goldengate_l2pdu_set_port_action(uint8 lchip, uint16 gport, uint8 action_index, ctc_pdu_port_l2pdu_action_t action)
{
    uint32 excp2_en = 0;
    uint32 excp2_discard = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("gport:0x%04X\n", gport);
    SYS_PDU_DBG_PARAM("action index:%d\n", action_index);
    SYS_PDU_DBG_PARAM("action:%d\n", action);

    if (action_index > MAX_SYS_L2PDU_PER_PORT_ACTION_INDEX)
    {
        return CTC_E_PDU_INVALID_ACTION_INDEX;
    }

    switch (action)
    {
    case CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU:
        /*excption2En set, exception2Discard set*/
        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
        CTC_SET_FLAG(excp2_en, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, excp2_en));

        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));
        CTC_SET_FLAG(excp2_discard, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, excp2_discard));
        break;

    case CTC_PDU_L2PDU_ACTION_TYPE_COPY_TO_CPU:
        /*excption2En set , exception2Discard clear*/
        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
        CTC_SET_FLAG(excp2_en, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, excp2_en));

        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));
        CTC_UNSET_FLAG(excp2_discard, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, excp2_discard));
        break;

    case CTC_PDU_L2PDU_ACTION_TYPE_FWD:
        /*excption2En clear , exception2Discard clear*/
        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
        CTC_UNSET_FLAG(excp2_en, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, excp2_en));

        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));
        CTC_UNSET_FLAG(excp2_discard, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, excp2_discard));
        break;

    case CTC_PDU_L2PDU_ACTION_TYPE_DISCARD:
        /*excption2En clear , exception2Discard set*/
        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
        CTC_UNSET_FLAG(excp2_en, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, excp2_en));

        CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));
        CTC_SET_FLAG(excp2_discard, (1 << action_index));
        CTC_ERROR_RETURN(sys_goldengate_port_set_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, excp2_discard));
        break;

    default:
        return CTC_E_INVALID_PARAM;
        break;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l2pdu_get_port_action(uint8 lchip, uint16 gport, uint8 action_index, ctc_pdu_port_l2pdu_action_t* p_action)
{
    uint32 excp2_en = 0;
    uint32 excp2_discard = 0;
    uint8  excp2_en_flag = 0;
    uint8  excp2_discard_flag = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("gport:0x%04X\n", gport);
    SYS_PDU_DBG_PARAM("action index:%d\n", action_index);

    if (action_index > MAX_SYS_L2PDU_PER_PORT_ACTION_INDEX)
    {
        return CTC_E_PDU_INVALID_ACTION_INDEX;
    }

    /*excption2En set, exception2Discard set*/
    CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
    if (CTC_FLAG_ISSET(excp2_en, (1 << action_index)))
    {
        excp2_en_flag = 1;
    }

    CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));
    if (CTC_FLAG_ISSET(excp2_discard, (1 << action_index)))
    {
        excp2_discard_flag = 1;
    }

    if (excp2_en_flag && excp2_discard_flag)
    {
        *p_action = CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU;
    }
    else if (excp2_en_flag)
    {
        *p_action = CTC_PDU_L2PDU_ACTION_TYPE_COPY_TO_CPU;
    }
    else if (excp2_discard_flag)
    {
        *p_action = CTC_PDU_L2PDU_ACTION_TYPE_DISCARD;
    }
    else
    {
        *p_action = CTC_PDU_L2PDU_ACTION_TYPE_FWD;
    }

    SYS_PDU_DBG_INFO("action:%d\n", *p_action);

    return CTC_E_NONE;
}

int32
sys_goldengate_l2pdu_show_port_action(uint8 lchip, uint16 gport)
{
    uint8 action_index = 0;
    uint32 excp2_en = 0;
    uint32 excp2_discard = 0;
    uint8 excp2_en_flag = 0;
    uint8 excp2_discard_flag = 0;

    LCHIP_CHECK(lchip);
    /*excption2En set, exception2Discard set*/
    CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_EN, &excp2_en));
    CTC_ERROR_RETURN(sys_goldengate_port_get_internal_property(lchip, gport, SYS_PORT_PROP_EXCEPTION_DISCARD, &excp2_discard));

    SYS_PDU_DBG_DUMP("\n--------------------------------------------------------------------------------------------------------------\n");
    SYS_PDU_DBG_DUMP("  Action Index               Action(Forward, Copy-to-cpu, Redirect-to-cpu or Discard)\n");
    SYS_PDU_DBG_DUMP("--------------------------------------------------------------------------------------------------------------\n");

    for (action_index = 0; action_index < 32; action_index++)
    {
        excp2_en_flag = CTC_FLAG_ISSET(excp2_en, (1 << action_index));
        excp2_discard_flag = CTC_FLAG_ISSET(excp2_discard, (1 << action_index));
        if (excp2_en_flag && excp2_discard_flag)
        {
            SYS_PDU_DBG_DUMP("  %-27d%s\n", action_index, "Redirect-to-cpu");
        }
        else if (excp2_en_flag)
        {
            SYS_PDU_DBG_DUMP("  %-27d%s\n", action_index, "Copy-to-cpu");
        }
        else if (excp2_discard_flag)
        {
            SYS_PDU_DBG_DUMP("  %-27d%s\n", action_index, "Discard");
        }
        else
        {
            SYS_PDU_DBG_DUMP("  %-27d%s\n", action_index, "Forward");
        }
    }

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_classify_l3pdu_by_l3hdr_proto(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 l3_header_protocol = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("l3 header protocol:%d\n", p_entry->l3hdr_proto);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_L3HDR_PROTO)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    l3_header_protocol = p_entry->l3hdr_proto;

    step = IpeException3Cam_array_1_l3HeaderProtocol_f - IpeException3Cam_array_0_l3HeaderProtocol_f;
    cmd = DRV_IOW(IpeException3Cam_t, IpeException3Cam_array_0_l3HeaderProtocol_f + (index * step));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &l3_header_protocol));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_classified_key_by_l3hdr_proto(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 l3_header_protocol = 0;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_L3HDR_PROTO)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeException3Cam_array_1_l3HeaderProtocol_f - IpeException3Cam_array_0_l3HeaderProtocol_f;
    cmd = DRV_IOR(IpeException3Cam_t, IpeException3Cam_array_0_l3HeaderProtocol_f + (index * step));
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &l3_header_protocol));

    p_entry->l3hdr_proto = l3_header_protocol;

    SYS_PDU_DBG_INFO("l3 header protocol:%d\n", p_entry->l3hdr_proto);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_classify_l3pdu_by_layer4_port(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 dest_port = 0;
    uint32 is_tcp_mask = 0;
    uint32 is_tcp_value = 0;
    uint32 is_udp_mask = 0;
    uint32 is_udp_value = 0;
    IpeException3Cam2_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);
    SYS_PDU_DBG_PARAM("dest port:%d  is tcp value:%d is udp value:%d\n",
                       dest_port, p_entry->l3pdu_by_port.is_tcp, p_entry->l3pdu_by_port.is_udp);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_PORT)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    if (p_entry->l3pdu_by_port.is_tcp && p_entry->l3pdu_by_port.is_udp)
    {
        return CTC_E_INVALID_PARAM;
    }

    dest_port = p_entry->l3pdu_by_port.dest_port;
    is_tcp_value = p_entry->l3pdu_by_port.is_tcp ? 1 : 0;
    is_udp_value = p_entry->l3pdu_by_port.is_udp ? 1 : 0;

    if (is_tcp_value || is_udp_value)
    {
        is_tcp_mask = p_entry->l3pdu_by_port.is_tcp ? 1 : 0;
        is_udp_mask = p_entry->l3pdu_by_port.is_udp ? 1 : 0;
    }
    else
    {
        is_tcp_mask = 1;
        is_udp_mask = 1;
    }

    step = IpeException3Cam2_array_1_cam2EntryValid_f - IpeException3Cam2_array_0_cam2EntryValid_f;

    sal_memset(&cam, 0, sizeof(IpeException3Cam2_m));
    cmd = DRV_IOR(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_destPort_f + (index * step), &cam, dest_port);
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isTcpMask_f + (index * step), &cam, is_tcp_mask);
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isTcpValue_f + (index * step), &cam, is_tcp_value);
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isUdpMask_f + (index * step), &cam, is_udp_mask);
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isUdpValue_f + (index * step), &cam, is_udp_value);

    cmd = DRV_IOW(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_classified_key_by_layer4_port(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 dest_port = 0;
    IpeException3Cam2_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_PORT)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeException3Cam2_array_1_cam2EntryValid_f - IpeException3Cam2_array_0_cam2EntryValid_f;

    sal_memset(&cam, 0, sizeof(IpeException3Cam2_m));
    cmd = DRV_IOR(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    p_entry->l3pdu_by_port.dest_port = DRV_GET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_destPort_f + (index * step), &cam);
    p_entry->l3pdu_by_port.is_tcp = DRV_GET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isTcpValue_f + (index * step), &cam);
    p_entry->l3pdu_by_port.is_udp = DRV_GET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_isUdpValue_f + (index * step), &cam);

    SYS_PDU_DBG_INFO("dest port:%d  is tcp value:%d is udp value:%d\n",
                     dest_port, p_entry->l3pdu_by_port.is_tcp, p_entry->l3pdu_by_port.is_udp);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_classify_l3pdu_by_layer3_ipda(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 is_ipv4_value = 0;
    uint32 is_ipv6_value = 0;
    IpeException3Cam3_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    SYS_PDU_DBG_INFO("is ipv4 value:%d, is ipv6 value:%d, ipda value:0x%X.\n",
                     p_entry->l3pdu_by_ipda.is_ipv4, p_entry->l3pdu_by_ipda.is_ipv6, p_entry->l3pdu_by_ipda.ipda);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_IPDA)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    if (p_entry->l3pdu_by_port.is_tcp && p_entry->l3pdu_by_port.is_udp)
    {
        return CTC_E_INVALID_PARAM;
    }

    if (p_entry->l3pdu_by_ipda.ipda > 0xFFF)
    {
        return CTC_E_PDU_INVALID_IPDA;
    }

    is_ipv4_value = p_entry->l3pdu_by_ipda.is_ipv4 ? 1 : 0;
    is_ipv6_value = p_entry->l3pdu_by_ipda.is_ipv6 ? 1 : 0;

    sal_memset(&cam, 0, sizeof(IpeException3Cam3_m));
    cmd = DRV_IOR(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    step = IpeException3Cam3_array_1_cam3EntryValid_f - IpeException3Cam3_array_0_cam3EntryValid_f;

    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV4Mask_f + (index * step), &cam, 1);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV4_f + (index * step), &cam, is_ipv4_value);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV6Mask_f + (index * step), &cam, 1);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV6_f + (index * step), &cam, is_ipv6_value);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrHigh_f + (index * step), &cam, (p_entry->l3pdu_by_ipda.ipda >> 8) & 0xF);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrHighMask_f + (index * step), &cam, 1);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrLow_f + (index * step), &cam, p_entry->l3pdu_by_ipda.ipda & 0xFF);
    DRV_SET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrLowMask_f + (index * step), &cam, 1);

    cmd = DRV_IOW(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_l3pdu_by_layer3_ipda(uint8 lchip, uint8 index, ctc_pdu_l3pdu_key_t* p_entry)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    IpeException3Cam3_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    SYS_PDU_DBG_INFO("is ipv4 value:%d, is ipv6 value:%d, ipda value:0x%X.\n",
                     p_entry->l3pdu_by_ipda.is_ipv4, p_entry->l3pdu_by_ipda.is_ipv6, p_entry->l3pdu_by_ipda.ipda);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_IPDA)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    sal_memset(&cam, 0, sizeof(IpeException3Cam3_m));
    cmd = DRV_IOR(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    step = IpeException3Cam3_array_1_cam3EntryValid_f - IpeException3Cam3_array_0_cam3EntryValid_f;
    p_entry->l3pdu_by_ipda.is_ipv4 = DRV_GET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV4_f + (index * step), &cam);
    p_entry->l3pdu_by_ipda.is_ipv6 = DRV_GET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_isV6_f + (index * step), &cam);
    p_entry->l3pdu_by_ipda.ipda = DRV_GET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrHigh_f + (index * step), &cam) << 8;
    p_entry->l3pdu_by_ipda.ipda |= DRV_GET_FIELD_V(IpeException3Cam3_t, IpeException3Cam3_array_0_addrLow_f + (index * step), &cam);

    cmd = DRV_IOW(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

/**
 @brief  Classify layer3 pdu based on layer3 header protocol, layer4 dest port
*/
int32
sys_goldengate_l3pdu_classify_l3pdu(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index,
                                    ctc_pdu_l3pdu_key_t* p_key)
{
    CTC_PTR_VALID_CHECK(p_key);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l3pdu type:%d\n", l3pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_L3HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_classify_l3pdu_by_l3hdr_proto(lchip, index, p_key));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER3_IPDA:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_classify_l3pdu_by_layer3_ipda(lchip, index, p_key));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_PORT:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_classify_l3pdu_by_layer4_port(lchip, index, p_key));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l3pdu_get_classified_key(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_l3pdu_key_t* p_key)
{
    CTC_PTR_VALID_CHECK(p_key);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l3pdu type:%d\n", l3pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_L3HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_classified_key_by_l3hdr_proto(lchip, index, p_key));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER3_IPDA:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_l3pdu_by_layer3_ipda(lchip, index, p_key));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_PORT:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_classified_key_by_layer4_port(lchip, index, p_key));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_set_global_action_of_fixed_l3pdu(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type,
                                                       ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    
    IpeException3Ctl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("action index:%d\n", p_action->action_index);
    SYS_PDU_DBG_PARAM("entry valid:%d\n", p_action->entry_valid);

    sal_memset(&ctl, 0, sizeof(IpeException3Ctl_m));

    cmd = DRV_IOR(IpeException3Ctl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_OSPF:
        SetIpeException3Ctl(V, ospfv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ospfv4ExceptionSubIndex_f,
                            &ctl, p_action->action_index);

        SetIpeException3Ctl(V, ospfv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ospfv6ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_PIM:
        SetIpeException3Ctl(V, pimv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, pimv4ExceptionSubIndex_f,
                            &ctl, p_action->action_index);

        SetIpeException3Ctl(V, pimv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, pimv6ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_VRRP:
        SetIpeException3Ctl(V, vrrpv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, vrrpv4ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        SetIpeException3Ctl(V, vrrpv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, vrrpv6ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RSVP:
        SetIpeException3Ctl(V, rsvpExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, rsvpExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RIP:
        SetIpeException3Ctl(V, ripExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ripExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_BGP:
        SetIpeException3Ctl(V, bgpv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, bgpv4ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        SetIpeException3Ctl(V, bgpv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, bgpv6ExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_MSDP:
        SetIpeException3Ctl(V, msdpExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, msdpExceptionSubIndex_f,
                            &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_LDP:
        SetIpeException3Ctl(V, ldpExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ldpExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4OSPF:
        SetIpeException3Ctl(V, ospfv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ospfv4ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6OSPF:
        SetIpeException3Ctl(V, ospfv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ospfv6ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4PIM:
        SetIpeException3Ctl(V, pimv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, pimv4ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6PIM:
        SetIpeException3Ctl(V, pimv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, pimv6ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4VRRP:
        SetIpeException3Ctl(V, vrrpv4ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, vrrpv4ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6VRRP:
        SetIpeException3Ctl(V, vrrpv6ExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, vrrpv6ExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RS:
        SetIpeException3Ctl(V, icmpv6RsExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, icmpv6RsExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RA:
        SetIpeException3Ctl(V, icmpv6RaExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, icmpv6RaExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NS:
        SetIpeException3Ctl(V, icmpv6NsExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, icmpv6NsExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NA:
        SetIpeException3Ctl(V, icmpv6NaExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, icmpv6NaExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_REDIRECT:
        SetIpeException3Ctl(V, icmpv6RedirectExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, icmpv6RedirectExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RIPNG:
        SetIpeException3Ctl(V, ripngExceptionEn_f, &ctl, p_action->entry_valid);
        SetIpeException3Ctl(V, ripngExceptionSubIndex_f, &ctl, p_action->action_index);
        break;

    default:
        break;
    }

    cmd = DRV_IOW(IpeException3Ctl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_global_action_of_fixed_l3pdu(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type,
                                                      ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;
    IpeException3Ctl_m ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    sal_memset(&ctl, 0, sizeof(IpeException3Ctl_m));
    cmd = DRV_IOR(IpeException3Ctl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_OSPF:
        GetIpeException3Ctl(A, ospfv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ospfv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        if (!entry_valid)
        {
            break;
        }
        GetIpeException3Ctl(A, ospfv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ospfv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_PIM:
        GetIpeException3Ctl(A, pimv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, pimv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        if (!entry_valid)
        {
            break;
        }
        GetIpeException3Ctl(A, pimv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, pimv6ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_VRRP:
        GetIpeException3Ctl(A, vrrpv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, vrrpv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        if (!entry_valid)
        {
            break;
        }
        GetIpeException3Ctl(A, vrrpv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, vrrpv6ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RSVP:
        GetIpeException3Ctl(A, rsvpExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, rsvpExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RIP:
        GetIpeException3Ctl(A, ripExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ripExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_BGP:
        GetIpeException3Ctl(A, bgpv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, bgpv4ExceptionSubIndex_f,
                            &ctl, &exception_sub_index);
        GetIpeException3Ctl(A, bgpv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, bgpv6ExceptionSubIndex_f,
                            &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_MSDP:
        GetIpeException3Ctl(A, msdpExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, msdpExceptionSubIndex_f,
                            &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_LDP:
        GetIpeException3Ctl(A, ldpExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ldpExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4OSPF:
        GetIpeException3Ctl(A, ospfv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ospfv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6OSPF:
        GetIpeException3Ctl(A, ospfv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ospfv6ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4PIM:
        GetIpeException3Ctl(A, pimv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, pimv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6PIM:
        GetIpeException3Ctl(A, pimv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, pimv6ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV4VRRP:
        GetIpeException3Ctl(A, vrrpv4ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, vrrpv4ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_IPV6VRRP:
        GetIpeException3Ctl(A, vrrpv6ExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, vrrpv6ExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RS:
        GetIpeException3Ctl(A, icmpv6RsExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, icmpv6RsExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RA:
        GetIpeException3Ctl(A, icmpv6RaExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, icmpv6RaExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NS:
        GetIpeException3Ctl(A, icmpv6NsExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, icmpv6NsExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NA:
        GetIpeException3Ctl(A, icmpv6NaExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, icmpv6NaExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_REDIRECT:
        GetIpeException3Ctl(A, icmpv6RedirectExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, icmpv6RedirectExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    case CTC_PDU_L3PDU_TYPE_RIPNG:
        GetIpeException3Ctl(A, ripngExceptionEn_f, &ctl, &entry_valid);
        GetIpeException3Ctl(A, ripngExceptionSubIndex_f, &ctl, &exception_sub_index);
        break;

    default:
        break;
    }

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("action index:%d\n", p_action->action_index);
    SYS_PDU_DBG_INFO("entry valid:%d\n", p_action->entry_valid);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_set_global_action_by_l3hdr_proto(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;
    IpeException3Cam_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d entry valid:%d  action index:%d\n", index, p_action->entry_valid, p_action->action_index);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_L3HDR_PROTO)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    entry_valid = p_action->entry_valid ? 1 : 0;
    exception_sub_index = p_action->action_index;

    sal_memset(&cam, 0, sizeof(IpeException3Cam_m));
    cmd = DRV_IOR(IpeException3Cam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    step = IpeException3Cam_array_1_camEntryValid_f - IpeException3Cam_array_0_camEntryValid_f;
    DRV_SET_FIELD_V(IpeException3Cam_t, IpeException3Cam_array_0_camEntryValid_f + (index * step), &cam, entry_valid);
    DRV_SET_FIELD_V(IpeException3Cam_t, IpeException3Cam_array_0_camExceptionSubIndex_f + (index * step), &cam, exception_sub_index);

    cmd = DRV_IOW(IpeException3Cam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_global_action_by_l3hdr_proto(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    int32  step = 0;
    
    uint32 cmd = 0;
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;
    IpeException3Cam_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_L3HDR_PROTO)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    step = IpeException3Cam_array_1_camEntryValid_f - IpeException3Cam_array_0_camEntryValid_f;
    sal_memset(&cam, 0, sizeof(IpeException3Cam_m));
    cmd = DRV_IOR(IpeException3Cam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    DRV_GET_FIELD_A(IpeException3Cam_t, IpeException3Cam_array_0_camEntryValid_f + (index * step), &cam, &entry_valid);
    DRV_GET_FIELD_A(IpeException3Cam_t, IpeException3Cam_array_0_camExceptionSubIndex_f + (index * step), &cam, &exception_sub_index);

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("index:%d entry valid:%d  action index:%d\n", index, p_action->entry_valid, p_action->action_index);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_set_global_action_by_layer4_port(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    IpeException3Cam2_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d entry valid:%d  action index:%d\n", index, p_action->entry_valid, p_action->action_index);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_PORT)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    sal_memset(&cam, 0, sizeof(IpeException3Cam2_m));
    cmd = DRV_IOR(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    step = IpeException3Cam2_array_1_cam2EntryValid_f - IpeException3Cam2_array_0_cam2EntryValid_f;
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_cam2EntryValid_f + (index * step), &cam, (p_action->entry_valid ? 1 : 0));
    DRV_SET_FIELD_V(IpeException3Cam2_t, IpeException3Cam2_array_0_cam2ExceptionSubIndex_f + (index * step), &cam, p_action->action_index);

    cmd = DRV_IOW(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_global_action_by_layer4_port(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    int32  step = 0;
    uint32 cmd = 0;
    
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;
    IpeException3Cam2_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_PORT)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    sal_memset(&cam, 0, sizeof(IpeException3Cam2_m));
    cmd = DRV_IOR(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    step = IpeException3Cam2_array_1_cam2EntryValid_f - IpeException3Cam2_array_0_cam2EntryValid_f;
    DRV_GET_FIELD_A(IpeException3Cam2_t, IpeException3Cam2_array_0_cam2EntryValid_f + (index * step), &cam, &entry_valid);
    DRV_GET_FIELD_A(IpeException3Cam2_t, IpeException3Cam2_array_0_cam2ExceptionSubIndex_f + (index * step), &cam, &exception_sub_index);

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("index:%d entry valid:%d  action index:%d\n",
                     index, p_action->entry_valid, p_action->action_index);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_set_global_action_by_layer3_ipda(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    
    int32  step = IpeException3Cam3_array_1_cam3EntryValid_f - IpeException3Cam3_array_0_cam3EntryValid_f;
    uint32 entry_valid_field_id = IpeException3Cam3_array_0_cam3EntryValid_f;
    uint32 exception_sub_index_field_id = IpeException3Cam3_array_0_cam3ExceptionSubIndex_f;
    IpeException3Cam3_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("index:%d entry valid:%d  action index:%d\n", index, p_action->entry_valid, p_action->action_index);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_IPDA)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    entry_valid_field_id += step * index;
    exception_sub_index_field_id += step * index;

    sal_memset(&cam, 0, sizeof(IpeException3Cam3_m));
    cmd = DRV_IOR(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    DRV_SET_FIELD_V(IpeException3Cam3_t, entry_valid_field_id, &cam, (p_action->entry_valid ? 1 : 0));
    DRV_SET_FIELD_V(IpeException3Cam3_t, exception_sub_index_field_id, &cam, p_action->action_index);

    cmd = DRV_IOW(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_global_action_by_layer3_ipda(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    
    int32  step = IpeException3Cam3_array_1_cam3EntryValid_f - IpeException3Cam3_array_0_cam3EntryValid_f;
    uint32 entry_valid = 0;
    uint32 exception_sub_index = 0;
    uint32 entry_valid_field_id = IpeException3Cam3_array_0_cam3EntryValid_f;
    uint32 exception_sub_index_field_id = IpeException3Cam3_array_0_cam3ExceptionSubIndex_f;
    IpeException3Cam3_m cam;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    if (index >= MAX_SYS_PDU_L3PDU_BASED_IPDA)
    {
        return CTC_E_PDU_INVALID_INDEX;
    }

    entry_valid_field_id += step * index;
    exception_sub_index_field_id += step * index;

    sal_memset(&cam, 0, sizeof(IpeException3Cam3_m));
    cmd = DRV_IOR(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam));

    DRV_GET_FIELD_A(IpeException3Cam3_t, entry_valid_field_id, &cam, &entry_valid);
    DRV_GET_FIELD_A(IpeException3Cam3_t, exception_sub_index_field_id, &cam, &exception_sub_index);

    p_action->entry_valid = entry_valid;
    p_action->action_index = exception_sub_index;

    SYS_PDU_DBG_INFO("index:%d entry valid:%d  action index:%d\n",
                     index, p_action->entry_valid, p_action->action_index);

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_set_global_action_by_layer4_type(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    return CTC_E_NOT_SUPPORT;
}

static int32
_sys_goldengate_l3pdu_get_global_action_by_layer4_type(uint8 lchip, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    return CTC_E_NOT_SUPPORT;
}

static int32
_sys_goldengate_l3pdu_set_global_action_misc(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    IpeIntfMapperCtl_m ipe_intf_mapper_ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);

    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(IpeIntfMapperCtl_m));
    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_intf_mapper_ctl));

    if (CTC_PDU_L3PDU_TYPE_ARP == l3pdu_type)
    {
        SetIpeIntfMapperCtl(V, arpCheckExceptionEn_f, &ipe_intf_mapper_ctl, p_action->entry_valid);
        SetIpeIntfMapperCtl(V, arpExceptionSubIndex_f, &ipe_intf_mapper_ctl, p_action->action_index);
    }
    else if (CTC_PDU_L3PDU_TYPE_DHCP == l3pdu_type)
    {
        SetIpeIntfMapperCtl(V, dhcpUnicastExceptionDisable_f, &ipe_intf_mapper_ctl, p_action->entry_valid ? 0 : 1);
        SetIpeIntfMapperCtl(V, dhcpExceptionSubIndex_f, &ipe_intf_mapper_ctl, p_action->action_index);
    }

    cmd = DRV_IOW(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_intf_mapper_ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_get_global_action_misc(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, ctc_pdu_global_l3pdu_action_t* p_action)
{
    uint32 cmd = 0;
    IpeIntfMapperCtl_m ipe_intf_mapper_ctl;

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    sal_memset(&ipe_intf_mapper_ctl, 0, sizeof(IpeIntfMapperCtl_m));

    cmd = DRV_IOR(IpeIntfMapperCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ipe_intf_mapper_ctl));

    if (CTC_PDU_L3PDU_TYPE_ARP == l3pdu_type)
    {
        p_action->entry_valid = GetIpeIntfMapperCtl(V, arpCheckExceptionEn_f, &ipe_intf_mapper_ctl);
        p_action->action_index = GetIpeIntfMapperCtl(V, arpExceptionSubIndex_f, &ipe_intf_mapper_ctl);
    }
    else if (CTC_PDU_L3PDU_TYPE_DHCP == l3pdu_type)
    {
        p_action->entry_valid = GetIpeIntfMapperCtl(V, dhcpUnicastExceptionDisable_f, &ipe_intf_mapper_ctl) ? 0 : 1;
        p_action->action_index = GetIpeIntfMapperCtl(V, dhcpExceptionSubIndex_f, &ipe_intf_mapper_ctl);
    }

    return CTC_E_NONE;
}

/**
 @brief  Set layer3 pdu global property
*/
int32
sys_goldengate_l3pdu_set_global_action(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    CTC_PTR_VALID_CHECK(p_action);

    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l3pdu type:%d\n", l3pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    if (p_action->action_index > MAX_SYS_L3PDU_ACTION_INDEX)
    {
        return CTC_E_PDU_INVALID_ACTION_INDEX;
    }

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_OSPF:
    case CTC_PDU_L3PDU_TYPE_PIM:
    case CTC_PDU_L3PDU_TYPE_VRRP:
    case CTC_PDU_L3PDU_TYPE_RSVP:
    case CTC_PDU_L3PDU_TYPE_RIP:
    case CTC_PDU_L3PDU_TYPE_BGP:
    case CTC_PDU_L3PDU_TYPE_MSDP:
    case CTC_PDU_L3PDU_TYPE_LDP:
    case CTC_PDU_L3PDU_TYPE_IPV4OSPF:
    case CTC_PDU_L3PDU_TYPE_IPV6OSPF:
    case CTC_PDU_L3PDU_TYPE_IPV4PIM:
    case CTC_PDU_L3PDU_TYPE_IPV6PIM:
    case CTC_PDU_L3PDU_TYPE_IPV4VRRP:
    case CTC_PDU_L3PDU_TYPE_IPV6VRRP:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RS:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RA:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NS:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NA:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_REDIRECT:
    case CTC_PDU_L3PDU_TYPE_RIPNG:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_of_fixed_l3pdu(lchip, l3pdu_type, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_L3HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_by_l3hdr_proto(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER3_IPDA:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_by_layer3_ipda(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_PORT:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_by_layer4_port(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_TYPE:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_by_layer4_type(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_ARP:
    case CTC_PDU_L3PDU_TYPE_DHCP:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_set_global_action_misc(lchip, l3pdu_type, p_action));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l3pdu_get_global_action(uint8 lchip, ctc_pdu_l3pdu_type_t l3pdu_type, uint8 index, ctc_pdu_global_l3pdu_action_t* p_action)
{
    SYS_PDU_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__);
    SYS_PDU_DBG_PARAM("l3pdu type:%d\n", l3pdu_type);
    SYS_PDU_DBG_PARAM("index:%d\n", index);

    switch (l3pdu_type)
    {
    case CTC_PDU_L3PDU_TYPE_OSPF:
    case CTC_PDU_L3PDU_TYPE_PIM:
    case CTC_PDU_L3PDU_TYPE_VRRP:
    case CTC_PDU_L3PDU_TYPE_RSVP:
    case CTC_PDU_L3PDU_TYPE_RIP:
    case CTC_PDU_L3PDU_TYPE_BGP:
    case CTC_PDU_L3PDU_TYPE_MSDP:
    case CTC_PDU_L3PDU_TYPE_LDP:
    case CTC_PDU_L3PDU_TYPE_IPV4OSPF:
    case CTC_PDU_L3PDU_TYPE_IPV6OSPF:
    case CTC_PDU_L3PDU_TYPE_IPV4PIM:
    case CTC_PDU_L3PDU_TYPE_IPV6PIM:
    case CTC_PDU_L3PDU_TYPE_IPV4VRRP:
    case CTC_PDU_L3PDU_TYPE_IPV6VRRP:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RS:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_RA:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NS:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_NA:
    case CTC_PDU_L3PDU_TYPE_ICMPIPV6_REDIRECT:
    case CTC_PDU_L3PDU_TYPE_RIPNG:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_of_fixed_l3pdu(lchip, l3pdu_type, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_L3HDR_PROTO:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_by_l3hdr_proto(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER3_IPDA:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_by_layer3_ipda(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_PORT:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_by_layer4_port(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_LAYER4_TYPE:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_by_layer4_type(lchip, index, p_action));
        break;

    case CTC_PDU_L3PDU_TYPE_ARP:
    case CTC_PDU_L3PDU_TYPE_DHCP:
        CTC_ERROR_RETURN(_sys_goldengate_l3pdu_get_global_action_misc(lchip, l3pdu_type, p_action));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

/**
 @brief  Per layer3 interface control layer3 pdu action
*/
int32
sys_goldengate_l3pdu_set_l3if_action(uint8 lchip, uint16 l3ifid, uint8 action_index, ctc_pdu_l3if_l3pdu_action_t action)
{
    if (action_index > MAX_SYS_L3PDU_PER_L3IF_ACTION_INDEX)
    {
        return CTC_E_PDU_INVALID_ACTION_INDEX;
    }

    switch (action)
    {
    case CTC_PDU_L3PDU_ACTION_TYPE_FWD:
        CTC_ERROR_RETURN(sys_goldengate_l3if_set_exception3_en(lchip, l3ifid, action_index, FALSE));
        break;

    case CTC_PDU_L3PDU_ACTION_TYPE_COPY_TO_CPU:
        CTC_ERROR_RETURN(sys_goldengate_l3if_set_exception3_en(lchip, l3ifid, action_index, TRUE));
        break;

    default:
        break;
    }

    return CTC_E_NONE;
}

int32
sys_goldengate_l3pdu_get_l3if_action(uint8 lchip, uint16 l3ifid, uint8 action_index, ctc_pdu_l3if_l3pdu_action_t* action)
{
    bool enbale = 0;

    if (action_index > MAX_SYS_L3PDU_PER_L3IF_ACTION_INDEX)
    {
        return CTC_E_PDU_INVALID_ACTION_INDEX;
    }

    CTC_ERROR_RETURN(sys_goldengate_l3if_get_exception3_en(lchip, l3ifid,  action_index, &enbale));

    if (enbale == TRUE)
    {
        *action = CTC_PDU_L3PDU_ACTION_TYPE_COPY_TO_CPU;
    }
    else
    {
        *action = CTC_PDU_L3PDU_ACTION_TYPE_FWD;
    }

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_exception_enable_init(uint8 lchip)
{
    uint32 cmd = 0;
    IpeBpduEscapeCtl_m ctl;

    sal_memset(&ctl, 0, sizeof(IpeBpduEscapeCtl_m));

    SetIpeBpduEscapeCtl(V, bpduEscapeEn_f, &ctl, 0xF);

    /* BPDU, SLOW_PROTOCOL, EAPOL, LLDP, L2ISIS auto identified */
    SetIpeBpduEscapeCtl(V, bpduExceptionEn_f, &ctl, 1);
    SetIpeBpduEscapeCtl(V, bpduExceptionSubIndex_f,
                        &ctl, CTC_L2PDU_ACTION_INDEX_BPDU);
    SetIpeBpduEscapeCtl(V, slowProtocolExceptionEn_f, &ctl, 1);
    SetIpeBpduEscapeCtl(V, slowProtocolExceptionSubIndex_f,
                        &ctl, CTC_L2PDU_ACTION_INDEX_SLOW_PROTO);
    SetIpeBpduEscapeCtl(V, efmSubIndex_f, &ctl, CTC_L2PDU_ACTION_INDEX_EFM_OAM);
    SetIpeBpduEscapeCtl(V, eapolExceptionEn_f, &ctl, 1);
    SetIpeBpduEscapeCtl(V, eapolExceptionSubIndex_f,
                        &ctl, CTC_L2PDU_ACTION_INDEX_EAPOL);
    SetIpeBpduEscapeCtl(V, lldpExceptionEn_f, &ctl, 1);
    SetIpeBpduEscapeCtl(V, lldpExceptionSubIndex_f,
                        &ctl, CTC_L2PDU_ACTION_INDEX_LLDP);
    SetIpeBpduEscapeCtl(V, l2isisExceptionEn_f, &ctl, 1);
    SetIpeBpduEscapeCtl(V, l2isisExceptionSubIndex_f,
                        &ctl, CTC_L2PDU_ACTION_INDEX_ISIS);

    cmd = DRV_IOW(IpeBpduEscapeCtl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_exception_enable_init(uint8 lchip)
{
    uint32 cmd = 0;
    IpeException3Ctl_m ctl;

    sal_memset(&ctl, 0, sizeof(IpeException3Ctl_m));

    SetIpeException3Ctl(V, exceptionCamEn_f, &ctl, 1);
    SetIpeException3Ctl(V, exceptionCamEn2_f, &ctl, 1);
    SetIpeException3Ctl(V, exceptionCamEn3_f, &ctl, 1);

    /* RIP, OSPF, BGP, PIM, VRRP, RSVP, MSDP, LDP auto identified */
    SetIpeException3Ctl(V, ospfv4ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ospfv4ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_OSPF);
    SetIpeException3Ctl(V, ospfv6ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ospfv6ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_OSPF);
    SetIpeException3Ctl(V, pimv4ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, pimv4ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_PIM);
    SetIpeException3Ctl(V, pimv6ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, pimv6ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_PIM);
    SetIpeException3Ctl(V, vrrpv4ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, vrrpv4ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_VRRP);
    SetIpeException3Ctl(V, vrrpv6ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, vrrpv6ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_VRRP);
    SetIpeException3Ctl(V, rsvpExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, rsvpExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_RSVP);
    SetIpeException3Ctl(V, ripExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ripExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_RIP);
    SetIpeException3Ctl(V, bgpv4ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, bgpv4ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_BGP);
    SetIpeException3Ctl(V, bgpv6ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, bgpv6ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_BGP);
    SetIpeException3Ctl(V, msdpExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, msdpExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_MSDP);
    SetIpeException3Ctl(V, ldpExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ldpExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_LDP);
    SetIpeException3Ctl(V, ospfv4ExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ospfv4ExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, icmpv6RsExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, icmpv6RsExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, icmpv6RaExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, icmpv6RaExceptionSubIndex_f,
                       &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, icmpv6NsExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, icmpv6NsExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, icmpv6NaExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, icmpv6NaExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, icmpv6RedirectExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, icmpv6RedirectExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_ICMPV6);
    SetIpeException3Ctl(V, ripngExceptionEn_f, &ctl, 1);
    SetIpeException3Ctl(V, ripngExceptionSubIndex_f,
                        &ctl, CTC_L3PDU_ACTION_INDEX_RIPNG);

    cmd = DRV_IOW(IpeException3Ctl_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ctl));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_cam_init(uint8 lchip)
{
    int32 cmd = 0;
    
    IpeBpduProtocolEscapeCam_m cam1;
    IpeBpduProtocolEscapeCam2_m cam2;
    IpeBpduProtocolEscapeCam3_m cam3;
    IpeBpduProtocolEscapeCam4_m cam4;
    IpeBpduProtocolEscapeCamResult_m rst1;
    IpeBpduProtocolEscapeCamResult2_m rst2;
    IpeBpduProtocolEscapeCamResult3_m rst3;
    IpeBpduProtocolEscapeCamResult4_m rst4;

    sal_memset(&cam1, 0, sizeof(IpeBpduProtocolEscapeCam_m));
    sal_memset(&cam2, 0, sizeof(IpeBpduProtocolEscapeCam2_m));
    sal_memset(&cam3, 0, sizeof(IpeBpduProtocolEscapeCam3_m));
    sal_memset(&cam4, 0, sizeof(IpeBpduProtocolEscapeCam4_m));

    sal_memset(&rst1, 0, sizeof(IpeBpduProtocolEscapeCamResult_m));
    sal_memset(&rst2, 0, sizeof(IpeBpduProtocolEscapeCamResult2_m));
    sal_memset(&rst3, 0, sizeof(IpeBpduProtocolEscapeCamResult3_m));
    sal_memset(&rst4, 0, sizeof(IpeBpduProtocolEscapeCamResult4_m));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam1));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &rst1));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam2));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &rst2));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam3));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &rst3));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCam4_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam4));

    cmd = DRV_IOW(IpeBpduProtocolEscapeCamResult4_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &rst4));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l3pdu_cam_init(uint8 lchip)
{
    int32 cmd ;
    

    IpeException3Cam_m cam1;
    IpeException3Cam2_m cam2;
    IpeException3Cam3_m cam3;

    sal_memset(&cam1, 0, sizeof(IpeException3Cam_m));
    sal_memset(&cam2, 0, sizeof(IpeException3Cam2_m));
    sal_memset(&cam3, 0, sizeof(IpeException3Cam3_m));

    cmd  = DRV_IOW(IpeException3Cam_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam1));

    cmd  = DRV_IOW(IpeException3Cam2_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam2));

    cmd  = DRV_IOW(IpeException3Cam3_t, DRV_ENTRY_FLAG);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cam3));

    return CTC_E_NONE;
}

static int32
_sys_goldengate_l2pdu_init_fixed_port_action(uint8 lchip)
{
    uint8  gchip = 0;
    uint32 i = 0;
    uint16 gport = 0;

    for (i = 0; i < MAX_PORT_NUM_PER_CHIP; i++)
    {
        if ((i & 0xFF) < SYS_PHY_PORT_NUM_PER_SLICE)
        {
            gport = CTC_MAP_LPORT_TO_GPORT(gchip, SYS_MAP_DRV_LPORT_TO_SYS_LPORT(i));
            sys_goldengate_l2pdu_set_port_action(lchip, gport, CTC_L2PDU_ACTION_INDEX_BPDU, CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU);
        }
    }

    return CTC_E_NONE;
}

/**
 @brief init pdu module
*/
int32
sys_goldengate_pdu_init(uint8 lchip)
{
    CTC_ERROR_RETURN(_sys_goldengate_l2pdu_exception_enable_init(lchip));

    CTC_ERROR_RETURN(_sys_goldengate_l2pdu_cam_init(lchip));

    CTC_ERROR_RETURN(_sys_goldengate_l3pdu_exception_enable_init(lchip));

    CTC_ERROR_RETURN(_sys_goldengate_l3pdu_cam_init(lchip));

    CTC_ERROR_RETURN(_sys_goldengate_l2pdu_init_fixed_port_action(lchip));

    return CTC_E_NONE;
}

#define ___________PDU_SHOW_INNER_FUNCTION___________
#define __1_SHOW_PDU_COMMON_FUN__
static char*
_sys_goldengate_pdu_token_alignment(uint8 lchip, uint8 width, char* p_content, char* p_buff)
{
    uint8 content_len = sal_strlen(p_content);
    uint8 star_pos = 0;
    uint8 alignment_type = SYS_PDU_TOKEN_ALIGNMENT_LEFT;

    sal_memset(p_buff, ' ', width);
    if (SYS_PDU_TOKEN_ALIGNMENT_LEFT == alignment_type)
    {
        sal_sprintf(p_buff, "%s", p_content);
        *(p_buff + content_len) = ' ';
        *(p_buff + width) = '\0';
    }
    else if (SYS_PDU_TOKEN_ALIGNMENT_MIDDLE == alignment_type)
    {
        star_pos = (width - content_len) / 2;
        sal_sprintf(p_buff + star_pos, "%s", p_content);
        *(p_buff + star_pos + content_len) = ' ';
        *(p_buff + width) = '\0';
    }
    else
    {
        star_pos = width - content_len;
        sal_sprintf(p_buff + star_pos, "%s", p_content);
    }

    return p_buff;
}

static char*
_sys_goldengate_pdu_lxpdu_action_index_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]  = "            ";
    char title[]        = "Action-index";
    char *desc[]        = {"<0-15>", "<0-31>", "<0-63>"};
    char empty[]        = "";
    char action_index[] = "31";
    char ignore[]       = "-";
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_ACTION_INDEX == item)
    {
        uint8 val = *((uint8*)p_val);
        sal_sprintf(action_index, "%2d", val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, action_index, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        uint32 val = *((uint32*)p_val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, desc[val%3], buff);
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }

    return NULL;
}

static char*
_sys_goldengate_pdu_lxpdu_valid_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]  = "             ";
    char title[] = "Valid";
    char true[]  = "True";
    char false[] = "False";
    char empty[] = "";
    char* desc[]  = {"per vlan cfg", "per port cfg"};
    int32 width = sal_strlen(buff);
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_VALID == item)
    {
        uint8 val = *((uint8*)p_val);

        if (TRUE == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, true, buff);
        }
        else if (FALSE == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, false, buff);
        }
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, desc[val], buff);
    }

    return NULL;
}

#define __1_SHOW_L2PDU_FUN__
static char*
_sys_goldengate_pdu_l2pdu_type_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]         =   "             ";
    char title[]               =   "Type";

    char* l2_fixed_pdu_token[] =  {"BPDU",  \
                                   "Slow Protocol",  \
                                   "EAPOL",  \
                                   "LLDP",  \
                                   "ISIS",  \
                                   "Efm Oam",  \
                                   "",  \
                                   "",  \
                                   "",  \
                                   "",  \
                                   "FIP"};

    char free_token[]          =   "None-defined";
    char ignore[]              =   "-";
    char empty[]               =   "";
    char user_token[]          =   "User-defined";
    uint32  val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32   width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, l2_fixed_pdu_token[val], buff);
    }
    else if (SYS_PDU_SHOW_USER_PDU == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, user_token, buff);
    }
    else if (SYS_PDU_SHOW_FREE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, free_token, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, (char*)p_val, buff);
    }

    return NULL;
}

static char*
_sys_goldengate_pdu_l2pdu_macda_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]      =  "              ";
    char macda_48bit_desc[] =  "xxxx.xxxx.xxxx";
    char macda_24bit_desc[] =  "0180.C2xx.xxxx";
    char ignore[]           =  "-";
    char title[]            =  "MAC-DA";
    char str[]              =  "";
    char* fixed_mac[]       = {"0180.c200.0000", \
                               "-", \
                               "-", \
                               "-", \
                               "-", \
                               "0180.c200.0002", \
                               "-", \
                               "-", \
                               "-", \
                               "-", \
                               "-"};
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        mac_addr_t* mac = (mac_addr_t*)p_val;
        sal_sprintf(str, "%.2X%.2X.%.2X%.2X.%.2X%.2X", \
                   (*mac)[0], (*mac)[1], (*mac)[2], (*mac)[3], (*mac)[4], (*mac)[5]);
        return _sys_goldengate_pdu_token_alignment(lchip, width, str, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        ctc_pdu_l2pdu_type_t l2pdu_type = *((ctc_pdu_l2pdu_type_t*)p_val);

        if (CTC_PDU_L2PDU_TYPE_MACDA == l2pdu_type)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, macda_48bit_desc, buff);
        }
        else if (CTC_PDU_L2PDU_TYPE_MACDA_LOW24 == l2pdu_type)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, macda_24bit_desc, buff);
        }
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        uint32 val = *((uint32*)p_val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, fixed_mac[val], buff);
    }

    return NULL;
}

static char*
_sys_goldengate_pdu_l2pdu_ethtype_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[] =  "          ";
    char title[]       =  "Ether-type";
    char* ether_type[] = {"-", \
                          "0x8809", \
                          "0x888E", \
                          "0x88CC", \
                          "0x22F4", \
                          "0x8809", \
                          "",       \
                          "",       \
                          "",       \
                          "",       \
                          "0x8914"};
    char desc[]        =  "x";
    char str[]         =  "          ";
    char ignore[]      =  "-";
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ether_type[val], buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        sal_sprintf(str, "0x%04X    ", val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, str, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, desc, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }

    return NULL;
}

static void
_sys_goldengate_pdu_l2pdu_item2str(uint8 lchip, char* column[], sys_pdu_show_item_t* item)
{
    uint8 idx = 0;

    sys_goldengate_pdu_show_token_t pdu_show_token[] =
    {
        &_sys_goldengate_pdu_l2pdu_type_token,
        &_sys_goldengate_pdu_l2pdu_macda_token,
        &_sys_goldengate_pdu_l2pdu_ethtype_token,
        &_sys_goldengate_pdu_lxpdu_action_index_token,
        &_sys_goldengate_pdu_lxpdu_valid_token
    };

    for (idx = 0; idx < SYS_PDU_SHOW_L2_COLUMN_NUM; idx++)
    {
        column[idx] = pdu_show_token[idx](lchip, item[idx].field, item[idx].p_val);
    }
}

static int32
_sys_goldengate_pdu_show_user_l2pdu(uint8 lchip, uint8 defined)
{
    uint32 val = 0;
    uint8 index = 0;
    uint8 configured = 0;
    char* column[SYS_PDU_SHOW_L3_COLUMN_NUM];
    ctc_pdu_l2pdu_key_t l2pdu_key;
    ctc_pdu_global_l2pdu_action_t l2pdu_action;
    sys_pdu_show_item_t item[SYS_PDU_SHOW_L2_COLUMN_NUM];
    ctc_pdu_l2pdu_type_t l2pdu_type;

    for (index = 0; index < 8; index++)
    {
        sal_memset(&l2pdu_action, 0, sizeof(ctc_pdu_global_l2pdu_action_t));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_global_action(lchip, CTC_PDU_L2PDU_TYPE_MACDA, index, &l2pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_classified_key(lchip, CTC_PDU_L2PDU_TYPE_MACDA, index, &l2pdu_key));
        configured = !((0 == l2pdu_action.entry_valid) && (IS_MAC_ALL_ZERO(l2pdu_key.l2pdu_by_mac.mac)));

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_FLEX, &l2pdu_key.l2pdu_by_mac.mac);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l2pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            l2pdu_type = CTC_PDU_L2PDU_TYPE_MACDA;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_DESC, &l2pdu_type);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_IGNORE, NULL);
            val = 1;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
    }

    for (index = 0; index < 10; index++)
    {
        sal_memset(&l2pdu_action, 0, sizeof(ctc_pdu_global_l2pdu_action_t));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_global_action(lchip, CTC_PDU_L2PDU_TYPE_MACDA_LOW24, index, &l2pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_classified_key(lchip, CTC_PDU_L2PDU_TYPE_MACDA_LOW24, index, &l2pdu_key));

        configured = !((0 == l2pdu_action.entry_valid) && (IS_MAC_LOW24BIT_ZERO(l2pdu_key.l2pdu_by_mac.mac)));

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_FLEX, &l2pdu_key.l2pdu_by_mac.mac);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l2pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            l2pdu_type = CTC_PDU_L2PDU_TYPE_MACDA_LOW24;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_DESC, &l2pdu_type);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_IGNORE, NULL);
            val = 1;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
    }

    for (index = 0; index < 16; index++)
    {
        sal_memset(&l2pdu_action, 0, sizeof(ctc_pdu_global_l2pdu_action_t));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_global_action(lchip, CTC_PDU_L2PDU_TYPE_L2HDR_PROTO, index, &l2pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_classified_key(lchip, CTC_PDU_L2PDU_TYPE_L2HDR_PROTO, index, &l2pdu_key));

        configured = !((0 == l2pdu_action.entry_valid) && (0 == l2pdu_key.l2hdr_proto));

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_FLEX, &l2pdu_key.l2hdr_proto);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l2pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_DESC, NULL);
            val = 1;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
            _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
            SYS_PDU_L2PDU_DUMP(column);
        }
    }

    return CTC_E_NONE;
}

#define __2_SHOW_L3PDU_FUN__
static char*
_sys_goldengate_pdu_l3pdu_ipda_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]            =  "              ";
    char ip_da_title_token[]      =  "IP-DA";
    char ip_da_ignore_token[]     =  "-";
    char ip_da_ipv4_desc_token[]  =  "224.0.0.x/8";
    char ip_da_ipv6_desc_token[]  =  "FF00::x/8";
    char efm_mac_da[]             =  "0180.c200.0002";
    char ip_da_value_token[]      =  "              ";
    char ip_da_empty_token[]      =  "Not available";
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_title_token, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_ignore_token, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        uint32 val = *(uint32*)p_val;
        if (CTC_IP_VER_4 == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_ipv4_desc_token, buff);
        }
        else if (CTC_IP_VER_6 == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_ipv6_desc_token, buff);
        }
    }
    else if (SYS_PDU_SHOW_IPV4_ADDR == item)
    {
        uint16 val = *(uint16*)p_val;
        sal_sprintf(ip_da_value_token, "224.0.0.%d", (val & 0xFF));
        return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_value_token, buff);
    }
    else if (SYS_PDU_SHOW_IPV6_ADDR == item)
    {
        uint16 val = *(uint16*)p_val;
        sal_sprintf(ip_da_value_token, "FF00::%02X", (val & 0xFF));
        return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_value_token, buff);
    }
    else if (SYS_PDU_SHOW_MAC_ADDR == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, efm_mac_da, buff);;
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ip_da_empty_token, buff);
    }

    return CTC_E_NONE;
}

char*
_sys_goldengate_pdu_l3pdu_type_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]         =   "               ";
    char type_title_token[]    =   "Type";

    char* l3_fixed_pdu_token[] =  {"OSPF",
                                   "PIM",
                                   "VRRP",
                                   "RSVP",
                                   "RIP",
                                   "BGP",
                                   "MSDP",
                                   "LDP",
                                   "OSPFv4",
                                   "OSPFv6",
                                   "PIM",
                                   "PIMv6",
                                   "VRRPv4",
                                   "VRRPv6",
                                   "ICMPv6 RS",
                                   "ICMPv6 RA",
                                   "ICMPv6 NS",
                                   "ICMPv6 NA",
                                   "ICMPv6 Redirect",
                                   "RIPng",
                                   "",
                                   "",
                                   "",
                                   "",
                                   "ARP",
                                   "DHCP",
                                   "DHCPv6",
                                   "IGMP"};

#if 0
    PacketInfo.igmpPacket = (ParserResult.layer4Type(3,0) == L4TYPE_IGMP) || ((ParserResult.layer3HeaderProtocol(7,0) == CBit(8, 'd', "103", 3)) && (ParserResult.uL4Source.gPort.l4SourcePort(11,8) == CBit(4, 'd', "0", 1)) && IpeLookupCtl.pimSnoopingEn);
#endif

    char free_token[]           =  "None-defined";
    char ignore[]               =  "-";
    char empty[]                =  "";
    char user_pdu[]             =  "User-defined";
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, type_title_token, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, l3_fixed_pdu_token[val], buff);
    }
    else if (SYS_PDU_SHOW_FREE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, free_token, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }
    else if (SYS_PDU_SHOW_USER_PDU == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, user_pdu, buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, (char*)p_val, buff);
    }

    return NULL;
}

char*
_sys_goldengate_pdu_l3pdu_l3type_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]         =  "           ";
    char l3type_title_token[]  =  "Layer3-Type";
    char ipv4[]                =  "IPv4";
    char ipv6[]                =  "IPv6";
    char ipv4_or_ipv6[]        =  "IPv4|IPv6";
    char ignore[]              =  "-";
    char *fixed_l3type_token[] = {ipv4_or_ipv6, \
                                  ipv4_or_ipv6, \
                                  ipv4_or_ipv6, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  ipv4, \
                                  ipv6, \
                                  ipv4, \
                                  ipv6, \
                                  ipv4, \
                                  ipv6, \
                                  ipv6, \
                                  ipv6, \
                                  ipv6, \
                                  ipv6, \
                                  ipv6, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  ignore, \
                                  "ARP",  \
                                  ipv4,   \
                                  ipv6,   \
                                  ipv4};

    char free_token[]          =  "No-defined";
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, l3type_title_token, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, fixed_l3type_token[val], buff);
    }
    else if (SYS_PDU_SHOW_IP_VER == item)
    {
        if (CTC_IP_VER_4 == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, ipv4, buff);
        }
        else if (CTC_IP_VER_6 == val)
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, ipv6, buff);
        }
        else
        {
            return _sys_goldengate_pdu_token_alignment(lchip, width, ipv4_or_ipv6, buff);
        }
    }
    else if (SYS_PDU_SHOW_FREE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, free_token, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, (char*)p_val, buff);
    }

    return NULL;
}

char*
_sys_goldengate_pdu_l3pdu_protocol_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]        =  "        ";
    char title[]              =  "Protocol";

    char* fixed_l3_protocol[] = {"89", \
                                 "103", \
                                 "112", \
                                 "46", \
                                 "17", \
                                 "6", \
                                 "6", \
                                 "6|17", \
                                 "89", \
                                 "89", \
                                 "103", \
                                 "103", \
                                 "112", \
                                 "112", \
                                 "133", \
                                 "134", \
                                 "135", \
                                 "136", \
                                 "137", \
                                 "17", \
                                 "-", \
                                 "-", \
                                 "-", \
                                 "-", \
                                 "-", \
                                 "17", \
                                 "17", \
                                 "2"};

    char ignore_token[]      =   "-";
    char desc[]              =   "x";
    char empty[]             =   "";
    char flex_l3_protocol[sizeof(title)] = {0};
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, fixed_l3_protocol[val], buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        sal_sprintf(flex_l3_protocol, "%d", val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, flex_l3_protocol, buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore_token, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, desc, buff);
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }

    return NULL;
}

char*
_sys_goldengate_pdu_l3pdu_port_token(uint8 lchip, uint8 item, void* p_val)
{
    static char buff[]             = "           ";
    char title[]                   = "Layer4-port";
    char ignore[]                  = "-";

    char *l3_fixed_layer4_port[28] = {ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      "520", \
                                      "179", \
                                      "639", \
                                      "646", \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      "58", \
                                      "58", \
                                      "58", \
                                      "58", \
                                      "58", \
                                      "521", \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      ignore, \
                                      "67|68", \
                                      "546|547", \
                                      "-"};

    char desc[]                    =  "x";
    char flex[]                    =  "           ";
    char empty[]                   =  "";
    uint32 val = (NULL != p_val) ? *((uint32*)p_val) : 0;
    int32 width = sal_strlen(buff);

    if (SYS_PDU_SHOW_COLUMN_TITLE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, title, buff);
    }
    else if (SYS_PDU_SHOW_FIXED == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, l3_fixed_layer4_port[val], buff);
    }
    else if (SYS_PDU_SHOW_IGNORE == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, ignore, buff);
    }
    else if (SYS_PDU_SHOW_DESC == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, desc, buff);
    }
    else if (SYS_PDU_SHOW_FLEX == item)
    {
        sal_sprintf(flex, "%d", val);
        return _sys_goldengate_pdu_token_alignment(lchip, width, flex, buff);
    }
    else if (SYS_PDU_SHOW_EMPTY == item)
    {
        return _sys_goldengate_pdu_token_alignment(lchip, width, empty, buff);
    }

    return NULL;
}

static void
_sys_goldengate_pdu_l3pdu_item2str(uint8 lchip, char* column[], sys_pdu_show_item_t* item)
{
    uint8 idx = 0;

    sys_goldengate_pdu_show_token_t pdu_show_token[] =
    {
        &_sys_goldengate_pdu_l3pdu_type_token,
        &_sys_goldengate_pdu_l3pdu_l3type_token,
        &_sys_goldengate_pdu_l3pdu_ipda_token,
        &_sys_goldengate_pdu_l3pdu_protocol_token,
        &_sys_goldengate_pdu_l3pdu_port_token,
        &_sys_goldengate_pdu_lxpdu_action_index_token,
        &_sys_goldengate_pdu_lxpdu_valid_token
    };

    for (idx = 0; idx < SYS_PDU_SHOW_L3_COLUMN_NUM; idx++)
    {
        column[idx] = pdu_show_token[idx](lchip, item[idx].field, item[idx].p_val);
    }
}

static int32
_sys_goldengate_pdu_show_user_l3pdu(uint8 lchip, uint8 defined)
{
    uint32 val = 0;
    uint32 protocol;
    uint32 index = 0;
    uint32 ip_ver = 0;
    uint32 port = 0;
    uint8 configured = 0;
    char* column[SYS_PDU_SHOW_L3_COLUMN_NUM];
    ctc_pdu_l3pdu_key_t l3pdu_key;
    ctc_pdu_global_l3pdu_action_t l3pdu_action;
    sys_pdu_show_item_t item[SYS_PDU_SHOW_L3_COLUMN_NUM];

    for (index = 0; index < 8; index++)
    {
        sal_memset(&l3pdu_action, 0, sizeof(l3pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_global_action(lchip, CTC_PDU_L3PDU_TYPE_L3HDR_PROTO, index, &l3pdu_action));
        sal_memset(&l3pdu_key, 0, sizeof(l3pdu_key));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_classified_key(lchip, CTC_PDU_L3PDU_TYPE_L3HDR_PROTO, index, &l3pdu_key));

        configured = !((0 == l3pdu_action.entry_valid) && (0 == l3pdu_key.l3hdr_proto));

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_FLEX, &l3pdu_key.l3hdr_proto);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_FLEX, &l3pdu_key.l3pdu_by_port.dest_port);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l3pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_DESC, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_IGNORE, NULL);
            val = 2;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
    }

    for (index = 0; index < 4; index++)
    {
        sal_memset(&l3pdu_action, 0, sizeof(l3pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_global_action(lchip, CTC_PDU_L3PDU_TYPE_LAYER3_IPDA, index, &l3pdu_action));
        sal_memset(&l3pdu_key, 0, sizeof(l3pdu_key));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_classified_key(lchip, CTC_PDU_L3PDU_TYPE_LAYER3_IPDA, index, &l3pdu_key));

        configured = !((0 == l3pdu_action.entry_valid) && (0 == l3pdu_key.l3pdu_by_ipda.ipda));
        ip_ver = l3pdu_key.l3pdu_by_ipda.is_ipv4 ? CTC_IP_VER_4 : (l3pdu_key.l3pdu_by_ipda.is_ipv6 ? CTC_IP_VER_6 : MAX_CTC_IP_VER);

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IP_VER, &ip_ver);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, (CTC_IP_VER_4 == ip_ver)   \
                                  ? SYS_PDU_SHOW_IPV4_ADDR : ((CTC_IP_VER_6 == ip_ver) \
                                  ? SYS_PDU_SHOW_IPV6_ADDR : SYS_PDU_SHOW_EMPTY), &l3pdu_key.l3pdu_by_ipda.ipda);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l3pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            ip_ver = CTC_IP_VER_4;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IP_VER, &ip_ver);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_DESC, &ip_ver);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_IGNORE, NULL);
            val = 2;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);

            ip_ver = CTC_IP_VER_6;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_EMPTY, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IP_VER, &ip_ver);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_DESC, &ip_ver);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_EMPTY, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_EMPTY, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_EMPTY, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_EMPTY, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
    }

    for (index = 0; index < 8; index++)
    {
        sal_memset(&l3pdu_action, 0, sizeof(l3pdu_action));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_global_action(lchip, CTC_PDU_L3PDU_TYPE_LAYER4_PORT, index, &l3pdu_action));
        sal_memset(&l3pdu_key, 0, sizeof(l3pdu_key));
        CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_classified_key(lchip, CTC_PDU_L3PDU_TYPE_LAYER4_PORT, index, &l3pdu_key));

        configured = !((0 == l3pdu_action.entry_valid) && (0 == l3pdu_key.l3pdu_by_port.dest_port));

        if (defined && configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_USER_PDU, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_IGNORE, NULL);
            protocol = l3pdu_key.l3pdu_by_port.is_tcp ? 6 : (l3pdu_key.l3pdu_by_port.is_udp ? 17 : 0);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_FLEX, &protocol);
            port = l3pdu_key.l3pdu_by_port.dest_port;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_FLEX, &port);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l3pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
        else if (!defined && !configured)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_FREE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_DESC, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_DESC, NULL);
            val = 2;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &val);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
            _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
            SYS_PDU_L3PDU_DUMP(column);
        }
    }

    return CTC_E_NONE;
}

#define ___________PDU_OUTER_FUNCTION___________
int32
sys_goldengate_pdu_show_l2pdu_cfg(uint8 lchip)
{
    ctc_pdu_global_l2pdu_action_t l2pdu_action;
    char* column[SYS_PDU_SHOW_L2_COLUMN_NUM];
    sys_pdu_show_item_t item[SYS_PDU_SHOW_L2_COLUMN_NUM];
    uint32 cmd = 0;
    uint32 idx = 0;
    uint32 value = 0;

    LCHIP_CHECK(lchip);
    SYS_PDU_DBG_DUMP("L2pdu:\n");
    SYS_PDU_DBG_DUMP("Note: for MAC address the token \"x\" used as an indication\n");
    SYS_PDU_DBG_DUMP("      of a max hex value 0xF that user can configure.\n");
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);

    SYS_PDU_DBG_DUMP("------------------------------------------------------------------------------\n");
    SYS_PDU_L2PDU_DUMP(column);
    SYS_PDU_DBG_DUMP("------------------------------------------------------------------------------\n");

    cmd = DRV_IOR(IpeIntfMapperCtl_t, IpeIntfMapperCtl_fipExceptionSubIndex_f);
    CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));

    for (idx = 0; idx < MAX_CTC_PDU_L2PDU_TYPE + 1; idx++)
    {
        if ((CTC_PDU_L2PDU_TYPE_L3TYPE == idx) || (CTC_PDU_L2PDU_TYPE_L2HDR_PROTO == idx)
           || (CTC_PDU_L2PDU_TYPE_MACDA == idx) || (CTC_PDU_L2PDU_TYPE_MACDA_LOW24 == idx)
           || (CTC_PDU_L2PDU_TYPE_ISIS == idx) || (CTC_PDU_L2PDU_TYPE_EFM_OAM == idx))
        {
            continue;
        }

        sal_memset(&l2pdu_action, 0, sizeof(ctc_pdu_global_l2pdu_action_t));
        CTC_ERROR_RETURN(sys_goldengate_l2pdu_get_global_action(lchip, idx, 0, &l2pdu_action));

        if (MAX_CTC_PDU_L2PDU_TYPE == idx)
        {
            l2pdu_action.action_index = value;
            value = 0;
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_DESC, &value);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_DESC, &value);
        }
        else
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l2pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l2pdu_action.entry_valid);
        }

        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_TYPE, SYS_PDU_SHOW_FIXED, &idx);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_MACDA, SYS_PDU_SHOW_FIXED, &idx);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L2_COLUMN_ETHTYPE, SYS_PDU_SHOW_FIXED, &idx);

        _sys_goldengate_pdu_l2pdu_item2str(lchip, column, item);
        SYS_PDU_L2PDU_DUMP(column);
    }

    CTC_ERROR_RETURN(_sys_goldengate_pdu_show_user_l2pdu(lchip, 1));
    CTC_ERROR_RETURN(_sys_goldengate_pdu_show_user_l2pdu(lchip, 0));

    return CTC_E_NONE;
}

int32
sys_goldengate_pdu_show_l3pdu_cfg(uint8 lchip)
{
    uint32 value = 0;
    uint32 cmd = 0;
    uint32 index = 0;
    char* column[SYS_PDU_SHOW_L3_COLUMN_NUM];
    ctc_pdu_l3pdu_key_t l3pdu_key;
    ctc_pdu_global_l3pdu_action_t l3pdu_action;
    sys_pdu_show_item_t item[SYS_PDU_SHOW_L3_COLUMN_NUM];

    LCHIP_CHECK(lchip);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_COLUMN_TITLE, NULL);
    _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);

    /*l3pdu based on l3-header proto*/
    SYS_PDU_DBG_DUMP("L3pdu:\n");
    SYS_PDU_DBG_DUMP("Note: for IPv4 address the token \"x\" used as an indication\n");
    SYS_PDU_DBG_DUMP("      of a max value 255 that user can configure.\n");
    SYS_PDU_DBG_DUMP("      for IPv6 address the token \"x\" means a max hex value 0xF.\n");
    SYS_PDU_DBG_DUMP("---------------------------------------------------------------------------------------------------\n");
    SYS_PDU_L3PDU_DUMP(column);
    SYS_PDU_DBG_DUMP("---------------------------------------------------------------------------------------------------\n");

    for (index = 0; index < MAX_CTC_PDU_L3PDU_TYPE + 2; index++)
    {
        if ((CTC_PDU_L3PDU_TYPE_L3HDR_PROTO == index) || (CTC_PDU_L3PDU_TYPE_LAYER3_IPDA == index)
           || (CTC_PDU_L3PDU_TYPE_LAYER4_PORT == index) || (CTC_PDU_L3PDU_TYPE_LAYER4_TYPE == index))
        {
            continue;
        }

        if (index < MAX_CTC_PDU_L3PDU_TYPE)
        {
            sal_memset(&l3pdu_action, 0, sizeof(l3pdu_action));
            CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_global_action(lchip, index, 0, &l3pdu_action));
            sal_memset(&l3pdu_key, 0, sizeof(l3pdu_key));
            CTC_ERROR_RETURN(sys_goldengate_l3pdu_get_classified_key(lchip, index, 0, &l3pdu_key));
        }

        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_TYPE, SYS_PDU_SHOW_FIXED, &index);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L3TYPE, SYS_PDU_SHOW_FIXED, &index);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_IPDA, SYS_PDU_SHOW_IGNORE, NULL);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_PROTOCOL, SYS_PDU_SHOW_FIXED, &index);
        SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_L4PORT, SYS_PDU_SHOW_FIXED, &index);

        if (MAX_CTC_PDU_L3PDU_TYPE + 1 != index)
        {
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_ACTION_INDEX, &l3pdu_action.action_index);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &l3pdu_action.entry_valid);
        }
        else
        {
            cmd = DRV_IOR(ParserLayer3ProtocolCtl_t, ParserLayer3ProtocolCtl_igmpTypeEn_f);
            CTC_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &value));
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_ACTION_INDEX, SYS_PDU_SHOW_IGNORE, NULL);
            SYS_PDU_SET_SHOW_ITEM(SYS_PDU_SHOW_L3_COLUMN_VALID, SYS_PDU_SHOW_VALID, &value);
        }

        _sys_goldengate_pdu_l3pdu_item2str(lchip, column, item);
        SYS_PDU_L3PDU_DUMP(column);
    }

    CTC_ERROR_RETURN(_sys_goldengate_pdu_show_user_l3pdu(lchip, 1));
    CTC_ERROR_RETURN(_sys_goldengate_pdu_show_user_l3pdu(lchip, 0));

    return CTC_E_NONE;
}

