/**
 @file ctc_humber_acl.h

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2012-10-19

 @version v2.0

The module provides ACL functions.

*/

#ifndef _CTC_GREATBELT_ACL_H
#define _CTC_GREATBELT_ACL_H
#ifdef __cplusplus
extern "C" {
#endif

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_const.h"
#include "ctc_parser.h"
#include "ctc_acl.h"
#include "ctc_stats.h"


/**
 @addtogroup acl ACL
 @{
*/

/**
 @brief     Init acl module.

 @param[in] lchip    local chip id

 @param[in] acl_global_cfg      Init parameter

 @remark    Init acl module.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_init(uint8 lchip, ctc_acl_global_cfg_t* acl_global_cfg);

/**
 @brief     Create a acl group.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID
 @param[in] group_info    ACL group info

 @remark    Creates a acl group with a specified priority.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_create_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info);

/**
 @brief     Destroy a acl group.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID

 @remark    Destroy a acl group.
            All entries that uses this group must have been removed before calling this routine,
            or the call will fail.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_destroy_group(uint8 lchip, uint32 group_id);

/**
 @brief     Install all entries of a acl group into the hardware tables.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID
 @param[in] group_info    ACL group info

 @remark    Installs a group of entries into the hardware tables.
            Will silently reinstall entries already in the hardware tables.
            If the group is empty, nothing is installed but the group_info is saved.
            Only after the group_info saved, ctc_acl_install_entry() will work.



 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_install_group(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info);

/**
 @brief     Uninstall all entries of a acl group from the hardware table.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID

 @remark    Uninstall all entries of a group from the hardware tables.
            Will silently ignore entries that are not in the hardware tables.
            This does not destroy the group or remove its entries,
            it only uninstalls them from the hardware tables.
            Remove an entry by using  ctc_acl_remove_entry(),
            and destroy a group by using ctc_acl_destroy_group().

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_uninstall_group(uint8 lchip, uint32 group_id);

/**
 @brief      Get group_info of a acl group.

 @param[in] lchip    local chip id

 @param[in]  group_id            ACL group ID
 @param[out] group_info          ACL group information

 @remark     Get group_info of a acl group.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_get_group_info(uint8 lchip, uint32 group_id, ctc_acl_group_info_t* group_info);

/**
 @brief     Add an acl entry to a specified acl group.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID
 @param[in] acl_entry     ACL entry info.

 @remark    Add an acl entry to a specified acl group.
            The entry cantains: key, action, entry_id, priority, refer to ctc_acl_entry_t.
            Remove an entry by using ctc_acl_remove_entry().
            It only add entry to the software table, install to hardware table
            by using ctc_acl_install_entry().

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_add_entry(uint8 lchip, uint32 group_id, ctc_acl_entry_t* acl_entry);

/**
 @brief     Remove an acl entry.

 @param[in] lchip    local chip id

 @param[in] entry_id      ACL entry ID

 @remark    Remove an acl entry from software table,
            uninstall from hardware table by calling ctc_acl_uninstall_entry().

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_remove_entry(uint8 lchip, uint32 entry_id);

/**
 @brief     Installs an entry into the hardware tables.

 @param[in] lchip    local chip id

 @param[in] entry_id      ACL entry ID

 @remark    Installs an entry into the hardware tables.
            Must add an entry to software tablse first, by calling ctc_acl_add_entry().

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_install_entry(uint8 lchip, uint32 entry_id);

/**
 @brief     Uninstall an acl entry from the hardware tables.

 @param[in] lchip    local chip id

 @param[in] entry_id      ACL entry ID

 @remark    Uninstall an acl entry from the hardware tables.
            The object of this entry is still in software table, thus can install again.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_uninstall_entry(uint8 lchip, uint32 entry_id);

/**
 @brief     Remove all acl entries of a acl group.

 @param[in] lchip    local chip id

 @param[in] group_id      ACL group ID

 @remark    Remove all acl entries of a acl group from software table, must uninstall all
            entries first.
            Uninstall one entry from hardware table by using ctc_acl_uninstall_entry().
            Uninstall a whole group from hardware table by using ctc_acl_uninstall_group().

 @return    CTC_E_XXX
*/
extern int32
ctc_humber_acl_remove_all_entry(uint8 lchip, uint32 group_id);

/**
 @brief     set an entry priority.

 @param[in] lchip    local chip id

 @param[in] entry_id      ACL entry ID

 @param[in] priority      ACL entry priority

 @remark    Sets the priority of an entry.
            Entries with higher priority values take precedence over entries with lower values.
            Since TCAM lookups start at low indexes, precedence within a physical block is the
            reverse of this.
            The effect of this is that entries with the greatest priority will have the lowest TCAM index.
            Entries should have only positive priority values. If 2 entry priority set equally,
            the latter is lower than former.
            Currently there are 1 predefined cases:
            CTC_ACL_ENTRY_PRIORITY_LOWEST  - Lowest possible priority (ALSO is the default value)

@return CTC_E_XXX
*/
extern int32
ctc_humber_acl_set_entry_priority(uint8 lchip, uint32 entry_id, uint32 priority);

/**
 @brief     Clear statistics of one ACL entry.

 @param[in] lchip    local chip id

 @param[in] entry_id       ACL entry ID

 @remark    Clear statistics of one ACL entry. If no statistics, return success.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_clear_stats(uint8 lchip, uint32 entry_id);

/**
 @brief      Get statistics from one ACL entry.

 @param[in] lchip    local chip id

 @param[in]  entry_id       ACL entry ID
 @param[out] stats          Pointer to stats of an ACL entry.

 @remark     Get statistics from one ACL entry.

@return CTC_E_XXX
*/
extern int32
ctc_humber_acl_get_stats(uint8 lchip, uint32 entry_id, ctc_stats_basic_t* stats);

/**
 @brief      Get an array of entry IDs in use in a group

 @param[in] lchip    local chip id

 @param[in|out]  query     Pointer to query structure.

 @remark     Fills an array with the entry IDs for the specified group. This should first be called with an  entry_size  of 0
to get the number of entries to be returned, so that an appropriately-sized array can be allocated.

@return CTC_E_XXX
*/
extern int32
ctc_humber_acl_get_multi_entry(uint8 lchip, ctc_acl_query_t* query);

/**
 @brief      Update acl action

 @param[in] lchip    local chip id

 @param[in]  entry_id     ACL entry need to update action
 @param[in]  action       New action to overwrite

 @remark     Update an ace's action, this action will overwrite the old ace's action.

 @return CTC_E_XXX
*/
extern int32
ctc_humber_acl_update_action(uint8 lchip, uint32 entry_id, ctc_acl_action_t* action);

/**
 @brief      Create a copy of an existing acl entry

 @param[in] lchip    local chip id

 @param[in]  copy_entry     Pointer to copy_entry struct

 @remark     Creates a copy of an existing acl entry to a sepcific group.
             The dst entry's priority is a default priority.

 @return CTC_E_XXX
*/

extern int32
ctc_humber_acl_copy_entry(uint8 lchip, ctc_acl_copy_entry_t* copy_entry);

/**@} end of @addgroup   */

#ifdef __cplusplus
}
#endif

#endif

