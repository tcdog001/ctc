/**
 @file ctc_goldengate_interrupt.c

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-10-23

 @version v2.0

 This file define ctc functions

*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "ctc_error.h"
#include "ctc_goldengate_interrupt.h"
#include "sys_goldengate_interrupt.h"

/****************************************************************************
*
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
*
* Global and Declaration
*
*****************************************************************************/

/****************************************************************************
*
* Function
*
*****************************************************************************/
int32
ctc_goldengate_interrupt_init(uint8 lchip, void* p_global_cfg)
{
    return sys_goldengate_interrupt_init(lchip, p_global_cfg);
}

int32
ctc_goldengate_interrupt_deinit(uint8 lchip)
{
    return sys_goldengate_interrupt_deinit(lchip);
}

int32
ctc_goldengate_interrupt_clear_status(uint8 lchip, ctc_intr_type_t* p_type)
{
    return sys_goldengate_interrupt_clear_status(lchip, p_type, TRUE);
}

int32
ctc_goldengate_interrupt_get_status(uint8 lchip, ctc_intr_type_t* p_type, ctc_intr_status_t* p_status)
{
    return sys_goldengate_interrupt_get_status(lchip, p_type, p_status);
}

int32
ctc_goldengate_interrupt_set_en(uint8 lchip, ctc_intr_type_t* p_type, uint32 enable)
{
    return sys_goldengate_interrupt_set_en(lchip, p_type, enable);
}

int32
ctc_goldengate_interrupt_get_en(uint8 lchip, ctc_intr_type_t* p_type, uint32* p_enable)
{
    return sys_goldengate_interrupt_get_en(lchip, p_type, p_enable);
}

int32
ctc_goldengate_interrupt_register_event_cb(uint8 lchip, ctc_interrupt_event_t event, CTC_INTERRUPT_EVENT_FUNC cb)
{
    return sys_goldengate_interrupt_register_event_cb(lchip, event, cb);
}

