/**
 @file ctc_humber_qos.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2012-12-14

 @version v2.0

   The file provide all qos related APIs of humber.
*/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "ctc_error.h"
#include "ctc_const.h"


#include "ctc_humber_qos.h"
#include "sys_humber_qos.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declaration
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Function
 *
 ****************************************************************************/

/*init*/
int32
ctc_humber_qos_init(uint8 lchip, void* p_glb_parm)
{
    CTC_ERROR_RETURN(sys_humber_qos_init(p_glb_parm));
    return CTC_E_NONE;
}

/*policer*/
int32
ctc_humber_qos_set_policer(uint8 lchip, ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_policer(p_policer));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_policer(uint8 lchip, ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_policer(p_policer));
    return CTC_E_NONE;
}

/*global param*/
int32
ctc_humber_qos_set_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_global_config(p_glb_cfg));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_global_config(p_glb_cfg));
    return CTC_E_NONE;
}

/*mapping*/
int32
ctc_humber_qos_set_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_domain_map(p_domain_map));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_domain_map(p_domain_map));
    return CTC_E_NONE;
}

/*queue*/
int32
ctc_humber_qos_set_queue(uint8 lchip, ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_queue(p_que_cfg));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_queue(uint8 lchip, ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_queue(p_que_cfg));
    return CTC_E_NONE;
}

/*shape*/
int32
ctc_humber_qos_set_shape(uint8 lchip, ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_shape(p_shape));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_shape(uint8 lchip, ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_shape(p_shape));
    return CTC_E_NONE;
}

/*schedule*/
int32
ctc_humber_qos_set_sched(uint8 lchip, ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_sched(p_sched));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_sched(uint8 lchip, ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_sched(p_sched));
    return CTC_E_NONE;
}

/*drop*/
int32
ctc_humber_qos_set_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_humber_qos_set_drop_scheme(p_drop));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_get_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_humber_qos_get_drop_scheme(p_drop));
    return CTC_E_NONE;
}

/*stats*/
int32
ctc_humber_qos_query_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_humber_qos_query_queue_stats(p_queue_stats));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_clear_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_humber_qos_clear_queue_stats(p_queue_stats));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_query_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_humber_qos_query_policer_stats(p_policer_stats));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_clear_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_humber_qos_clear_policer_stats(p_policer_stats));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_create_service(uint8 lchip, ctc_qos_service_info_t* p_service)
{
    CTC_ERROR_RETURN(sys_humber_qos_create_service(p_service));
    return CTC_E_NONE;
}

int32
ctc_humber_qos_destroy_service(uint8 lchip, ctc_qos_service_info_t* p_service)
{
    CTC_ERROR_RETURN(sys_humber_qos_destroy_service(p_service));
    return CTC_E_NONE;
}

