/**
 @file ctc_nexthop_cli.c

 @date 2009-11-30

 @version v2.0

 The file apply clis of port module
*/

#include "ctc_api.h"
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_l2.h"
#include "ctc_error.h"
#include "ctc_debug.h"

#include "ctc_port_mapping_cli.h"
#include "ctc_nexthop_cli.h"
#include "sys_humber_nexthop_api.h"
#include "sys_humber_nexthop.h"

enum cli_humber_nh_type_e
{
    CLI_HUMBER_NH_TYPE_NULL,
    CLI_HUMBER_NH_TYPE_MCAST,
    CLI_HUMBER_NH_TYPE_BRGUC,
    CLI_HUMBER_NH_TYPE_IPUC,
    CLI_HUMBER_NH_TYPE_MPLS,
    CLI_HUMBER_NH_TYPE_ECMP, /*For IPUC, MPLS, etc*/
    CLI_HUMBER_NH_TYPE_DROP,
    CLI_HUMBER_NH_TYPE_TOCPU,
    CLI_HUMBER_NH_TYPE_UNROV,
    CLI_HUMBER_NH_TYPE_ILOOP,
    CLI_HUMBER_NH_TYPE_ELOOP,
    CLI_HUMBER_NH_TYPE_RSPAN,
    CLI_HUMBER_NH_TYPE_DOWNMEP,
    CLI_HUMBER_NH_TYPE_IP_TUNNEL,
    CLI_HUMBER_NH_TYPE_MAX
};
typedef enum cli_humber_nh_type_e cli_humber_nh_type_t;

#define CTC_CLI_NH_PARSE_MPLS_LABEL_PARAM(__label_param, __tmp_argi,  __label_str, __map_ttl_str, __is_mcast_str)     \
    {                                                                                                         \
        __tmp_argi = CTC_CLI_GET_ARGC_INDEX(__label_str);             \
        if (0xFF != __tmp_argi)                                                                                 \
        { \
            CTC_SET_FLAG(__label_param.lable_flag, CTC_MPLS_NH_LABEL_IS_VALID);                 \
            CTC_CLI_GET_UINT32_RANGE(__label_str, __label_param.label, argv[(__tmp_argi + 1)], 0, CTC_MAX_UINT32_VALUE);       \
            CTC_CLI_GET_UINT8_RANGE("ttl", __label_param.ttl, argv[(__tmp_argi + 3)], 0, CTC_MAX_UINT8_VALUE);           \
            CTC_CLI_GET_UINT8_RANGE("exp", __label_param.exp, argv[(__tmp_argi + 5)], 0, CTC_MAX_UINT8_VALUE);              \
            CTC_CLI_GET_UINT8_RANGE("exp-type", __label_param.exp_type, argv[(__tmp_argi + 7)], 0, CTC_MAX_UINT8_VALUE);    \
            __tmp_argi = CTC_CLI_GET_ARGC_INDEX(__map_ttl_str);     \
            if (0xFF != __tmp_argi)                                                                             \
            {                                                                                                   \
                CTC_SET_FLAG(__label_param.lable_flag, CTC_MPLS_NH_LABEL_MAP_TTL);              \
            }                                                                                                   \
            __tmp_argi = CTC_CLI_GET_ARGC_INDEX(__is_mcast_str);   \
            if (0xFF != __tmp_argi)                                                                             \
            {                                                                                                   \
                CTC_SET_FLAG(__label_param.lable_flag, CTC_MPLS_NH_LABEL_IS_MCAST);             \
            }                                                                                                   \
            label_num++; \
            arrayi++; \
        }                                                                                                       \
    }

#define CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR  "mac MAC "CTC_CLI_L3IF_ALL_STR " payload-op (op-none|op-route|op-l2vpn "CTC_CLI_NH_EGS_VLAN_EDIT_STR ")\
    ((martini-cw (no-seq|per-pw-seq seq-index INDEX|glb-seq0|glb-seq1))|label1 LABLE ttl1 TTL exp1 EXP exp1-type EXP_TYPE  (map-ttl1|) (is-mcast1|) )\
    (label2 LABLE ttl2 TTL exp2 EXP exp2-type EXP_TYPE (map-ttl2|) (is-mcast2|)|)\
    (label3 LABLE ttl3 TTL exp3 EXP exp3-type EXP_TYPE (map-ttl3|) (is-mcast3|)|)\
    (label4 LABLE ttl4 TTL exp4 EXP exp4-type EXP_TYPE (map-ttl4|) (is-mcast4|)|)"

#define CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC \
    CTC_CLI_MAC_DESC,    \
    CTC_CLI_MAC_FORMAT,                                             \
    CTC_CLI_L3IF_ALL_DESC,                                          \
    "Mpls push nexthop payload operation type",                     \
    "Payload could be ip, mpls or ethernet(Swap label on LSR/Pop label and do label Swap on LER)", \
    "Payload could be ip, will decreace ip header's ttl(L3VPN/FTN)",           \
    "Payload could be ethernet, will edit ethernet's vlan tag(L2VPN)",     \
    CTC_CLI_NH_EGS_VLAN_EDIT_DESC,                                  \
    "First label is martini control word",                          \
    "Martini sequence type is none",                                \
    "Martini sequence type is per-pw",                              \
    "Martini per-pw sequence index",                                \
    "Sequence index value",                                         \
    "Martini sequence type is global sequence type0",               \
    "Martini sequence type is global sequence type1",               \
    "MPLS label1",                                                  \
    "MPLS label1 valule",                                           \
    "MPLS label1's ttl",                                            \
    "MPLS label1's ttl value(0~255)",                                      \
    "MPLS EXP1",                                                    \
    "MPLS EXP1 value(0-7)",                                              \
    "MPLS EXP1 type(0-2)",                                               \
    "MPLS EXP1 type value, 0:user-define EXP to outer header; 1 Use EXP value from EXP map; 2: Copy packet EXP to outer header", \
    "MPLS label1's ttl mode, if set means new ttl will be (oldTTL - specified TTL) otherwise new ttl is specified TTL", \
    "MPLS label1 is mcast label",                                   \
    "MPLS label2",                                                  \
    "MPLS label2 valule",                                           \
    "MPLS label2's ttl",                                            \
    "MPLS label2's ttl value(0~255)",                                      \
    "MPLS EXP2",                                                    \
    "MPLS EXP2 value(0-7)",                                              \
    "MPLS EXP2 type(0-2)",                                              \
    "MPLS EXP2 type value, 0:user-define EXP to outer header; 1 Use EXP value from EXP map; 2: Copy packet EXP to outer header", \
    "MPLS label2's ttl mode, if set means new ttl will be (oldTTL - specified TTL) otherwise new ttl is specified TTL", \
    "MPLS label2 is mcast label",                                   \
    "MPLS label3",                                                  \
    "MPLS label3 valule",                                           \
    "MPLS label3's ttl",                                            \
    "MPLS label3's ttl value(0~255)",                                      \
    "MPLS EXP3",                                                    \
    "MPLS EXP3 value(0-7)",                                              \
    "MPLS EXP3 type(0-2)",                                               \
    "MPLS EXP3 type value,0:user-define EXP to outer header; 1 Use EXP value from EXP map; 2: Copy packet EXP to outer header", \
    "MPLS label3's ttl mode, if set means new ttl will be (oldTTL - specified TTL) otherwise new ttl is specified TTL", \
    "MPLS label3 is mcast label",                                   \
    "MPLS label4",                                                  \
    "MPLS label4 valule",                                           \
    "MPLS label4's ttl",                                            \
    "MPLS label4's ttl value(0~255)",                                      \
    "MPLS EXP4",                                                    \
    "MPLS EXP4 value(0-7)",                                              \
    "MPLS EXP4 type(0-2)",                                               \
    "MPLS EXP4 type value, 0:user-define EXP to outer header; 1 Use EXP value from EXP map; 2: Copy packet EXP to outer header", \
    "MPLS label4's ttl mode, if set means new ttl will be (oldTTL - specified TTL) otherwise new ttl is specified TTL", \
    "MPLS label4 is mcast label"                                 \

extern int32
sys_humber_nh_dump_all(cli_humber_nh_type_t nh_type, bool detail);
extern bool
sys_humber_chip_is_local(uint8 gchip_id, uint8* lchip_id);
extern uint8
sys_humber_get_local_chip_num(void);

extern int32
sys_humber_nh_display_current_global_sram_info();

extern int32
sys_humber_nh_dump(uint32 nhid, bool detail);

extern int32
sys_humber_nh_debug_ip_tunnel();

CTC_CLI(ctc_cli_l2_add_flex_nh,
        ctc_cli_l2_add_flex_nh_cmd,
        "nexthop add flex NHID dsnh-offset OFFSET port GPORT_ID ((swap-mac | {replace-mac-da MAC | replace-mac-sa MAC | replace-svlan VLAN_ID}) |)",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ADD_STR,
        CTC_CLI_NH_FLEX_STR,
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_DSNH_OFFSET_STR,
        CTC_CLI_NH_DSNH_OFFSET_VALUE_STR,
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC,
        "Swap macda and macsa",
        CTC_CLI_MAC_DESC,
        CTC_CLI_MAC_FORMAT,
        CTC_CLI_MAC_DESC,
        CTC_CLI_MAC_FORMAT,
        "Replace svlan",
        CTC_CLI_VLAN_RANGE_DESC)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid, dsnh_offset;
    uint16 gport;
    uint8 tmp_argi;
    mac_addr_t mac;
    ctc_misc_nh_param_t nh_param;

    sal_memset(&nh_param, 0, sizeof(ctc_misc_nh_param_t));

    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);
    CTC_CLI_GET_UINT32("DsNexthop Table offset", dsnh_offset, argv[1]);
    CTC_CLI_GET_UINT16("gport", gport, argv[2]);

    nh_param.type  = CTC_MISC_NH_TYPE_REPLACE_L2HDR;

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("swap-mac");
    if (0xFF != tmp_argi)
    {
        nh_param.misc_param.l2edit.flag |= CTC_MISC_NH_L2_EDIT_SWAP_MAC;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("replace-mac-da");
    if (0xFF != tmp_argi)
    {
        if (tmp_argi == (argc - 1))
        {
            ctc_cli_out("%% Incomplete command\n");                       \
            return CLI_ERROR;
        }

        nh_param.misc_param.l2edit.flag |= CTC_MISC_NH_L2_EDIT_REPLACE_MAC_DA;

        CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[tmp_argi + 1]);

        sal_memcpy(nh_param.misc_param.l2edit.mac_da, mac, sizeof(mac_addr_t));
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("replace-mac-sa");
    if (0xFF != tmp_argi)
    {
        if (tmp_argi == (argc - 1))
        {
            ctc_cli_out("%% Incomplete command\n");                       \
            return CLI_ERROR;
        }

        nh_param.misc_param.l2edit.flag |= CTC_MISC_NH_L2_EDIT_REPLACE_MAC_SA;

        CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[tmp_argi + 1]);

        sal_memcpy(nh_param.misc_param.l2edit.mac_sa, mac, sizeof(mac_addr_t));
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("replace-svlan");
    if (0xFF != tmp_argi)
    {
        if (tmp_argi == (argc - 1))
        {
            ctc_cli_out("%% Incomplete command\n");                       \
            return CLI_ERROR;
        }

        nh_param.misc_param.l2edit.flag |= CTC_MISC_NH_L2_EDIT_REPLACE_SVLAN_TAG;
        CTC_CLI_GET_UINT16_RANGE("replace svlan", nh_param.misc_param.l2edit.vlan_id, argv[tmp_argi + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    nh_param.gport = gport;
    nh_param.dsnh_offset = dsnh_offset;

    ret = ctc_nh_add_misc(nhid, &nh_param);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_l2_remove_flex_nh,
        ctc_cli_l2_remove_flex_nh_cmd,
        "nexthop remove flex NHID",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_DEL_STR,
        CTC_CLI_NH_FLEX_STR,
        CTC_CLI_NH_ID_STR)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid;

    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);

    ret = ctc_nh_remove_misc(nhid);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_nexthop_show_ip_tunnel_nexthop,
        ctc_cli_hb_nexthop_show_ip_tunnel_nexthop_cmd,
        "show ip-tunnel nexthop info",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_IP_TUNNEL_STR,
        CTC_CLI_NH_M_STR,
        "Information")
{
    int32 ret  = CLI_SUCCESS;

    ret = sys_humber_nh_debug_ip_tunnel();
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_show_nexthop_by_nhid_type,
        ctc_cli_hb_show_nexthop_by_nhid_type_cmd,
        "show nexthop NHID (detail |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "The nexthop ID",
        "Display detail information")
{
    uint32 nhid;
    int32 ret = CLI_ERROR;
    bool detail = FALSE;

    if (argc > 1)
    {
        detail = TRUE;
    }

    CTC_CLI_GET_UINT32("NexthopID", nhid, argv[0]);

    ret = sys_humber_nh_dump(nhid, detail);
    if (ret)
    {
        ctc_cli_out("%% Dump nexthop fail, ret = %s\n", ctc_get_error_desc(ret));
    }

    return ret;

}

CTC_CLI(ctc_cli_hb_show_nexthop_all_by_type,
        ctc_cli_hb_show_nexthop_all_by_type_cmd,
        "show nexthop all ((mcast|brguc|ipuc|ecmp|mpls|iloop|rspan|downmep|ip-tunnel)|) (detail |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "All nexthop",
        "All multicast nexthop",
        "All bridge unicast nexthop",
        "All ipuc nexthop",
        "All ecmp nexthop",
        "All mpls nexthop",
        "All iloop nexthop",
        "All RSPAN nexthop",
        "All Downmep nexthop",
        "All Ip tunnel nexthop",
        "Display detail information")
{
    int32 ret = 0;

    if (0 == argc)
    {
        ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MAX, FALSE);
    }
    else if (1 == argc)
    {
        if (CLI_CLI_STR_EQUAL("mcast", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MCAST, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("brguc", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_BRGUC, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ipuc", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_IPUC, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("mpls", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MPLS, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ecmp", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_ECMP, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("iloop", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_ILOOP, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("rspan", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_RSPAN, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("downmep", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_DOWNMEP, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ip-tunnel", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_IP_TUNNEL, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("detail", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MAX, TRUE);
        }
        else
        {
            ctc_cli_out("Invalid Nexthop Type Input\n");
        }
    }
    else if (2 == argc)
    {
        if (CLI_CLI_STR_EQUAL("mcast", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MCAST, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("brguc", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_BRGUC, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ipuc", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_IPUC, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("mpls", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_MPLS, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ecmp", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_ECMP, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("rspan", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_RSPAN, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("downmep", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_DOWNMEP, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ip-tunnel", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_IP_TUNNEL, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("iloop", 0))
        {
            ret = sys_humber_nh_dump_all(CLI_HUMBER_NH_TYPE_ILOOP, TRUE);
        }
        else
        {
            ctc_cli_out("Invalid Nexthop Type Input\n");
        }
    }
    else
    {
        ctc_cli_out("%% Invalid input parameters\n");
    }

    if (ret)
    {
        ctc_cli_out("%% Dump nexthop fail\n");
    }

    return ret;

}

CTC_CLI(ctc_cli_hb_nexthop_show_global_offset,
        ctc_cli_hb_nexthop_show_global_offset_cmd,
        "show nexthop info global-offset",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "Nexthop information",
        "Global dynamic sram(Global DsNexthop and Global DsMet) offset allocation information")
{
    return sys_humber_nh_display_current_global_sram_info();
}

CTC_CLI(ctc_cli_hb_add_mpls_switch_nexthop,
        ctc_cli_hb_nh_add_mpls_switch_nexthop_cmd,
        "nexthop add mpls NHID (dsnh-offset OFFSET |) dsnh8w switch (port GPORT_ID vpls-port VPLS_PPRT)",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ADD_STR,
        CTC_CLI_NH_MPLS_STR,
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_DSNH_OFFSET_STR,
        CTC_CLI_NH_DSNH_OFFSET_VALUE_STR,
        "Use DsNexthop8W table, default use DsNexthop4W table",
        "Mpls switch nexthop",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPORT_ID_DESC,
        "MPLS vpls port check enable",
        "MPLS vpls port value <0-8191>")
{

    int32 ret  = CLI_SUCCESS;
    uint32 nhid, dsnh_offset = 0;
    uint8 tmp_argi = 0;
    ctc_mpls_nexthop_switch_param_s nhinfo;
    ctc_mpls_nexthop_param_t nh_param = {0};

    sal_memset(&nhinfo, 0, sizeof(ctc_mpls_nexthop_switch_param_s));
    CTC_CLI_GET_UINT32_RANGE("Nexthop ID", nhid, argv[0], 0, CTC_MAX_UINT32_VALUE);

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("dsnh-offset");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_GET_UINT32_RANGE("dsnh_offset", dsnh_offset, argv[tmp_argi + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("port");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_GET_UINT16_RANGE("gport", nhinfo.gport, argv[tmp_argi + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("vpls-port");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_GET_UINT16_RANGE("logic port", nh_param.logic_port, argv[tmp_argi + 1], 0, CTC_MAX_UINT16_VALUE);
    }
    /*dsnh8w is parameter*/
    nh_param.logic_port_valid = TRUE;

    nh_param.nh_prop = CTC_MPLS_NH_SWITCH_TYPE;
    nh_param.dsnh_offset = dsnh_offset;
    nh_param.nh_para.nh_param_switch = nhinfo;
    ret = ctc_nh_add_mpls(nhid, &nh_param);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}
static INLINE int32
_ctc_nexthop_cli_parse_mpls_push_nexthop(char** argv, uint16 argc,
                                         ctc_mpls_nexthop_push_param_t* p_nhinfo)
{
    uint8 tmp_argi, arrayi = 0;
    uint8 label_num = 0;
    int ret = CLI_SUCCESS;
    mac_addr_t mac;

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("mac");
    if (0xFF != tmp_argi)
    {

        /*mac MAC (sub-if port GPORT_ID vlan VLAN_ID | vlan-if vlan VLAN_ID port GPORT_ID | routed-port GPORT_ID) payload-op (op-none|op-route|op-l2vpn ...*/
        CTC_CLI_GET_MAC_ADDRESS("mac address", mac, argv[tmp_argi + 1]);

        sal_memcpy(p_nhinfo->nh_com.mac, mac, sizeof(mac_addr_t));
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("op-none");
    if (0xFF != tmp_argi)
    {
        p_nhinfo->nh_com.opcode = CTC_MPLS_NH_PUSH_OP_NONE;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("op-route");
    if (0xFF != tmp_argi)
    {
        p_nhinfo->nh_com.opcode = CTC_MPLS_NH_PUSH_OP_ROUTE;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("op-l2vpn");
    if (0xFF != tmp_argi)
    {
        p_nhinfo->nh_com.opcode = CTC_MPLS_NH_PUSH_OP_L2VPN;
        ret = _ctc_vlan_parser_egress_vlan_edit(&p_nhinfo->nh_com.vlan_info, &argv[tmp_argi], (argc - tmp_argi));

    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("martini-cw");
    if (0xFF != tmp_argi)
    {
        p_nhinfo->martini_encap_valid = TRUE;
        tmp_argi = CTC_CLI_GET_ARGC_INDEX("no-seq");
        if (0xFF != tmp_argi)
        {
            p_nhinfo->seq_num_type = CTC_MPLS_NH_MARTINI_SEQ_NONE;
        }

        tmp_argi = CTC_CLI_GET_ARGC_INDEX("per-pw-seq");
        if (0xFF != tmp_argi)
        {
            p_nhinfo->seq_num_type = CTC_MPLS_NH_MARTINI_SEQ_PER_PW;
            CTC_CLI_GET_INTEGER("Martini label, per pw sequence number", p_nhinfo->seq_num_index, argv[(tmp_argi + 2)]);
        }

        tmp_argi = CTC_CLI_GET_ARGC_INDEX("glb-seq0");
        if (0xFF != tmp_argi)
        {
            p_nhinfo->seq_num_type = CTC_MPLS_NH_MARTINI_SEQ_GLB_TYPE0;
        }

        tmp_argi = CTC_CLI_GET_ARGC_INDEX("glb-seq1");
        if (0xFF != tmp_argi)
        {
            p_nhinfo->seq_num_type = CTC_MPLS_NH_MARTINI_SEQ_GLB_TYPE1;
        }
    }
    else
    {
        CTC_CLI_NH_PARSE_MPLS_LABEL_PARAM(p_nhinfo->push_label[arrayi], tmp_argi,  "label1", "map-ttl1", "is-mcast1");
    }

    CTC_CLI_NH_PARSE_MPLS_LABEL_PARAM((p_nhinfo->push_label[arrayi]), tmp_argi,  "label2", "map-ttl2", "is-mcast2");
    CTC_CLI_NH_PARSE_MPLS_LABEL_PARAM((p_nhinfo->push_label[arrayi]), tmp_argi,  "label3", "map-ttl3", "is-mcast3");
    CTC_CLI_NH_PARSE_MPLS_LABEL_PARAM((p_nhinfo->push_label[arrayi]), tmp_argi,  "label4", "map-ttl4", "is-mcast4");
    p_nhinfo->label_num = label_num;

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("sub-if");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_NH_PARSE_L3IF(tmp_argi, p_nhinfo->nh_com.oif.gport, p_nhinfo->nh_com.oif.vid, p_nhinfo->nh_com.oif.oif_type);
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("vlan-if");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_NH_PARSE_L3IF(tmp_argi, p_nhinfo->nh_com.oif.gport, p_nhinfo->nh_com.oif.vid, p_nhinfo->nh_com.oif.oif_type);
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("routed-port");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_NH_PARSE_L3IF(tmp_argi, p_nhinfo->nh_com.oif.gport, p_nhinfo->nh_com.oif.vid, p_nhinfo->nh_com.oif.oif_type);
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_nh_add_mpls_push_nexthop,
        ctc_cli_hb_nh_add_mpls_push_nexthop_cmd,
        "nexthop add mpls NHID (dsnh-offset OFFSET|) push (unrov|fwd ((is-hvpls|) vpls-port LOGIC_PORT|) ("CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR "))",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ADD_STR,
        CTC_CLI_NH_MPLS_STR,
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_DSNH_OFFSET_STR,
        CTC_CLI_NH_DSNH_OFFSET_VALUE_STR,
        "Mpls push nexthop",
        "Unresolved nexthop",
        "Forward Nexthop",
        "Enable H-VPLS in VPLS network",
        "Destination logic port in VPLS network",
        "MPLS vpls port value <0-8191>",
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid, dsnh_offset = 0, tmp_argi;
    ctc_mpls_nexthop_push_param_t nhinfo;
    ctc_mpls_nexthop_param_t nh_param = {0};

    sal_memset(&nhinfo, 0, sizeof(ctc_mpls_nexthop_push_param_t));
    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);
    tmp_argi = CTC_CLI_GET_ARGC_INDEX("dsnh-offset");
    if (0xFF != tmp_argi)
    {
        CTC_CLI_GET_UINT32("DsNexthop Table offset", dsnh_offset, argv[tmp_argi + 1]);
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("unrov");
    if (0xFF != tmp_argi)
    {
      nh_param.flag |= CTC_MPLS_NH_IS_UNRSV;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("fwd");
    if (0xFF != tmp_argi)
    {
        if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_argi]), (argc - tmp_argi), &nhinfo))
        {
            return CLI_ERROR;
        }
    }
    	tmp_argi = CTC_CLI_GET_ARGC_INDEX("is-hvpls");
    if (0xFF != tmp_argi)
    {
       nh_param.flag |= CTC_MPLS_NH_IS_HVPLS;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("vpls-port");
    if (0xFF != tmp_argi)
    {
        nh_param.logic_port_valid  = TRUE ;
        CTC_CLI_GET_UINT16("logic port", nh_param.logic_port, argv[(tmp_argi + 1)]);
    }
    nh_param.nh_prop = CTC_MPLS_NH_PUSH_TYPE;
    nh_param.dsnh_offset = dsnh_offset;
    nh_param.nh_para.nh_param_push = nhinfo;
    ret = ctc_nh_add_mpls(nhid, &nh_param);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_nh_update_mpls_push_nexthop,
        ctc_cli_hb_nh_update_mpls_push_nexthop_cmd,
        "nexthop update mpls NHID push ( fwd-attr|unrov2fwd) ((is-hvpls|) vpls-port LOGIC_PORT|) ("CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR ")",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_UPDATE_STR,
        CTC_CLI_NH_MPLS_STR,
        CTC_CLI_NH_ID_STR,
        "Mpls push nexthop",
        "Update forward nexthop",
        "Unresolved nexthop to forward nexthop",
        "Enable H-VPLS in VPLS network",
        "Destination logic port in VPLS network",
        "MPLS vpls port value <0-8191>",
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid;
    uint8 tmp_argi;
    ctc_mpls_nexthop_push_param_t nhinfo;
    ctc_mpls_nexthop_param_t nh_param = {0};

    sal_memset(&nh_param, 0, sizeof(nh_param));
    sal_memset(&nhinfo, 0, sizeof(ctc_mpls_nexthop_push_param_t));
    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);

    if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[1]), (argc - 1), &nhinfo))
    {
        return CLI_ERROR;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("unrov2fwd");
    if (0xFF != tmp_argi)
    {
        nh_param.upd_type  = CTC_NH_UPD_UNRSV_TO_FWD;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("fwd-attr");
    if (0xFF != tmp_argi)
    {
        nh_param.upd_type  = CTC_NH_UPD_FWD_ATTR;

    }
   	tmp_argi = CTC_CLI_GET_ARGC_INDEX("is-hvpls");
    if (0xFF != tmp_argi)
    {
       nh_param.flag |= CTC_MPLS_NH_IS_HVPLS;
    }

    tmp_argi = CTC_CLI_GET_ARGC_INDEX("vpls-port");
    if (0xFF != tmp_argi)
    {
        nh_param.logic_port_valid  = TRUE ;
        CTC_CLI_GET_UINT16("logic port", nh_param.logic_port, argv[(tmp_argi + 1)]);
    }
    nh_param.nh_prop = CTC_MPLS_NH_PUSH_TYPE;
    nh_param.nh_para.nh_param_push = nhinfo;
    ret = ctc_nh_update_mpls(nhid, &nh_param);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_nh_add_aps_mpls_push_nexthop,
        ctc_cli_hb_nh_add_aps_mpls_push_nexthop_cmd,
        "nexthop add aps-mpls NHID (dsnh-offset OFFSET|) (aps-bridge-id APS_BRIDGE_ID) push ((is-hvpls|) vpls-port LOGIC_PORT|) (working-path "CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR " )" \
        "(protection-path "CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR " )",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ADD_STR,
        "APS MPLS nexthop",
        CTC_CLI_NH_ID_STR,
        CTC_CLI_NH_DSNH_OFFSET_STR,
        CTC_CLI_NH_DSNH_OFFSET_VALUE_STR,
        CTC_CLI_APS_BRIDGE_ID_STR,
        CTC_CLI_APS_BRIDGE_ID_DESC,
        "Mpls push nexthop",
        "Enable H-VPLS in VPLS network",
        "Destination logic port in VPLS network",
        "MPLS vpls port value <0-8191>",
        CTC_CLI_NH_APS_WORKING_PATH_DESC,
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC,
        CTC_CLI_NH_APS_PROTECTION_PATH_DESC,
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid, dsnh_offset = 0, tmp_arg_w, tmp_arg_p, aps_bridge_id;
    ctc_mpls_nexthop_push_param_t nhinfo_w, nhinfo_p;
    ctc_mpls_nexthop_param_t nh_param = {0};

    sal_memset(&nhinfo_w, 0, sizeof(ctc_mpls_nexthop_push_param_t));
    sal_memset(&nhinfo_p, 0, sizeof(ctc_mpls_nexthop_push_param_t));

    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);

    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("dsnh-offset");
    if (0xFF != tmp_arg_w)
    {
        CTC_CLI_GET_UINT32_RANGE("dsnh_offset", dsnh_offset, argv[tmp_arg_w + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    /*2. APS Bridge ID*/
    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("aps-bridge-id");
    if (0xFF == tmp_arg_w)
    {
        ctc_cli_out("Invalid input\n");
    }

    CTC_CLI_GET_UINT32("APS bridge id", aps_bridge_id, argv[(tmp_arg_w + 1)]);
   	tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("is-hvpls");
    if (0xFF != tmp_arg_w)
    {
       nh_param.flag |= CTC_MPLS_NH_IS_HVPLS;
    }

    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("vpls-port");
    if (0xFF != tmp_arg_w)
    {
        nh_param.logic_port_valid  = TRUE ;
        CTC_CLI_GET_UINT16("logic port", nh_param.logic_port, argv[(tmp_arg_w + 1)]);
    }
    /*3. Working path*/
    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("working-path");
    if (0xFF == tmp_arg_w)
    {
        ctc_cli_out("Invalid input\n");
    }
    else
    {
        /*4. Protection path*/
        tmp_arg_p = CTC_CLI_GET_ARGC_INDEX("protection-path");
        if (0xFF == tmp_arg_p)
        {
            /*.parser working path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_w ]), (argc - tmp_arg_w), &nhinfo_w))
            {
                return CLI_ERROR;
            }
        }
        else
        {
            /*.parser working path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_w ]), (tmp_arg_p - tmp_arg_w), &nhinfo_w))
            {
                return CLI_ERROR;
            }

            /*.parser protection path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_p ]), (argc - tmp_arg_p), &nhinfo_p))
            {
                return CLI_ERROR;
            }
        }
    }

    nh_param.nh_prop = CTC_MPLS_NH_PUSH_TYPE;
    nh_param.aps_en  = TRUE;
    nh_param.dsnh_offset = dsnh_offset;
    nh_param.aps_bridge_group_id = aps_bridge_id;
    nh_param.nh_para.nh_param_push = nhinfo_w;
    nh_param.nh_p_para.nh_p_param_push = nhinfo_p;
    ret = ctc_nh_add_mpls(nhid, &nh_param);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_nh_update_aps_mpls_push_nexthop,
        ctc_cli_hb_nh_update_aps_mpls_push_nexthop_cmd,
        "nexthop update aps-mpls NHID aps-bridge-id APS_BRIDGE_ID push ((is-hvpls|) vpls-port LOGIC_PORT|) (working-path "CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR "" \
        "(protection-path "CTC_CLI_NH_MPLS_PUSH_NH_PARAM_STR "",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_UPDATE_STR,
        "APS MPLS nexthop",
        CTC_CLI_NH_ID_STR,
        CTC_CLI_APS_BRIDGE_ID_STR,
        CTC_CLI_APS_BRIDGE_ID_DESC,
        "Mpls push nexthop",
        "Enable H-VPLS in VPLS network",
        "Destination logic port in VPLS network",
        "MPLS vpls port value <0-8191>",
        CTC_CLI_NH_APS_WORKING_PATH_DESC,
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC,
        CTC_CLI_APS_BRIDGE_ID_DESC,
        CTC_CLI_NH_APS_PROTECTION_PATH_DESC,
        CTC_CLI_NH_MPLS_PUSH_NH_PARAM_DESC)
{
    int32 ret  = CLI_SUCCESS;
    uint32 nhid, dsnh_offset = 0, tmp_arg_w, tmp_arg_p, aps_bridge_id;
    ctc_mpls_nexthop_push_param_t nhinfo_w, nhinfo_p;
    ctc_mpls_nexthop_param_t nh_param = {0};

    sal_memset(&nhinfo_w, 0, sizeof(ctc_mpls_nexthop_push_param_t));
    sal_memset(&nhinfo_p, 0, sizeof(ctc_mpls_nexthop_push_param_t));

    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);

    CTC_CLI_GET_UINT32("APS bridge id", aps_bridge_id, argv[1]);
   	tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("is-hvpls");
    if (0xFF != tmp_arg_w)
    {
       nh_param.flag |= CTC_MPLS_NH_IS_HVPLS;
    }

    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("vpls-port");
    if (0xFF != tmp_arg_w)
    {
        nh_param.logic_port_valid  = TRUE ;
        CTC_CLI_GET_UINT16("logic port", nh_param.logic_port, argv[(tmp_arg_w + 1)]);
    }
    /*3. Working path*/
    tmp_arg_w = CTC_CLI_GET_ARGC_INDEX("working-path");
    if (0xFF == tmp_arg_w)
    {
        ctc_cli_out("Invalid input\n");
    }
    else
    {
        /*4. Protection path*/
        tmp_arg_p = CTC_CLI_GET_ARGC_INDEX("protection-path");
        if (0xFF == tmp_arg_p)
        {
            /*.parser working path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_w ]), (argc - tmp_arg_w), &nhinfo_w))
            {
                return CLI_ERROR;
            }
        }
        else
        {
            /*.parser working path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_w ]), (tmp_arg_p - tmp_arg_w), &nhinfo_w))
            {
                return CLI_ERROR;
            }

            /*.parser protection path param*/
            if (_ctc_nexthop_cli_parse_mpls_push_nexthop(&(argv[tmp_arg_p ]), (argc - tmp_arg_p), &nhinfo_p))
            {
                return CLI_ERROR;
            }
        }
    }

    nh_param.upd_type  = CTC_NH_UPD_FWD_ATTR;
    nh_param.nh_prop = CTC_MPLS_NH_PUSH_TYPE;
    nh_param.aps_en  = TRUE;
    nh_param.dsnh_offset = dsnh_offset;
    nh_param.aps_bridge_group_id = aps_bridge_id;
    nh_param.nh_para.nh_param_push = nhinfo_w;
    nh_param.nh_p_para.nh_p_param_push = nhinfo_p;
    ret = ctc_nh_update_mpls(nhid, &nh_param);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

int32
ctc_humber_nexthop_cli_init(void)
{

    install_element(CTC_SDK_MODE, &ctc_cli_l2_add_flex_nh_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_l2_remove_flex_nh_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nh_add_mpls_switch_nexthop_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_hb_nh_add_mpls_push_nexthop_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nh_update_mpls_push_nexthop_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nh_add_aps_mpls_push_nexthop_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nh_update_aps_mpls_push_nexthop_cmd);

#ifdef SDK_INTERNAL_CLI_SHOW
    install_element(CTC_SDK_MODE, &ctc_cli_hb_show_nexthop_by_nhid_type_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_show_nexthop_all_by_type_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nexthop_show_global_offset_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_nexthop_show_ip_tunnel_nexthop_cmd);
#endif

    return CLI_SUCCESS;
}

