/**
 @file ctc_monitor_cli.c

 @date 2010-4-1

 @version v2.0
*/

#include "ctc_api.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_port_mapping_cli.h"
#include "ctc_monitor_cli.h"

CTC_CLI(ctc_cli_monitor_set_monitor,
        ctc_cli_monitor_set_monitor_cmd,
        "monitor (buffer|latency) (port GPORT_ID) (inform|scan|log) (enable|disable)",
        CTC_CLI_MONITOR_M_STR,
        "Buffer Monitor",
        "Latency Monitor",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Inform and generate event",
        "Scan and generate stats",
        "Log to cpu",
        "Enable",
        "Disable")
{
    int32 ret = 0;
    uint8 index = 0;
    uint16 gport = 0;
    ctc_monitor_config_t config;
    sal_memset(&config, 0, sizeof(config));

    index = CTC_CLI_GET_ARGC_INDEX("buffer");
    if (0xFF != index)
    {
        config.monitor_type = CTC_MONITOR_BUFFER;
    }
    else
    {
        config.monitor_type = CTC_MONITOR_LATENCY;
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("gport", gport, argv[index + 1]);
        config.gport = gport;
    }

    index = CTC_CLI_GET_ARGC_INDEX("inform");
    if (0xFF != index)
    {
        config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_EN;
    }


    index = CTC_CLI_GET_ARGC_INDEX("scan");
    if (0xFF != index)
    {
        config.cfg_type = CTC_MONITOR_CONFIG_MON_SCAN_EN;
    }


    index = CTC_CLI_GET_ARGC_INDEX("log");
    if (0xFF != index)
    {
        config.cfg_type = CTC_MONITOR_CONFIG_LOG_EN;
    }


    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (0xFF != index)
    {
        config.value = 1;
    }

    ret = ctc_monitor_set_config(&config);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_monitor_set_timer,
        ctc_cli_monitor_set_timer_cmd,
        "monitor (buffer|latency) (scan-interval TIMER)",
        CTC_CLI_MONITOR_M_STR,
        "Buffer Monitor",
        "Latency Monitor",
         "Scan interval",
         "Value <ms>")
{
    int32 ret = 0;
    uint8 index = 0;
    uint16 interval = 0;
    ctc_monitor_config_t config;
    sal_memset(&config, 0, sizeof(config));

    index = CTC_CLI_GET_ARGC_INDEX("buffer");
    if (0xFF != index)
    {
        config.monitor_type = CTC_MONITOR_BUFFER;
    }
    else
    {
        config.monitor_type = CTC_MONITOR_LATENCY;
    }

    index = CTC_CLI_GET_ARGC_INDEX("scan-interval");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("scan interval", interval, argv[index + 1]);
        config.value = interval;
    }

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INTERVAL;

    ret = ctc_monitor_set_config(&config);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }


    return ret;
}

CTC_CLI(ctc_cli_monitor_op_watermark,
        ctc_cli_monitor_op_watermark_cmd,
        "(show|clear) monitor (buffer|latency) (port GPORT_ID) watermark",
        "Show",
        "Clear",
        CTC_CLI_MONITOR_M_STR,
        "Buffer Monitor",
        "Latency Monitor",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Watermark")
{
    int32 ret = 0;
    ctc_monitor_watermark_t watermark;
    uint8 index = 0;
    uint16 gport = 0;
    bool  clear_op = 0;
    sal_memset(&watermark, 0, sizeof(watermark));

    index = CTC_CLI_GET_ARGC_INDEX("clear");
    if (0xFF != index)
    {
         clear_op = TRUE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("buffer");
    if (0xFF != index)
    {
        watermark.monitor_type = CTC_MONITOR_BUFFER;
    }
    else
    {
        watermark.monitor_type = CTC_MONITOR_LATENCY;
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("gport", gport, argv[index + 1]);
        watermark.gport = gport;
    }

    if (clear_op == 0)
    {
        ret = ctc_monitor_get_watermark(&watermark);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }

        if (watermark.monitor_type == CTC_MONITOR_LATENCY)
        {
            ctc_cli_out("Max Latency:%"PRIu64"ns\n", watermark.u.latency.max_latency);
        }
        else
        {
            ctc_cli_out("Max UcCnt:%d, McCnt:%d, TotoalCnt:%d\n",
                        watermark.u.buffer.max_uc_cnt,
                        watermark.u.buffer.max_mc_cnt,
                        watermark.u.buffer.max_total_cnt);
        }
    }
    else
    {
        ret = ctc_monitor_clear_watermark(&watermark);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return ret;
}

CTC_CLI(ctc_cli_monitor_set_inform_thrd,
        ctc_cli_monitor_set_inform_thrd_cmd,
        "monitor (buffer|latency) (port GPORT_ID) (inform-thrd MIN MAX) ",
        CTC_CLI_MONITOR_M_STR,
        "Buffer Monitor",
        "Latency Monitor",
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPHYPORT_ID_DESC,
        "Inform when greater or less than threshold",
        "Min value , for buffer is buffer cell <0-0xFFFF> and 16 multiple(such as 0,16,32,...), for latency is level <0-7>",
        "Max value , for buffer is buffer cell <0-0xFFFF> and 16 multiple(such as 0,16,32,...), for latency is level <0-7>")
{
    int32 ret = 0;
    uint8 index = 0;
    uint16 gport = 0;
    uint32 min_value = 0;
    uint32 max_value = 0;
    ctc_monitor_config_t config;
    sal_memset(&config, 0, sizeof(config));


    index = CTC_CLI_GET_ARGC_INDEX("buffer");
    if (0xFF != index)
    {
        config.monitor_type = CTC_MONITOR_BUFFER;
    }
    else
    {
        config.monitor_type = CTC_MONITOR_LATENCY;
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("gport", gport, argv[index + 1]);
        config.gport = gport;
    }

    index = CTC_CLI_GET_ARGC_INDEX("inform-thrd");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("min", min_value, argv[index + 1]);
        CTC_CLI_GET_UINT16("man", max_value, argv[index + 2]);
    }

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MIN;
    config.value = min_value;
    ret = ctc_monitor_set_config(&config);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MAX;
    config.value = max_value;
    ret = ctc_monitor_set_config(&config);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_monitor_set_latency_log_level,
        ctc_cli_monitor_set_latency_log_level_cmd,
        "monitor (latency) (port GPORT_ID) (log-level LEVEL) ",
        CTC_CLI_MONITOR_M_STR,
        "Latency Monitor",
        "Global physical port",
        CTC_CLI_GPHYPORT_ID_DESC,
        "Log level",
        "Value <0-7>"
        )
{
    int32 ret = 0;
    uint8 index = 0;
    uint16 gport = 0;
    uint32 level = 0;
    ctc_monitor_config_t config;
    sal_memset(&config, 0, sizeof(config));

    config.monitor_type = CTC_MONITOR_LATENCY;

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("gport", gport, argv[index + 1]);
        config.gport = gport;
    }

    index = CTC_CLI_GET_ARGC_INDEX("log-level");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("min", level, argv[index + 1]);
    }

    config.cfg_type = CTC_MONITOR_CONFIG_LOG_THRD_LEVEL;
    config.value = level;
    ret = ctc_monitor_set_config(&config);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}




CTC_CLI(ctc_cli_monitor_set_latency_level_thrd,
        ctc_cli_monitor_set_latency_level_thrd_cmd,
        "monitor latency level-thrd THRD0 THRD1 THRD2 THRD3 THRD4 THRD5 THRD6 THRD7",
        CTC_CLI_MONITOR_M_STR,
        "Latency Monitor",
        "Threshold zone",
        "Level 0 threshold, <0-0xFFF>",
        "Level 1 threshold, <0-0xFFF>",
        "Level 2 threshold, <0-0xFFF>",
        "Level 3 threshold, <0-0xFFF>",
        "Level 4 threshold, <0-0xFFF>",
        "Level 5 threshold, <0-0xFFF>",
        "Level 6 threshold, <0-0xFFF>",
        "Level 7 threshold, <0-0xFFF>"
        )
{

    int32 ret = 0;
    uint8 level = 0;
    uint32 value = 0;
    ctc_monitor_glb_cfg_t config;
    sal_memset(&config, 0, sizeof(config));

    config.cfg_type = CTC_MONITOR_GLB_CONFIG_LATENCY_THRD;

    for (level = 0; level < 8; level++)
    {
        CTC_CLI_GET_UINT16("thrd", value, argv[level]);
        config.u.thrd.level = level;
        config.u.thrd.threshold = value;

        ret = ctc_monitor_set_global_config(&config);
        if (ret < 0)
        {
            ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_monitor_set_buffer_log_mode,
        ctc_cli_monitor_set_buffer_log_mode_cmd,
        "monitor buffer log-mode (causer|victim)",
        CTC_CLI_MONITOR_M_STR,
        "Buffer Monitor",
        "Buffer log mode",
        "Log packets which genrate buffer congestion",
        "Log congestion packets "

        )
{

    int32 ret = 0;
    uint8 index = 0;
    ctc_monitor_glb_cfg_t config;
    sal_memset(&config, 0, sizeof(config));

    config.cfg_type = CTC_MONITOR_GLB_CONFIG_BUFFER_LOG_MODE;

    index = CTC_CLI_GET_ARGC_INDEX("causer");
    if (0xFF != index)
    {
        config.u.value = 0;
    }

    index = CTC_CLI_GET_ARGC_INDEX("victim");
    if (0xFF != index)
    {
        config.u.value = 1;
    }

    ret = ctc_monitor_set_global_config(&config);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_monitor_show_port,
        ctc_cli_monitor_show_port_cmd,
        "show monitor port GPORT_ID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MONITOR_M_STR,
        CTC_CLI_GPORT_DESC,
        CTC_CLI_GPHYPORT_ID_DESC
        )
{
    int32 ret = CLI_SUCCESS;
    uint16 gport = 0;
    ctc_monitor_watermark_t watermark;
    ctc_monitor_config_t config;

    sal_memset(&config, 0, sizeof(config));
    sal_memset(&watermark, 0, sizeof(watermark));

    CTC_CLI_GET_UINT16("port", gport, argv[0]);
    config.gport = gport;
    watermark.gport = gport;

    ctc_cli_out("----------------------------------------\n");
    ctc_cli_out("Buffer Monitor:\n");
    ctc_cli_out("----------------------------------------\n");
    config.monitor_type = CTC_MONITOR_BUFFER;
    watermark.monitor_type = CTC_MONITOR_BUFFER;

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_EN;
    ret = ctc_monitor_get_config(&config);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    ctc_cli_out("%-15s :%-10d\n", "inform en", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MIN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "inform min", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MAX;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "inform max", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_SCAN_EN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "scan en", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_LOG_EN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "log en", config.value);

    CTC_CLI_ERROR_RETURN(ctc_monitor_get_watermark(&watermark));
    ctc_cli_out("%-15s :%-10d\n", "max buffer", watermark.u.buffer.max_total_cnt);


    ctc_cli_out("\n----------------------------------------\n");
    ctc_cli_out("Latency Monitor:\n");
    ctc_cli_out("----------------------------------------\n");
    config.monitor_type = CTC_MONITOR_LATENCY;
    watermark.monitor_type = CTC_MONITOR_LATENCY;

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_EN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "inform en", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MIN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "inform min", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_INFORM_MAX;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "inform max", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_MON_SCAN_EN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "scan en", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_LOG_EN;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "log en", config.value);

    config.cfg_type = CTC_MONITOR_CONFIG_LOG_THRD_LEVEL;
    CTC_CLI_ERROR_RETURN(ctc_monitor_get_config(&config));
    ctc_cli_out("%-15s :%-10d\n", "log level", config.value);

    CTC_CLI_ERROR_RETURN(ctc_monitor_get_watermark(&watermark));
    ctc_cli_out("%-15s :%-10d\n", "max latency", watermark.u.latency.max_latency);

    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_monitor_debug_on,
        ctc_cli_monitor_debug_on_cmd,
        "debug monitor (ctc|sys) (debug-level {func|param|info|error|export} |) (log LOG_FILE |)",
        CTC_CLI_DEBUG_STR,
        "Monitor module",
        "CTC layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR,
        CTC_CLI_DEBUG_LEVEL_EXPORT,
        CTC_CLI_DEBUG_MODE_LOG,
        CTC_CLI_LOG_FILE)
{

    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR|CTC_DEBUG_LEVEL_EXPORT;
    uint8 index = 0;
    char file[MAX_FILE_NAME_SIZE];

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }

        index = CTC_CLI_GET_ARGC_INDEX("export");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_EXPORT;
        }

    }

    index = CTC_CLI_GET_ARGC_INDEX("log");
    if (index != 0xFF)
    {
        sal_strcpy((char*)&file, argv[index + 1]);
        level |= CTC_DEBUG_LEVEL_LOGFILE;
        ctc_debug_set_log_file("monitor", "monitor", (void*)&file, 1);
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = MONITOR_CTC;
    }
    else
    {
        typeenum = MONITOR_SYS;

    }

    ctc_debug_set_flag("monitor", "monitor", typeenum, level, TRUE);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_monitor_debug_off,
        ctc_cli_monitor_debug_off_cmd,
        "no debug monitor (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        "Monitor Module",
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = MONITOR_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = MONITOR_SYS;
    }

    ctc_debug_set_flag("monitor", "monitor", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_monitor_show_debug,
        ctc_cli_monitor_show_debug_cmd,
        "show debug monitor (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_DEBUG_STR,
        "Monitor Module",
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = MONITOR_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = MONITOR_SYS;
    }

    ctc_cli_out("Monitor:%s debug %s level:%s\n", argv[0],
                (ctc_debug_get_flag("monitor", "monitor", typeenum, &level) == TRUE) ? "on" : "off",
                ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

int32
ctc_monitor_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_monitor_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_timer_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_op_watermark_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_inform_thrd_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_latency_level_thrd_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_buffer_log_mode_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_set_latency_log_level_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_show_debug_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_monitor_show_port_cmd);

    return CLI_SUCCESS;
}


