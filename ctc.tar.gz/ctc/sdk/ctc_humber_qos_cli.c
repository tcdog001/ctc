/**
 @date 2009-12-22

 @version v2.0

---file comments----
*/

/****************************************************************************
 *
 * Header files
 *
 *****************************************************************************/
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_api.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_qos_cli.h"

#include "sys_humber_stats.h"
#include "sys_humber_queue_enq.h"
#include "ctc_port_mapping_cli.h"
/****************************************************************************
 *
 * Function
 *
 *****************************************************************************/

extern int32 sys_humber_qos_class_init(void);

CTC_CLI(ctc_cli_hb_qos_use_default_domain,
        ctc_cli_hb_qos_use_default_domain_cmd,
        "qos domain default",
        CTC_CLI_QOS_STR,
        "QoS domain",
        "Default value")
{
    int32 ret = CLI_SUCCESS;

    ret = sys_humber_qos_class_init();
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_hb_qos_show_fabric_traffic_stats,
        ctc_cli_hb_qos_show_fabric_traffic_stats_cmd,
        "show qos fabric lchip CHIP tx-stats dest-gchip CHIP",
        CTC_CLI_SHOW_STR,
        CTC_CLI_QOS_STR,
        "Fabric",
        "Local chip",
        "<0-1>",
        "Fabric tx stats",
        "Dest gchip id",
        "<0-15>")
{
    uint8 lchip = 0, lchip_num = 0;
    uint32 target_chipid = 0;
    int i;
    uint16 queue_id;
    sys_stats_queue_t stats;
    char s_byte[UINT64_STR_LEN];
    uint64 drop_pkts;
    uint64 drop_bytes;
    uint64 deq_pkts;
    uint64 deq_bytes;
    int32 ret = 0;

    ctc_get_local_chip_num(&lchip_num);
    lchip = ctc_cmd_str2uint(argv[0], &ret);
    if (lchip >= lchip_num)
    {
        ctc_cli_out("Invalid lchip!\n");
        return CLI_ERROR;
    }

    target_chipid = ctc_cmd_str2uint(argv[1], &ret);
    drop_pkts = 0;
    drop_bytes = 0;
    deq_pkts = 0;
    deq_bytes = 0;

    for (i = 0; i < 4; i++)
    {
        ret = sys_humber_queue_get_queue_id(CTC_QUEUE_TYPE_FABRIC, target_chipid, i, &queue_id);
        if (ret < 0)
        {
            ctc_cli_out("ret = %d, %s\n", ret, ctc_get_error_desc(ret));
            return CLI_ERROR;
        }

        sys_humber_stats_get_queue_stats(lchip, queue_id, &stats);
        drop_pkts += stats.queue_drop_pkts;
        drop_bytes += stats.queue_drop_bytes;
        deq_pkts += stats.queue_deq_pkts;
        deq_bytes += stats.queue_deq_bytes;
    }

    ctc_cli_out("To chip %d fabric statistics:\n", target_chipid);
    ctc_uint64_to_str(drop_pkts, s_byte);
    ctc_cli_out("    Dropped packets:%s ,", s_byte);
    ctc_uint64_to_str(drop_bytes, s_byte);
    ctc_cli_out("Dropped bytes:%s\n", s_byte);
    ctc_uint64_to_str(deq_pkts, s_byte);
    ctc_cli_out("    Transmitted packets:%s ,", s_byte);
    ctc_uint64_to_str(deq_bytes, s_byte);
    ctc_cli_out("Transmitted bytes:%s\n", s_byte);

    return CLI_SUCCESS;
}

int32
ctc_humber_qos_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_hb_qos_use_default_domain_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_hb_qos_show_fabric_traffic_stats_cmd);

    return 0;
}

