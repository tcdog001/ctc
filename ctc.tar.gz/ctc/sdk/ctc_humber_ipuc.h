/**
 @file ctc_humber_ipuc.h

 @author Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-12-07

 @version v2.0

 This file define ctc functions of SDK
*/

#ifndef _CTC_HUMBER_IPUC_H
#define _CTC_HUMBER_IPUC_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_const.h"
#include "ctc_ipuc.h"
#include "ctc_nexthop.h"
/****************************************************************
*
* Defines and Macros
*
****************************************************************/

/****************************************************************
 *
* Function
*
****************************************************************/
/**
 @addtogroup ipuc IPUC
 @{
*/

/**
 @brief Initialize the IPUC module

 @param[in] lchip    local chip id

 @param[in] ipuc_global_cfg ipuc module global config

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_init(uint8 lchip, void* ipuc_global_cfg);

/**
 @brief Add a route entry

 @param[in] lchip    local chip id

 @param[in] p_ipuc_param Data of the ipuc entry

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_add(uint8 lchip, ctc_ipuc_param_t* p_ipuc_param);

/**
 @brief Remove a route entry

 @param[in] lchip    local chip id

 @param[in] p_ipuc_info Data of the ipuc entry, route_flag no need to specified

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_remove(uint8 lchip, ctc_ipuc_param_t* p_ipuc_param);

/**
 @brief Add the default route entrys for both ipv4 and ipv6, default routes should be installed before using ipuc function

 @param[in] lchip    local chip id

 @param[in] ip_ver ip version of the default route

 @param[in] nh_id Nexthop ID of the default route

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_add_default_entry(uint8 lchip, uint8 ip_ver, uint32 nh_id);

/**
 @brief Add an IP-Tunnel route entry

 @param[in] lchip    local chip id

 @param[in] p_ipuc_tunnel_param Data of the ipuc entry

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_add_tunnel(uint8 lchip, ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param);

/**
 @brief Remove a route entry

 @param[in] lchip    local chip id

 @param[in] p_ipuc_tunnel_param Data of the ipuc entry, route_flag no need to specified

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_remove_tunnel(uint8 lchip, ctc_ipuc_tunnel_param_t* p_ipuc_tunnel_param);

/**
 @brief Enable or disable the ipv6 function

 @param[in] lchip    local chip id

 @param[in] enable TRUE or FALSE

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_ipv6_enable(uint8 lchip, bool enable);

/**
 @brief Enable or disable the cpu rpf check function

 @param[in] lchip    local chip id

 @param[in] enable TRUE or FALSE

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_cpu_rpf_check(uint8 lchip, bool enable);

/**
 @brief Config route behavior, such as ttl limit, mcast address check, etc.

 @param[in] lchip    local chip id

 @param[in] p_route_ctl_info Structure of input information

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_set_route_ctl(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop);

/**
 @brief Config lookup behavior, such as ipsa lookup etc.

 @param[in] lchip    local chip id

 @param[in] p_lookup_ctl_info Structure of input information

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_set_lookup_ctl(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop);

/**
 @brief set global property for ipuc module

 @param[in] lchip    local chip id

 @param[in] p_global_prop the property should be set

 @return CTC_E_XXX

*/
extern int32
ctc_humber_ipuc_set_global_property(uint8 lchip, ctc_ipuc_global_property_t* p_global_prop);

/**@} end of @addgroup   */

#ifdef __cplusplus
}
#endif

#endif

