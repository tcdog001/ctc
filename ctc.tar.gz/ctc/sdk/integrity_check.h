#ifndef _CTC_DBG_TOOL_INT_CHK_H_
#define _CTC_DBG_TOOL_INT_CHK_H_

int32 integrity_check(uint8 chip_id, char*result_file);

#endif
