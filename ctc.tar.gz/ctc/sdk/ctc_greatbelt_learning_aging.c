/**
 @file ctc_greatbelt_learning_aging.c

 @date 2010-3-16

 @version v2.0

---file comments----
*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "ctc_const.h"
#include "ctc_error.h"

#include "ctc_learning_aging.h"
#include "sys_greatbelt_learning_aging.h"

/***************************************
 Learning Module's HUMBER API Interfaces
*****************************************/

int32
ctc_greatbelt_set_learning_action(uint8 lchip, ctc_learning_action_info_t* p_learning_action)
{
    CTC_ERROR_RETURN(sys_greatbelt_learning_set_action(p_learning_action));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_get_learning_action(uint8 lchip, ctc_learning_action_info_t* p_learning_action)
{
    CTC_ERROR_RETURN(sys_greatbelt_learning_get_action(p_learning_action));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_learning_get_cache_entry_valid_bitmap(uint8 lchip, uint16* entry_vld_bitmap)
{
    CTC_ERROR_RETURN(sys_greatbelt_learning_get_cache_entry_valid_bitmap(lchip, entry_vld_bitmap));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_learning_clear_learning_cache(uint8 lchip, uint16 entry_vld_bitmap)
{
    CTC_ERROR_RETURN(sys_greatbelt_learning_clear_learning_cache(lchip, entry_vld_bitmap));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_learning_read_learning_cache(uint8 lchip,
                                           uint16 entry_vld_bitmap,
                                           ctc_learning_cache_t* l2_lc)
{
    CTC_ERROR_RETURN(sys_greatbelt_learning_read_learning_cache(lchip, entry_vld_bitmap, l2_lc));
    return CTC_E_NONE;
}

/***************************************
 Aging Module's HUMBER API Interfaces
*****************************************/

int32
ctc_greatbelt_aging_set_property(uint8 lchip, ctc_aging_table_type_t  tbl_type, ctc_aging_prop_t aging_prop, uint32 value)
{
    CTC_ERROR_RETURN(sys_greatbelt_aging_set_property(tbl_type, aging_prop, value));

    return CTC_E_NONE;
}

int32
ctc_greatbelt_aging_get_property(uint8 lchip, ctc_aging_table_type_t  tbl_type, ctc_aging_prop_t aging_prop, uint32* value)
{
    CTC_ERROR_RETURN(sys_greatbelt_aging_get_property(tbl_type, aging_prop, value));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_aging_read_aging_fifo(uint8 lchip,
                                    ctc_aging_fifo_info_t* fifo_info_ptr)
{
    CTC_ERROR_RETURN(sys_greatbelt_aging_read_aging_fifo(lchip, fifo_info_ptr));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_learning_aging_init(uint8 lchip, void* global_cfg)
{
     ctc_learn_aging_global_cfg_t cfg;
     
     if(global_cfg == NULL)
     {
         sal_memset(&cfg, 0, sizeof(cfg));
         cfg.hw_mac_aging_en = 1;
         cfg.hw_mac_learn_en = 1;
         cfg.scl_aging_en    = 0;
         cfg.hw_scl_aging_en = 0;
         global_cfg = &cfg;
     }  
    CTC_ERROR_RETURN(sys_greatbelt_learning_aging_init((ctc_learn_aging_global_cfg_t*)global_cfg));
    return CTC_E_NONE;
}

