#include "drv_lib.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_dkit_common.h"
#include "ctc_dkit_cli.h"

#define DKITS_SWAP32(val) \
    ((uint32)( \
         (((uint32)(val) & (uint32)0x000000ffUL) << 24) | \
         (((uint32)(val) & (uint32)0x0000ff00UL) << 8) | \
         (((uint32)(val) & (uint32)0x00ff0000UL) >> 8) | \
         (((uint32)(val) & (uint32)0xff000000UL) >> 24)))

enum swap_direction_e
{
    HOST_TO_NETWORK,
    NETWORK_TO_HOST
};
typedef enum swap_direction_e swap_direction_t;

enum ctc_dkits_format_type_e
{
    CTC_DKITS_FORMAT_TYPE_NONE,
    CTC_DKITS_FORMAT_TYPE_1BYTE,
    CTC_DKITS_FORMAT_TYPE_2BYTE,
    CTC_DKITS_FORMAT_TYPE_4BYTE,
    CTC_DKITS_FORMAT_TYPE_NUM
};
typedef enum ctc_dkits_format_type_e ctc_dkits_format_type_t;

enum ctc_dkits_dump_tbl_diff_flag_e
{
    CTC_DKITS_DUMP_TBL_DIFF_FLAG_TBL = 1U << 0,
    CTC_DKITS_DUMP_TBL_DIFF_FLAG_KEY = 1U << 1,
    CTC_DKITS_DUMP_TBL_DIFF_FLAG_AD  = 1U << 2,
    CTC_DKITS_DUMP_TBL_DIFF_FLAG_ALL = 1U << 3
};
typedef enum ctc_dkits_dump_tbl_diff_flag_e ctc_dkits_dump_tbl_diff_flag_t;


extern host_type_t
drv_get_host_type (void);

struct ctc_dkits_dump_tbl_block_data_s
{
    uint32 entry;
    uint8  repeat;
}__attribute__((packed));
typedef struct ctc_dkits_dump_tbl_block_data_s ctc_dkits_dump_tbl_block_data_t;

struct ctc_dkits_tcam_tbl_info_s
{
    uint32                         valid;
    uint32                         tcam_type;
    tbls_id_t                      ad_tblid;
};
typedef struct ctc_dkits_tcam_tbl_info_s ctc_dkits_tcam_tbl_info_t;

extern void
ctc_dkits_dump_diff_write(tbls_id_t tblid_, uint32 idx_, uint32 bits, char* p_field_name, uint32* p_src_value, uint32* p_dst_value, sal_file_t p_wf);
extern ctc_dkit_chip_api_t* g_dkit_chip_api;

#define __INTERNAL_FUNCTION__
void
ctc_dkits_dump_swap32(uint32* data, int32 len)
{
    int32 cnt;

    for (cnt = 0; cnt < len; cnt++)
    {
        data[cnt] = DKITS_SWAP32(data[cnt]);
    }

    return;
}

static void
_ctc_dkits_dump_cfg_brief_str(char* p_str, uint8 pos, int8 extr_len)
{
    if (extr_len < 0)
    {
        return;
    }

    sal_memcpy(p_str + pos - extr_len, p_str + pos, (sal_strlen(p_str + pos) + 1));

    return;
}

static int32
_ctc_dkits_dump_evaluate_entry(uint16 word, uint32* p_entry, uint8* p_repeat)
{
    uint32 i = 0, j = 0;
    uint32 entry = 0;

    /* 4 byte repeat */
    for (i = 0; i < word; i++)
    {
        entry = *(p_entry + i);

        for (j = i + 1; j < word; j++)
        {
            if (*(p_entry + j) != entry)
            {
                break;
            }

            if (*(p_entry + j) == entry)
            {
                (*p_repeat)++;
                i++;
            }
        }
    }

    return CLI_SUCCESS;
}

void
ctc_dkits_dump_diff_status(uint8 reset, tbls_id_t* p_tblid, uint32* p_idx)
{
    static tbls_id_t lastest_tblid = MaxTblId_t;
    static uint32 lastest_tblidx = 0xFFFFFFFF;
    if (reset)
    {
        lastest_tblid = MaxTblId_t;
        lastest_tblidx = 0xFFFFFFFF;
    }
    if (NULL != p_tblid)
    {
        if (MaxTblId_t == *p_tblid)
        {
            *p_tblid = lastest_tblid;
        }
        else
        {
            lastest_tblid = *p_tblid;
        }
    }
    if  (NULL != p_idx)
    {
        if (0xFFFFFFFF == *p_idx)
        {
            *p_idx = lastest_tblidx;
        }
        else
        {
            lastest_tblidx = *p_idx;
        }
    }

    return;
}

static int32
_ctc_dkits_dump_select_format(ctc_dkits_dump_tbl_block_hdr_t* p_tbl_block_hdr, uint32* p_data_entry, uint32* p_mask_entry)
{
    uint8  repeat = 0;
    uint16 word = 0;
    uint32 tblid = CTC_DKITS_DUMP_BLOCK_HDR_TBLID(p_tbl_block_hdr);

    word = TABLE_ENTRY_SIZE(tblid) / 4;

    _ctc_dkits_dump_evaluate_entry(word, p_data_entry, &repeat);
    if (p_mask_entry)
    {
        _ctc_dkits_dump_evaluate_entry(word, p_mask_entry, &repeat);
    }

    if ((repeat * 4) > (word - repeat))
    {
        p_tbl_block_hdr->format = CTC_DKITS_FORMAT_TYPE_4BYTE;
    }
    else
    {
        p_tbl_block_hdr->format = CTC_DKITS_FORMAT_TYPE_NONE;
    }

    return CLI_SUCCESS;
}

static int32
_ctc_dkits_dump_format_entry(ctc_dkits_dump_tbl_block_hdr_t* p_tbl_block_hdr, uint32* p_entry, uint8* p_buf, uint16* p_buf_len)
{
    ctc_dkits_dump_tbl_block_data_t tbl_block_data;
    uint32 i = 0, j = 0, entry = 0;
    uint8  repeat = 0;
    uint32 tblid = CTC_DKITS_DUMP_BLOCK_HDR_TBLID(p_tbl_block_hdr);

    for (i = 0; i < TABLE_ENTRY_SIZE(tblid) / 4;)
    {
        repeat = 0;
        entry= *(p_entry + i);

        sal_memset(&tbl_block_data, 0, sizeof(ctc_dkits_dump_tbl_block_data_t));
        /* compress all zero word */
        for (j = i + 1; j < TABLE_ENTRY_SIZE(tblid) / 4; j++)
        {
            if (entry != *(p_entry + j))
            {
                break;
            }

            if (entry == *(p_entry + j))
            {
                repeat++;
            }
        }
        if (0 != repeat)
        {
            tbl_block_data.repeat = repeat;
            i = j;
        }
        else
        {
            i++;
        }
        tbl_block_data.repeat++;
        tbl_block_data.entry = entry;

        sal_memcpy(p_buf + *p_buf_len, &tbl_block_data, sizeof(ctc_dkits_dump_tbl_block_data_t));
        *p_buf_len += sizeof(ctc_dkits_dump_tbl_block_data_t);
    }

    return CLI_SUCCESS;
}

static int32
_ctc_dkits_dump_plain_entry(uint8 word, uint32* p_entry, uint8 *p_buf, uint16* p_buf_len)
{
    uint8 i = 0;

    for (i = 0; i < word; i++)
    {
        sal_memcpy(p_buf + *p_buf_len, p_entry + i, sizeof(uint32));
        *p_buf_len += sizeof(uint32);
    }

    return CLI_SUCCESS;
}

static void
 _ctc_dkits_dump_cmp_tbl_entry(ctc_dkits_dump_key_tbl_info_t* p_key_tbl_info,
                               ctc_dkits_dump_tbl_entry_t* p_src_entry,
                               ctc_dkits_dump_tbl_entry_t* p_dst_entry,
                               ctc_dkits_dump_tbl_diff_flag_t* p_diff_flag)
{
    uint32 i = 0;

    *p_diff_flag = 0;
    if (MaxTblId_t != p_key_tbl_info->tblid)
    {
        for (i = 0; i < (TABLE_ENTRY_SIZE(p_key_tbl_info->tblid) / DRV_BYTES_PER_WORD); i++)
        {
            if ((p_src_entry->data_entry[i] != p_dst_entry->data_entry[i])
               || (p_src_entry->mask_entry[i] != p_dst_entry->mask_entry[i]))
            {
                *p_diff_flag |= CTC_DKITS_DUMP_TBL_DIFF_FLAG_KEY;
            }
        }
    }
    if (MaxTblId_t != p_key_tbl_info->ad_tblid)
    {
        for (i = 0; i < (TABLE_ENTRY_SIZE(p_key_tbl_info->ad_tblid) / DRV_BYTES_PER_WORD); i++)
        {
            if (p_src_entry->ad_entry[i] != p_dst_entry->ad_entry[i])
            {
                *p_diff_flag |= CTC_DKITS_DUMP_TBL_DIFF_FLAG_AD;
            }
        }
    }

    return;
}

static void
_ctc_dkits_dump_diff_ctl(tbls_id_t tblid, uint8 tbl_type, uint32* p_line_word, uint32* p_tbl_word)
{
    if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type)
        || (CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== tbl_type)
        || (CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_type))
    {
        *p_line_word = DIFF_HASH_WORD_NUM_PER_LINE;
        *p_tbl_word = (TABLE_ENTRY_SIZE(tblid) / DRV_BYTES_PER_WORD) * 2;/* hash key&ad */
    }
    else if ((CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
            || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_type))
    {
        *p_line_word = DIFF_TCAM_WORD_NUM_PER_LINE;
        *p_tbl_word = (TABLE_ENTRY_SIZE(tblid) / DRV_BYTES_PER_WORD) * 4;/* key&mask&ad*/
    }

    return;
}

static uint32
_ctc_dkits_dump_diff_check(tbls_id_t tblid, uint8 tbl_type,
                           ctc_dkits_dump_tbl_entry_t* p_src_entry,
                           ctc_dkits_dump_tbl_entry_t* p_dst_entry)
{
    if (((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type)
       || (CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== tbl_type)
       || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)))
    {
        if ((NULL != p_src_entry) && (NULL == p_src_entry->data_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s src data is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
        if ((NULL != p_dst_entry) && (NULL == p_dst_entry->data_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s dst data is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
    }

    if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
    {
        if ((NULL != p_src_entry) && (NULL == p_src_entry->mask_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s src mask is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
        if ((NULL != p_dst_entry) && (NULL == p_dst_entry->mask_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s dst mask is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
    }

    if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_type)
       || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_type))
    {
        if ((NULL != p_src_entry) && (NULL == p_src_entry->data_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s src ad is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
        if ((NULL != p_dst_entry) && (NULL == p_dst_entry->data_entry))
        {
            CTC_DKIT_PRINT("Error, diff %s dst ad is null!\n", TABLE_NAME(tblid));
            goto CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END;
        }
    }

    return 1;

CTC_DKITS_DUMP_DIFF_CHECK_ERROR_END:

    return 0;
}

static void
_ctc_dkits_dump_diff_entry(uint32 idx, tbls_id_t tblid, uint32* p_word_idx, uint8 tbl_type,
                           ctc_dkits_dump_tbl_entry_t* p_src_entry,
                           ctc_dkits_dump_tbl_entry_t* p_dst_entry,
                           uint32** pp_entry, uint32* p_is_empty)
{
    ctc_dkits_dump_tbl_entry_t* p_cmp_entry = NULL;
    static uint32 src_data_word = 0, dst_data_word = 0, src_mask_word = 0, dst_mask_word = 0;
    static uint32 line_word = 0, tbl_word = 0, is_empty = 0;
    static uint32 alter = 0, shift = 0;
    uint32* p_data_word = NULL;
    uint32* p_mask_word = NULL;

    *p_is_empty = 0;

    if (0 == idx)
    {
        src_data_word = 0;
        dst_data_word = 0;
        src_mask_word = 0;
        dst_mask_word = 0;
        is_empty = 0;
        if ((CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
           || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_type))
        {
            alter = DIFF_TCAM_WORD_ALTER_NUM;
            shift = alter * 2;

        }
        else if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type)
                || (CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_type)
                || (CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== tbl_type))
        {
            alter = DIFF_HASH_WORD_ALTER_NUM;
            shift = alter;
        }
        _ctc_dkits_dump_diff_ctl(tblid, tbl_type, &line_word, &tbl_word);
    }

    if (0 == (idx % alter))
    {
        if (0 == ((idx / shift) % 2))
        {
            p_cmp_entry = p_src_entry;
            p_data_word = &src_data_word;
            p_mask_word = &src_mask_word;
        }
        else
        {
            p_cmp_entry = p_dst_entry;
            p_data_word = &dst_data_word;
            p_mask_word = &dst_mask_word;
        }

        if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type)
            || (CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== tbl_type)
           || (CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_type))
        {
            if (NULL != p_cmp_entry)
            {
                *p_word_idx = *p_data_word;
                *p_data_word += alter;
                *pp_entry = (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type || CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD == tbl_type) ?
                             p_cmp_entry->data_entry : p_cmp_entry->ad_entry;
            }
            else
            {
                *pp_entry = NULL;
                is_empty = 0;
            }
        }
        else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
        {
            if (NULL != p_cmp_entry)
            {
                if (0 == ((idx / alter) % 2))
                {
                    *p_word_idx = *p_data_word;
                    *p_data_word += alter;
                    *pp_entry = p_cmp_entry->data_entry;
                }
                else
                {
                    *p_word_idx = *p_mask_word;
                    *p_mask_word += alter;
                    *pp_entry = p_cmp_entry->mask_entry;
                }
            }
            else
            {
                *pp_entry = NULL;
                is_empty = 0;
            }
        }
        else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_type)
        {
            if (NULL != p_cmp_entry)
            {
                if (0 == ((idx / alter) % 2))
                {
                    *p_word_idx = *p_data_word;
                    *p_data_word += alter;
                    *pp_entry = p_cmp_entry->ad_entry;
                }
                else
                {
                    *pp_entry = NULL;
                    is_empty = 1;
                }
            }
            else
            {
                *pp_entry = NULL;
                if (0 == ((idx / alter) % 2))
                {
                    is_empty = 0;
                }
                else
                {
                    is_empty = 1;
                }
            }
        }
    }
    else
    {
        (*p_word_idx)++;
    }

    *p_is_empty = is_empty;

    return;
}

static int32
_ctc_dkits_dump_diff_field(ctc_dkits_dump_key_tbl_info_t* p_key_tbl_info, ctc_dkits_dump_tbl_entry_t* p_src_tbl, ctc_dkits_dump_tbl_entry_t* p_dst_tbl, sal_file_t p_wf)
{
    uint32 tfi = 0, fwn = 0, fvi = 0, is_diff = 0;
    uint32 src_value[MAX_ENTRY_WORD] = {0};
    uint32 dst_value[MAX_ENTRY_WORD] = {0};
    fields_t* p_fld_ptr = NULL;
    tables_info_t* p_tbl_ptr = NULL;

    p_tbl_ptr = TABLE_INFO_PTR(p_key_tbl_info->tblid);

    for (tfi = 0; tfi < TABLE_FIELD_NUM(p_key_tbl_info->tblid); tfi++)
    {
        p_fld_ptr = &(p_tbl_ptr->ptr_fields[tfi]);

        sal_memset(src_value, 0 , sizeof(src_value));
        sal_memset(dst_value, 0 , sizeof(dst_value));
        drv_get_field(p_key_tbl_info->tblid, tfi, p_src_tbl->data_entry, src_value);
        drv_get_field(p_key_tbl_info->tblid, tfi, p_dst_tbl->data_entry, dst_value);

        fwn = (CTC_DKITS_FIELD_LEN(p_fld_ptr) / (sizeof(uint32) * 8)) + ((CTC_DKITS_FIELD_LEN(p_fld_ptr) % (sizeof(uint32) * 8)) ? 1 : 0);
        for (fvi = 0; fvi < fwn; fvi++)
        {
            if (src_value[fvi] != dst_value[fvi])
            {
                is_diff = 1;
                break;
            }
        }

        if (is_diff)
        {
            is_diff = 0;
            fwn = (CTC_DKITS_FIELD_LEN(p_fld_ptr) / (sizeof(uint32) * 8)) + ((CTC_DKITS_FIELD_LEN(p_fld_ptr) % (sizeof(uint32) * 8)) ? 1 : 0);

            sal_memset(src_value, 0 , sizeof(src_value));
            sal_memset(dst_value, 0 , sizeof(dst_value));
            drv_get_field(p_key_tbl_info->tblid, tfi, p_src_tbl->data_entry, src_value);
            drv_get_field(p_key_tbl_info->tblid, tfi, p_dst_tbl->data_entry, dst_value);

            ctc_dkits_dump_diff_write(p_key_tbl_info->tblid, p_key_tbl_info->idx, (uint32)CTC_DKITS_FIELD_LEN(p_fld_ptr),
                                       p_fld_ptr->ptr_field_name, src_value, dst_value, p_wf);
        }
    }

    return CLI_SUCCESS;
}

static int32
_ctc_dkits_dump_diff_flex(ctc_dkits_dump_key_tbl_info_t* p_key_tbl_info,
                          ctc_dkits_dump_tbl_entry_t* p_src_tbl,
                          ctc_dkits_dump_tbl_entry_t* p_dst_tbl,
                          sal_file_t p_wf)
{
    uint32 serdes_id = 0;
    uint32 register_mode = 0;
    uint32 offset = 0;
    uint32 value1 = 0;
    uint32 value2 = 0;
    char format2[100] = {0};
    char* p_mode[CTC_DKIT_SERDES_PLLB+1] = {"Tx", "Rx", "Common", "PLLA", "PLLB"};
    char str1[100] = {0};
    char str2[100] = {0};
    char format[50] = {0};

    if (p_key_tbl_info->tbl_type == CTC_DKITS_DUMP_TBL_TYPE_SERDES)
    {
        ctc_dkits_dump_serdes_tbl_t* p_src_serdes_tbl = (ctc_dkits_dump_serdes_tbl_t*)p_src_tbl->data_entry;
        ctc_dkits_dump_serdes_tbl_t* p_dst_serdes_tbl = (ctc_dkits_dump_serdes_tbl_t*)p_dst_tbl->data_entry;

        if (p_src_serdes_tbl->data != p_dst_serdes_tbl->data)
        {
                sal_sprintf(format2, "%%-%du%%-%ds%%-%du%%-%ds%%-%ds", 10, 10, 10, 20, 20);
                serdes_id = p_src_serdes_tbl->serdes_id;
                register_mode = p_src_serdes_tbl->serdes_mode;
                offset = p_src_serdes_tbl->offset;
                value1 = p_src_serdes_tbl->data;
                value2 = p_dst_serdes_tbl->data;

                sal_fprintf(p_wf, format2, serdes_id, ((register_mode<=CTC_DKIT_SERDES_PLLB)?p_mode[register_mode]:""), offset,
                    CTC_DKITS_DUMP_HEX(str1, format, value1, 4), CTC_DKITS_DUMP_HEX(str2, format, value2, 4));
                sal_fprintf(p_wf, "\n");
        }
    }

    return DRV_E_NONE;
}

static int32
_ctc_dkits_dump_diff_key(ctc_dkits_dump_key_tbl_info_t* p_key_tbl_info, ctc_dkits_dump_tbl_entry_t* p_src_entry, ctc_dkits_dump_tbl_entry_t* p_dst_entry, sal_file_t p_wf)
{
    uint32 i = 0, j = 0, valid = 0;
    tbls_id_t tblid[] = {p_key_tbl_info->tblid, p_key_tbl_info->ad_tblid, MaxTblId_t};
    uint32 idx[2] = {p_key_tbl_info->idx, p_key_tbl_info->ad_idx};
    char str[300] = {0};
    char tbl[300] = {0};
    char format[100] = {0};
    char format2[100] = {0};
    uint32* p_entry = NULL;
    uint32 line_word = 0, tbl_word = 0, word_idx = 0, is_empty = 0;

    for (i = 0; MaxTblId_t != tblid[i]; i++)
    {
        valid = _ctc_dkits_dump_diff_check(tblid[i], p_key_tbl_info->tbl_type, p_src_entry, p_dst_entry);
        if (!valid)
        {
            continue;
        }
        _ctc_dkits_dump_diff_ctl(tblid[i], p_key_tbl_info->tbl_type, &line_word, &tbl_word);

        for (j = 0; j < tbl_word; j++)
        {
            _ctc_dkits_dump_diff_entry(j, tblid[i], &word_idx, p_key_tbl_info->tbl_type,
                                       p_src_entry, p_dst_entry, &p_entry, &is_empty);

            if (0 == (j % line_word))
            {
                sal_sprintf(format2, "%%-%ds%%-%ds", TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN, DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                if (0 == j)
                {
                    sal_sprintf(tbl, "%s[%u]", TABLE_NAME(tblid[i]), idx[i]);
                    _ctc_dkits_dump_cfg_brief_str(tbl, sal_strlen(TABLE_NAME(tblid[i])), ((int8)(sal_strlen(tbl)) - TBL_NAME_IDX_MAX_PRINT_LEN));
                    if (NULL != p_entry)
                    {
                        sal_fprintf(p_wf, format2, tbl, CTC_DKITS_DUMP_HEX(str, format, p_entry[word_idx], 8));
                    }
                    else
                    {
                        sal_fprintf(p_wf, format2, tbl, is_empty ? " " : "--------");
                    }
                }
                else
                {
                    if (NULL != p_entry)
                    {
                        sal_fprintf(p_wf, format2, " ", CTC_DKITS_DUMP_HEX(str, format, p_entry[word_idx], 8));
                    }
                    else
                    {
                        sal_fprintf(p_wf, format2, " ", is_empty ? " " : "--------");
                    }
                }
            }
            else
            {
                sal_sprintf(format2, "%%-%ds", DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                if (NULL != p_entry)
                {
                    sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_entry[word_idx], 8));
                }
                else
                {
                    sal_fprintf(p_wf, format2, is_empty ? " " : "--------");
                }
            }
            if (0 == ((j + 1) % line_word))
            {
                sal_fprintf(p_wf, "%s", "\n");
            }
        }
        if (0 != j % line_word)
        {
            sal_fprintf(p_wf, "\n");
        }
    }

    return CLI_SUCCESS;
}

/*p_flag: bit0--hash header, bit1--tcam header*/
static void
_ctc_dkits_dump_diff(ctc_dkits_dump_tbl_type_t tbl_type, ctc_dkits_dump_key_tbl_info_t* p_key_tbl_info, ctc_dkits_dump_tbl_entry_t* p_src_tbl,
    ctc_dkits_dump_tbl_entry_t* p_dst_tbl, uint32* p_flag, sal_file_t p_wf)
{
    ctc_dkits_dump_tbl_diff_flag_t diff_flag = 0;

    if ((NULL != p_src_tbl) && (NULL != p_dst_tbl))
    {
        _ctc_dkits_dump_cmp_tbl_entry(p_key_tbl_info, p_src_tbl, p_dst_tbl, &diff_flag);
        if (!(DKITS_FLAG_ISSET(diff_flag, CTC_DKITS_DUMP_TBL_DIFF_FLAG_TBL)
           || DKITS_FLAG_ISSET(diff_flag, CTC_DKITS_DUMP_TBL_DIFF_FLAG_KEY)
           || DKITS_FLAG_ISSET(diff_flag, CTC_DKITS_DUMP_TBL_DIFF_FLAG_AD)))
        {
            return;
        }
    }

    /*Dump header*/
    if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== tbl_type) || (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type))
    {
        if (!DKITS_IS_BIT_SET(*p_flag, 0))
        {
            DKITS_BIT_SET(*p_flag, 0);
            ctc_dkits_dump_txt_header(CTC_DKITS_DUMP_TEXT_HEADER_DIFF_HASH, p_wf);
        }
    }
    else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
    {
        if (!DKITS_IS_BIT_SET(*p_flag, 1))
        {
            DKITS_BIT_SET(*p_flag, 1);
            ctc_dkits_dump_txt_header(CTC_DKITS_DUMP_TEXT_HEADER_DIFF_TCAM, p_wf);
        }
    }

    if ((CTC_DKITS_DUMP_TBL_TYPE_STATIC == tbl_type) || (CTC_DKITS_DUMP_TBL_TYPE_SERDES == tbl_type))
    {
        if ((NULL == p_src_tbl) || (NULL == p_dst_tbl))
        {
            CTC_DKIT_PRINT("Diff static tbl field error, ");
            if (NULL == p_src_tbl)
            {
                CTC_DKIT_PRINT("src tbl is NULL, ");
            }
            if (NULL == p_dst_tbl)
            {
                CTC_DKIT_PRINT("dst tbl is NULL, ");
            }
            CTC_DKIT_PRINT("tblName:%s, index:%u\n", TABLE_NAME(p_key_tbl_info->tblid), p_key_tbl_info->idx);
            return;
        }

        if (CTC_DKITS_DUMP_TBL_TYPE_SERDES == tbl_type)
        {
            _ctc_dkits_dump_diff_flex(p_key_tbl_info, p_src_tbl, p_dst_tbl, p_wf);
        }
        else
        {
            _ctc_dkits_dump_diff_field(p_key_tbl_info, p_src_tbl, p_dst_tbl, p_wf);
        }

    }
    else if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == tbl_type)
            || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
            || (CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD == tbl_type))
    {
        if ((NULL == p_src_tbl) && (NULL == p_dst_tbl))
        {
            CTC_DKIT_PRINT("Diff key tbl error!\n");
            return;
        }
        _ctc_dkits_dump_diff_key(p_key_tbl_info, p_src_tbl, p_dst_tbl, p_wf);
    }

    return;
}

int32
ctc_dkits_dump_get_tbl_entry(sal_file_t p_rf, host_type_t cfg_endian, ctc_dkits_dump_tbl_entry_t* p_tbl_entry,
                    ctc_dkits_dump_key_tbl_info_t* p_info)
{
    uint8  buf[500] = {0};
    ctc_dkits_dump_tbl_block_hdr_t tbl_block_hdr;
    int32 ret = 0;

    /*get entry from bin*/
    sal_memset(&tbl_block_hdr, 0, sizeof(ctc_dkits_dump_tbl_block_hdr_t));
    ctc_dkits_dump_read_bin(buf, cfg_endian, &tbl_block_hdr, p_rf);

    /*get entry refer info:tbl_type, order */
    //ret = _ctc_greatbelt_dkits_dump_decode_entry(&tbl_block_hdr, p_info);
    ret = g_dkit_chip_api->dkits_dump_decode_entry(&tbl_block_hdr, p_info);

    /*store entry info */
    ctc_dkits_dump_data2tbl(p_info->tbl_type, cfg_endian, &tbl_block_hdr, buf, p_tbl_entry);

    return ret;
}

int32
ctc_dkits_dump_cmp_tbl(sal_file_t p_srf, sal_file_t p_drf, host_type_t src_cfg_endian, host_type_t dst_cfg_endian, sal_file_t p_wf)
{
    uint32 read_src = 1, read_dst = 1, src_end = 0, dst_end = 0;
    uint32 seop = 0, deop = 0;
    uint32* src_data_entry = NULL;
    uint32* src_mask_entry = NULL;
    uint32* src_ad_entry = NULL;
    uint32* dst_data_entry = NULL;
    uint32* dst_mask_entry = NULL;
    uint32* dst_ad_entry = NULL;
    ctc_dkits_dump_tbl_entry_t src_tbl_entry, dst_tbl_entry;
    ctc_dkits_dump_key_tbl_info_t src_key_tbl_info, dst_key_tbl_info;
    ctc_dkits_dump_key_tbl_info_t ad_tbl_info;
    int32 ret = 0;
    uint32 flag = 0;
    src_data_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    src_mask_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    src_ad_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    dst_data_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    dst_mask_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    dst_ad_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));

    sal_memset(&src_tbl_entry, 0, sizeof(ctc_dkits_dump_tbl_entry_t));
    sal_memset(&dst_tbl_entry, 0, sizeof(ctc_dkits_dump_tbl_entry_t));

    src_tbl_entry.data_entry = src_data_entry;
    src_tbl_entry.mask_entry = src_mask_entry;
    src_tbl_entry.ad_entry = src_ad_entry;

    dst_tbl_entry.data_entry = dst_data_entry;
    dst_tbl_entry.mask_entry = dst_mask_entry;
    dst_tbl_entry.ad_entry = dst_ad_entry;

    sal_fseek(p_srf, 0, SEEK_END);
    seop = sal_ftell(p_srf);
    if (seop < sizeof(ctc_dkits_dump_centec_file_hdr_t))
    {
        return CLI_SUCCESS;
    }
    sal_fseek(p_srf, sizeof(ctc_dkits_dump_centec_file_hdr_t), SEEK_SET);

    sal_fseek(p_drf, 0, SEEK_END);
    deop = sal_ftell(p_drf);
    if (deop < sizeof(ctc_dkits_dump_centec_file_hdr_t))
    {
        return CLI_SUCCESS;
    }
    sal_fseek(p_drf, sizeof(ctc_dkits_dump_centec_file_hdr_t), SEEK_SET);

    while (!src_end || !dst_end)
    {
        if (read_src)
        {
            if ((1 != sal_feof(p_srf)) && (seop != sal_ftell(p_srf)))
            {
                sal_memset(src_data_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
                sal_memset(src_mask_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
                sal_memset(src_ad_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));

                src_key_tbl_info.tblid = MaxTblId_t;
                src_key_tbl_info.ad_tblid = MaxTblId_t;

                /*get key info*/
                ret = ctc_dkits_dump_get_tbl_entry(p_srf, src_cfg_endian, &src_tbl_entry, &src_key_tbl_info);
                if (ret)
                {
                    continue;
                }

                if (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == src_key_tbl_info.tbl_type)
                {
                    /*get ad info*/
                    ctc_dkits_dump_get_tbl_entry(p_srf, src_cfg_endian, &src_tbl_entry, &ad_tbl_info);
                    src_key_tbl_info.ad_tblid = ad_tbl_info.ad_tblid;
                    src_key_tbl_info.ad_idx = ad_tbl_info.ad_idx;
                }
                else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == src_key_tbl_info.tbl_type)
                {
                    /*get ad info*/
                    ctc_dkits_dump_get_tbl_entry(p_srf, src_cfg_endian, &src_tbl_entry, &ad_tbl_info);
                    src_key_tbl_info.ad_tblid = ad_tbl_info.ad_tblid;
                    src_key_tbl_info.ad_idx = ad_tbl_info.ad_idx;
                }
            }
            else
            {
                src_end = 1;
            }
        }

        if (read_dst)
        {
            if ((1 != sal_feof(p_drf)) && (deop != sal_ftell(p_drf)))
            {
                sal_memset(dst_data_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
                sal_memset(dst_mask_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
                sal_memset(dst_ad_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));

                dst_key_tbl_info.tblid = MaxTblId_t;
                dst_key_tbl_info.ad_tblid = MaxTblId_t;

                /*get key info*/
                ret = ctc_dkits_dump_get_tbl_entry(p_drf, dst_cfg_endian, &dst_tbl_entry, &dst_key_tbl_info);
                if (ret)
                {
                    continue;
                }

                if (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == dst_key_tbl_info.tbl_type)
                {
                    ctc_dkits_dump_get_tbl_entry(p_drf, dst_cfg_endian, &dst_tbl_entry, &ad_tbl_info);
                    dst_key_tbl_info.ad_tblid = ad_tbl_info.ad_tblid;
                    dst_key_tbl_info.ad_idx = ad_tbl_info.ad_idx;
                }
                else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == dst_key_tbl_info.tbl_type)
                {
                    ctc_dkits_dump_get_tbl_entry(p_drf, dst_cfg_endian, &dst_tbl_entry, &ad_tbl_info);
                    dst_key_tbl_info.ad_tblid = ad_tbl_info.ad_tblid;
                    dst_key_tbl_info.ad_idx = ad_tbl_info.ad_idx;
                }

            }
            else
            {
                dst_end = 1;
            }
        }

        if (!src_end && dst_end)
        {
            _ctc_dkits_dump_diff(src_key_tbl_info.tbl_type, &src_key_tbl_info, &src_tbl_entry, NULL, &flag, p_wf);
            read_src = 1;
            read_dst = 0;
        }
        else if (src_end && !dst_end)
        {
            _ctc_dkits_dump_diff(dst_key_tbl_info.tbl_type, &dst_key_tbl_info, NULL, &dst_tbl_entry, &flag, p_wf);
            read_src = 0;
            read_dst = 1;
        }
        else if ((!src_end && !dst_end) && (src_key_tbl_info.tblid == dst_key_tbl_info.tblid))
        {
            if (src_key_tbl_info.idx == dst_key_tbl_info.idx)
            {
                _ctc_dkits_dump_diff(src_key_tbl_info.tbl_type, &src_key_tbl_info, &src_tbl_entry, &dst_tbl_entry, &flag, p_wf);
                read_src = 1;
                read_dst = 1;
            }
            else if (src_key_tbl_info.idx < dst_key_tbl_info.idx)
            {
                _ctc_dkits_dump_diff(src_key_tbl_info.tbl_type, &src_key_tbl_info, &src_tbl_entry, NULL, &flag, p_wf);
                read_src = 1;
                read_dst = 0;
            }
            else if (src_key_tbl_info.idx > dst_key_tbl_info.idx)
            {
                _ctc_dkits_dump_diff(dst_key_tbl_info.tbl_type, &dst_key_tbl_info, NULL, &dst_tbl_entry, &flag, p_wf);
                read_src = 0;
                read_dst = 1;
            }
        }
        else if ((!src_end && !dst_end) && (src_key_tbl_info.tblid != dst_key_tbl_info.tblid))
        {
            if (((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == src_key_tbl_info.tbl_type || CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== src_key_tbl_info.tbl_type)
                && (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == dst_key_tbl_info.tbl_type || CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== dst_key_tbl_info.tbl_type))
                ||  ((CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == src_key_tbl_info.tbl_type)
                && (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == dst_key_tbl_info.tbl_type)))
            {
                if (src_key_tbl_info.order < dst_key_tbl_info.order)
                {
                    _ctc_dkits_dump_diff(src_key_tbl_info.tbl_type, &src_key_tbl_info, &src_tbl_entry, NULL, &flag, p_wf);
                    read_src = 1;
                    read_dst = 0;
                }
                else if (src_key_tbl_info.order > dst_key_tbl_info.order)
                {
                    _ctc_dkits_dump_diff(dst_key_tbl_info.tbl_type, &dst_key_tbl_info, NULL, &dst_tbl_entry, &flag, p_wf);
                    read_src = 0;
                    read_dst = 1;
                }
            }
            else if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == src_key_tbl_info.tbl_type || CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD== src_key_tbl_info.tbl_type)
                     && (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == dst_key_tbl_info.tbl_type))
            {
                _ctc_dkits_dump_diff(src_key_tbl_info.tbl_type, &src_key_tbl_info, &src_tbl_entry, NULL, &flag, p_wf);
                read_src = 1;
                read_dst = 0;
            }
            else if ((CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == src_key_tbl_info.tbl_type)
                     && (CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == dst_key_tbl_info.tbl_type || CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY == dst_key_tbl_info.tbl_type))
            {
                _ctc_dkits_dump_diff(dst_key_tbl_info.tbl_type, &dst_key_tbl_info, NULL, &dst_tbl_entry, &flag, p_wf);
                read_src = 0;
                read_dst = 1;
            }
        }
    }

    sal_free(src_data_entry);
    sal_free(src_mask_entry);
    sal_free(src_ad_entry);
    sal_free(dst_data_entry);
    sal_free(dst_mask_entry);
    sal_free(dst_ad_entry);

    return CLI_SUCCESS;
}

int32
ctc_dkits_dump_data2text(sal_file_t p_rf, host_type_t cfg_endian, sal_file_t p_wf)
{
    uint32 i = 0, eop = 0, tbl_header = 0;
    char* str = NULL;
    char* tbl = NULL;
    char format[100] = {0};
    char format2[100] = {0};
    uint32* data_entry = NULL;
    uint32* mask_entry = NULL;
    uint32* ad_entry = NULL;
    uint32* p_entry_data = NULL;
    uint32 tbl_word = 0, word_num_per_line = 0, word_idx = 0, data_word = 0, mask_word = 0;
    ctc_dkits_dump_tbl_entry_t tbl_entry;
    uint8 header_type = 0;
    static uint32 pre = 0;
    uint32 cur = 0;
    ctc_dkits_dump_serdes_tbl_t* serdes_tbl = NULL;
    uint32 serdes_id = 0;
    uint32 register_mode = 0;
    uint32 offset = 0;
    uint32 value = 0;
    char* p_mode[CTC_DKIT_SERDES_PLLB+1] = {"Tx", "Rx", "Common", "PLLA", "PLLB"};
    ctc_dkits_dump_key_tbl_info_t tbl_info;
    tbls_id_t tb_id = 0;
    uint32 index = 0;

    str = (char*)sal_malloc(300 * sizeof(char));
    tbl = (char*)sal_malloc(300 * sizeof(char));
    data_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    mask_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));
    ad_entry = (uint32*)sal_malloc(MAX_ENTRY_WORD * sizeof(uint32));

    sal_memset(str, 0, 300 * sizeof(char));
    sal_memset(tbl, 0, 300 * sizeof(char));
    sal_memset(data_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
    sal_memset(mask_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
    sal_memset(ad_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));

    tbl_entry.data_entry = data_entry;
    tbl_entry.mask_entry = mask_entry;
    tbl_entry.ad_entry = ad_entry;

    sal_fseek(p_rf, 0, SEEK_END);
    eop = sal_ftell(p_rf);
    if (eop <= sizeof(ctc_dkits_dump_centec_file_hdr_t))
    {
        return CLI_SUCCESS;
    }
    sal_fseek(p_rf, sizeof(ctc_dkits_dump_centec_file_hdr_t), SEEK_SET);

    while (eop != sal_ftell(p_rf) && (1 != sal_feof(p_rf)))
    {
        cur = sal_ftell(p_rf);
        if ((cur - pre) > (eop/10))
        {
            sal_udelay(10);
            pre = cur;
        }

        sal_memset(data_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
        sal_memset(mask_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
        sal_memset(ad_entry, 0, MAX_ENTRY_WORD * sizeof(uint32));
        data_word = 0;
        mask_word = 0;

         ctc_dkits_dump_get_tbl_entry(p_rf, cfg_endian, &tbl_entry, &tbl_info);

        /*Default using key info*/
        tb_id = tbl_info.tblid;
        index = tbl_info.idx;

        switch(tbl_info.tbl_type)
        {
            case CTC_DKITS_DUMP_TBL_TYPE_STATIC:
            case CTC_DKITS_DUMP_TBL_TYPE_HASH_KEY:
            case CTC_DKITS_DUMP_TBL_TYPE_HASH_NO_AD:
                header_type = CTC_DKITS_DUMP_TEXT_HEADER_DUMP_TBL;
                tbl_word = TABLE_ENTRY_SIZE(tb_id) / DRV_BYTES_PER_WORD;
                break;

            case CTC_DKITS_DUMP_TBL_TYPE_SERDES:
                header_type = CTC_DKITS_DUMP_TEXT_HEADER_DUMP_SERDES;
                tbl_word = 1;
                break;

            case CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY:
                header_type = CTC_DKITS_DUMP_TEXT_HEADER_DUMP_TCAM;
                tbl_word = (TABLE_ENTRY_SIZE(tb_id) / DRV_BYTES_PER_WORD) * 2;
                break;

            case CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD:
                header_type = CTC_DKITS_DUMP_TEXT_HEADER_DUMP_TCAM;
                tbl_word = (TABLE_ENTRY_SIZE(tbl_info.ad_tblid) / DRV_BYTES_PER_WORD);
                break;

            default:
               break;
        }

        if (0 == tbl_header)
        {
            tbl_header = 1;
            ctc_dkits_dump_txt_header(header_type, p_wf);
        }

        for (i = 0; i < tbl_word; i++)
        {
            if (CTC_DKITS_DUMP_TBL_TYPE_SERDES == tbl_info.tbl_type)
            {
                word_num_per_line = DUMP_TBL_WORD_NUM_PER_LINE;
                sal_sprintf(format2, "%%-%du%%-%ds%%-%du0x%%0%dx", 10, 10, 10, 4);
                serdes_tbl = (ctc_dkits_dump_serdes_tbl_t*)tbl_entry.data_entry;
                serdes_id = serdes_tbl->serdes_id;
                register_mode = serdes_tbl->serdes_mode;
                offset = serdes_tbl->offset;
                value = serdes_tbl->data;

                sal_fprintf(p_wf, format2, serdes_id, ((register_mode<=CTC_DKIT_SERDES_PLLB)?p_mode[register_mode]:""), offset, value);
                continue;
            }
            else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_info.tbl_type)
            {
                word_num_per_line = DUMP_TCAM_WORD_NUM_PER_LINE;

                if (0 == (i%(DUMP_TCAM_WORD_NUM_PER_LINE/2)))
                {
                    if (0 == ((i/(DUMP_TCAM_WORD_NUM_PER_LINE/2))%2))
                    {
                        word_idx = data_word;
                        data_word += DUMP_TCAM_WORD_NUM_PER_LINE/2;
                        p_entry_data = tbl_entry.data_entry;
                    }
                    else
                    {
                        word_idx = mask_word;
                        mask_word += DUMP_TCAM_WORD_NUM_PER_LINE/2;
                        p_entry_data = tbl_entry.mask_entry;
                    }
                }
                else
                {
                    word_idx++;
                }
            }
            else
            {
                word_idx = i;
                if (CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_info.tbl_type)
                {
                    word_num_per_line = DUMP_TBL_WORD_NUM_PER_LINE;
                    p_entry_data = tbl_entry.ad_entry;
                    tb_id = tbl_info.ad_tblid;
                    index = tbl_info.ad_idx;
                }
                else if (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_info.tbl_type)
                {
                    word_num_per_line = DUMP_TCAM_WORD_NUM_PER_LINE / 2;
                    p_entry_data = tbl_entry.ad_entry;
                    tb_id = tbl_info.ad_tblid;
                    index = tbl_info.ad_idx;
                }
                else
                {
                    word_num_per_line = DUMP_TBL_WORD_NUM_PER_LINE;
                    p_entry_data = tbl_entry.data_entry;
                }
            }

            if (0 == (i % word_num_per_line))
            {
                sal_sprintf(format2, "%%-%ds%%-%ds", TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN, DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                if (0 == i)
                {
                    sal_sprintf(tbl, "%s[%u]", TABLE_NAME(tb_id), index);
                    _ctc_dkits_dump_cfg_brief_str(tbl, sal_strlen(TABLE_NAME(tb_id)), ((int8)(sal_strlen(tbl)) - TBL_NAME_IDX_MAX_PRINT_LEN));
                    sal_fprintf(p_wf, format2, tbl, CTC_DKITS_DUMP_HEX(str, format, p_entry_data[word_idx], 8));
                }
                else
                {
                    sal_fprintf(p_wf, format2, " ", CTC_DKITS_DUMP_HEX(str, format, p_entry_data[word_idx], 8));
                }
            }
            else
            {
                sal_sprintf(format2, "%%-%ds", DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_entry_data[word_idx], 8));
            }
            if (0 == ((i + 1) % word_num_per_line))
            {
                sal_fprintf(p_wf, "%s", "\n");
            }
        }

        if (0 != i % word_num_per_line)
        {
            sal_fprintf(p_wf, "\n");
        }
    }

    pre = 0;

    sal_free(str);
    sal_free(tbl);
    sal_free(data_entry);
    sal_free(mask_entry);
    sal_free(ad_entry);

    return CLI_SUCCESS;
}

void
ctc_dkits_dump_diff_write(tbls_id_t tblid_, uint32 idx_, uint32 bits, char* p_field_name, uint32* p_src_value, uint32* p_dst_value, sal_file_t p_wf)
{
    tbls_id_t tblid = MaxTblId_t;;
    uint32  fvi = 0, fwn = 0, idx = 0xFFFFFFFF;
    char str[100] = {0};
    char str2[100] = {0};
    char format[50] = {0};
    char format2[50] = {0};

    fwn = (bits / (sizeof(uint32) * 8)) + ((bits % (sizeof(uint32) * 8)) ? 1 : 0);
    ctc_dkits_dump_diff_status(0, &tblid, &idx);

    for (fvi = 0; fvi < fwn; fvi++)
    {
        if (0 == fvi)
        {
            if ((tblid != tblid_) || (idx != idx_))
            {
                tblid = tblid_;
                idx = idx_;
                ctc_dkits_dump_diff_status(0, &tblid, &idx);

                sal_sprintf(str, "%s[%u]", TABLE_NAME(tblid), idx);
                _ctc_dkits_dump_cfg_brief_str(str, sal_strlen(TABLE_NAME(tblid)), ((int8)(sal_strlen(str)) - TBL_NAME_IDX_MAX_PRINT_LEN));
                sal_sprintf(str2, "%s", p_field_name);
                _ctc_dkits_dump_cfg_brief_str(str2, sal_strlen(p_field_name), ((int8)(sal_strlen(str2)) - FIELD_NAME_MAX_PRINT_LEN));

                sal_sprintf(format, "%%-%ds%%-%ds", TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN,
                                                    FIELD_NAME_MAX_PRINT_LEN + COLUNM_SPACE_LEN);

                sal_fprintf(p_wf, format, str, str2);
                sal_sprintf(format2, "%%-%ds", DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_src_value[fvi], 8));
                sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_dst_value[fvi], 8));
                sal_fprintf(p_wf, "\n");
            }
            else
            {
                sal_sprintf(str2, "%s", p_field_name);
                _ctc_dkits_dump_cfg_brief_str(str2, sal_strlen(p_field_name), ((int8)(sal_strlen(str2)) - FIELD_NAME_MAX_PRINT_LEN));

                sal_sprintf(format, "%%-%ds%%-%ds", TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN,
                                                    FIELD_NAME_MAX_PRINT_LEN + COLUNM_SPACE_LEN);

                sal_fprintf(p_wf, format, " ", str2);
                sal_sprintf(format2, "%%-%ds", DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
                sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_src_value[fvi], 8));
                sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_dst_value[fvi], 8));
                sal_fprintf(p_wf, "\n");
            }
        }
        else
        {
            sal_sprintf(format, "%%-%ds%%-%ds", TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN,
                                                FIELD_NAME_MAX_PRINT_LEN + COLUNM_SPACE_LEN);

            sal_fprintf(p_wf, format, " ", " ");
            sal_sprintf(format2, "%%-%ds", DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN);
            sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_src_value[fvi], 8));
            sal_fprintf(p_wf, format2, CTC_DKITS_DUMP_HEX(str, format, p_dst_value[fvi], 8));
            sal_fprintf(p_wf, "\n");
        }
    }

    return;
}

int32
ctc_dkits_dump_read_bin(uint8* p_buf, host_type_t cfg_endian, ctc_dkits_dump_tbl_block_hdr_t* p_tbl_block_hdr, sal_file_t p_rf)
{
    uint32 entry_byte = 0;
    host_type_t host_endian;

    host_endian = drv_get_host_type();
    sal_fread(p_tbl_block_hdr, sizeof(ctc_dkits_dump_tbl_block_hdr_t), 1, p_rf);

    if (cfg_endian != host_endian)
    {
        ctc_dkits_dump_swap32((uint32*)p_tbl_block_hdr, 1);
    }

    if (CTC_DKITS_FORMAT_TYPE_4BYTE == p_tbl_block_hdr->format)
    {
        entry_byte = sizeof(ctc_dkits_dump_tbl_block_data_t);
    }
    else
    {
        entry_byte = sizeof(uint32);
    }
    sal_fread(p_buf, (p_tbl_block_hdr->entry_num + 1) * entry_byte, 1, p_rf);

    return CLI_SUCCESS;
}

int32
ctc_dkits_dump_tbl2data(uint16 tbl_id, uint16 index, uint32* p_data_entry, uint32* p_mask_entry, sal_file_t p_f)
{
    uint8  data[500] = {0}, is_tcam = 0;
    uint16 mem_len = 0;
    ctc_dkits_dump_tbl_block_hdr_t tbl_block_hdr;

    sal_memset(&tbl_block_hdr, 0, sizeof(ctc_dkits_dump_tbl_block_hdr_t));

    tbl_block_hdr.tblid_0_7 = tbl_id & 0xFF;
    tbl_block_hdr.tblid_8_12 = (tbl_id >> 8) & 0x1F;
    tbl_block_hdr.idx = index;
    is_tcam = (NULL == p_mask_entry) ? 0 : 1;

    _ctc_dkits_dump_select_format(&tbl_block_hdr, p_data_entry, p_mask_entry);

    if (CTC_DKITS_FORMAT_TYPE_4BYTE == tbl_block_hdr.format)
    {
        sal_memset(data, 0, sizeof(data));
        _ctc_dkits_dump_format_entry(&tbl_block_hdr, p_data_entry, data, &mem_len);

        if (1 == is_tcam)
        {
            _ctc_dkits_dump_format_entry(&tbl_block_hdr, p_mask_entry, data, &mem_len);
        }
        tbl_block_hdr.entry_num = (mem_len / sizeof(ctc_dkits_dump_tbl_block_data_t)) - 1;
        sal_fwrite(&tbl_block_hdr, sizeof(ctc_dkits_dump_tbl_block_hdr_t), 1, p_f);
        sal_fwrite(data, mem_len, 1, p_f);
    }
    else
    {
        sal_memset(data, 0, sizeof(data));
        _ctc_dkits_dump_plain_entry((TABLE_ENTRY_SIZE(tbl_id)/4), p_data_entry, data, &mem_len);

        if (1 == is_tcam)
        {
            _ctc_dkits_dump_plain_entry((TABLE_ENTRY_SIZE(tbl_id)/4), p_mask_entry, data, &mem_len);
        }
        tbl_block_hdr.entry_num = (mem_len / sizeof(uint32)) - 1;
        sal_fwrite(&tbl_block_hdr, sizeof(ctc_dkits_dump_tbl_block_hdr_t), 1, p_f);
        sal_fwrite(data, mem_len, 1, p_f);
    }

    return CLI_SUCCESS;
}

int32
ctc_dkits_dump_data2tbl(ctc_dkits_dump_tbl_type_t tbl_type, host_type_t cfg_endian, ctc_dkits_dump_tbl_block_hdr_t* p_tbl_block_hdr, uint8* p_buf, ctc_dkits_dump_tbl_entry_t* p_tbl_entry)
{
    uint8 i = 0, j  = 0, bytes = 0, count = 0;
    ctc_dkits_dump_tbl_block_data_t tbl_block_data;
    host_type_t host_endian;
    tbls_id_t tblid = CTC_DKITS_DUMP_BLOCK_HDR_TBLID(p_tbl_block_hdr);

    host_endian = drv_get_host_type();

    for (i = 0; i < p_tbl_block_hdr->entry_num + 1; i++)
    {
        sal_memset(&tbl_block_data, 0, sizeof(ctc_dkits_dump_tbl_block_data_t));
        bytes = CTC_DKITS_DUMP_BLOCK_DATA_BYTE(p_tbl_block_hdr->format);

        if (CTC_DKITS_FORMAT_TYPE_4BYTE == p_tbl_block_hdr->format)
        {
            sal_memcpy(&tbl_block_data, p_buf + (i * bytes), bytes);
        }
        else
        {
            sal_memcpy(&(tbl_block_data.entry), p_buf + (i * bytes), bytes);
            tbl_block_data.repeat = 1;
        }

        if (cfg_endian != host_endian)
        {
            ctc_dkits_dump_swap32((uint32*)&tbl_block_data.entry, 1);
        }

        for (j = 0; j < tbl_block_data.repeat; j++)
        {
            if ((CTC_DKITS_DUMP_TBL_TYPE_TCAM_KEY == tbl_type)
                && ((count * sizeof(uint32)) >= TABLE_ENTRY_SIZE(tblid)))
            {
                p_tbl_entry->mask_entry[count - (TABLE_ENTRY_SIZE(tblid) / sizeof(uint32))] = tbl_block_data.entry;
            }
            else if ((CTC_DKITS_DUMP_TBL_TYPE_HASH_AD == tbl_type)
                    || (CTC_DKITS_DUMP_TBL_TYPE_TCAM_AD == tbl_type))
            {
                p_tbl_entry->ad_entry[count] = tbl_block_data.entry;
            }
            else
            {
                p_tbl_entry->data_entry[count] = tbl_block_data.entry;
            }
            count++;
        }
    }

    return CLI_SUCCESS;
}

void
ctc_dkits_dump_txt_header(ctc_dkits_dump_text_header_type_t type, sal_file_t p_wf)
{
    uint32 n = 0, i = 0;
    char format[100] = {0};

    if (CTC_DKITS_DUMP_TEXT_HEADER_DUMP_TBL == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DUMP_TBL_WORD_NUM_PER_LINE * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN));

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%s\n", (TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN));

        sal_fprintf(p_wf, format, "TblName[Index]", "Value");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DUMP_TCAM == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DUMP_TCAM_WORD_NUM_PER_LINE * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN));

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%s\n",
                    (TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN),
                    (((DUMP_TCAM_WORD_NUM_PER_LINE/2) * DUMP_ENTRY_WORD_STR_LEN)
                    + (DUMP_ENTRY_WORD_SPACE_LEN * 3)));

        sal_fprintf(p_wf, format, "TblName[Index]", "Data", "Mask");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DIFF_TBL == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + FIELD_NAME_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DUMP_ENTRY_WORD_STR_LEN * 2) + DUMP_ENTRY_WORD_SPACE_LEN;

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%-9s%%-9s\n", (TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN),
                                                        (FIELD_NAME_MAX_PRINT_LEN + COLUNM_SPACE_LEN));

        sal_fprintf(p_wf, format, "TblName[Index]", "FieldName", "File1", "File2");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DIFF_HASH == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DIFF_HASH_WORD_NUM_PER_LINE * DUMP_ENTRY_WORD_STR_LEN)
            + ((DIFF_HASH_WORD_NUM_PER_LINE - 1) * DUMP_ENTRY_WORD_SPACE_LEN);

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%s\n",
                    (TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN),
                    ((DIFF_HASH_WORD_NUM_PER_LINE / 2) * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN)));

        sal_fprintf(p_wf, format, "TblName[Index]", "File1", "File2");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DIFF_TCAM == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DIFF_TCAM_WORD_NUM_PER_LINE * DUMP_ENTRY_WORD_STR_LEN)
            + ((DIFF_TCAM_WORD_NUM_PER_LINE - 1) * DUMP_ENTRY_WORD_SPACE_LEN);

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%-%ds%%-%ds%%s\n",
                    (TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN),
                    ((DIFF_TCAM_WORD_NUM_PER_LINE / 4) * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN)),
                    ((DIFF_TCAM_WORD_NUM_PER_LINE / 4) * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN)),
                    ((DIFF_TCAM_WORD_NUM_PER_LINE / 4) * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN)));

        sal_fprintf(p_wf, format, "TblName[Index]", "File1 data", "File1 mask", "File2 data", "File2 mask");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DUMP_SERDES == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DUMP_TBL_WORD_NUM_PER_LINE * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN));

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%-%ds%%s\n", 10, 10, 10);

        sal_fprintf(p_wf, format, "SerdesID", "Register", "Offset", "Value");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    else if (CTC_DKITS_DUMP_TEXT_HEADER_DIFF_SERDES == type)
    {
        n = TBL_NAME_IDX_MAX_PRINT_LEN + COLUNM_SPACE_LEN \
            + (DUMP_TBL_WORD_NUM_PER_LINE * (DUMP_ENTRY_WORD_STR_LEN + DUMP_ENTRY_WORD_SPACE_LEN));

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");

        sal_sprintf(format, "%%-%ds%%-%ds%%-%ds%%-%ds%%-%ds\n", 10, 10, 10, 20, 20);

        sal_fprintf(p_wf, format, "SerdesID", "Register", "Offset", "File1 Data", "File2 Data");

        for (i = 0; i < n; i++)
        {
            sal_fprintf(p_wf, "-");
        }
        sal_fprintf(p_wf, "\n");
    }
    return;
}

