/**
 @file sys_humber_sync_ether.c

 @date 2011-1-18

 @version v2.0

 sync ethernet function of Humber
*/

/***************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "ctc_error.h"
#include "ctc_macro.h"
#include "sys_humber_chip.h"
#include "sys_humber_sync_ether.h"
#include "sys_humber_port.h"
#include "drv_humber_data_path.h"
#include "drv_io.h"

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/
#define SYS_SYNC_ETHER_SERDE_MAX 60
#define SYS_SYNC_ETHER_CLOCK_MAX 2
#define SYS_SYNC_ETHER_DIVIDER_MAX 64
#define SYS_SYNC_ETHER_SERDES_4G_MAX 48

/**
 @brief  Define sys layer synce global configure data structure
*/
struct sys_sync_ether_master_s
{
    sal_mutex_t* p_sync_ether_mutex;
    uint8 recovered_clock_lport[SYS_SYNC_ETHER_CLOCK_MAX];
};
typedef struct sys_sync_ether_master_s sys_sync_ether_master_t;

#define SYNCE_LOCK \
    if (p_sync_ether_master->p_sync_ether_mutex) sal_mutex_lock(p_sync_ether_master->p_sync_ether_mutex)
#define SYNCE_UNLOCK \
    if (p_sync_ether_master->p_sync_ether_mutex) sal_mutex_unlock(p_sync_ether_master->p_sync_ether_mutex)

#define SYS_SYNC_ETHER_INIT_CHECK() \
    if (!p_sync_ether_master) \
    { \
        return CTC_E_SYNCE_NOT_INIT; \
    }

#define SYS_SYNC_ETHER_LCHIP_CHECK(val) \
    do { \
        if (val >= sys_humber_get_local_chip_num()){ \
            return CTC_E_INVALID_LOCAL_CHIPID; } \
    } while (0)

static sys_sync_ether_master_t* p_sync_ether_master = NULL;
extern sys_port_master_t* p_port_master;
/***************************************************************
 *
 *  Functions
 *
 ***************************************************************/
static int32
_sys_humber_sync_ether_reset(uint8 lchip, uint8 sync_ether_clock_id)
{
    uint32 cmd = 0, tmp = 1;

    if (0 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG0, SYNC_ETHERNET_CFG0_CFG_ETHER_RESET0);
    }
    else if (1 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG1, SYNC_ETHERNET_CFG1_CFG_ETHER_RESET1);
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));

    return CTC_E_NONE;
}

static int32
_sys_humber_sync_ether_release_reset(uint8 lchip, uint8 sync_ether_clock_id)
{
    uint32 cmd = 0, tmp = 0;

    if (0 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG0, SYNC_ETHERNET_CFG0_CFG_ETHER_RESET0);
    }
    else if (1 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG1, SYNC_ETHERNET_CFG1_CFG_ETHER_RESET1);
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));

    return CTC_E_NONE;
}

static int32
_sys_humber_sync_ether_serde_select_set(uint8 lchip, uint8 sync_ether_clock_id, uint8 lport)
{
    uint32 cmd = 0, tmp = 0;
    ctc_port_mac_type_t type;
    uint8 serde_id = 0;

    if (p_port_master)
    {
        type = p_port_master->igs_port_prop[lchip][lport].port_mac_type;

        switch (type)
        {
        case CTC_PORT_MAC_GMAC:    /*lport<0-47>-->serdes_4g<0-47>*/
            if (lport % 4)
            {
                return CTC_E_SYNCE_INVALID_RECOVERED_PORT;
            }

            serde_id = lport;
            break;

        case CTC_PORT_MAC_XGMAC:    /*lport<0,12,24,36>-->serdes_4g<0,4,8,12>*/
            serde_id = lport / 3;
            break;

        case CTC_PORT_MAC_SGMAC:
            if (drv_humber_sgmac_use_hss4g(lchip))    /*lport<48,49,50,51>-->serdes_4g<16,20,24,28>*/
            {
                serde_id = (lport - SYS_SYNC_ETHER_SERDES_4G_MAX) * 4 + 16;
            }
            else    /*lport<48,49,50,51>-->serdes_6g<0,4,8,12>*/
            {
                serde_id = (lport - SYS_SYNC_ETHER_SERDES_4G_MAX) * 4 + SYS_SYNC_ETHER_SERDES_4G_MAX;
            }

            break;

        default:
            return CTC_E_INVALID_PORT_MAC_TYPE;
        }
    }
    else
    {
        return CTC_E_SYNCE_NO_SERDES_INFO;
    }

    if (0 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_SELECT0, SYNC_ETHERNET_SELECT0_CFG_ETHER_CLK_SELECT0);
    }
    else if (1 == sync_ether_clock_id)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_SELECT1, SYNC_ETHERNET_SELECT1_CFG_ETHER_CLK_SELECT1);
    }
    else
    {
        return CTC_E_INVALID_PARAM;
    }

    tmp = 1 << (serde_id / 4);
    CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &tmp));

    p_sync_ether_master->recovered_clock_lport[sync_ether_clock_id] = lport;

    return CTC_E_NONE;
}

int32
sys_humber_sync_ether_init()
{
    uint32 cmd = 0;
    int32 ret = CTC_E_NONE;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    sync_ethernet_cfg0_t sync_ether_config;

    if (p_sync_ether_master != NULL)
    {
        return CTC_E_NONE;
    }

    /* create SyncE master */
    p_sync_ether_master = (sys_sync_ether_master_t*)mem_malloc(MEM_SYNC_ETHER_MODULE, sizeof(sys_sync_ether_master_t));
    if (NULL == p_sync_ether_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_sync_ether_master, 0, sizeof(sys_sync_ether_master_t));
    ret = sal_mutex_create(&(p_sync_ether_master->p_sync_ether_mutex));
    if (ret || !(p_sync_ether_master->p_sync_ether_mutex))
    {
        mem_free(p_sync_ether_master);
        return CTC_E_FAIL_CREATE_MUTEX;
    }

    sal_memset(&sync_ether_config, 0, sizeof(sync_ethernet_cfg0_t));
    sync_ether_config.cfg_ether_user_go0 = 0;
    lchip_num = sys_humber_get_local_chip_num();

    for (lchip = 0; lchip < lchip_num; lchip++)
    {
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config));
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG1, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config));
    }

    return CTC_E_NONE;
}

int32
sys_humber_sync_ether_set_cfg(uint8 lchip, uint8 sync_ether_clock_id, ctc_sync_ether_cfg_t* p_sync_ether_cfg)
{
    uint32 cmd = 0;
    sync_ethernet_cfg0_t sync_ether_config;

    sal_memset(&sync_ether_config, 0, sizeof(sync_ethernet_cfg0_t));

    SYS_SYNC_ETHER_INIT_CHECK();
    SYS_SYNC_ETHER_LCHIP_CHECK(lchip);
    CTC_PTR_VALID_CHECK(p_sync_ether_cfg);
    if (sync_ether_clock_id >= SYS_SYNC_ETHER_CLOCK_MAX)
    {
        return CTC_E_SYNCE_CLOCK_ID_EXCEED_MAX_VALUE;
    }

    if (p_sync_ether_cfg->recovered_clock_lport >= CTC_MAX_PHY_PORT)
    {
        return CTC_E_LOCAL_PORT_NOT_EXIST;
    }

    if (p_sync_ether_cfg->divider >= SYS_SYNC_ETHER_DIVIDER_MAX)
    {
        return CTC_E_SYNCE_DIVIDER_EXCEED_MAX_VALUE;
    }

    SYNCE_LOCK;
    CTC_ERROR_RETURN_WITH_UNLOCK(_sys_humber_sync_ether_reset(lchip, sync_ether_clock_id), p_sync_ether_master->p_sync_ether_mutex);

    switch (sync_ether_clock_id)
    {
    case 0:
        cmd = DRV_IOR(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config), p_sync_ether_master->p_sync_ether_mutex);
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        break;

    case 1:
        cmd = DRV_IOR(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config), p_sync_ether_master->p_sync_ether_mutex);
        cmd = DRV_IOW(IOC_REG, SYNC_ETHERNET_CFG1, DRV_ENTRY_FLAG);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    sync_ether_config.cfg_ether_user_go0 = p_sync_ether_cfg->clock_output_en ? 1 : 0;
    sync_ether_config.cfg_ether_divider0 = p_sync_ether_cfg->divider;
    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config), p_sync_ether_master->p_sync_ether_mutex);
    CTC_ERROR_RETURN_WITH_UNLOCK(_sys_humber_sync_ether_serde_select_set(lchip, sync_ether_clock_id, p_sync_ether_cfg->recovered_clock_lport), p_sync_ether_master->p_sync_ether_mutex);
    CTC_ERROR_RETURN_WITH_UNLOCK(_sys_humber_sync_ether_release_reset(lchip, sync_ether_clock_id), p_sync_ether_master->p_sync_ether_mutex);
    SYNCE_UNLOCK;
    return CTC_E_NONE;
}

int32
sys_humber_sync_ether_get_cfg(uint8 lchip, uint8 sync_ether_clock_id, ctc_sync_ether_cfg_t* p_sync_ether_cfg)
{
    uint32 cmd = 0;
    sync_ethernet_cfg0_t sync_ether_config;

    SYS_SYNC_ETHER_INIT_CHECK();
    SYS_SYNC_ETHER_LCHIP_CHECK(lchip);
    CTC_PTR_VALID_CHECK(p_sync_ether_cfg);
    if (sync_ether_clock_id >= SYS_SYNC_ETHER_CLOCK_MAX)
    {
        return CTC_E_SYNCE_CLOCK_ID_EXCEED_MAX_VALUE;
    }

    sal_memset(&sync_ether_config, 0, sizeof(sync_ethernet_cfg0_t));

    SYNCE_LOCK;

    switch (sync_ether_clock_id)
    {
    case 0:
        cmd = DRV_IOR(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        break;

    case 1:
        cmd = DRV_IOR(IOC_REG, SYNC_ETHERNET_CFG0, DRV_ENTRY_FLAG);
        break;

    default:
        return CTC_E_INVALID_PARAM;
    }

    CTC_ERROR_RETURN_WITH_UNLOCK(drv_reg_ioctl(lchip, 0, cmd, &sync_ether_config), p_sync_ether_master->p_sync_ether_mutex);
    SYNCE_UNLOCK;

    p_sync_ether_cfg->clock_output_en = sync_ether_config.cfg_ether_user_go0;
    p_sync_ether_cfg->divider = sync_ether_config.cfg_ether_divider0;
    p_sync_ether_cfg->recovered_clock_lport = p_sync_ether_master->recovered_clock_lport[sync_ether_clock_id];

    return CTC_E_NONE;
}

