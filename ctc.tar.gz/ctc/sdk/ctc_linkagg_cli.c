/**
 @file ctc_linkagg_cli.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2009-11-18

 @version v2.0

 This file contains linkagg cli function
*/

#include "ctc_debug.h"
#include "ctc_vlan_cli.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_error.h"
#include "ctc_api.h"
#include "ctc_port_mapping_cli.h"

CTC_CLI(ctc_cli_linkagg_create,
        ctc_cli_linkagg_create_cmd,
        "linkagg create linkagg AGG_ID ((static|dynamic|failover|rr (random|))|)",
        CTC_CLI_LINKAGG_M_STR,
        "Create linkagg group",
        CTC_CLI_LINKAGG_DESC,
        CTC_CLI_LINKAGG_ID_DESC,
        "Static linkagg group",
        "Dlb linkagg group",
        "static likagg group enable failover",
        "Round robin group",
        "Random rr")
{
    int32 ret = CLI_SUCCESS;
    ctc_linkagg_group_t linkagg_grp;

    sal_memset(&linkagg_grp, 0, sizeof(ctc_linkagg_group_t));
    CTC_CLI_GET_UINT8("linkagg id", linkagg_grp.tid, argv[0]);

    if (argc > 1)
    {
        if (0 == sal_memcmp("static", argv[1], sizeof("static")))
        {
            linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_STATIC;
        }
        else if (0 == sal_memcmp("dynamic", argv[1], sizeof("dynamic")))
        {
            linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_DLB;
        }
        else if (0 == sal_memcmp("failover", argv[1], sizeof("failover")))
        {
            linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_STATIC_FAILOVER;
        }
        else
        {
            linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_RR;
            if (argc > 2)
            {
                linkagg_grp.flag |= CTC_LINKAGG_GROUP_FLAG_RANDOM_RR;
            }
        }
    }

    ret = ctc_linkagg_create(&linkagg_grp);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

CTC_CLI(ctc_cli_linkagg_remove,
        ctc_cli_linkagg_remove_cmd,
        "linkagg remove linkagg AGG_ID",
        CTC_CLI_LINKAGG_M_STR,
        "Remove linkagg group",
        CTC_CLI_LINKAGG_DESC,
        CTC_CLI_LINKAGG_ID_DESC)
{
    int32 ret = CLI_SUCCESS;
    uint8 tid = CTC_MAX_LINKAGG_GROUP_NUM;

    CTC_CLI_GET_UINT8("linkagg id", tid, argv[0]);

    ret = ctc_linkagg_destroy(tid);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_linkagg_add_or_remove_port,
        ctc_cli_linkagg_add_or_remove_port_cmd,
        "linkagg AGG_ID (add | remove) member-port GPHYPORT_ID",
        CTC_CLI_LINKAGG_M_STR,
        CTC_CLI_LINKAGG_ID_DESC,
        "Add member port to linkagg group",
        "Remove member port from linkagg group",
        "Member-port, global port",
        CTC_CLI_GPHYPORT_ID_DESC)
{
    int32 ret = CLI_SUCCESS;
    uint8 tid = CTC_MAX_LINKAGG_GROUP_NUM;
    uint16 gport = 0;

    CTC_CLI_GET_UINT8("linkagg id", tid, argv[0]);
    CTC_CLI_GET_UINT16("gport", gport, argv[2]);


    if (0 == sal_memcmp("ad", argv[1], 2))
    {
        ret = ctc_linkagg_add_port(tid, gport);
    }
    else if (0 == sal_memcmp("re", argv[1], 2))
    {
        ret = ctc_linkagg_remove_port(tid, gport);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_linkagg_show_member_port,
        ctc_cli_linkagg_show_member_port_cmd,
        "show linkagg AGG_ID member-ports",
        CTC_CLI_SHOW_STR,
        CTC_CLI_LINKAGG_M_STR,
        CTC_CLI_LINKAGG_ID_DESC,
        "Member ports of linkagg group")
{
    int32 ret = CLI_SUCCESS;
    uint8 cnt  = 0;
    uint8 idx = 0;
    uint8 tid = CTC_MAX_LINKAGG_GROUP_NUM;
    uint16* p_gports;
    uint8 max_num = 0;

    CTC_CLI_GET_UINT8("linkagg id", tid, argv[0]);

    ctc_linkagg_get_max_mem_num(&max_num);

    p_gports = (uint16*)sal_malloc(sizeof(uint16) * max_num);
    if (NULL == p_gports)
    {
        return CLI_ERROR;
    }

    sal_memset(p_gports, 0, sizeof(uint16) * max_num);

    ret = ctc_linkagg_get_member_ports(tid, p_gports, &cnt);

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("%-11s%s\n", "No.", "Member-Gport");
    ctc_cli_out("----------------------\n");

    for (idx = 0; idx < cnt; idx++)
    {
        CTC_PORT_UNMAPPING(p_gports[idx]);
        ctc_cli_out("%-11u0x%04X\n", idx + 1, p_gports[idx]);
    }

    sal_free(p_gports);
    p_gports = NULL;

    return ret;
}

CTC_CLI(ctc_cli_linkagg_debug_on,
        ctc_cli_linkagg_debug_on_cmd,
        "debug linkagg (ctc|sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_LINKAGG_M_STR,
        "CTC Layer",
        "SYS Layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = LINKAGG_CTC;
    }
    else
    {
        typeenum = LINKAGG_SYS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    ctc_debug_set_flag("linkagg", "linkagg", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_linkagg_debug_off,
        ctc_cli_linkagg_debug_off_cmd,
        "no debug linkagg (ctc|sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_LINKAGG_M_STR,
        "CTC Layer",
        "SYS Layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = LINKAGG_CTC;
    }
    else
    {
        typeenum = LINKAGG_SYS;
    }

    ctc_debug_set_flag("linkagg", "linkagg", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

int32
ctc_linkagg_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_create_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_remove_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_add_or_remove_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_show_member_port_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_linkagg_debug_off_cmd);

    return CLI_SUCCESS;
}

