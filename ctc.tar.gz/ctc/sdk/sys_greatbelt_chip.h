/**
 @file sys_greatbelt_chip.h

 @date 2009-10-19

 @version v2.0

 The file contains all chip related APIs of sys layer
*/

#ifndef _SYS_GREATBELT_CHIP_H
#define _SYS_GREATBELT_CHIP_H
#ifdef __cplusplus
extern "C" {
#endif

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_const.h"
#include "ctc_chip.h"
#include "ctc_debug.h"

/****************************************************************
*
* Defines and Macros
*
****************************************************************/
#define SYS_CHIP_HSS12G_MACRO_NUM   4
#define STS_CHIP_HSS12G_LINK_NUM   8
#define SYS_DRV_LOCAL_PORT_LENGTH           9
#define SYS_DRV_LOCAL_PORT_MASK           0x1FF

#define SYS_CHIP_CPU_MAC_ETHER_TYPE 0x5a5a
#define SYS_CHIP_SWITH_THREADHOLD 20

#define SYS_MAP_GPORT_TO_LPORT(gport, lchip, lport) \
    { \
        uint8 gchip; \
        gchip = ((gport >> CTC_LOCAL_PORT_LENGTH)); \
        if (gchip >= 0x1e){ \
            return CTC_E_INVALID_GLOBAL_CHIPID; } \
        lport = (gport & CTC_LOCAL_PORT_MASK); \
        if (lport >= MAX_PORT_NUM_PER_CHIP) \
        {return CTC_E_INVALID_LOCAL_PORT; } \
        if (FALSE == sys_greatbelt_chip_is_local(gchip, &lchip)) \
        {return CTC_E_CHIP_IS_REMOTE; } \
    }

#define SYS_MAP_GCHIP_TO_LCHIP(gchip, lchip) \
    { \
        if (gchip >= 0x1e) \
        {return CTC_E_INVALID_GLOBAL_CHIPID; } \
        if (FALSE == sys_greatbelt_chip_is_local(gchip, &lchip)) \
        {return CTC_E_CHIP_IS_REMOTE; } \
    }

#define SYS_MAP_GPORT_TO_GCHIP(gport) (((gport) >> CTC_LOCAL_PORT_LENGTH) & 0x1f)

/*Notice: the macro is only used to get driver gport, which can be used for software, actually local phy port supported by gb is 8 bits*/
#define SYS_MAP_CTC_GPORT_TO_DRV_GPORT(gport) ((CTC_MAP_GPORT_TO_GCHIP(gport) << SYS_DRV_LOCAL_PORT_LENGTH) |CTC_MAP_GPORT_TO_LPORT(gport))
#define SYS_MAP_DRV_PORT_TO_CTC_LPORT(port) (port & SYS_DRV_LOCAL_PORT_MASK)

#define SYS_LOCAL_CHIPID_CHECK(lchip) \
    do { \
        uint8 local_chip_num = sys_greatbelt_get_local_chip_num(); \
        if (lchip >= local_chip_num){ return CTC_E_INVALID_LOCAL_CHIPID; } \
    } while (0);

#define SYS_CHIP_DBG_OUT(level, FMT, ...) \
    do { \
        CTC_DEBUG_OUT(chip, chip, CHIP_SYS, level, FMT, ##__VA_ARGS__); \
    } while (0)

/*#define SYS_HUMBER_CHIP_CLOCK 625*/
#define CHIP_LOCK \
    if (p_chip_master->p_chip_mutex) sal_mutex_lock(p_chip_master->p_chip_mutex)

#define CHIP_UNLOCK \
    if (p_chip_master->p_chip_mutex) sal_mutex_unlock(p_chip_master->p_chip_mutex)

#define LCHIP_CHECK(lchip)                              \
    do {                                                     \
        if ((lchip) >= sys_greatbelt_get_local_chip_num()){  \
            return CTC_E_INVALID_LOCAL_CHIPID; }              \
    } while (0)

#define SYS_CHIP_FFE_C0_OFFSET 0x08
#define SYS_CHIP_FFE_C1_OFFSET 0x09
#define SYS_CHIP_FFE_C2_OFFSET 0x0a
#define SYS_CHIP_POLARITY_OFFSET 0x0d

#define SYS_CHIP_PLL_RESET0_OFFSET 0x8
#define SYS_CHIP_PLL_RESET1_OFFSET 0x9


struct sys_chip_master_s
{
    sal_mutex_t* p_chip_mutex;
    uint8   lchip_num;
    uint8   cut_through_en;
    uint8   g_chip_id[CTC_MAX_LOCAL_CHIP_NUM];
    uint8   port_mdio_mapping_tbl[CTC_MAX_PHY_PORT];
    uint8   port_phy_mapping_tbl[CTC_MAX_PHY_PORT];
    char    datapath_mode[20];
    uint8   first_ge_opt_reg_used;
    uint8   first_ge_opt_reg;
    uint8   second_ge_opt_reg_used;
    uint8   second_ge_opt_reg;
    mac_addr_t cpu_mac_sa;
    mac_addr_t cpu_mac_da[MAX_CTC_CPU_MACDA_NUM];
    uint8   cut_through_speed;
    uint8   ecc_recover_en;
    uint8   cpu_eth_en;
};
typedef struct sys_chip_master_s sys_chip_master_t;

enum sys_chip_mdio_bus_e
{
    SYS_CHIP_MDIO_BUS0,
    SYS_CHIP_MDIO_BUS1,
    SYS_CHIP_MDIO_BUS2,
    SYS_CHIP_MDIO_BUS3,

    SYS_CHIP_MAX_MDIO_BUS
};
typedef enum sys_chip_mdio_bus_e sys_chip_mdio_bus_t;

enum sys_datapath_debug_type_e
{
    SYS_CHIP_DATAPATH_DEBUG_PLL,
    SYS_CHIP_DATAPATH_DEBUG_HSS,
    SYS_CHIP_DATAPATH_DEBUG_SERDES,
    SYS_CHIP_DATAPATH_DEBUG_MAC,
    SYS_CHIP_DATAPATH_DEBUG_SYNCE,
    SYS_CHIP_DATAPATH_DEBUG_CALDE,
    SYS_CHIP_DATAPATH_DEBUG_MISC,
    SYS_CHIP_DATAPATH_DEBUG_CHAN,
    SYS_CHIP_DATAPATH_DEBUG_INTER_PORT,

    SYS_CHIP_HSS_MAX_DEBUG_TYPE
};
typedef enum sys_datapath_debug_type_e sys_datapath_debug_type_t;


enum sys_chip_device_id_type_e
{
    SYS_CHIP_DEVICE_ID_GB_5160,
    SYS_CHIP_DEVICE_ID_GB_5162,
    SYS_CHIP_DEVICE_ID_GB_5163,
    SYS_CHIP_DEVICE_ID_RM_5120,
    SYS_CHIP_DEVICE_ID_RT_3162,
    SYS_CHIP_DEVICE_ID_RT_3163,
    SYS_CHIP_DEVICE_ID_INVALID
};
typedef enum sys_chip_device_id_type_e sys_chip_device_id_type_t;

struct sys_chip_device_info_s
{
    uint16 device_id;
    uint16 version_id;
};
typedef struct sys_chip_device_info_s sys_chip_device_info_t;

/*Notice: Cannot change enum, refer to ctc_bpe_intlk_mode_t */
enum sys_chip_intlk_mode_e
{
    SYS_CHIP_INTLK_PKT_MODE,
    SYS_CHIP_INTLK_SEGMENT_MODE,
    SYS_CHIP_INTLK_FABRIC_MODE
};
typedef enum sys_chip_intlk_mode_e sys_chip_intlk_mode_t;

/****************************************************************************
 *
* Function
*
*****************************************************************************/
extern int32
sys_greatbelt_chip_init(uint8 lchip_num);

extern uint8
sys_greatbelt_get_local_chip_num(void);

extern int32
sys_greatbelt_set_gchip_id(uint8 lchip_id, uint8 gchip_id);

extern bool
sys_greatbelt_chip_is_local(uint8 gchip_id, uint8* lchip_id);

extern int32
sys_greatbelt_get_gchip_id(uint8 lchip_id, uint8* gchip_id);

extern int32
sys_greatbelt_datapath_init(void);

extern int32
sys_greatbelt_chip_ecc_recover_init(void);

extern uint32
sys_greatbelt_chip_get_ecc_recover_en(void);

extern int32
sys_greatbelt_chip_show_ecc_recover_status(uint8 lchip, uint8 is_all);

extern int32
sys_greatbelt_set_chip_global_cfg(ctc_chip_global_cfg_t* chip_cfg);

extern int32
sys_greatbelt_get_chip_clock(uint16* freq);

extern int32
sys_greatbelt_get_chip_cpumac(uint8* mac_sa, uint8* mac_da);

extern int32
sys_greatbelt_chip_get_cpu_eth_en(uint8 *enable);

extern int32
sys_greatbelt_chip_set_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para);

extern int32
sys_greatbelt_chip_get_phy_mapping(ctc_chip_phy_mapping_para_t* phy_mapping_para);

extern int32
sys_greatbelt_chip_get_phy_mdio(uint16 gport, uint8* mdio_bus, uint8* phy_addr);

extern int32
sys_greatbelt_chip_write_gephy_reg(uint16 gport, ctc_chip_gephy_para_t* gephy_para);

extern int32
sys_greatbelt_chip_read_gephy_reg(uint16 gport, ctc_chip_gephy_para_t* gephy_para);

extern int32
sys_greatbelt_chip_write_xgphy_reg(uint16 gport, ctc_chip_xgphy_para_t* xgphy_para);

extern int32
sys_greatbelt_chip_read_xgphy_reg(uint16 gport, ctc_chip_xgphy_para_t* xgphy_para);

extern int32
sys_greatbelt_chip_set_gephy_scan_special_reg(ctc_chip_ge_opt_reg_t* p_gephy_opt, bool enable);

extern int32
sys_greatbelt_chip_set_xgphy_scan_special_reg(ctc_chip_xg_opt_reg_t* p_xgphy_opt, uint8 enable);

extern int32
sys_greatbelt_chip_set_phy_scan_para(ctc_chip_phy_scan_ctrl_t* p_scan_para);

extern int32
sys_greatbelt_chip_set_phy_scan_en(uint8 lchip, bool enable);

extern int32
sys_greatbelt_chip_set_i2c_scan_para(ctc_chip_i2c_scan_t* p_i2c_para);

extern int32
sys_greatbelt_chip_set_i2c_scan_en(uint8 lchip, bool enable);

extern int32
sys_greatbelt_chip_read_i2c_buf(ctc_chip_i2c_scan_read_t* p_i2c_scan_read);

extern int32
sys_greatbelt_chip_i2c_read(ctc_chip_i2c_read_t* p_i2c_para);

extern int32
sys_greatbelt_chip_i2c_write(ctc_chip_i2c_write_t* p_i2c_para);

extern int32
sys_greatbelt_chip_set_mac_led_mode(ctc_chip_led_para_t* p_led_para, ctc_chip_mac_led_type_t led_type);

extern int32
sys_greatbelt_chip_set_mac_led_mapping(ctc_chip_mac_led_mapping_t* p_led_map);

extern int32
sys_greatbelt_chip_set_mac_led_en(uint8 lchip, bool enable);

extern int32
sys_greatbelt_chip_set_gpio_mode(uint8 gpio_id, ctc_chip_gpio_mode_t mode);

extern int32
sys_greatbelt_chip_set_gpio_output(uint8 gpio_id, uint8 out_para);

extern int32
sys_greatbelt_chip_set_access_type(ctc_chip_access_type_t access_type);

extern int32
sys_greatbelt_chip_get_access_type(ctc_chip_access_type_t* p_access_type);

extern int32
sys_greatbelt_chip_hss12g_link_power_up(uint8 lchip, uint8 hssid, uint8 link_idx);

extern int32
sys_greatbelt_chip_hss12g_link_power_down(uint8 lchip, uint8 hssid, uint8 link_idx);

/* return value units: MHz*/
extern uint32
sys_greatbelt_get_core_freq(uint8 lchip);

int32
sys_greatbelt_datapath_sim_init(void);

int32
sys_greatbelt_chip_set_serdes_mode(uint8 lchip, ctc_chip_serdes_info_t* p_serdes_info);

int32
sys_greatbelt_parse_datapath_file(char* datapath_config_file);

int32
sys_greatbelt_init_pll_hss(void);

int32
sys_greatbelt_chip_mdio_read(uint8 lchip, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para);

int32
sys_greatbelt_chip_mdio_write(uint8 lchip, ctc_chip_mdio_type_t type, ctc_chip_mdio_para_t* p_para);

int32
sys_greatbelt_chip_set_hss12g_enable(uint8 lchip, uint8 hssid, ctc_chip_serdes_mode_t mode, uint8 enable);


/*cut through*/
extern int32
sys_greatbelt_get_cut_through_speed(uint16 gport);

extern int32
sys_greatbelt_get_cut_through_en();

extern int32
sys_greatbelt_chip_set_mdio_clock(ctc_chip_mdio_type_t type, uint16 freq);

extern int32
sys_greatbelt_chip_get_mdio_clock(ctc_chip_mdio_type_t type, uint16* freq);

extern int32
sys_greatbelt_get_chip_sensor(uint8 lchip, ctc_chip_sensor_type_t type, uint32* p_value);

extern int32
sys_greatbelt_chip_set_property(uint8 lchip, ctc_chip_property_t chip_prop, void* p_value);

extern int32
sys_greatbelt_chip_reset_rx_serdes(uint8 lchip, uint8 serdes_id, uint8 reset);

extern int32
sys_greatbelt_chip_set_force_signal_detect(uint8 lchip, bool enable);

extern int32
sys_greatbelt_chip_reset_mdio(uint8 lchip);

extern int32
sys_greatbelt_chip_get_device_info(uint8 lchip, sys_chip_device_info_t* p_device_info);

extern int32
sys_greatbelt_chip_get_net_tx_cal_10g_entry(uint8 lchip, uint8* value);

extern char *
sys_greatbelt_chip_deviceid2str(sys_chip_device_info_t* p_device_info);

extern int32
sys_greatbelt_chip_device_check(uint8 lchip);

extern int32
sys_greatbelt_chip_intlk_register_init(uint8 lchip, uint8 intlk_mode);

extern int32
sys_greatbelt_chip_reset_rx_hss(uint8 lchip, uint8 hss_id, uint8 reset);
#ifdef __cplusplus
}
#endif

#endif

