/**
 @file ctc_greatbelt_queue.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2010-01-13

 @version v2.0

   The file provide all queue related APIs of greatbelt SDK.
*/

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#include "sal.h"
#include "ctc_error.h"
#include "ctc_const.h"

#include "ctc_greatbelt_qos.h"
#include "sys_greatbelt_qos.h"

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declaration
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Function
 *
 ****************************************************************************/

/*init*/
extern int32
ctc_greatbelt_qos_init(uint8 lchip, void* p_glb_parm)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_init(p_glb_parm));
    return CTC_E_NONE;
}

/*policer*/
extern int32
ctc_greatbelt_qos_set_policer(uint8 lchip, ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_policer(p_policer));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_policer(uint8 lchip, ctc_qos_policer_t* p_policer)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_policer(p_policer));
    return CTC_E_NONE;
}

/*global param*/
extern int32
ctc_greatbelt_qos_set_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_global_config(p_glb_cfg));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_global_config(uint8 lchip, ctc_qos_glb_cfg_t* p_glb_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_global_config(p_glb_cfg));
    return CTC_E_NONE;
}

/*mapping*/
extern int32
ctc_greatbelt_qos_set_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_domain_map(p_domain_map));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_domain_map(uint8 lchip, ctc_qos_domain_map_t* p_domain_map)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_domain_map(p_domain_map));
    return CTC_E_NONE;
}

/*queue*/
extern int32
ctc_greatbelt_qos_set_queue(uint8 lchip, ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_queue(p_que_cfg));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_queue(uint8 lchip, ctc_qos_queue_cfg_t* p_que_cfg)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_queue(p_que_cfg));
    return CTC_E_NONE;
}

/*shape*/
extern int32
ctc_greatbelt_qos_set_shape(uint8 lchip, ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_shape(p_shape));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_shape(uint8 lchip, ctc_qos_shape_t* p_shape)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_shape(p_shape));
    return CTC_E_NONE;
}

/*schedule*/
extern int32
ctc_greatbelt_qos_set_sched(uint8 lchip, ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_sched(p_sched));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_sched(uint8 lchip, ctc_qos_sched_t* p_sched)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_sched(p_sched));
    return CTC_E_NONE;
}

/*drop*/
extern int32
ctc_greatbelt_qos_set_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_set_drop_scheme(p_drop));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_get_drop_scheme(uint8 lchip, ctc_qos_drop_t* p_drop)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_get_drop_scheme(p_drop));
    return CTC_E_NONE;
}

/*stats*/
extern int32
ctc_greatbelt_qos_query_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_query_queue_stats(p_queue_stats));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_clear_queue_stats(uint8 lchip, ctc_qos_queue_stats_t* p_queue_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_clear_queue_stats(p_queue_stats));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_query_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_query_policer_stats(p_policer_stats));
    return CTC_E_NONE;
}

extern int32
ctc_greatbelt_qos_clear_policer_stats(uint8 lchip, ctc_qos_policer_stats_t* p_policer_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_qos_clear_policer_stats(p_policer_stats));
    return CTC_E_NONE;
}

