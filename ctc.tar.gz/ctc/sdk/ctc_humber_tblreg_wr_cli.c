#include "ctc_error.h"
#include "ctc_debug.h"
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_const.h"

#include "drv_io.h"
#include "drv_cfg.h"
#include "drv_humber.h"

#include "ctc_humber_tblreg_wr_cli.h"
#define _GLB_ENABLE_DBGSHOW_

#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG      0
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG      1
#define CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL       2
#define CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL       3
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG      4
#define CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL      5
#define CTC_DIAG_TBLREG_CHIP_LIST_REG               6
#define CTC_DIAG_TBLREG_CHIP_LIST_TBL                7

typedef struct
{
    uint32  param[5];
    uint8   buf[CTC_HUMBER_TR_BUF_SIZE];
}
ctc_dbg_tblreg_show_req_t;

void
ctc_humber_sort_tblreg_fields(fields_t* fld_ptr, uint8 num_fields, uint8* sequence)
{
    uint8 field_idx = 0;
    int16 fld_idx = 0;
    int16 fld_idx_tmp = 0;

    /* sort all field */
    for (field_idx = 0; field_idx < num_fields; field_idx++)
    {
        /* For every field, loop to compare with previous field in sequence[], which is sorted.
           If the field is small than previous one, do swap. So it may be do many times swap for a field */
        for (fld_idx = field_idx; fld_idx >= 0; fld_idx--)
        {
            if (fld_idx == 0)
            {
                sequence[0] = field_idx;
                break;
            }

            fld_idx_tmp = sequence[fld_idx - 1];
            if (fld_ptr[field_idx].word_offset < fld_ptr[fld_idx_tmp].word_offset)
            {
                sequence[fld_idx] = sequence[fld_idx - 1];
            }
            else if (fld_ptr[field_idx].word_offset == fld_ptr[fld_idx_tmp].word_offset)
            {
                if (fld_ptr[field_idx].bit_offset > fld_ptr[fld_idx_tmp].bit_offset)
                {
                    sequence[fld_idx] = sequence[fld_idx - 1];
                }
                else
                {
                    sequence[fld_idx] = field_idx;
                    break;
                }
            }
            else
            {
                sequence[fld_idx] = field_idx;
                break;
            }
        }
    }
}

void
ctc_dbg_tblreg_dump_chip_read_reg_db_by_id(int8* reg_name, uint32 id, uint32 detail)
{
    registers_t* reg_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 fld_idx = 0;
    uint32 fld_idx_tmp;
    uint32 reg_id = 0;
    uint32 filed_id = 0;
    uint8* sequence = NULL;

    for (reg_id = 0; reg_id < id; reg_id++)
    {
        filed_id += DRV_REG_GET_INFO(reg_id).num_fields;
    }

    reg_ptr = DRV_REG_GET_INFOPTR(id);

    ctc_cli_out("%-5s %-10s %-6s %-6s %-6s %-20s\n",
                "RegID", "Address", "Number", "DataSZ", "Fields", "Name");
    ctc_cli_out("----------------------------------------------------------------------\n");

    ctc_cli_out("%-5d 0x%08x %-6d %-6d %-6d %-20s\n",
                id, reg_ptr->hw_data_base, reg_ptr->max_index_num, reg_ptr->entry_size,
                reg_ptr->num_fields, reg_name);

    if (detail)
    {
        sequence = (uint8*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(uint8*) * reg_ptr->num_fields);
        if (!sequence)
        {
            return;
        }

        sal_memset(sequence, 0, sizeof(uint8*) * reg_ptr->num_fields);
        ctc_humber_sort_tblreg_fields(reg_ptr->ptr_fields, reg_ptr->num_fields, sequence);

        ctc_cli_out("%-5s %-5s %-6s %-4s %-4s %-30s\n", "RegID", "FldID", "Length", "Word", "Bit", "Name");

        for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
        {
            fld_idx_tmp = sequence[fld_idx];
            fld_ptr = &(reg_ptr->ptr_fields[fld_idx_tmp]);
            ctc_cli_out("%-5d %-5d %-6d %-4d %-4d %-30s\n", id, fld_idx_tmp, fld_ptr->len,
                        fld_ptr->word_offset, fld_ptr->bit_offset, CTC_HUMBER_GET_REG_FIELD_STR(filed_id + fld_idx_tmp));
        }

        ctc_cli_out("\n");
        mem_free(sequence);
        sequence = NULL;
    }
}

void
ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(int8* tbl_name, uint32 id, uint32 detail)
{
    tables_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    uint32 fld_idx = 0;
    uint32 fld_idx_tmp;
    uint32 tbl_id = 0;
    uint32 filed_id = 0;
    uint8* sequence = NULL;

    for (tbl_id = 0; tbl_id < id; tbl_id++)
    {
        filed_id += DRV_TBL_GET_INFO(tbl_id).num_fields;
    }

    tbl_ptr = DRV_TBL_GET_INFOPTR(id);

    ctc_cli_out("%-5s %-10s %-10s %-6s %-6s %-6s %-6s %-20s\n",
                "TblID", "Address", "MaskAddr", "Number", "KeySZ", "DataSZ", "Fields", "Name");
    ctc_cli_out("--------------------------------------------------------------------------------\n");

    ctc_cli_out("%-5d 0x%08x 0x%08x %-6d %-6d %-6d %-6d %-20s\n",
                id, tbl_ptr->hw_data_base, tbl_ptr->hw_mask_base, tbl_ptr->max_index_num,
                tbl_ptr->key_size, tbl_ptr->entry_size, tbl_ptr->num_fields, tbl_name);

    if (detail)
    {
        sequence = (uint8*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(uint8*) * tbl_ptr->num_fields);
        sal_memset(sequence, 0, sizeof(uint8*) * tbl_ptr->num_fields);
        ctc_humber_sort_tblreg_fields(tbl_ptr->ptr_fields, tbl_ptr->num_fields, sequence);

        ctc_cli_out("%-5s %-5s %-6s %-4s %-4s %-30s\n", "TblID", "FldID", "Length", "Word", "Bit", "Name");

        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_idx_tmp = sequence[fld_idx];
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx_tmp]);
            ctc_cli_out("%-5d %-5d %-6d %-4d %-4d %-30s\n", id, fld_idx_tmp,
                        fld_ptr->len, fld_ptr->word_offset, fld_ptr->bit_offset, CTC_HUMBER_GET_TBL_FIELD_STR(filed_id + fld_idx_tmp));
        }

        ctc_cli_out("\n");

        mem_free(sequence);
        sequence = NULL;
    }
}

int32
ctc_dbg_tblreg_dump_chip_read_reg_db(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 reg_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    int8* reg_name = NULL;

    all = req->param[1];
    detail = req->param[2];

    reg_name = (int8*)req->buf;
    if ((ret = ctc_humber_tr_str2id(REGISTER_ID, reg_name, &reg_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", reg_name);
        return CLI_ERROR;
    }

    ctc_dbg_tblreg_dump_chip_read_reg_db_by_id(reg_name, reg_id, detail);

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CLI_SUCCESS;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl_db(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 tbl_id = 0;
    uint32 all = 0;
    uint32 detail = 0;
    int32 ret = 0;
    int8* tbl_name = NULL;

    all = req->param[1];
    detail = req->param[2];

    tbl_name = (int8*)req->buf;
    if ((ret = ctc_humber_tr_str2id(TABLE_ID, tbl_name, &tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CTC_E_NONE;
    }

    ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id(tbl_name, tbl_id, detail);
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CTC_E_NONE;
}

extern uint32 ctc_get_local_chip_num(uint8* chip_num);

int32
ctc_dbg_tblreg_dump_chip_read_reg(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    int8* reg_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 reg_id = 0;
    uint32 value = 0;
    uint32 num = 0;
    int32 ret = 0;
    registers_t* reg_ptr = NULL;
    fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 fld_idx_tmp = 0;
    uint32 addr = 0;
    uint8 chip_num = 0;
    uint32 id = 0;
    uint32 filed_id = 0;
    uint8* sequence = NULL;

    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    reg_name = (int8*)req->buf;

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        ctc_cli_out("%% Chip %d out-of-range\n", chip);
        return CTC_E_NONE;
    }

    if ((ret = ctc_humber_tr_str2id(REGISTER_ID, reg_name, &reg_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", reg_name);
        return CTC_E_NONE;
    }

    for (id = 0; id < reg_id; id++)
    {
        filed_id += DRV_REG_GET_INFO(id).num_fields;
    }

    reg_ptr = DRV_REG_GET_INFOPTR(reg_id);
    sequence = (uint8*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(uint8*) * reg_ptr->num_fields);
    sal_memset(sequence, 0, sizeof(uint8*) * reg_ptr->num_fields);
    ctc_humber_sort_tblreg_fields(reg_ptr->ptr_fields, reg_ptr->num_fields, sequence);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= reg_ptr->max_index_num)
        {
            ctc_cli_out("%% Index %d out-of-range %d\n", index, reg_ptr->max_index_num);
            break;
        }

        ret = drv_io_api[chip].drv_sram_reg_read(chip, reg_id, index, entry_data_buf);
        if (ret < 0)
        {
            ctc_cli_out("%% Read index %d failed %d\n", index, ret);
            break;
        }

        addr  = reg_ptr->hw_data_base + index * reg_ptr->entry_size;
        ctc_cli_out("%-6s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Name", index, addr);
        ctc_cli_out("----------------------------------------------------------------------\n");

        for (fld_idx = 0; fld_idx < reg_ptr->num_fields; fld_idx++)
        {
            fld_idx_tmp = sequence[fld_idx];
            fld_ptr = &(reg_ptr->ptr_fields[fld_idx_tmp]);
            drv_reg_field_get(reg_id, fld_idx_tmp, entry_data_buf, &value);
            ctc_cli_out("%-6d 0x%08x %-10s\n", fld_idx_tmp, value, CTC_HUMBER_GET_REG_FIELD_STR(filed_id + fld_idx_tmp));
        }

        ctc_cli_out("\n");
    }

    mem_free(sequence);
    sequence = NULL;
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CTC_E_NONE;
}

int32
ctc_dbg_tblreg_dump_chip_read_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    uint32 entry_mask_buf[MAX_ENTRY_WORD];
    tbl_entry_t entry;
    int8* tbl_name = NULL;
    uint8 chip = 0;
    int32 start_index = 0;
    int32 index = 0;
    uint32 tbl_id = 0;
    uint32 value = 0;
    uint32 mask = 0;
    uint32 num = 0;
    int32 ret = 0;
    tables_t* tbl_ptr = NULL;
    fields_t* fld_ptr = NULL;
    int32 i = 0;
    int32 fld_idx = 0;
    uint32 fld_idx_tmp = 0;
    uint32 addr = 0;
    uint8 chip_num = 0;
    uint32 id = 0;
    uint32 filed_id = 0;
    uint8* sequence = NULL;

    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    sal_memset(entry_mask_buf, 0, sizeof(entry_mask_buf));
    entry.data_entry = entry_data_buf;
    entry.mask_entry = entry_mask_buf;

    chip = req->param[1];
    start_index = req->param[2];
    num = req->param[3];
    tbl_name = (int8*)req->buf;

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        ctc_cli_out("%% Chip %d out-of-range\n", chip);
        return CTC_E_NONE;
    }

    if ((ret = ctc_humber_tr_str2id(TABLE_ID, tbl_name, &tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", tbl_name);
        return CTC_E_NONE;
    }

    for (id = 0; id < tbl_id; id++)
    {
        filed_id += DRV_TBL_GET_INFO(id).num_fields;
    }

    tbl_ptr = DRV_TBL_GET_INFOPTR(tbl_id);
    sequence = (uint8*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(uint8*) * tbl_ptr->num_fields);
    sal_memset(sequence, 0, sizeof(uint8*) * tbl_ptr->num_fields);
    ctc_humber_sort_tblreg_fields(tbl_ptr->ptr_fields, tbl_ptr->num_fields, sequence);

    for (i = 0; i < num; i++)
    {
        index = start_index + i;
        if (index >= tbl_ptr->max_index_num)
        {
            ctc_cli_out("%% Index %d out-of-range %d\n", index, tbl_ptr->max_index_num);
            break;
        }

        if ((tbl_id == DS_POLICER) || (tbl_id == DS_FORWARDING_STATS))
        {
            uint32 cmd;
            uint32 data_entry[MAX_ENTRY_WORD] = {0};
            cmd = DRV_IOR(IOC_TABLE, tbl_id, DRV_ENTRY_FLAG);
            ret = drv_tbl_ioctl(chip, index, cmd, data_entry);
            drv_sram_tbl_ds_to_entry(tbl_id, data_entry, entry.data_entry);
        }
        else
        {
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                ret = drv_io_api[chip].drv_sram_tbl_read(chip, tbl_id, index, entry.data_entry);
            }
            else
            {
                ret = drv_io_api[chip].drv_tcam_tbl_read(chip, tbl_id, index, &entry);
            }
        }

        if (ret < 0)
        {
            ctc_cli_out("%% Read index %d failed %d\n", index, ret);
            break;
        }

        if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
        {
            addr  = tbl_ptr->hw_data_base + index * tbl_ptr->entry_size;
            ctc_cli_out("%-6s %-10s %-10s %-10s Index(%d) Address(0x%08x)\n", "Field", "Value", "Mask", "Name", index, addr);
        }
        else
        {
            ctc_cli_out("%-6s %-10s %-10s %-10s Index(%d)\n", "Field", "Value", "Mask", "Name", index);
        }

        ctc_cli_out("----------------------------------------------------------------------\n");

        for (fld_idx = 0; fld_idx < tbl_ptr->num_fields; fld_idx++)
        {
            fld_idx_tmp = sequence[fld_idx];
            fld_ptr = &(tbl_ptr->ptr_fields[fld_idx_tmp]);
            drv_tbl_field_get(tbl_id, fld_idx_tmp, entry.data_entry, &value);
            if (INVALID_MASK_OFFSET == tbl_ptr->hw_mask_base)
            {
                ctc_cli_out("%-6d 0x%08x %-10s %-10s\n", fld_idx_tmp, value, "", CTC_HUMBER_GET_TBL_FIELD_STR(filed_id + fld_idx_tmp));
            }
            else
            {
                drv_tbl_field_get(tbl_id, fld_idx_tmp, entry.mask_entry, &mask);
                ctc_cli_out("%-6d 0x%08x 0x%08x %-10s\n", fld_idx_tmp, value, mask, CTC_HUMBER_GET_TBL_FIELD_STR(filed_id + fld_idx_tmp));
            }
        }

        ctc_cli_out("\n");
    }

    mem_free(sequence);
    sequence = NULL;
#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CTC_E_NONE;
}

int32
ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    uint32 entry_data_buf[MAX_ENTRY_WORD];
    int8* reg_name = NULL;
    uint8 chip = 0;
    int32 index = 0;
    uint32 reg_tbl_id = 0;
    uint32 value = 0;
    uint32 cmd = 0;
    int32 ret = 0;
    registers_t* reg_ptr = NULL;
    tables_t* tbl_ptr = NULL;
    int32 fld_id = 0;
    int32 fld_ok = FALSE;
    uint32 max_index_num = 0;
    uint32 reg_or_tbl = (CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG == req->param[0]) ? REGISTER_ID : TABLE_ID;
    uint8 chip_num = 0;

    sal_memset(entry_data_buf, 0, sizeof(entry_data_buf));
    chip = req->param[1];
    index = req->param[2];
    fld_id = req->param[3];
    value = req->param[4];
    reg_name = (int8*)req->buf;

    sal_printf("Write %s field %d chip %d index %d value 0x%0x \n",
               reg_name, fld_id, chip, index, value);

    ctc_get_local_chip_num(&chip_num);
    if (chip >= chip_num)
    {
        ctc_cli_out("%% Chip %d out-of-range\n", chip);
        return CTC_E_NONE;
    }

    if ((ret = ctc_humber_tr_str2id(reg_or_tbl, reg_name, &reg_tbl_id)) < 0)
    {
        ctc_cli_out("%% Not found %s\n", reg_name);
        return CTC_E_NONE;
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        reg_ptr = DRV_REG_GET_INFOPTR(reg_tbl_id);
        if (fld_id < reg_ptr->num_fields)
        {
            fld_ok = TRUE;
        }

        max_index_num = reg_ptr->max_index_num;
    }
    else
    {
        tbl_ptr = DRV_TBL_GET_INFOPTR(reg_tbl_id);
        if (fld_id < tbl_ptr->num_fields)
        {
            fld_ok = TRUE;
        }

        max_index_num = tbl_ptr->max_index_num;
    }

    if (!fld_ok)
    {
        ctc_cli_out("%% %s has no field %d\n", reg_name, fld_id);
        return CTC_E_NONE;
    }

    if (index >= max_index_num)
    {
        ctc_cli_out("%% Index %d out-of-range %d\n", index, max_index_num);
        return CTC_E_NONE;
    }

    if (REGISTER_ID == reg_or_tbl)
    {
        cmd = DRV_IOW(IOC_REG, reg_tbl_id, fld_id);
        ret = drv_reg_ioctl(chip, index, cmd, &value);
    }
    else
    {
        cmd = DRV_IOW(IOC_TABLE, reg_tbl_id, fld_id);
        ret = drv_tbl_ioctl(chip, index, cmd, &value);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% Write %s index %d failed %d\n", (REGISTER_ID == reg_or_tbl) ? "tbl" : "reg", index, ret);
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */
    return CTC_E_NONE;
}

int32
ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(ctc_dbg_tblreg_show_req_t* req)
{
#define CTC_HUMBER_LIST_MAX_NUM 64
    uint32 ids[CTC_HUMBER_LIST_MAX_NUM];
    uint8 upper_name[CTC_HUMBER_TR_BUF_SIZE];
    uint32  i = 0;
    uint32 id_index = 0;
    uint32 first_flag = TRUE;
    registers_t* reg_ptr = NULL;
    tables_t* tbl_ptr = NULL;
    uint8* p_char = NULL;

    sal_memset(ids, 0, sizeof(ids));
    sal_memset(upper_name, 0, sizeof(upper_name));

    if (0 == sal_strlen((char*)req->buf))
    {
        ctc_cli_out("%% Input NULL string \n");
    }

    sal_strncpy((char*)upper_name, (char*)req->buf, CTC_HUMBER_TR_BUF_SIZE);

    /* convert the alphabets to upper case before comparison */
    for (i = 0; i < sal_strlen((char*)upper_name); i++)
    {
        if (sal_isalpha(upper_name[i]) && sal_islower(upper_name[i]))
        {
            upper_name[i] = sal_toupper(upper_name[i]);
        }
    }

    if (CTC_DIAG_TBLREG_CHIP_LIST_REG == req->param[0])
    {
        for (i = 0; i < MAX_REG_NUM; i++)
        {
            p_char = (uint8*)sal_strstr((char*)ctc_humber_reg_str[i], (char*)upper_name);
            if (p_char)
            {
                if (sal_strlen((char*)ctc_humber_reg_str[i]) == sal_strlen((char*)upper_name))
                {
                    /* full match */
                    ctc_dbg_tblreg_dump_chip_read_reg_db_by_id((int8*)upper_name, i, TRUE);
                    return CTC_E_NONE;
                }

                ids[id_index] = i;
                id_index++;
                if (id_index >= CTC_HUMBER_LIST_MAX_NUM)
                {
                    ctc_cli_out("Too much matched, only display first %d entries. \n", id_index);
                    break;
                }
            }
        }

        if (id_index == 0)
        {
            ctc_cli_out("%% Not found %s \n", req->buf);
            return CTC_E_NONE;
        }

        for (i = 0; i < id_index; i++)
        {
            reg_ptr = DRV_REG_GET_INFOPTR(ids[i]);

            if (first_flag)
            {
                ctc_cli_out("Found %d matched entries  \n", id_index);
                ctc_cli_out("%-5s %-10s %-6s %-6s %-6s %-20s\n",
                            "RegID", "Address", "Number", "DataSZ", "Fields", "Name");
                ctc_cli_out("----------------------------------------------------------------------\n");
                first_flag = FALSE;
            }

            ctc_cli_out("%-5d 0x%08x %-6d %-6d %-6d %-20s\n",
                        ids[i], reg_ptr->hw_data_base, reg_ptr->max_index_num, reg_ptr->entry_size,
                        reg_ptr->num_fields, ctc_humber_reg_str[ids[i]]);
        }
    }
    else if (CTC_DIAG_TBLREG_CHIP_LIST_TBL == req->param[0])
    {
        for (i = 0; i < MAX_TBL_NUM; i++)
        {
            p_char = (uint8*)sal_strstr((char*)ctc_humber_table_str[i], (char*)upper_name);
            if (p_char)
            {
                if (sal_strlen((char*)ctc_humber_table_str[i]) == sal_strlen((char*)upper_name))
                {
                    /* full match */
                    ctc_dbg_tblreg_dump_chip_read_tbl_db_by_id((int8*)upper_name, i, TRUE);
                    return CTC_E_NONE;
                }

                ids[id_index] = i;
                id_index++;
                if (id_index >= CTC_HUMBER_LIST_MAX_NUM)
                {
                    ctc_cli_out("Too much matched, only display first %d entries. \n", id_index);
                    break;
                }
            }
        }

        if (id_index == 0)
        {
            ctc_cli_out("%% Not found %s \n", req->buf);
            return CTC_E_NONE;
        }

        for (i = 0; i < id_index; i++)
        {
            tbl_ptr = DRV_TBL_GET_INFOPTR(ids[i]);

            if (first_flag)
            {
                ctc_cli_out("Found %d matched entries  \n", id_index);
                ctc_cli_out("%-5s %-10s %-10s %-6s %-6s %-6s %-6s %-20s\n",
                            "TblID", "Address", "MaskAddr", "Number", "KeySZ", "DataSZ", "Fields", "Name");
                ctc_cli_out("--------------------------------------------------------------------------------\n");
                first_flag = FALSE;
            }

            ctc_cli_out("%-5d 0x%08x 0x%08x %-6d %-6d %-6d %-6d %-20s\n",
                        ids[i], tbl_ptr->hw_data_base, tbl_ptr->hw_mask_base, tbl_ptr->max_index_num,
                        tbl_ptr->key_size, tbl_ptr->entry_size, tbl_ptr->num_fields, ctc_humber_table_str[ids[i]]);
        }
    }

    return CTC_E_NONE;
}

int32
ctc_dbg_tblreg_dump_chip(ctc_dbg_tblreg_show_req_t* req)
{
#ifdef _GLB_ENABLE_DBGSHOW_
    int32 ret = 0;

    switch (req->param[0])
    {
    case CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG:
        ret = ctc_dbg_tblreg_dump_chip_read_reg_db(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG:
        ret = ctc_dbg_tblreg_dump_chip_read_reg(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl_db(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL:
        ret = ctc_dbg_tblreg_dump_chip_read_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG:
    case CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL:
        ret = ctc_dbg_tblreg_dump_chip_write_reg_or_tbl(req);
        break;

    case CTC_DIAG_TBLREG_CHIP_LIST_REG:
    case CTC_DIAG_TBLREG_CHIP_LIST_TBL:
        ret = ctc_dbg_tblreg_dump_chip_list_tbl_or_reg(req);
        break;

    default:
        break;
    }

#endif /* _GLB_ENABLE_DBGSHOW_ */

    return CTC_E_NONE;
}

CTC_CLI(ctc_cli_hb_debug_tblreg_show_drv_list_reg,
        show_cli_drv_list_reg_cmd,
        "listreg REG_NAME",
        "List registers",
        "Substring of register name")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 opcode = CTC_DIAG_TBLREG_CHIP_LIST_REG;

    req.param[0] = opcode;

    sal_strncpy((char*)req.buf, argv[0], CTC_HUMBER_TR_BUF_SIZE);
    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tblreg_show_drv_list_tbl,
        show_cli_drv_list_tbl_cmd,
        "listtbl STRING:TBL_NAME",
        "List tables",
        "Substring of table name")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 opcode = CTC_DIAG_TBLREG_CHIP_LIST_TBL;

    req.param[0] = opcode;

    sal_strncpy((char*)req.buf, argv[0], CTC_HUMBER_TR_BUF_SIZE);
    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tblreg_show_drv_get_reg_or_tbl,
        show_cli_drv_get_reg_or_tbl_cmd,
        "read humber CHIP_ID (reg|tbl) (TBL_REG_NAME|) (detail|)",
        "Read registers",
        "Humber",
        "Chip Id <0-1>",
        "Register",
        "Table",
        "Register or table name",
        "Detail")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 chip = 0;
    uint32 all = TRUE;
    uint32 detail = FALSE;
    uint32 opcode = 0;

    CTC_CLI_GET_UINT32_RANGE("Chip", chip, argv[0], 0, 1);

    if ((CLI_CLI_STR_EQUAL("reg", 1)))
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_S_REG;
    }
    else
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_S_TBL;
    }

    if (argc > 2)
    {
        if (argc == 4)
        {
            all = FALSE;
            detail = TRUE;
        }
        else
        {
            if ((CLI_CLI_STR_EQUAL("detail", 2)))
            {
                all = TRUE;
                detail = TRUE;
            }
            else
            {
                all = FALSE;
                detail = FALSE;
            }
        }
    }

    if (!all)
    {
        sal_strncpy((char*)req.buf, argv[2], CTC_HUMBER_TR_BUF_SIZE);
    }

    req.param[0] = opcode;
    req.param[1] = all;
    req.param[2] = detail;
    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tblreg_show_drv_read_reg_or_tbl_field,
        show_cli_drv_read_reg_or_tbl_field_cmd,
        "read humber CHIP_ID (reg|tbl) TBL_REG_NAME INDEX (COUNT|)",
        "Read registers",
        "Humber",
        "Chip Id <0-1>",
        "Register",
        "Table",
        "Register or table name",
        "Register or table index",
        "The counts of sequential registers you need to read <1-8192>")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 chip = 0;
    uint32 index = 0;
    uint32 num = 1;
    uint32 opcode = 0;

    if ((CLI_CLI_STR_EQUAL("reg", 1)))
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_R_REG;
    }
    else
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_R_TBL;
    }

    CTC_CLI_GET_UINT32_RANGE("Chip", chip, argv[0], 0, 1);
    CTC_CLI_GET_UINT32_RANGE("Index", index, argv[3], 0, 0xFFFFFFFF);

    if (argc > 4)
    {
        CTC_CLI_GET_UINT32_RANGE("Number", num, argv[4], 1, 8192);
    }

    req.param[0] = opcode;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = num;
    sal_strncpy((char*)req.buf, argv[2], CTC_HUMBER_TR_BUF_SIZE);

    ctc_dbg_tblreg_dump_chip(&req);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_hb_debug_tblreg_show_drv_write_reg_or_tbl_field,
        show_cli_drv_write_reg_or_tbl_field_cmd,
        "write humber CHIP_ID (reg|tbl) TBL_REG_NAME FLD_ID INDEX VALUE",
        "Write registers",
        "Humber",
        "Chip Id <0-1>",
        "Register",
        "Table",
        "Register or table name",
        "Field ID",
        "Register or table index",
        "Value")
{
    ctc_dbg_tblreg_show_req_t req;
    uint32 chip = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    uint32 value = 0;
    uint32 opcode = 0;

    if ((CLI_CLI_STR_EQUAL("reg", 1)))
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_W_REG;
    }
    else
    {
        opcode = CTC_DIAG_TBLREG_CHIP_ACCESS_W_TBL;
    }

    CTC_CLI_GET_UINT32_RANGE("Chip", chip, argv[0], 0, 1);
    CTC_CLI_GET_UINT32_RANGE("Field ID", field_id, argv[3], 0, 0xFFFFFFFF);
    CTC_CLI_GET_UINT32_RANGE("Index", index, argv[4], 0, 0xFFFFFFFF);
    CTC_CLI_GET_UINT32_RANGE("Value", value, argv[5], 0, 0xFFFFFFFF);

    req.param[0] = opcode;
    req.param[1] = chip;
    req.param[2] = index;
    req.param[3] = field_id;
    req.param[4] = value;
    sal_strncpy((char*)req.buf, argv[2], CTC_HUMBER_TR_BUF_SIZE);

    ctc_dbg_tblreg_dump_chip(&req);
    return CLI_SUCCESS;
}

int32
ctc_humber_tblreg_wr_cli_init(void)
{
    install_element(CTC_SDK_MODE, &show_cli_drv_read_reg_or_tbl_field_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_write_reg_or_tbl_field_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_list_reg_cmd);
    install_element(CTC_SDK_MODE, &show_cli_drv_list_tbl_cmd);

    return CLI_SUCCESS;
}

