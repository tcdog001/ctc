/**
 @file ctc_greatbelt_oam.c

 @date 2010-3-9

 @version v2.0

  This file contains  OAM (Ethernet OAM/MPLS OAM/PBX OAM and EFM OAM) associated APIs's implementation
*/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#include "sal.h"
#include "ctc_oam.h"
#include "ctc_error.h"
#include "ctc_greatbelt_oam.h"
#include "sys_greatbelt_oam.h"
#include "sys_greatbelt_acl.h"
#include "sys_greatbelt_nexthop_api.h"
#include "sys_greatbelt_common.h"
#include "sys_greatbelt_chip.h"
#include "sys_greatbelt_port.h"

/****************************************************************************
 *
* Defines and Macros
*
*****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
*
*****************************************************************************/

/****************************************************************************
 *
* Function
*
*****************************************************************************/
int32
ctc_greatbelt_oam_add_maid(uint8 lchip, ctc_oam_maid_t* p_maid)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_add_maid(p_maid));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_remove_maid(uint8 lchip, ctc_oam_maid_t* p_maid)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_remove_maid(p_maid));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_add_lmep(uint8 lchip, ctc_oam_lmep_t* p_lmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_add_lmep(p_lmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_remove_lmep(uint8 lchip, ctc_oam_lmep_t* p_lmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_remove_lmep(p_lmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_update_lmep(uint8 lchip, ctc_oam_update_t* p_lmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_update_lmep(p_lmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_add_rmep(uint8 lchip, ctc_oam_rmep_t* p_rmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_add_rmep(p_rmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_remove_rmep(uint8 lchip, ctc_oam_rmep_t* p_rmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_remove_rmep(p_rmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_update_rmep(uint8 lchip, ctc_oam_update_t* p_rmep)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_update_rmep(p_rmep));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_add_mip(uint8 lchip, ctc_oam_mip_t* p_mip)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_add_mip(p_mip));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_remove_mip(uint8 lchip, ctc_oam_mip_t* p_mip)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_remove_mip(p_mip));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_set_property(uint8 lchip, ctc_oam_property_t* p_prop)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_set_property(p_prop));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_get_defect_info(uint8 lchip, void* p_defect_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_get_defect_info(lchip, p_defect_info));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_get_mep_info(uint8 lchip, ctc_oam_mep_info_t* p_mep_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_get_mep_info(lchip, p_mep_info, 0));
    return CTC_E_NONE;
}


int32
ctc_greatbelt_oam_get_mep_info_with_key(uint8 lchip, ctc_oam_mep_info_with_key_t* p_mep_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_get_mep_info(0, p_mep_info, 1));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_get_stats(uint8 lchip, ctc_oam_stats_info_t* p_stat_info)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_get_stats_info(p_stat_info));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_set_trpt_cfg(uint8 lchip, ctc_oam_trpt_t* p_trpt)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_set_trpt_cfg(p_trpt));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_set_trpt_en(uint8 lchip, uint8 gchip, uint8 session_id, uint8 enable)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_set_trpt_en(gchip, session_id, enable));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_get_trpt_stats(uint8 lchip, uint8 gchip, uint8 session_id,  ctc_oam_trpt_stats_t* p_trpt_stats)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_get_trpt_stats(gchip, session_id, p_trpt_stats));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_clear_trpt_stats(uint8 lchip, uint8 gchip, uint8 session_id)
{
    CTC_ERROR_RETURN(sys_greatbelt_oam_clear_trpt_stats(gchip, session_id));
    return CTC_E_NONE;
}

int32
ctc_greatbelt_oam_init(uint8 lchip, ctc_oam_global_t* p_cfg)
{
    ctc_oam_global_t oam_global;

    if (NULL == p_cfg)
    {
        sal_memset(&oam_global, 0, sizeof(ctc_oam_global_t));

        /*eth oam global param*/
        oam_global.mep_index_alloc_by_sdk       = 1;

        /*TP Y.1731 OAM*/
        oam_global.tp_y1731_ach_chan_type       = 0x8902;
        oam_global.tp_section_oam_based_l3if    = 0;
    }
    else
    {
        sal_memcpy(&oam_global, p_cfg, sizeof(ctc_oam_global_t));
    }

    CTC_ERROR_RETURN(sys_greatbelt_oam_init(&oam_global));

    /*init mpls bfd vccv with ip*/
    if(p_cfg && p_cfg->mpls_pw_vccv_with_ip_en)
    {
        ctc_acl_group_info_t    group_info;
        ctc_acl_entry_t         acl_entry;
        ctc_ip_nh_param_t       nh_param;

        uint32 nhid             = CTC_NH_RESERVED_NHID_FOR_NONE;
        uint32 group_id         = CTC_ACL_GROUP_ID_MAX -1;

        uint8 lchip     = 0;
        uint8 gchip     = 0;
        uint8 lchip_num = 0;
        uint32 gport    = 0;
        uint8 lport     = 0;

        sal_memset(&group_info, 0, sizeof(ctc_acl_group_info_t));
        sal_memset(&acl_entry,  0, sizeof(ctc_acl_entry_t));
        sal_memset(&nh_param,   0, sizeof(ctc_ip_nh_param_t));

        /*create nexthop */
        nh_param.oif.gport      = SYS_RESERVE_PORT_PW_VCCV_BFD;
        nh_param.oif.is_l2_port = 1;

        CTC_ERROR_RETURN(sys_greatbelt_ipuc_nh_create(nhid, &nh_param));

        /*create acl group*/
        group_info.dir      = CTC_INGRESS;
        group_info.type     = CTC_ACL_GROUP_TYPE_GLOBAL;
        group_info.priority = 0;
        CTC_ERROR_RETURN(sys_greatbelt_acl_create_group(group_id,    &group_info));

        acl_entry.entry_id  = 0xFFFFFFFF;
        acl_entry.key.type  = CTC_ACL_KEY_MPLS;
        acl_entry.key.u.mpls_key.flag               |= CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL0;
        acl_entry.key.u.mpls_key.mpls_label0        = 0x000;
        acl_entry.key.u.mpls_key.mpls_label0_mask   = 0x100;
        acl_entry.key.u.mpls_key.flag               |= CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL1;
        acl_entry.key.u.mpls_key.mpls_label1        = 0x100;
        acl_entry.key.u.mpls_key.mpls_label1_mask   = 0x100;
        acl_entry.key.u.mpls_key.flag               |= CTC_ACL_MPLS_KEY_FLAG_MPLS_LABEL2;
        acl_entry.key.u.mpls_key.mpls_label2        = 0x10000021;
        acl_entry.key.u.mpls_key.mpls_label2_mask   = 0xFFFFFFFF;

        CTC_SET_FLAG(acl_entry.action.flag, CTC_ACL_ACTION_FLAG_REDIRECT);
        acl_entry.action.nh_id  = nhid;

        CTC_ERROR_RETURN(sys_greatbelt_acl_add_entry(group_id,       &acl_entry));

        CTC_ERROR_RETURN(sys_greatbelt_acl_install_group(group_id,   &group_info));
        /*init all port acl0 en*/

        lchip_num = sys_greatbelt_get_local_chip_num();

        for(lchip = 0; lchip < lchip_num; lchip++)
        {
            sys_greatbelt_get_gchip_id(lchip, &gchip);

            for (lport = 0; lport < CTC_MAX_PHY_PORT; lport++)
            {
                gport = CTC_MAP_LPORT_TO_GPORT(gchip, lport);
                sys_greatbelt_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, CTC_ACL_EN_0);
            }
        }
    }

    return CTC_E_NONE;
}

