#include "sal.h"
#include <limits.h>

typedef struct vx_task_s
{
    char thread_type;
}* vx_task_t;

struct sal_task
{
    vx_task_t pthread;
};

sal_err_t
sal_task_create(sal_task_t** ptask,
                char* name,
                size_t stack_size,
                int prio,
                void (* start)(void*),
                void* arg)
{
    int rv;
    sal_task_t* task;
    sigset_t new_mask, orig_mask;

    task = (sal_task_t*)mem_malloc(MEM_SAL_MODULE, sizeof(sal_task_t));
    if (!task)
    {
        return ENOMEM;
    }

    sigemptyset(&new_mask);
    sigaddset(&new_mask, SIGINT);
    sigprocmask(SIG_BLOCK, &new_mask, &orig_mask);
    rv = taskSpawn(name, prio, (VX_UNBREAKABLE | VX_FP_TASK), stack_size, (FUNCPTR)start,
                   PTR_TO_INT(arg), 0, 0, 0, 0, 0, 0, 0, 0, 0);
    sigprocmask(SIG_SETMASK, &orig_mask, NULL);

    if (rv == ERROR)
    {
        return -1;
    }
    else
    {
        task->pthread = (vx_task_t)INT_TO_PTR(rv);
        *ptask = task;
        return 0;
    }
}

void
sal_task_destroy(sal_task_t* task)
{
    taskDelete(PTR_TO_INT(task->pthread));
    mem_free(task);
}

void
sal_task_exit(int rc)
{
    exit(rc);
}

void
sal_task_sleep(uint32_t msec)
{
    taskDelay(msec);
}

void
sal_task_yield()
{
#if 0
    sched_yield();
#endif
}

void
sal_gettime(sal_systime_t* tv)
{
    struct timespec temp_tv;

    sal_memset(&temp_tv, 0, sizeof(temp_tv));

    clock_gettime(CLOCK_REALTIME, &temp_tv);

    tv->tv_sec = temp_tv.tv_sec;
    tv->tv_usec = temp_tv.tv_nsec / 1000;
}

void
sal_getuptime(struct timespec* ts)
{
#if 0
    zhuj_debug
    int fd;
    unsigned long sec, njiffy;
    char buf[64];

    fd = open("/proc/uptime", O_RDONLY);
    if (fd == -1)
    {
        perror("failed to open /proc/uptime:");
        return;
    }

    memset(buf, 0, 64);
    read(fd, buf, 64);
    sscanf(buf, "%lu.%lu", &sec, &njiffy);
    ts->tv_sec = sec;
    ts->tv_nsec = njiffy * 1000000000 / 100;
    close(fd);
#endif
}

sal_err_t
sal_task_set_priority(int32 priority)
{
    return 0;
}

void sal_udelay(uint32 usec)
{
    return;
}

