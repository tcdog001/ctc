/**
 @file sys_goldengate_ftm.h

 @date 2011-11-16

 @version v2.0

 alloc memory and offset
*/

#ifndef _SYS_GREAT_BELT_FTM_H
#define _SYS_GREAT_BELT_FTM_H
#ifdef __cplusplus
extern "C" {
#endif
#include "ctc_ftm.h"


#define SYS_FTM_DS_STATS_HW_INDIRECT_ADDR 0x1600000

#define SYS_FTM_GET_TCAM_AD_IDX( key_tblid, key_idx)  sys_goldengate_ftm_get_tcam_ad_index(key_tblid, key_idx)

#define SYS_FTM_DBG_OUT(level, FMT, ...) \
    do { \
        CTC_DEBUG_OUT(ftm, ftm, FTM_SYS, level, FMT, ##__VA_ARGS__); \
    } while (0)

#define SYS_FTM_SPEC(lchip, spec_id)   sys_goldengate_ftm_get_spec(lchip, spec_id)

enum sys_ftm_dyn_entry_type_e
{
    SYS_FTM_DYN_ENTRY_GLB_MET,
    SYS_FTM_DYN_ENTRY_VSI,
    SYS_FTM_DYN_ENTRY_ECMP,
    SYS_FTM_DYN_ENTRY_LOGIC_MET,
    SYS_FTM_DYN_ENTRY_MAX
};
typedef enum sys_ftm_dyn_entry_type_e sys_ftm_dyn_entry_type_t;

enum sys_ftm_dyn_nh_type_e
{
    SYS_FTM_DYN_NH0,
    SYS_FTM_DYN_NH1,
    SYS_FTM_DYN_NH2,
    SYS_FTM_DYN_NH3,
    SYS_FTM_DYN_NH_MAX
};

typedef struct sys_ftm_specs_info_s
{
    uint32 used_size;
}sys_ftm_specs_info_t;

typedef int32 (*sys_ftm_callback_t)(uint8 lchip, sys_ftm_specs_info_t* specs_info);

extern int32
sys_goldengate_ftm_register_callback(uint8 lchip, uint32 spec_type, sys_ftm_callback_t func);

extern int32
sys_goldengate_ftm_get_dyn_entry_size(uint8 lchip, sys_ftm_dyn_entry_type_t type,
                                     uint32* p_size);

extern int32
sys_goldengate_ftm_lkp_register_init(uint8 lchip);

extern int32
sys_goldengate_ftm_get_tcam_ad_index(uint8 lchip, uint32 key_tbl_id,  uint32 key_index);

extern int32
sys_goldengate_ftm_query_table_entry_num(uint8 lchip, uint32 table_id, uint32* entry_num);

extern int32
sys_goldengate_ftm_get_dynamic_table_info(uint8 lchip, uint32 tbl_id,
                                         uint8* dyn_tbl_idx,
                                         uint32* entry_enum,
                                         uint32* nh_glb_entry_num);

extern  int32
sys_goldengate_ftm_alloc_table_offset(uint8 lchip, uint32 table_id, uint8 dir, uint32 block_size, uint32* offset);

extern  int32
sys_goldengate_ftm_free_table_offset(uint8 lchip, uint32 table_id, uint8 dir, uint32 block_size, uint32 offset);

extern int32
sys_goldengate_ftm_mem_alloc(uint8 lchip, ctc_ftm_profile_info_t* profile_info);

extern int32
sys_goldengate_ftm_show_alloc_info(uint8 lchip);

extern int32
sys_goldengate_ftm_get_spec(uint8 lchip, uint32 spec);

extern int32
sys_goldengate_ftm_show_alloc_info_detail(uint8 lchip);

#ifdef __cplusplus
}
#endif

#endif

