/**
 @file sys_humber_ipmc.c

 @date 2010-01-14

 @version v2.0

 The file contains all ipmc related function
*/

#include "sal.h"
#include "drv_io.h"
#include "drv_common.h"
#include "ctc_const.h"
#include "ctc_error.h"
#include "ctc_avl_tree.h"
#include "ctc_hash.h"
#include "ctc_ipmc.h"
#include "ctc_linklist.h"
#include "sys_humber_nexthop_api.h"
#include "sys_humber_ftm.h"
#include "sys_humber_chip.h"
#include "sys_humber_ipmc.h"
#include "sys_humber_ipmc_db.h"
#include "sys_humber_nexthop.h"
#include "drv_humber.h"

#define IPMC_IPV4_HASH_SIZE     4096
#define IPMC_IPV6_HASH_SIZE     4096

sys_ipmc_db_master_t* p_ipmc_db_master = NULL;

extern sys_ipmc_master_t* p_ipmc_master;

static uint32
_sys_humber_ipmc_ipv4_hash_make(sys_ipmc_group_node_t* p_node_to_lkp)
{
    uint32 a, b, c;

    a = b = 0x9e3779b9;  /* the golden ratio; an arbitrary value */

    a += p_node_to_lkp->address.ipv4.group_addr;
    b += p_node_to_lkp->address.ipv4.vrfid;
    b += p_node_to_lkp->address.ipv4.src_addr << 16;

    c = (a & 0xfff) ^ ((a >> 12) & 0xfff) ^ ((a >> 24) & 0xff) ^
        (b & 0xfff) ^ ((b >> 12) & 0xfff);

    return c % IPMC_IPV4_HASH_SIZE;
}

static uint32
_sys_humber_ipmc_ipv6_hash_make(sys_ipmc_group_node_t* p_node_to_lkp)
{

    uint32 a, b, c;

    a = b = 0x9e3779b9;  /* the golden ratio; an arbitrary value */
    c = 0;

    a += p_node_to_lkp->address.ipv6.group_addr[0];
    b += p_node_to_lkp->address.ipv6.group_addr[1];
    c += p_node_to_lkp->address.ipv6.group_addr[2];
    MIX(a, b, c);

    c += 7;

    a += p_node_to_lkp->address.ipv6.group_addr[3];
    b += p_node_to_lkp->address.ipv6.vrfid;
    b += p_node_to_lkp->address.ipv6.src_addr[3] << 16;

    MIX(a, b, c);

    return c % IPMC_IPV6_HASH_SIZE;
}

static bool
_sys_humber_ipmc_ipv4_hash_compare(sys_ipmc_group_node_t* p_node_in_bucket, sys_ipmc_group_node_t* p_node_to_lkp)
{
    if (p_node_in_bucket->address.ipv4.vrfid != p_node_to_lkp->address.ipv4.vrfid)
    {
        return FALSE;
    }

    if (p_node_in_bucket->src_ip_mask_len != p_node_to_lkp->src_ip_mask_len)
    {
        return FALSE;
    }

    if (p_node_in_bucket->address.ipv4.src_addr != p_node_to_lkp->address.ipv4.src_addr)
    {
        return FALSE;
    }

    if (p_node_in_bucket->group_ip_mask_len != p_node_to_lkp->group_ip_mask_len)
    {
        return FALSE;
    }

    if (p_node_in_bucket->address.ipv4.group_addr != p_node_to_lkp->address.ipv4.group_addr)
    {
        return FALSE;
    }

    /* the wanted ipmc group can't be found in DB */
    return TRUE;
}

static bool
_sys_humber_ipmc_ipv6_hash_compare(sys_ipmc_group_node_t* p_node_in_bucket, sys_ipmc_group_node_t* p_node_to_lkp)
{
    uint8 i;

    if (p_node_in_bucket->address.ipv6.vrfid != p_node_to_lkp->address.ipv6.vrfid)
    {
        return FALSE;
    }

    if (p_node_in_bucket->src_ip_mask_len != p_node_to_lkp->src_ip_mask_len)
    {
        return FALSE;
    }

    for (i = 0; i < 4; i++)
    {
        if (p_node_in_bucket->address.ipv6.src_addr[i] != p_node_to_lkp->address.ipv6.src_addr[i])
        {
            return FALSE;
        }
    }

    if (p_node_in_bucket->group_ip_mask_len != p_node_to_lkp->group_ip_mask_len)
    {
        return FALSE;
    }

    for (i = 0; i < 4; i++)
    {
        if (p_node_in_bucket->address.ipv6.group_addr[i] != p_node_to_lkp->address.ipv6.group_addr[i])
        {
            return FALSE;
        }
    }

    /* the wanted ipmc group has already exsited in DB */
    return TRUE;
}

int32
sys_humber_ipmc_ipv4_syn_key(uint32 new_offset, uint32 old_offset)
{
    sys_ipmc_group_node_t* p_node;
    ds_ipv4_mcast_da_t dsipda;
    ds_ipv4_mcast_rpf_t dsipsa;
    uint8 chip_num = 0;
    uint8 i;
    uint32 cmdr, cmdw;

    p_node = (sys_ipmc_group_node_t*)(SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_4], old_offset));

    if (NULL == p_node)
    {
        return CTC_E_NONE;
    }

    if (new_offset == old_offset)
    {
        return CTC_E_ENTRY_EXIST;
    }

    /* add key to new offset */
    chip_num = sys_humber_get_local_chip_num();
    cmdr = DRV_IOR(IOC_TABLE, p_ipmc_master->da_table_id[CTC_IP_VER_4], DRV_ENTRY_FLAG);
    cmdw = DRV_IOW(IOC_TABLE, p_ipmc_master->da_table_id[CTC_IP_VER_4], DRV_ENTRY_FLAG);

    for (i = 0; i < chip_num; i++)
    {
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, old_offset, cmdr, &dsipda));
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, new_offset, cmdw, &dsipda));
    }

    cmdr = DRV_IOR(IOC_TABLE, p_ipmc_master->sa_table_id[CTC_IP_VER_4], DRV_ENTRY_FLAG);
    cmdw = DRV_IOW(IOC_TABLE, p_ipmc_master->sa_table_id[CTC_IP_VER_4], DRV_ENTRY_FLAG);

    for (i = 0; i < chip_num; i++)
    {
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, old_offset, cmdr, &dsipsa));
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, new_offset, cmdw, &dsipsa));
    }

    p_node->index = new_offset;
    CTC_ERROR_RETURN(sys_humber_ipmc_write_key(p_node));

    /* remove key from old offset */
    p_node->index = old_offset;
    CTC_ERROR_RETURN(sys_humber_ipmc_remove_key(p_node));

    p_node->index = new_offset;

    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_4], new_offset)
        = SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_4], old_offset);
    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_4], old_offset)
        = NULL;

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_ipv6_syn_key(uint32 new_offset, uint32 old_offset)
{
    sys_ipmc_group_node_t* p_node;
    ds_ipv6_mcast_da_t dsipda;
    ds_ipv6_mcast_rpf_t dsipsa;
    uint8 chip_num = 0;
    uint8 i;
    uint32 cmdr, cmdw;

    p_node = (sys_ipmc_group_node_t*)(SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_6], old_offset));

    if (NULL == p_node)
    {
        return CTC_E_NONE;
    }

    if (new_offset == old_offset)
    {
        return CTC_E_ENTRY_EXIST;
    }

    /* add key to new offset */
    chip_num = sys_humber_get_local_chip_num();
    cmdr = DRV_IOR(IOC_TABLE, p_ipmc_master->da_table_id[CTC_IP_VER_6], DRV_ENTRY_FLAG);
    cmdw = DRV_IOW(IOC_TABLE, p_ipmc_master->da_table_id[CTC_IP_VER_6], DRV_ENTRY_FLAG);

    for (i = 0; i < chip_num; i++)
    {
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, old_offset, cmdr, &dsipda));
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, new_offset, cmdw, &dsipda));
    }

    cmdr = DRV_IOR(IOC_TABLE, p_ipmc_master->sa_table_id[CTC_IP_VER_6], DRV_ENTRY_FLAG);
    cmdw = DRV_IOW(IOC_TABLE, p_ipmc_master->sa_table_id[CTC_IP_VER_6], DRV_ENTRY_FLAG);

    for (i = 0; i < chip_num; i++)
    {
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, old_offset, cmdr, &dsipsa));
        CTC_ERROR_RETURN(drv_tbl_ioctl(i, new_offset, cmdw, &dsipsa));
    }

    p_node->index = new_offset;
    CTC_ERROR_RETURN(sys_humber_ipmc_write_key(p_node));

    /* remove key from old offset */
    p_node->index = old_offset;
    CTC_ERROR_RETURN(sys_humber_ipmc_remove_key(p_node));

    p_node->index = new_offset;

    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_6], new_offset)
        = SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_6], old_offset);
    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_6], old_offset)
        = NULL;

    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_ipv4_db_init(void)
{
    uint32 table_size;
    sys_sort_block_init_info_t init_info;
    sys_humber_opf_t opf;

    sal_memset(p_ipmc_db_master->ipmc_ipv4_blocks, 0, sizeof(p_ipmc_db_master->ipmc_ipv4_blocks));
    sal_memset(&init_info, 0, sizeof(sys_sort_block_init_info_t));

    init_info.user_data_of = NULL;
    init_info.dir = SYS_SORT_BLOCK_DIR_DOWN;

    CTC_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV4_MCAST_ROUTE_KEY, &table_size));
    if (table_size < MAX_SYS_IPMC_IPV4_BLOCK)
    {
        return CTC_E_NO_RESOURCE;
    }

    sys_humber_opf_init(OPF_IPV4_MC_BLOCK, MAX_SYS_IPMC_IPV4_BLOCK);
    opf.pool_type = OPF_IPV4_MC_BLOCK;
    init_info.opf = &opf;

    /* index : table_size -1 is reserved for  default entry */
    /*bolck 0 for (S, G), occupy half of IP Mcast Tcam*/
    init_info.block = &p_ipmc_db_master->ipmc_ipv4_blocks[SYS_IPMC_IPV4_SRC_GRP_BLOCK];
    init_info.boundary_l = 0;
    init_info.boundary_r = table_size / 2 - 1;
    init_info.is_block_can_shrink = TRUE;
    init_info.max_offset_num = table_size - 1;
    opf.pool_index = 0;
    CTC_ERROR_RETURN(sys_humber_sort_key_init_block(&init_info));

    /*bolck 1 for (*, G), occupy half of IP Mcast Tcam*/
    init_info.block = &p_ipmc_db_master->ipmc_ipv4_blocks[SYS_IPMC_IPV4_WILDCARD_GRP_BLOCK];
    init_info.boundary_l = table_size / 2;
    init_info.boundary_r = table_size - 2;
    opf.pool_index++;
    CTC_ERROR_RETURN(sys_humber_sort_key_init_block(&init_info));

    CTC_ERROR_RETURN(sys_humber_sort_key_init_offset_array(
                         &p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_4], table_size));

    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_ipv6_db_init(void)
{
    uint32 table_size;
    sys_sort_block_init_info_t init_info;
    sys_humber_opf_t opf;

    sal_memset(p_ipmc_db_master->ipmc_ipv6_blocks, 0, sizeof(p_ipmc_db_master->ipmc_ipv6_blocks));
    sal_memset(&init_info, 0, sizeof(sys_sort_block_init_info_t));
    init_info.user_data_of = NULL;
    init_info.dir = SYS_SORT_BLOCK_DIR_DOWN;

    CTC_ERROR_RETURN(sys_alloc_get_table_entry_num(DS_IPV6_MCAST_ROUTE_KEY, &table_size));
    if (table_size < MAX_SYS_IPMC_IPV6_BLOCK)
    {
        return CTC_E_NO_RESOURCE;
    }

    sys_humber_opf_init(OPF_IPV6_MC_BLOCK, MAX_SYS_IPMC_IPV6_BLOCK);
    opf.pool_type = OPF_IPV6_MC_BLOCK;
    init_info.opf = &opf;

    /* index : table_size -1 is reserved for  default entry */
    /*bolck 0 for (S, G), occupy half of IP Mcast Tcam*/
    init_info.block = &p_ipmc_db_master->ipmc_ipv6_blocks[SYS_IPMC_IPV6_SRC_GRP_BLOCK];
    init_info.boundary_l = 0;
    init_info.boundary_r = table_size / 2 - 1;
    init_info.is_block_can_shrink = TRUE;
    init_info.max_offset_num = table_size - 1;
    opf.pool_index = 0;
    CTC_ERROR_RETURN(sys_humber_sort_key_init_block(&init_info));

    /*bolck 1 for (*, G), occupy half of IP Mcast Tcam*/
    init_info.block = &p_ipmc_db_master->ipmc_ipv6_blocks[SYS_IPMC_IPV6_WILDCARD_GRP_BLOCK];
    init_info.boundary_l = table_size / 2;
    init_info.boundary_r = table_size - 2;
    opf.pool_index++;
    CTC_ERROR_RETURN(sys_humber_sort_key_init_block(&init_info));

    CTC_ERROR_RETURN(sys_humber_sort_key_init_offset_array(
                         &p_ipmc_db_master->p_ipmc_offset_array[CTC_IP_VER_6], table_size));

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_init(void)
{
    p_ipmc_db_master = mem_malloc(MEM_IPMC_MODULE, sizeof(sys_ipmc_db_master_t));
    if (NULL == p_ipmc_db_master)
    {
        return CTC_E_NO_MEMORY;
    }

    /*SYS_IPMC_CREAT_LOCK;*/

    p_ipmc_db_master->ipmc_hash[CTC_IP_VER_4] = ctc_hash_create(1, IPMC_IPV4_HASH_SIZE,
                                                                (hash_key_fn)_sys_humber_ipmc_ipv4_hash_make,
                                                                (hash_cmp_fn)_sys_humber_ipmc_ipv4_hash_compare);

    if (!p_ipmc_db_master->ipmc_hash[CTC_IP_VER_4])
    {
        return CTC_E_NO_MEMORY;

    }

    p_ipmc_db_master->ipmc_hash[CTC_IP_VER_6] = ctc_hash_create(1, IPMC_IPV6_HASH_SIZE,
                                                                (hash_key_fn)_sys_humber_ipmc_ipv6_hash_make,
                                                                (hash_cmp_fn)_sys_humber_ipmc_ipv6_hash_compare);

    if (!p_ipmc_db_master->ipmc_hash[CTC_IP_VER_6])
    {
        return CTC_E_NO_MEMORY;

    }

    _sys_humber_ipmc_ipv4_db_init();
    _sys_humber_ipmc_ipv6_db_init();

    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_4].block = p_ipmc_db_master->ipmc_ipv4_blocks;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_4].max_block_num = MAX_SYS_IPMC_IPV4_BLOCK;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_4].sort_key_syn_key = sys_humber_ipmc_ipv4_syn_key;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_4].type = OPF_IPV4_MC_BLOCK;

    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_6].block = p_ipmc_db_master->ipmc_ipv6_blocks;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_6].max_block_num = MAX_SYS_IPMC_IPV6_BLOCK;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_6].sort_key_syn_key = sys_humber_ipmc_ipv6_syn_key;
    p_ipmc_db_master->ipmc_sort_key_info[CTC_IP_VER_6].type = OPF_IPV6_MC_BLOCK;

    return CTC_E_NONE;
}

static int32
_sys_ipmc_ipv4_get_block_id(sys_ipmc_group_node_t* p_node, uint8* p_block_id)
{
    uint8 src_ip_mask_len, group_ip_mask_len;
    uint8 is_wildcard_src = FALSE, is_wildcard_dst = FALSE;

    CTC_PTR_VALID_CHECK(p_node);
    CTC_PTR_VALID_CHECK(p_block_id);

    src_ip_mask_len     = p_node->src_ip_mask_len;
    group_ip_mask_len   = p_node->group_ip_mask_len;

    if (0 == group_ip_mask_len)
    {
        is_wildcard_dst = TRUE;
    }

    if (0 == src_ip_mask_len)
    {
        is_wildcard_src = TRUE;
    }

    if (!is_wildcard_dst && !is_wildcard_src)
    {
        *p_block_id = SYS_IPMC_IPV4_SRC_GRP_BLOCK;
    }
    else if (is_wildcard_src)
    {
        *p_block_id = SYS_IPMC_IPV4_WILDCARD_GRP_BLOCK;
    }
    else
    {
        return CTC_E_IPMC_INVALID_MASK_LEN;
    }

    return CTC_E_NONE;
}

static int32
_sys_ipmc_ipv6_get_block_id(sys_ipmc_group_node_t* p_node, uint8* p_block_id)
{
    uint8 src_ip_mask_len, group_ip_mask_len;
    uint8 is_wildcard_src = FALSE, is_wildcard_dst = FALSE;

    CTC_PTR_VALID_CHECK(p_node);
    CTC_PTR_VALID_CHECK(p_block_id);

    src_ip_mask_len     = p_node->src_ip_mask_len;
    group_ip_mask_len   = p_node->group_ip_mask_len;

    if (0 == group_ip_mask_len)
    {
        is_wildcard_dst = TRUE;
    }

    if (0 == src_ip_mask_len)
    {
        is_wildcard_src = TRUE;
    }

    if (!is_wildcard_dst && !is_wildcard_src)
    {
        *p_block_id = SYS_IPMC_IPV6_SRC_GRP_BLOCK;
    }
    else if (is_wildcard_src)
    {
        *p_block_id = SYS_IPMC_IPV6_WILDCARD_GRP_BLOCK;
    }
    else
    {
        return CTC_E_IPMC_INVALID_MASK_LEN;
    }

    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_db_add(sys_ipmc_group_node_t* p_node)
{

    ctc_hash_insert(p_ipmc_db_master->ipmc_hash[p_node->ip_version], p_node);
    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_db_remove(sys_ipmc_group_node_t* p_node)
{

    ctc_hash_remove(p_ipmc_db_master->ipmc_hash[p_node->ip_version], p_node);
    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_db_get_offset(sys_ipmc_group_node_t* p_node)
{
    uint8 block_id = 0;
    uint8 ip_version = p_node->ip_version;

    if (CTC_IP_VER_4 == ip_version)
    {
        CTC_ERROR_RETURN(_sys_ipmc_ipv4_get_block_id(p_node, &block_id));
    }
    else
    {
        CTC_ERROR_RETURN(_sys_ipmc_ipv6_get_block_id(p_node, &block_id));
    }

    p_ipmc_db_master->ipmc_sort_key_info[ip_version].block_id = block_id;

    CTC_ERROR_RETURN(sys_humber_sort_key_alloc_offset(&p_ipmc_db_master->ipmc_sort_key_info[ip_version], &p_node->index));

    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[ip_version], p_node->index) = p_node;

    return CTC_E_NONE;
}

static int32
_sys_humber_ipmc_db_free_offset(sys_ipmc_group_node_t* p_node)
{
    uint8 block_id = 0;
    uint8 ip_version = p_node->ip_version;

    /* free offset from offset database by block id */
    if (CTC_IP_VER_4 == ip_version)
    {
        CTC_ERROR_RETURN(_sys_ipmc_ipv4_get_block_id(p_node, &block_id));
    }
    else
    {
        CTC_ERROR_RETURN(_sys_ipmc_ipv6_get_block_id(p_node, &block_id));
    }

    p_ipmc_db_master->ipmc_sort_key_info[ip_version].block_id = block_id;

    SORT_KEY_GET_OFFSET_PTR(p_ipmc_db_master->p_ipmc_offset_array[ip_version], p_node->index) = NULL;

    CTC_ERROR_RETURN(sys_humber_sort_key_free_offset(&p_ipmc_db_master->ipmc_sort_key_info[ip_version],  p_node->index));

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_add(sys_ipmc_group_node_t* p_node)
{
    CTC_ERROR_RETURN(_sys_humber_ipmc_db_get_offset(p_node));
    CTC_ERROR_RETURN(_sys_humber_ipmc_db_add(p_node));

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_remove(sys_ipmc_group_node_t* p_node)
{

    _sys_humber_ipmc_db_free_offset(p_node);

    /* free group node from database, which can be Hash or AVL */
    CTC_ERROR_RETURN(_sys_humber_ipmc_db_remove(p_node));

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_lookup(sys_ipmc_group_node_t** pp_node)
{
    sys_ipmc_group_node_t* p_ipmc_group_node;

    p_ipmc_group_node = ctc_hash_lookup(p_ipmc_db_master->ipmc_hash[(*pp_node)->ip_version], *pp_node);

    *pp_node = p_ipmc_group_node;

    return CTC_E_NONE;
}

int32
sys_humber_show_ipmc_info(sys_ipmc_group_node_t* p_node, void* data)
{
    char buf[CTC_IPV6_ADDR_STR_LEN];

#define SYS_IPMC_MASK_LEN  5
    char buf2[SYS_IPMC_MASK_LEN];
    uint32 tempip = 0;

    SYS_IPMC_DBG_INFO("%5d", p_node->index);

    if (CTC_IP_VER_4 == p_node->ip_version)
    {
        /* print IPv4 source IP address */
        sal_snprintf(buf2, SYS_IPMC_MASK_LEN, "/%d", p_node->src_ip_mask_len);
        tempip = sal_ntohl(p_node->address.ipv4.src_addr);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_strncat(buf, buf2, SYS_IPMC_MASK_LEN);
        SYS_IPMC_DBG_INFO("%20s", buf);

        /* print IPv4 group IP address */
        sal_snprintf(buf2, SYS_IPMC_MASK_LEN, "/%d", p_node->group_ip_mask_len);
        tempip = sal_ntohl(p_node->address.ipv4.group_addr);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_strncat(buf, buf2, SYS_IPMC_MASK_LEN);
        SYS_IPMC_DBG_INFO(" %20s", buf);

        /* print vrfId */
        SYS_IPMC_DBG_INFO(" %8d", p_node->address.ipv4.vrfid);

    }
    else
    {
        uint32 ipv6_address[4] = {0, 0, 0, 0};

        /* print IPv6 source IP address */
        sal_snprintf(buf2, SYS_IPMC_MASK_LEN, "/%d", p_node->src_ip_mask_len);

        ipv6_address[0] = sal_htonl(p_node->address.ipv6.src_addr[3]);
        ipv6_address[1] = sal_htonl(p_node->address.ipv6.src_addr[2]);
        ipv6_address[2] = sal_htonl(p_node->address.ipv6.src_addr[1]);
        ipv6_address[3] = sal_htonl(p_node->address.ipv6.src_addr[0]);

        sal_inet_ntop(AF_INET6, ipv6_address, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_strncat(buf, buf2, SYS_IPMC_MASK_LEN);
        SYS_IPMC_DBG_INFO("%20s", buf);

        /* print IPv6 group IP address */
        sal_snprintf(buf2, SYS_IPMC_MASK_LEN, "/%d", p_node->group_ip_mask_len);

        ipv6_address[0] = sal_htonl(p_node->address.ipv6.group_addr[3]);
        ipv6_address[1] = sal_htonl(p_node->address.ipv6.group_addr[2]);
        ipv6_address[2] = sal_htonl(p_node->address.ipv6.group_addr[1]);
        ipv6_address[3] = sal_htonl(p_node->address.ipv6.group_addr[0]);

        sal_inet_ntop(AF_INET6, ipv6_address, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_strncat(buf, buf2, SYS_IPMC_MASK_LEN);
        SYS_IPMC_DBG_INFO("%21s", buf);

        /* print vrfId */
        SYS_IPMC_DBG_INFO("%9d", p_node->address.ipv6.vrfid);
    }

    buf2[0] = '\0';
    if (CTC_FLAG_ISSET(p_node->flag, CTC_IPMC_FLAG_RPF_CHECK))
    {
        sal_strncat(buf2, "R", 1);
    }

    if (CTC_FLAG_ISSET(p_node->flag, CTC_IPMC_FLAG_TTL_CHECK))
    {
        sal_strncat(buf2, "T", 1);
    }

    if (CTC_FLAG_ISSET(p_node->flag, CTC_IPMC_FLAG_COPY_TOCPU))
    {
        sal_strncat(buf2, "C", 1);
    }

    if (CTC_FLAG_ISSET(p_node->flag, CTC_IPMC_FLAG_RPF_FAIL_BRIDGE_AND_TOCPU))
    {
        sal_strncat(buf2, "F", 1);
    }

    SYS_IPMC_DBG_INFO("%11d %8s\n", p_node->nexthop_id, buf2);

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_show_group_info(uint8 ip_version)
{
    CTC_IP_VER_CHECK(ip_version);
    SYS_IPMC_DBG_DUMP("\n-----------------------------------------------------------------------------\n");
    SYS_IPMC_DBG_DUMP("index           source IP             group IP    vrfId    nextHop     flag");
    SYS_IPMC_DBG_DUMP("\n-----------------------------------------------------------------------------\n");

    ctc_hash_traverse(p_ipmc_db_master->ipmc_hash[ip_version], (hash_traversal_fn)sys_humber_show_ipmc_info, NULL);

    SYS_IPMC_DBG_DUMP("-----------------------------------------------------------------------------\n\n");

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_show_count(void)
{
    uint32 i;

    for (i = 0; i < MAX_CTC_IP_VER; i++)
    {

        SYS_IPMC_DBG_DUMP("IPMCv%c total %d routes\n", (i == CTC_IP_VER_4) ? '4' : '6', p_ipmc_db_master->ipmc_hash[i]->count);
    }

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_db_show_member_info(ctc_ipmc_group_info_t* p_group)
{
    uint8 ip_version = 0;
    sys_ipmc_group_node_t* p_group_node;
    sys_ipmc_group_node_t group_node;
    sys_nh_offset_array_t fwd_offset;
    sys_ipmc_rpf_info_t sys_ipmc_rpf_info;

    sal_memset(&group_node, 0, sizeof(sys_ipmc_group_node_t));
    sal_memset(&fwd_offset, 0, sizeof(sys_nh_offset_array_t));
    sal_memset(&sys_ipmc_rpf_info, 0, sizeof(sys_ipmc_rpf_info_t));

    CTC_PTR_VALID_CHECK(p_group);
    CTC_IP_VER_CHECK(p_group->ip_version);
    SYS_IPMC_VERSION_ENABLE_CHECK(p_group->ip_version);
    SYS_IPMC_MASK_LEN_CHECK(p_group->ip_version, p_group->src_ip_mask_len, p_group->group_ip_mask_len);
    SYS_IPMC_MASK_ADDR(p_group->address, p_group->src_ip_mask_len, p_group->group_ip_mask_len, p_group->ip_version);

    ip_version = p_group->ip_version;

    p_group_node = &group_node;
    p_group_node->ip_version        = p_group->ip_version;
    p_group_node->src_ip_mask_len   = p_group->src_ip_mask_len;
    p_group_node->group_ip_mask_len = p_group->group_ip_mask_len;
    sal_memcpy(&p_group_node->address, &p_group->address, p_ipmc_master->addr_len[ip_version]);

    CTC_ERROR_RETURN(sys_humber_ipmc_db_lookup(&p_group_node));

    if (!p_group_node)
    {
        /* The group to show is NOT existed*/
        return CTC_E_IPMC_GROUP_NOT_EXIST;
    }
    else
    {
        SYS_NH_DBG_DUMP(" ~~~~~~IPMC Fdb Info:~~~~~\n");
        SYS_NH_DBG_DUMP(" Allocation type: Tcam\n");
        SYS_NH_DBG_DUMP(" Key offset      : 0x%x\n", p_group_node->index);
        SYS_NH_DBG_DUMP(" Ad offset       : 0x%x\n\n", p_group_node->index);

        sys_humber_nh_dump_mcast(p_group_node->nexthop_id, TRUE);
    }

    return CTC_E_NONE;
}

int32
sys_humber_ipmc_offset_show(ctc_ip_ver_t ip_ver, uint8 blockid)
{
    sys_sort_block_t* p_block;
    sys_humber_opf_t opf;

    if (blockid >= MAX_SYS_IPMC_IPV4_BLOCK)
    {
        SYS_IPMC_DBG_INFO("Error Block Index\n");
        return CTC_E_NONE;
    }

    p_block = &p_ipmc_db_master->ipmc_sort_key_info[ip_ver].block[blockid];

    SYS_IPMC_DBG_DUMP("All From %d To %d Init From %d To %d All %d Use %d Dir %d shrink %d\n",
                      p_block->all_left_b, p_block->all_right_b, p_block->init_left_b, p_block->init_right_b,
                      p_block->all_of_num, p_block->used_of_num, p_block->preferred_dir, p_block->is_block_can_shrink);

    opf.pool_type = p_ipmc_db_master->ipmc_sort_key_info[ip_ver].type;
    opf.pool_index = blockid;
    sys_humber_opf_print_sample_info(&opf);

    return CTC_E_NONE;
}

