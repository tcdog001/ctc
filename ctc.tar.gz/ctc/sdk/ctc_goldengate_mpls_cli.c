/**
 @file ctc_mpls_cli.c

 @date 2010-03-16

 @version v2.0

 The file apply clis of ipuc module
*/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_mpls_cli.h"
#include "ctc_api.h"
#include "ctc_mpls.h"
#include "ctc_port_mapping_cli.h"

extern int32
sys_goldengate_mpls_ilm_show(uint8 lchip, ctc_mpls_ilm_t* p_ilm_info, uint8  show_type);

extern int32
sys_goldengate_mpls_sqn_show(uint8 lchip, uint8 index);

extern int32
sys_goldengate_show_mpls_status(uint8 lchip);

CTC_CLI(ctc_cli_gg_mpls_show_ilm,
        ctc_cli_gg_mpls_show_ilm_cmd,
        "show mpls ilm (SPACEID ((LABEL detail) |) |) (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MPLS_M_STR,
        "Ilm entries",
        "space id <0-255>, 0 is platform space",
        "label <0-1048575>",
        "Key and associate-data offset info",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = 0;
    uint8 show_type = 0;
    ctc_mpls_ilm_t mpls_ilm;
    uint8 lchip = 0;
    uint8 index = 0;
    sal_memset(&mpls_ilm, 0, sizeof(ctc_mpls_ilm_t));

    

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
        if (5 == argc)
        {
            CTC_CLI_GET_UINT8("space", mpls_ilm.spaceid, argv[0]);
            CTC_CLI_GET_UINT32("label", mpls_ilm.label, argv[1]);
            show_type = 1;
        }
        else if (3 == argc)
        {
            CTC_CLI_GET_UINT8("space", mpls_ilm.spaceid, argv[0]);
            show_type = 2;
        }
        else
        {
            show_type = 3;
        }
    }
    else
    {
        if (3 == argc)
        {
            CTC_CLI_GET_UINT8("space", mpls_ilm.spaceid, argv[0]);
            CTC_CLI_GET_UINT32("label", mpls_ilm.label, argv[1]);
            show_type = 1;
        }
        else if (1 == argc)
        {
            CTC_CLI_GET_UINT8("space", mpls_ilm.spaceid, argv[0]);
            show_type = 2;
        }
        else
        {
            show_type = 3;
        }
    }

    ret = sys_goldengate_mpls_ilm_show(lchip, &mpls_ilm, show_type);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gg_mpls_show_sqn,
        ctc_cli_gg_mpls_show_sqn_cmd,
        "show mpls sequence-number SQN_INDEX (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MPLS_M_STR,
        "Sequence counter",
        "Sequence counter index, <0-255>",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    uint8 index;
    uint8 sindex;
    int32 ret = 0;
    uint8 lchip = 0;

    CTC_CLI_GET_UINT8_RANGE("index", sindex, argv[0], 0, CTC_MAX_UINT8_VALUE);
    
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    ret = sys_goldengate_mpls_sqn_show(lchip, sindex);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gg_mpls_show_mpls_status,
        ctc_cli_gg_mpls_show_mpls_status_cmd,
        "show mpls status (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MPLS_M_STR,
        "MPLS Status",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{

    int32 ret  = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    ret = sys_goldengate_show_mpls_status(lchip);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;

}

int32
ctc_goldengate_mpls_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gg_mpls_show_ilm_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_mpls_show_sqn_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_mpls_show_mpls_status_cmd);

    return CLI_SUCCESS;
}

