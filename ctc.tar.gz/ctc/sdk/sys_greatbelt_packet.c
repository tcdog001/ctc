/**
 @file ctc_greatbelt_packet.c

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-11-25

 @version v2.0

 This file define sys functions

*/

/****************************************************************************
*
* Header Files
*
****************************************************************************/
#include "ctc_error.h"
#include "ctc_macro.h"
#include "ctc_debug.h"
#include "ctc_packet.h"
#include "ctc_parser.h"
#include "ctc_qos.h"
#include "ctc_oam.h"
#include "ctc_crc.h"
#include "ctc_greatbelt_packet.h"
#include "sys_greatbelt_common.h"
#include "sys_greatbelt_packet.h"
#include "sys_greatbelt_packet_priv.h"
#include "sys_greatbelt_dma.h"
#include "sys_greatbelt_chip.h"
#include "sys_greatbelt_vlan.h"
#include "sys_greatbelt_nexthop_api.h"
#include "sys_greatbelt_nexthop.h"
#include "sys_greatbelt_stacking.h"
#include "sys_greatbelt_port.h"
#include "drv_lib.h"

/****************************************************************************
*
* Defines and Macros
*
*****************************************************************************/
#define SYS_GB_HDR_CRC_OFFSET       15
#define SYS_GB_HDR_IPSA_OFFSET      28
#define SYS_GB_PKT_STR      "Packet Module "
/****************************************************************************
*
* Global and Declaration
*
*****************************************************************************/
sys_pkt_master_t* p_pkt_master = NULL;
extern char* sys_greatbelt_reason_2Str(uint16 reason_id);


extern host_type_t
drv_get_host_type(void);
/****************************************************************************
*
* Function
*
*****************************************************************************/
static int32
_sys_greatbelt_packet_dump(uint8* data, uint32 len)
{
    uint32 cnt = 0;
    char line[256];
    char tmp[32];

    if (0 == len)
    {
        return CTC_E_NONE;
    }

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt % 16) == 0)
        {
            if (cnt != 0)
            {
                SYS_PKT_DUMP("%s", line);
            }

            sal_memset(line, 0, sizeof(line));
            if (cnt == 0)
            {
                sal_sprintf(tmp, "0x%04x:  ", cnt);
            }
            else
            {
                sal_sprintf(tmp, "\n0x%04x:  ", cnt);
            }
            sal_strcat(line, tmp);
        }

        sal_sprintf(tmp, "%02x", data[cnt]);
        sal_strcat(line, tmp);

        if ((cnt % 2) == 1)
        {
            sal_strcat(line, " ");
        }
    }

    SYS_PKT_DUMP("%s", line);
    SYS_PKT_DUMP("\n");

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_packet_dump_header(ctc_pkt_rx_t  *p_rx_info)
{
    char* p_str_tmp = NULL;
    char str[40] = {0};

    SYS_PKT_DUMP("-----------------------------------------------\n");
    SYS_PKT_DUMP("Packet Header Raw Info(Length : %d): \n", CTC_PKT_HEADER_LEN);
    SYS_PKT_DUMP("-----------------------------------------------\n");

    p_str_tmp = sys_greatbelt_reason_2Str(p_rx_info->rx_info.reason);
    sal_sprintf((char*)&str, "%s%s%d%s", p_str_tmp, "(ID:", p_rx_info->rx_info.reason, ")");

    SYS_PKT_DUMP("%-20s: %s\n", "cpu reason", (char*)&str);

    /*source*/
    SYS_PKT_DUMP("%-20s: 0x%.04x\n", "src port", p_rx_info->rx_info.src_port);
    SYS_PKT_DUMP("%-20s: %d\n", "src svid", p_rx_info->rx_info.src_svid);
    SYS_PKT_DUMP("%-20s: %d\n", "src cvid", p_rx_info->rx_info.src_cvid);
    SYS_PKT_DUMP("%-20s: %d\n", "src cos", p_rx_info->rx_info.src_cos);
    SYS_PKT_DUMP("%-20s: %d\n", "vrf", p_rx_info->rx_info.vrfid);
    SYS_PKT_DUMP("%-20s: %d\n", "fid", p_rx_info->rx_info.fid);
    SYS_PKT_DUMP("%-20s: %d\n", "ttl", p_rx_info->rx_info.ttl);
    SYS_PKT_DUMP("%-20s: %d\n", "priority", p_rx_info->rx_info.priority);
    SYS_PKT_DUMP("%-20s: %d\n", "color", p_rx_info->rx_info.color);
    SYS_PKT_DUMP("%-20s: %d\n", "hash value", p_rx_info->rx_info.hash);
    SYS_PKT_DUMP("%-20s: %d\n", "critical packet", p_rx_info->rx_info.is_critical);
    SYS_PKT_DUMP("%-20s: %d\n", "packet type", p_rx_info->rx_info.packet_type);
    SYS_PKT_DUMP("%-20s: %d\n", "payload offset", p_rx_info->rx_info.payload_offset);
    SYS_PKT_DUMP("%-20s: %d\n", "buffer log victim packet",CTC_FLAG_ISSET(p_rx_info->rx_info.flags, CTC_PKT_FLAG_BUFFER_VICTIM_PKT));
    SYS_PKT_DUMP("%-20s: %d\n", "operation type", p_rx_info->rx_info.oper_type);
    SYS_PKT_DUMP("%-20s: %d\n", "logic src port", p_rx_info->rx_info.logic_src_port);
    SYS_PKT_DUMP("%-20s: %d\n", "meta data", p_rx_info->rx_info.meta_data);
    SYS_PKT_DUMP("%-20s: %d\n", "mac unknown", CTC_FLAG_ISSET(p_rx_info->rx_info.flags, CTC_PKT_FLAG_UNKOWN_MACDA));

    if (p_rx_info->rx_info.oper_type == CTC_PKT_OPER_OAM)
    {
        SYS_PKT_DUMP("\n");
        SYS_PKT_DUMP("oam info:\n");
        SYS_PKT_DUMP("%-20s: %d\n", "oam type", p_rx_info->rx_info.oam.type);
        SYS_PKT_DUMP("%-20s: %d\n", "mep index", p_rx_info->rx_info.oam.mep_index);
    }

    if (p_rx_info->rx_info.oper_type == CTC_PKT_OPER_PTP)
    {
        SYS_PKT_DUMP("\n");
        SYS_PKT_DUMP("ptp info:\n");
        SYS_PKT_DUMP("%-20s: %d\n", "seconds", p_rx_info->rx_info.ptp.ts.seconds);
        SYS_PKT_DUMP("%-20s: %d\n", "nanoseconds", p_rx_info->rx_info.ptp.ts.nanoseconds);
    }

    if ((p_rx_info->pkt_buf) && (p_rx_info->pkt_buf[0].data))
    {
        SYS_PKT_DUMP("\n");
        CTC_ERROR_RETURN(_sys_greatbelt_packet_dump((p_rx_info->pkt_buf[0].data), CTC_PKT_HEADER_LEN));
    }

    SYS_PKT_DUMP("-----------------------------------------------\n");

    return CTC_E_NONE;
}
int32
sys_greatbelt_packet_swap32(uint32* data, int32 len, uint32 hton)
{
    int32 cnt;

    for (cnt = 0; cnt < len; cnt++)
    {
        if (hton)
        {
            data[cnt] = sal_htonl(data[cnt]);
        }
        else
        {
            data[cnt] = sal_ntohl(data[cnt]);
        }
    }

    return CTC_E_NONE;
}

char*
_sys_packet_mode_str(uint32 mode)
{
    switch (mode)
    {
    case CTC_PKT_MODE_DMA:
        return "DMA";

    case CTC_PKT_MODE_ETH:
        return "ETH";

    default:
        return "Invalid";
    }
}

static INLINE int32
_sys_greatbelt_packet_bit62_to_ts(uint32 ns_only_format, uint64 ts_61_0, ctc_packet_ts_t* p_ts)
{
    if (ns_only_format)
    {
        /* [61:0] nano seconds */
        p_ts->seconds = ts_61_0 / 1000000000;
        p_ts->nanoseconds = ts_61_0 % 1000000000;
    }
    else
    {
        /* [61:30] seconds + [29:0] nano seconds */
        p_ts->seconds = (ts_61_0 >> 30) & 0xFFFFFFFF;
        p_ts->nanoseconds = ts_61_0 & 0x3FFFFFFF;
    }

    return CTC_E_NONE;
}

static INLINE int32
_sys_greatbelt_packet_ts_to_bit62(uint32 ns_only_format, ctc_packet_ts_t* p_ts, uint64* p_ts_61_0)
{
    if (ns_only_format)
    {
        /* [61:0] nano seconds */
        *p_ts_61_0 = ((uint64)(p_ts->seconds)) * 1000000000 + p_ts->nanoseconds;
    }
    else
    {
        /* [61:30] seconds + [29:0] nano seconds */
        *p_ts_61_0 = ((uint64)(p_ts->seconds) << 30) | ((uint64)p_ts->nanoseconds);
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_packet_rx_dump(ctc_pkt_rx_t* p_pkt_rx)
{
    uint32 len = 0;

    if (CTC_BMP_ISSET(p_pkt_master->reason_bm, p_pkt_rx->rx_info.reason))
    {
        if (p_pkt_rx->pkt_len < CTC_PKT_HEADER_LEN)
        {
            SYS_PKT_DUMP("Packet length is too small!!!Pkt len: %d\n",p_pkt_rx->pkt_len);
            return CTC_E_EXCEED_MIN_SIZE;
        }

        if (p_pkt_master->header_en[p_pkt_rx->rx_info.reason])
        {
            CTC_ERROR_RETURN(_sys_greatbelt_packet_dump_header(p_pkt_rx));
        }

        if (p_pkt_rx->pkt_len - CTC_PKT_HEADER_LEN < SYS_PKT_BUF_PKT_LEN)
        {
            len = p_pkt_rx->pkt_len- CTC_PKT_HEADER_LEN;
        }
        else
        {
            len = SYS_PKT_BUF_PKT_LEN;
        }

        SYS_PKT_DUMP("\n-----------------------------------------------\n");
        SYS_PKT_DUMP("Packet Info(Length : %d):\n", (p_pkt_rx->pkt_len-CTC_PKT_HEADER_LEN));
        SYS_PKT_DUMP("-----------------------------------------------\n");
        CTC_ERROR_RETURN(_sys_greatbelt_packet_dump((p_pkt_rx->pkt_buf[0].data+CTC_PKT_HEADER_LEN), len));
    }

    return 0;
}
static int32
_sys_greatbelt_packet_txinfo_to_rawhdr(ctc_pkt_info_t* p_tx_info, ms_packet_header_t* p_raw_hdr)
{
    sys_greatbelt_pkt_hdr_ip_sa_t* p_ip_sa = NULL;
    uint32 dest_map = 0;
    uint64 ts_61_0 = 0;
    uint16 vlan_ptr = 0;
    uint8 rawhdr_crc4 = 0;
    uint8* p = NULL;
    uint8* pkt_data = NULL;
    uint8 gchip = 0;
    uint8 src_gchip = 0;
    uint16 lport = 0;
    uint8 hash = 0;
    uint32 offset = 0;
    drv_work_platform_type_t platform_type;

    drv_get_platform_type(&platform_type);

    if (p_tx_info->priority > 64)
    {
        /*64 is special used for dyingGasp*/
        return CTC_E_INVALID_PARAM;
    }
    CTC_ERROR_RETURN( sys_greatbelt_port_dest_gport_check(p_tx_info->dest_gport));
    sal_memset(p_raw_hdr, 0, sizeof(ms_packet_header_t));

    /* 1. must be inited */

    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_PKT_TYPE_VALID))
    {
        p_raw_hdr->packet_type = p_tx_info->packet_type;
    }
    else
    {
        p_raw_hdr->packet_type = CTC_PARSER_PKT_TYPE_ETHERNET;
    }
    p_raw_hdr->non_crc = TRUE;
    p_raw_hdr->from_cpu_or_oam = TRUE;
    p_raw_hdr->operation_type = p_tx_info->oper_type;
    p_raw_hdr->critical_packet = p_tx_info->is_critical;
    p_raw_hdr->source_cos = p_tx_info->src_cos;
    p_raw_hdr->ttl = p_tx_info->ttl;

    /* 2. next_hop_ptr */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_BYPASS))
    {
        CTC_ERROR_RETURN(sys_greatbelt_nh_get_resolved_offset(SYS_NH_RES_OFFSET_TYPE_BYPASS_NH,
                                                      &offset));
        p_raw_hdr->next_hop_ptr = offset;
    }
    else
    {
        if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_VALID))
        {
            p_raw_hdr->next_hop_ptr = p_tx_info->nh_offset;
            if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_NH_OFFSET_IS_8W))
            {
                p_raw_hdr->next_hop_ext = TRUE;
            }
        }
        else
        {
            CTC_ERROR_RETURN(sys_greatbelt_nh_get_resolved_offset(SYS_NH_RES_OFFSET_TYPE_BRIDGE_NH,
                                                  &offset));
            p_raw_hdr->next_hop_ptr = offset;
        }
    }

    /* 3. dest_map */
    dest_map = 0;
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_MCAST))
    {
        /* mcast */
        p_raw_hdr->next_hop_ptr = 0;
        if (sys_greatbelt_get_gchip_id(0, &gchip) < 0)
        {
            gchip = 0;
        }
        dest_map = SYS_GREATBELT_BUILD_DESTMAP(1, gchip, p_tx_info->dest_group_id);
    }
    else
    {
        gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
        if (CTC_IS_CPU_PORT(p_tx_info->dest_gport))
        {
            dest_map = SYS_REASON_ENCAP_DEST_MAP(gchip, SYS_PKT_CPU_QDEST_BY_DMA);
        }
        else
        {
            lport = CTC_MAP_GPORT_TO_LPORT(p_tx_info->dest_gport);

            if(CTC_PKT_OPER_C2C == p_tx_info->oper_type)
            {
                lport = SYS_RESERVE_PORT_ID_CPU_REMOTE;
            }
            dest_map = SYS_GREATBELT_BUILD_DESTMAP(0, gchip, lport);
        }

    }



    p_raw_hdr->dest_map = dest_map;

    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_PORT_VALID))
    {
        p_raw_hdr->source_port = p_tx_info->src_port;
    }
    else
    {
        sys_greatbelt_get_gchip_id(0, &src_gchip);
        p_raw_hdr->source_port = CTC_MAP_LPORT_TO_GPORT(src_gchip, SYS_RESERVE_PORT_ID_CPU);
    }

    SYS_GREATBELT_GPORT_TO_GPORT14(p_raw_hdr->source_port);

    /* 4. svid */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID))
    {
        p_raw_hdr->src_svlan_id_valid = TRUE;
        p_raw_hdr->src_vlan_id = p_tx_info->src_svid;
        p_raw_hdr->src_vlan_ptr = p_tx_info->src_svid;
        p_raw_hdr->stag_action = CTC_VLAN_TAG_OP_ADD;
        p_raw_hdr->svlan_tag_operation_valid = TRUE;
    }

    /* 5. cvid */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID))
    {
        p_raw_hdr->src_cvlan_id_valid = TRUE;
        p_raw_hdr->src_cvlan_id = p_tx_info->src_cvid;
        p_raw_hdr->src_vlan_ptr = p_tx_info->src_cvid;
        /* TTL: { 2'b00, cTagAction[1:0], srcCtagCos[2:0], srcCtagCfi } */
        CTC_UNSET_FLAG(p_raw_hdr->ttl, 0x30);
        CTC_SET_FLAG(p_raw_hdr->ttl, ((CTC_VLAN_TAG_OP_ADD << 4) & 0x30));
        /* IPSA: {macKnown, srcDscp[5:0], 5'd0, isIpv4, cvlanTagOperationValid, aclDscp[5:0],
         * isidValid, ecnAware, congestionValid, ecnEn, layer3Offset[7:0] }
         */
        CTC_SET_FLAG(p_raw_hdr->ip_sa, (1 << 18));
    }

    /* 6. encap header hash for linkagg */
    if (CTC_LINKAGG_CHIPID == gchip)
    {
        if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_HASH_VALID))
        {
            hash = p_tx_info->hash;
        }
        else
        {
            pkt_data = (uint8*)p_raw_hdr + CTC_PKT_HEADER_LEN;
            hash = ctc_crc_calculate_crc8(pkt_data, 12, 0);
        }

        p_raw_hdr->header_hash2_0 = (hash & 0x07);
        p_raw_hdr->header_hash7_3 = ((hash >> 3) & 0x1F);
    }

    /* 7. encap priority, prioty 63 mapping to dma channel 3 */
    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_PRIORITY))
    {
        p_raw_hdr->priority = (p_tx_info->priority==64)?63:p_tx_info->priority;
    }
    else
    {
        p_raw_hdr->priority = 63;
    }

    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_COLOR))
    {
        p_raw_hdr->color = p_tx_info->color;
    }
    else
    {
        p_raw_hdr->color = CTC_QOS_COLOR_GREEN;
    }

    if (CTC_FLAG_ISSET(p_tx_info->flags, CTC_PKT_FLAG_INGRESS_MODE))
    {
        gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
        lport = CTC_MAP_GPORT_TO_LPORT(p_tx_info->dest_gport);
        /* dest_map is ILOOP */
        dest_map = SYS_GREATBELT_BUILD_DESTMAP(0, gchip, SYS_RESERVE_PORT_ID_ILOOP);
        p_raw_hdr->dest_map = dest_map;

        /* nexthop_ptr is lport */
        p_raw_hdr->next_hop_ptr = lport;
    }

    if (CTC_PKT_OPER_OAM == p_tx_info->oper_type)
    {
        /* 8. OAM */
        p = (uint8*)(p_raw_hdr) + SYS_GB_HDR_IPSA_OFFSET;
        p_ip_sa = (sys_greatbelt_pkt_hdr_ip_sa_t*)p;
        p_ip_sa->oam.rx_oam = FALSE;
        p_ip_sa->oam.link_oam = CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM);
        p_ip_sa->oam.dm_en = CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM);
        p_ip_sa->oam.gal_exist = CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL);
        p_ip_sa->oam.mip_en_or_cw_added = CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_CW);
        p_ip_sa->oam.oam_type = p_tx_info->oam.type;

        /* TPOAM Y.1731 Section need not append 13 label */
        if (CTC_OAM_TYPE_ACH == p_tx_info->oam.type)
        {
            p_ip_sa->oam.mpls_label_disable =
                CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM) ? 0xF : 0x0;

            /* only ACH encapsulation need to change packet_type */
            if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL))
            {
                p_raw_hdr->packet_type = CTC_PARSER_PKT_TYPE_MPLS;
            }
            else
            {
                p_raw_hdr->packet_type = CTC_PARSER_PKT_TYPE_RESERVED;
            }
        }

        /* set for UP MEP */
        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP))
        {
            if (CTC_OAM_TYPE_ETH != p_tx_info->oam.type)
            {
                /* only Eth OAM support UP MEP */
                return CTC_E_INVALID_DIR;
            }

            /* set UP MEP */
            CTC_SET_FLAG(p_raw_hdr->source_port_isolate_id, 0x01);

            gchip = CTC_MAP_GPORT_TO_GCHIP(p_tx_info->dest_gport);
            lport = CTC_MAP_GPORT_TO_LPORT(p_tx_info->dest_gport);
            /* dest_map is ILOOP */
            dest_map = SYS_GREATBELT_BUILD_DESTMAP(0, gchip, SYS_RESERVE_PORT_ID_ILOOP);
            p_raw_hdr->dest_map = dest_map;

            /* nexthop_ptr is lport */
            p_raw_hdr->next_hop_ptr = lport;

            /* src vlan_ptr is vlan_ptr by vid */
            sys_greatbelt_vlan_get_vlan_ptr(p_tx_info->oam.vid, &vlan_ptr);
            p_raw_hdr->src_vlan_ptr = vlan_ptr;
        }

        /* set bypass MIP port */
        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_TX_MIP_TUNNEL))
        {
            /* bypass OAM packet to MIP configured port; otherwise, packet will send to CPU again */
            p_ip_sa->oam.oam_type = CTC_OAM_TYPE_NONE;
            p_raw_hdr->oam_tunnel_en = TRUE;
        }

        /* set timestamp offset in bytes for DM */
        if (CTC_FLAG_ISSET(p_tx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM))
        {
            p_raw_hdr->logic_src_port = (p_tx_info->oam.dm_ts_offset >> 2) & 0x3F;
            p_raw_hdr->rxtx_fcl3 = (p_tx_info->oam.dm_ts_offset >> 1) & 0x01;
            p_raw_hdr->rxtx_fcl0 = (p_tx_info->oam.dm_ts_offset) & 0x01;
        }
    }
    else if (CTC_PKT_OPER_PTP == p_tx_info->oper_type)
    {
        /* 9. PTP */
        /*  PTP Timestamp Bits Mapping
            Timestamp               Field Name          BIT Width       BIT Base
            ptpTimestamp[21:0]      ipSa                22(ipSa[21:0])  0
            ptpTimestamp[22]        rxtxFcl0            1               22
            ptpTimestamp[24:23]     rxtxFcl2_1          2               23
            ptpTimestamp[25]        rxtxFcl3            1               25
            ptpTimestamp[41:26]     fid                 16              26
            ptpTimestamp[53:42]     srcCvlanId          12              42
            ptpTimestamp[54]        srcCvlanIdValid     1               54
            ptpTimestamp[60:55]     rxtxFcl22_17        6               55
            ptpTimestamp[61]        srcCtagOffsetType   1               61
        */
        _sys_greatbelt_packet_ts_to_bit62(TRUE, &p_tx_info->ptp.ts, &ts_61_0);
        p_raw_hdr->ip_sa                = (ts_61_0 >> 0) & 0x3FFFFF;
        p_raw_hdr->rxtx_fcl0            = (ts_61_0 >> 22) & 0x0001;
        p_raw_hdr->rxtx_fcl2_1          = (ts_61_0 >> 23) & 0x0003;
        p_raw_hdr->rxtx_fcl3            = (ts_61_0 >> 25) & 0x0001;
        p_raw_hdr->fid                  = (ts_61_0 >> 26) & 0xFFFF;
        p_raw_hdr->src_cvlan_id         = (ts_61_0 >> 42) & 0x0FFF;
        p_raw_hdr->src_cvlan_id_valid   = (ts_61_0 >> 54) & 0x0001;
        p_raw_hdr->rxtx_fcl22_17        = (ts_61_0 >> 55) & 0x003F;
        p_raw_hdr->src_ctag_offset_type = (ts_61_0 >> 61) & 0x0001;

        /* source_port_isolate_id[5:0] = ptpOffsetType[1:0] + ptpEditType[1:0] + ptpSequenceId[1:0] */
        p_raw_hdr->source_port_isolate_id = 0;
        p_raw_hdr->source_port_isolate_id |= (p_tx_info->ptp.oper & 0x03) << 2;
        if (CTC_PTP_CAPTURE_ONLY == p_tx_info->ptp.oper)
        {
            p_raw_hdr->source_port_isolate_id |= (p_tx_info->ptp.seq_id & 0x03);
        }
    }
    else if (CTC_PKT_OPER_C2C == p_tx_info->oper_type)
    {
        p_raw_hdr->bypass_ingress_edit = 1;
        p_raw_hdr->rxtx_fcl0 = 0;
    }

    sys_greatbelt_packet_swap32((uint32*)p_raw_hdr, CTC_PKT_HEADER_LEN / 4, TRUE);
    /* calc bridge header CRC */
    rawhdr_crc4 = ctc_crc_calculate_crc4((uint8*)p_raw_hdr, CTC_PKT_HEADER_LEN, 0);
    if (platform_type == HW_PLATFORM)
    {
        sys_greatbelt_packet_swap32((uint32*)p_raw_hdr, CTC_PKT_HEADER_LEN / 4, TRUE);
        p_raw_hdr->header_crc = (rawhdr_crc4 & 0xF);
    }

    return CTC_E_NONE;
}

static int32
_sys_greatbelt_packet_rawhdr_to_rxinfo(ms_packet_header_t* p_raw_hdr, ctc_pkt_info_t* p_rx_info)
{
    sys_greatbelt_pkt_hdr_ip_sa_t* p_ip_sa = NULL;
    uint32 dest_map = 0;
    uint64 ts_61_0 = 0;
    uint32 ns_only_format = FALSE;
    uint8* p = NULL;
    uint8 gchip = 0;
    uint8 lport = 0;
    uint8 from_egress = FALSE;

    sal_memset(p_rx_info, 0, sizeof(ctc_pkt_info_t));

    /* convert endian */
    CTC_ERROR_RETURN(sys_greatbelt_packet_swap32((uint32*)p_raw_hdr, CTC_PKT_HEADER_LEN / 4, FALSE));

    /* 1. must be inited */
    p_rx_info->packet_type = p_raw_hdr->packet_type;
    p_rx_info->oper_type = p_raw_hdr->operation_type;
    p_rx_info->priority = p_raw_hdr->priority;
    p_rx_info->color = p_raw_hdr->color;
    p_rx_info->src_cos = p_raw_hdr->source_cos;
    p_rx_info->src_port = p_raw_hdr->source_port;
    p_rx_info->vrfid = p_raw_hdr->fid;
    p_rx_info->payload_offset = p_raw_hdr->packet_offset;

    SYS_GREATBELT_GPORT14_TO_GPORT(p_rx_info->src_port);
    if (CTC_IS_LINKAGG_PORT(p_rx_info->src_port))
    {
        /* if sourcePort[13:9] == 5'd31, {sourcePort[15:14], sourcePort[8:6]} is chipId[4:0], sourcePort[5:0] is TID  */
        p_rx_info->src_chip = ((p_raw_hdr->source_port15_14 << 3) & 0x18 ) | ((p_raw_hdr->source_port >> 6) & 0x07);
        p_rx_info->src_port &= 0xFF3F;  /* clear 0x00C0 for chipId */
    }
    else
    {
        p_rx_info->src_chip = CTC_MAP_GPORT_TO_GCHIP(p_rx_info->src_port);
    }
    p_rx_info->ttl = p_raw_hdr->ttl;
    p_rx_info->is_critical = p_raw_hdr->critical_packet ? TRUE : FALSE;

    /* 2. get RX reason from next_hop_ptr */
    p_rx_info->reason = CTC_PKT_CPU_REASON_GET_BY_NHPTR(p_raw_hdr->next_hop_ptr);

    /* 3. judge whether from ingress or egress */
    from_egress = (CTC_PKT_CPU_REASON_L3_MTU_FAIL == p_rx_info->reason)
               || (CTC_PKT_CPU_REASON_IPMC_TTL_CHECK_FAIL == p_rx_info->reason);

    /* 4. get dest_map */
    dest_map = p_raw_hdr->dest_map;
    if (CTC_IS_BIT_SET(dest_map, 21))
    {
        CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_MCAST);
        p_rx_info->dest_group_id = (dest_map & 0xFFFF);
    }
    else
    {
        gchip = (dest_map >> 16) & 0x1F;
        lport = (dest_map & 0xFF);
        p_rx_info->dest_gport = CTC_MAP_LPORT_TO_GPORT(gchip, lport);
    }

    /* 5. get svid / cvid */
    if (from_egress)
    {
        /* EPE: can only get FID */
        if (p_raw_hdr->fid)
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
            p_rx_info->src_svid = p_raw_hdr->fid;
        }
    }
    else
    {
        /* IPE: use src_svlan_id_valid/src_cvlan_id_valid */
        if (p_raw_hdr->src_svlan_id_valid)
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
            p_rx_info->src_svid = p_raw_hdr->src_vlan_id;
        }

        if (p_raw_hdr->src_cvlan_id_valid)
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID);
            p_rx_info->src_cvid = p_raw_hdr->src_cvlan_id;
        }
    }

    if (CTC_PKT_OPER_OAM == p_rx_info->oper_type)
    {
        /* 6. get OAM */
        if (CTC_FLAG_ISSET(p_raw_hdr->source_port_isolate_id, 0x01))  /* sourcePortIsolateId[5:0]/{oamDestChipId[4:0],isUp} */
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP);
        }

        if (CTC_FLAG_ISSET(p_raw_hdr->pbb_src_port_type, 0x04))  /* pbbSrcPortType[2:0]/{lmReceivedPacket, lmPacketType[1:0] } */
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_LM);
        }

        p = (uint8*)(p_raw_hdr) + SYS_GB_HDR_IPSA_OFFSET;
        p_ip_sa = (sys_greatbelt_pkt_hdr_ip_sa_t*)p;

        p_rx_info->oam.type = p_ip_sa->oam.oam_type;
        if (p_ip_sa->oam.link_oam)
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_LINK_OAM);
        }

        if (p_ip_sa->oam.dm_en)
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_DM);
        }

        if (p_ip_sa->oam.gal_exist)
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_HAS_MPLS_GAL);
        }

        if (p_ip_sa->oam.mip_en_or_cw_added)
        {
            CTC_SET_FLAG(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_MIP);
        }

        p_rx_info->oam.mep_index = (p_ip_sa->oam.mpls_label_disable << 10) | (p_ip_sa->oam.mep_index_9_0);

        /* get timestamp offset in bytes for DM */
        if (p_ip_sa->oam.dm_en)
        {
            /* If dm_en, the srcCvlanIdValid and srcCvlanId is used by DM Timestamp */
            if (CTC_FLAG_ISSET(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID))
            {
                CTC_UNSET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID);
                p_rx_info->src_cvid = 0;
            }

            /*  DM Timestamp Bits Mapping
                Timestamp               Field Name          BIT Width   BIT Base
                dmTimestamp[0]          rxtxFcl0            1           0
                dmTimestamp[1]          rxtxFcl3            1           1
                dmTimestamp[17:2]       logicSrcPort        16          2
                dmTimestamp[33:18]      fid                 16          18
                dmTimestamp[45:34]      srcCvlanId          12          34
                dmTimestamp[46]         srcCvlanIdValid     1           46
                dmTimestamp[54:47]      ttl                 8           47
                dmTimestamp[60:55]      rxtxFcl22_17        6           55
                dmTimestamp[61]         srcCtagOffsetType   1           61
             */
            ts_61_0 = ((uint64)(p_raw_hdr->rxtx_fcl0 & 0x0001) << 0)
                | ((uint64)(p_raw_hdr->rxtx_fcl3 & 0x0001) << 1)
                | ((uint64)(p_raw_hdr->logic_src_port & 0xFFFF) << 2)
                | ((uint64)(p_raw_hdr->fid & 0xFFFF) << 18)
                | ((uint64)(p_raw_hdr->src_cvlan_id & 0x0FFF) << 34)
                | ((uint64)(p_raw_hdr->src_cvlan_id_valid & 0x0001) << 46)
                | ((uint64)(p_raw_hdr->ttl & 0x00FF) << 47)
                | ((uint64)(p_raw_hdr->rxtx_fcl22_17 & 0x003F) << 55)
                | ((uint64)(p_raw_hdr->src_ctag_offset_type & 0x0001) << 61);
            ns_only_format = (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP)) ? FALSE : TRUE;
            _sys_greatbelt_packet_bit62_to_ts(ns_only_format, ts_61_0, &p_rx_info->oam.dm_ts);
        }

        if (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_LM))
        {
            /*  LM FCL Bits Mapping
                LM FCL                  Field Name          BIT Width   BIT Base
                Fcl[0]                  rxtxFcl0            1           0
                Fcl[2:1]                rxtxFcl2_1          2           1
                Fcl[3]                  rxtxFcl3            1           3
                Fcl[15:4]               srcCvlanId          12          4
                Fcl[16]                 srcCvlanIdValid     1           16
                Fcl[22:17]              rxtxFcl22_17        6           17
                Fcl[30:23]              ttl                 8           23
                Fcl[31]                 srcCtagOffsetType   1           31
            */
            p_rx_info->oam.lm_fcl = ((p_raw_hdr->rxtx_fcl0 & 0x0001) << 0)
                | ((p_raw_hdr->rxtx_fcl2_1 & 0x0003) << 1)
                | ((p_raw_hdr->rxtx_fcl3 & 0x0001) << 3)
                | ((p_raw_hdr->src_cvlan_id & 0x0FFF) << 4)
                | ((p_raw_hdr->src_cvlan_id_valid & 0x0001) << 16)
                | ((p_raw_hdr->rxtx_fcl22_17 & 0x003F) << 17)
                | ((p_raw_hdr->ttl & 0x00FF) << 23)
                | ((p_raw_hdr->src_ctag_offset_type & 0x0001) << 31);
        }

        /* get svid from vlan_ptr for Up MEP/Up MIP */
        if (CTC_FLAG_ISSET(p_rx_info->oam.flags, CTC_PKT_OAM_FLAG_IS_UP_MEP))
        {
            CTC_SET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_SVID_VALID);
            p_rx_info->src_svid = p_raw_hdr->src_vlan_ptr;
        }
    }
    else if (CTC_PKT_OPER_PTP == p_rx_info->oper_type)
    {
        /* 7. get PTP */

        /* If is PTP, the srcCvlanIdValid and srcCvlanId is used by PTP Timestamp */
        if (CTC_FLAG_ISSET(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID))
        {
            CTC_UNSET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_SRC_CVID_VALID);
            p_rx_info->src_cvid = 0;
        }

        /*  PTP Timestamp Bits Mapping
            Timestamp               Field Name          BIT Width       BIT Base
            ptpTimestamp[21:0]      ipSa                22(ipSa[21:0])  0
            ptpTimestamp[22]        rxtxFcl0            1               22
            ptpTimestamp[24:23]     rxtxFcl2_1          2               23
            ptpTimestamp[25]        rxtxFcl3            1               25
            ptpTimestamp[41:26]     fid                 16              26
            ptpTimestamp[53:42]     srcCvlanId          12              42
            ptpTimestamp[54]        srcCvlanIdValid     1               54
            ptpTimestamp[60:55]     rxtxFcl22_17        6               55
            ptpTimestamp[61]        srcCtagOffsetType   1               61
        */
        ts_61_0 = ((uint64)(p_raw_hdr->ip_sa & 0x3FFFFF) << 0)
            | ((uint64)(p_raw_hdr->rxtx_fcl0 & 0x0001) << 22)
            | ((uint64)(p_raw_hdr->rxtx_fcl2_1 & 0x0003) << 23)
            | ((uint64)(p_raw_hdr->rxtx_fcl3 & 0x0001) << 25)
            | ((uint64)(p_raw_hdr->fid & 0xFFFF) << 26)
            | ((uint64)(p_raw_hdr->src_cvlan_id & 0x0FFF) << 42)
            | ((uint64)(p_raw_hdr->src_cvlan_id_valid & 0x0001) << 54)
            | ((uint64)(p_raw_hdr->rxtx_fcl22_17 & 0x003F) << 55)
            | ((uint64)(p_raw_hdr->src_ctag_offset_type & 0x0001) << 61);
        _sys_greatbelt_packet_bit62_to_ts(TRUE, ts_61_0, &p_rx_info->ptp.ts);
    }
    else if (CTC_PKT_OPER_C2C == p_rx_info->oper_type)
    {
        sys_chip_device_info_t device_info;
        sal_memset(&device_info, 0, sizeof(sys_chip_device_info_t));
        sys_greatbelt_chip_get_device_info(0, &device_info);

        p_rx_info->reason       = CTC_PKT_CPU_REASON_FWD_CPU;
        if(device_info.version_id >= 2)
        {
            lport = p_raw_hdr->src_vlan_id & 0x7F;
            sys_greatbelt_get_gchip_id(0, &gchip);
            p_rx_info->src_port     = CTC_MAP_LPORT_TO_GPORT(gchip, lport);
        }

        if (CTC_FLAG_ISSET(p_rx_info->flags, CTC_PKT_FLAG_MCAST))
        {
            CTC_UNSET_FLAG(p_rx_info->flags, CTC_PKT_FLAG_MCAST);
            p_rx_info->dest_group_id = 0;
        }


    }

    return CTC_E_NONE;
}

int32
_sys_greatbelt_packet_swap_payload(uint32 len, uint8* p_payload)
{
    uint32 u32_len = len / 4;
    uint32 left_len = len % 4;
    host_type_t byte_order;
    drv_work_platform_type_t platform_type;

    byte_order = drv_get_host_type();
    drv_get_platform_type(&platform_type);

    if ((byte_order == HOST_LE)&&(platform_type == HW_PLATFORM))
    {
        if (left_len)
        {
            u32_len += 1;
        }
        sys_greatbelt_packet_swap32((uint32*)p_payload, u32_len, TRUE);
    }

    return 0;
}

int32
sys_greatbelt_packet_rx(ctc_pkt_rx_t* p_pkt_rx)
{
    CTC_ERROR_RETURN(sys_greatbelt_packet_decap(p_pkt_rx));

    if ((p_pkt_rx->rx_info.reason - CTC_PKT_CPU_REASON_OAM) == CTC_OAM_EXCP_BFD_TIMER_NEGOTIATION)
    {
        if (p_pkt_master->internal_rx_cb)
        {
            p_pkt_master->internal_rx_cb(p_pkt_rx);
        }
    }

    if (p_pkt_master->cfg.rx_cb)
    {
        p_pkt_master->cfg.rx_cb(p_pkt_rx);
    }

    if (p_pkt_rx->rx_info.reason < CTC_PKT_CPU_REASON_MAX_COUNT)
    {
        p_pkt_master->stats.rx[p_pkt_rx->rx_info.reason]++;
    }

    _sys_greatbelt_packet_rx_dump(p_pkt_rx);

    if (p_pkt_master->buf_id  < SYS_PKT_BUF_MAX)
    {
        p_pkt_master->pkt_buf[p_pkt_master->buf_id].pkt_len = p_pkt_rx->pkt_len;

        if (p_pkt_rx->pkt_buf->len <= SYS_PKT_BUF_PKT_LEN)
        {
            sal_memcpy(p_pkt_master->pkt_buf[p_pkt_master->buf_id].pkt_data,
                       p_pkt_rx->pkt_buf->data,
                       p_pkt_rx->pkt_buf->len);
        }

        p_pkt_master->buf_id++;
        if (p_pkt_master->buf_id == SYS_PKT_BUF_MAX)
        {
            p_pkt_master->buf_id = 0;
        }

    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_tx(ctc_pkt_tx_t* p_pkt_tx)
{
    CTC_ERROR_RETURN(sys_greatbelt_packet_encap(p_pkt_tx));

    if (CTC_PKT_MODE_ETH == p_pkt_tx->mode)
    {
        if (p_pkt_master->cfg.socket_tx_cb )
        {
            p_pkt_master->cfg.socket_tx_cb(p_pkt_tx);
        }
        else
        {
            SYS_PKT_DUMP(SYS_GB_PKT_STR "do not support Socket Tx!\n");
            return CTC_E_UNEXPECT;
        }
    }
    else if (CTC_PKT_MODE_DMA == p_pkt_tx->mode)
    {
        {
            /* call ctc DMA TX API */
            sys_greatbelt_dma_pkt_tx(p_pkt_tx);
        }
    }
    else
    {
        return CTC_E_UNEXPECT;
    }

    if (CTC_FLAG_ISSET(p_pkt_tx->tx_info.flags, CTC_PKT_FLAG_MCAST))
    {
         p_pkt_master->stats.mc_tx++;
    }
    else
    {
         p_pkt_master->stats.uc_tx++;
    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_encap(ctc_pkt_tx_t* p_pkt_tx)
{
    ctc_pkt_info_t* p_tx_info = NULL;
    ms_packet_header_t* p_raw_hdr = NULL;
    sys_greatbelt_cpumac_header_t* p_cpumac_hdr = NULL;

    CTC_PTR_VALID_CHECK(p_pkt_tx);
    p_tx_info = &p_pkt_tx->tx_info;

    SYS_PKT_DBG_FUNC();

    if (p_pkt_tx->skb.len > (CTC_PKT_MTU - CTC_PKT_HDR_ROOM))
    {
        return CTC_E_EXCEED_MAX_SIZE;
    }

    /* 1. encode packet header */
    p_raw_hdr = (ms_packet_header_t*)ctc_packet_skb_push(&p_pkt_tx->skb, CTC_PKT_HEADER_LEN);
    CTC_ERROR_RETURN(_sys_greatbelt_packet_txinfo_to_rawhdr(p_tx_info, p_raw_hdr));

    _sys_greatbelt_packet_swap_payload(p_pkt_tx->skb.len-CTC_PKT_HEADER_LEN, p_pkt_tx->skb.data+CTC_PKT_HEADER_LEN);

    if (CTC_PKT_MODE_ETH == p_pkt_tx->mode)
    {
        /* 2. encode CPUMAC Header */
        p_cpumac_hdr = (sys_greatbelt_cpumac_header_t*)ctc_packet_skb_push(&p_pkt_tx->skb, CTC_PKT_CPUMAC_LEN);
        p_cpumac_hdr->macda[0] = p_pkt_master->cpu_mac_sa[0];
        p_cpumac_hdr->macda[1] = p_pkt_master->cpu_mac_sa[1];
        p_cpumac_hdr->macda[2] = p_pkt_master->cpu_mac_sa[2];
        p_cpumac_hdr->macda[3] = p_pkt_master->cpu_mac_sa[3];
        p_cpumac_hdr->macda[4] = p_pkt_master->cpu_mac_sa[4];
        p_cpumac_hdr->macda[5] = p_pkt_master->cpu_mac_sa[5];
        p_cpumac_hdr->macsa[0] = p_pkt_master->cpu_mac_da[0];
        p_cpumac_hdr->macsa[1] = p_pkt_master->cpu_mac_da[1];
        p_cpumac_hdr->macsa[2] = p_pkt_master->cpu_mac_da[2];
        p_cpumac_hdr->macsa[3] = p_pkt_master->cpu_mac_da[3];
        p_cpumac_hdr->macsa[4] = p_pkt_master->cpu_mac_da[4];
        p_cpumac_hdr->macsa[5] = p_pkt_master->cpu_mac_da[5];
        p_cpumac_hdr->vlan_tpid = sal_htons(0x8100);
        p_cpumac_hdr->vlan_vid = sal_htons(0);
        p_cpumac_hdr->type = sal_htons(0x5A5A);
        p_cpumac_hdr->reserved = sal_htons(0);
    }

    /* add stats */
    p_pkt_master->stats.encap++;

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_decap(ctc_pkt_rx_t* p_pkt_rx)
{
    ms_packet_header_t raw_hdr;
    ms_packet_header_t* p_raw_hdr = &raw_hdr;
    uint16 eth_hdr_len = 0;
    uint16 pkt_hdr_len = 0;
    uint16 stk_hdr_len = 0;
    int32 ret = 0;

    CTC_PTR_VALID_CHECK(p_pkt_rx);

    SYS_PKT_DBG_FUNC();
    SYS_PKT_DBG_INFO("len %d, buf_count %d \n", p_pkt_rx->pkt_len,
                     p_pkt_rx->buf_count);

    _sys_greatbelt_packet_swap_payload(p_pkt_rx->pkt_buf->len, p_pkt_rx->pkt_buf->data);

    /* 1. check packet length */
    /* ethernet has 20 Bytes L2 header */
    if (CTC_PKT_MODE_ETH == p_pkt_rx->mode)
    {
        eth_hdr_len = CTC_PKT_CPUMAC_LEN;
    }
    else
    {
        eth_hdr_len = 0;
    }

    pkt_hdr_len = CTC_PKT_HEADER_LEN;

    if (p_pkt_rx->pkt_len < (eth_hdr_len + pkt_hdr_len))
    {
        return DRV_E_WRONG_SIZE;
    }

    if (p_pkt_rx->pkt_buf[0].len < (eth_hdr_len + pkt_hdr_len))
    {
        return DRV_E_WRONG_SIZE;
    }

    p_pkt_rx->eth_hdr_len = eth_hdr_len;
    p_pkt_rx->pkt_hdr_len = pkt_hdr_len;
    /* 2. decode raw header */
    sal_memcpy(p_raw_hdr, p_pkt_rx->pkt_buf[0].data + eth_hdr_len, CTC_PKT_HEADER_LEN);

    /* 3. convert raw header to rx_info */
    CTC_ERROR_RETURN(_sys_greatbelt_packet_rawhdr_to_rxinfo(p_raw_hdr, &p_pkt_rx->rx_info));

    ret = sys_greatbelt_stacking_get_stkhdr_len(p_pkt_rx->rx_info.src_port, p_pkt_rx->rx_info.src_chip, &stk_hdr_len);
    p_pkt_rx->stk_hdr_len = stk_hdr_len;

    /* add stats */
    p_pkt_master->stats.decap++;

    return CTC_E_NONE;
}
int32
sys_greatbelt_packet_dump()
{
    return CTC_E_NONE;
}

/**
 @brief Display packet
*/
int32
sys_greatbelt_packet_stats_dump()
{
    uint16 idx = 0;
    uint32 rx = 0;
    char* p_str_tmp = NULL;
    char str[40] = {0};
    uint32 reason_cnt = 0;

    if (p_pkt_master == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    SYS_PKT_DUMP("Packet Tx Statistics:\n");
    SYS_PKT_DUMP("------------------------------\n");
    SYS_PKT_DUMP("%-20s: %d \n", "Total TX Count", (p_pkt_master->stats.uc_tx+p_pkt_master->stats.mc_tx));

    if ((p_pkt_master->stats.uc_tx) || (p_pkt_master->stats.mc_tx))
    {
        SYS_PKT_DUMP("--%-18s: %d \n", "Uc Count", p_pkt_master->stats.uc_tx);
        SYS_PKT_DUMP("--%-18s: %d \n", "Mc Count", p_pkt_master->stats.mc_tx);
    }

    SYS_PKT_DUMP("\n");

    for (idx  = 0; idx  < CTC_PKT_CPU_REASON_MAX_COUNT; idx ++)
    {
        rx += p_pkt_master->stats.rx[idx];
    }

    SYS_PKT_DUMP("Packet Rx Statistics:\n");
    SYS_PKT_DUMP("------------------------------\n");
    SYS_PKT_DUMP("%-20s: %d \n", "Total RX Count", rx);
    SYS_PKT_DUMP("\n");
    SYS_PKT_DUMP("%-20s\n", "Detail RX Count");

    if (rx)
    {
        for (idx  = 0; idx  < CTC_PKT_CPU_REASON_MAX_COUNT; idx ++)
        {
            reason_cnt = p_pkt_master->stats.rx[idx];

            if (reason_cnt)
            {
                p_str_tmp = sys_greatbelt_reason_2Str(idx);
                sal_sprintf((char*)&str, "%s%s%d%s", p_str_tmp, "(ID:", idx, ")");

                SYS_PKT_DUMP("%-20s: %d \n", (char*)&str, reason_cnt);
            }
        }
    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_stats_clear()
{
    if (p_pkt_master == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    sal_memset(&p_pkt_master->stats, 0, sizeof(sys_pkt_stats_t));

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_set_reason_log(uint16 reason_id, uint8 enable, uint8 is_all, uint8 is_detail)
{
    uint16 index = 0;

    if ((reason_id >= CTC_PKT_CPU_REASON_MAX_COUNT) && !is_all)
    {
        return CTC_E_EXCEED_MAX_SIZE;
    }

    if (enable)
    {
        if (is_all)
        {
            for (index = 0; index < CTC_PKT_CPU_REASON_MAX_COUNT; index++)
            {
                CTC_BMP_SET(p_pkt_master->reason_bm, index);
                p_pkt_master->header_en[index] = is_detail;
            }
        }
        else
        {
            CTC_BMP_SET(p_pkt_master->reason_bm, reason_id);
            p_pkt_master->header_en[reason_id] = is_detail;
        }
    }
    else
    {
        if (is_all)
        {
            for (index = 0; index < CTC_PKT_CPU_REASON_MAX_COUNT; index++)
            {
                CTC_BMP_UNSET(p_pkt_master->reason_bm, index);
                p_pkt_master->header_en[index] = is_detail;
            }
        }
        else
        {
            CTC_BMP_UNSET(p_pkt_master->reason_bm, reason_id);
            p_pkt_master->header_en[reason_id] = is_detail;
        }
    }

    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_buffer_dump(uint8 buf_cnt, uint8 flag)
{
    uint8 buf_id = 0;
    uint8 idx = 0;
    if (p_pkt_master == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    CTC_MAX_VALUE_CHECK(buf_cnt, SYS_PKT_BUF_MAX);

    if (!CTC_IS_BIT_SET(flag, 0))
    {
        CTC_BIT_SET(flag, 0);
        buf_cnt = SYS_PKT_BUF_MAX;
    }

    buf_id = p_pkt_master->buf_id;

    while(buf_cnt)
    {
        buf_id = buf_id? (buf_id - 1):(SYS_PKT_BUF_MAX - 1);
        buf_cnt--;

        if (p_pkt_master->pkt_buf[buf_id].pkt_len)
        {
            uint8 len = 0;
            SYS_PKT_DUMP("Packet No.%d, Pkt len: %d\n", idx++, p_pkt_master->pkt_buf[buf_id].pkt_len);

            if (CTC_IS_BIT_SET(flag, 1))
            {
                ctc_pkt_rx_t pkt_rx;
                ms_packet_header_t raw_hdr;

                sal_memset(&pkt_rx, 0, sizeof(pkt_rx));
                sal_memset(&raw_hdr, 0, sizeof(raw_hdr));
                sal_memcpy(&raw_hdr, p_pkt_master->pkt_buf[buf_id].pkt_data, CTC_PKT_HEADER_LEN);

                /* convert raw header to rx_info */
                CTC_ERROR_RETURN(_sys_greatbelt_packet_rawhdr_to_rxinfo(&raw_hdr, &pkt_rx.rx_info));
                CTC_ERROR_RETURN(_sys_greatbelt_packet_dump_header(&pkt_rx));

                _sys_greatbelt_packet_dump(p_pkt_master->pkt_buf[buf_id].pkt_data, CTC_PKT_HEADER_LEN);
            }

            if (CTC_IS_BIT_SET(flag, 0))
            {
                SYS_PKT_DUMP("-----------------------------------------------\n");
                SYS_PKT_DUMP("Packet Info(Length : %d):\n", (p_pkt_master->pkt_buf[buf_id].pkt_len-CTC_PKT_HEADER_LEN));
                SYS_PKT_DUMP("-----------------------------------------------\n");

                /*print packet*/
                len = (p_pkt_master->pkt_buf[buf_id].pkt_len <= SYS_PKT_BUF_PKT_LEN)?
                (p_pkt_master->pkt_buf[buf_id].pkt_len-CTC_PKT_HEADER_LEN): (SYS_PKT_BUF_PKT_LEN-CTC_PKT_HEADER_LEN);
                CTC_ERROR_RETURN(_sys_greatbelt_packet_dump(p_pkt_master->pkt_buf[buf_id].pkt_data+CTC_PKT_HEADER_LEN, len));
            }
        }

    }

    return CTC_E_NONE;

}

int32
sys_greatbelt_packet_buffer_clear()
{
    if (p_pkt_master == NULL)
    {
        return CTC_E_NOT_INIT;
    }

    sal_memset(&p_pkt_master->pkt_buf, 0, sizeof(p_pkt_master->pkt_buf));
    p_pkt_master->buf_id = 0;

    return CTC_E_NONE;
}
int32
sys_greatbelt_packet_register_internal_rx_cb(CTC_PKT_RX_CALLBACK internal_rx_cb)
{
    if (NULL == p_pkt_master)
    {
        return CTC_E_NOT_INIT;
    }

    p_pkt_master->internal_rx_cb = internal_rx_cb;
    return CTC_E_NONE;
}

int32
sys_greatbelt_packet_init(void* p_global_cfg)
{
    ctc_pkt_global_cfg_t* p_pkt_cfg = (ctc_pkt_global_cfg_t*)p_global_cfg;

    /* 2. allocate interrupt master */
    if (p_pkt_master)
    {
        return CTC_E_NONE;
    }

    p_pkt_master = (sys_pkt_master_t*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(sys_pkt_master_t));
    if (NULL == p_pkt_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_pkt_master, 0, sizeof(sys_pkt_master_t));
    sal_memcpy(&p_pkt_master->cfg, p_pkt_cfg, sizeof(ctc_pkt_global_cfg_t));
    sys_greatbelt_get_chip_cpumac(p_pkt_master->cpu_mac_sa, p_pkt_master->cpu_mac_da);

    return CTC_E_NONE;
}

