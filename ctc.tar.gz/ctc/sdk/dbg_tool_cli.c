#include "sal.h"
#include "drv_lib.h"
#include "ctc_cli.h"
#include "dbg_tool_cli.h"
#include "ctc_tblreg_wr_cli.h"
#include "ctc_drv_cli.h"
#include "ctc_linkread_cli.h"

extern int32 ctc_dbg_tool_init(uint8 cli_tree_mode);

int32
ctc_dbg_tool_cli_init(uint8 cli_tree_mode)
{
    ctc_drv_cli_init(cli_tree_mode);
    ctc_tblreg_wr_cli_init(cli_tree_mode);
    ctc_linkread_cli_init(cli_tree_mode);
    ctc_dbg_tool_init(cli_tree_mode);
    return CLI_SUCCESS;
}

